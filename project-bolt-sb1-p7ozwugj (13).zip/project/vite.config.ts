import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      three: fileURLToPath(new URL('node_modules/three/build/three.module.js', import.meta.url)),
    },
  },
  optimizeDeps: {
    include: ['three', 'lenis/react'],
    exclude: ['lucide-react'],
  },
});
