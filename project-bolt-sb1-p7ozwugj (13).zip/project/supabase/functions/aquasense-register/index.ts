import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const url = new URL(req.url);
    const path = url.pathname.replace("/functions/v1/aquasense-register", "");

    // GET /aquasense-register?device_id=AQUASENSE-01
    // Returns the passport_id currently mapped to this device
    if (req.method === "GET" && path === "") {
      const deviceId = url.searchParams.get("device_id");
      if (!deviceId) {
        return new Response(
          JSON.stringify({ error: "Missing device_id parameter" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const { data, error } = await supabase
        .from("aquasense_device_mappings")
        .select("device_id, passport_id, updated_at")
        .eq("device_id", deviceId)
        .maybeSingle();

      if (error) {
        return new Response(
          JSON.stringify({ error: "Database lookup failed" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      if (!data) {
        return new Response(
          JSON.stringify({ device_id: deviceId, passport_id: null, message: "Device not yet registered to a passport" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify(data),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // POST /aquasense-register
    // Body: { device_id: "AQUASENSE-01", passport_id: "RW-WP-2026-00001" }
    // Registers or updates the device-to-passport mapping
    if (req.method === "POST" && path === "") {
      const body = await req.json();
      const deviceId = body.device_id;
      const passportId = body.passport_id;

      if (!deviceId || !passportId) {
        return new Response(
          JSON.stringify({ error: "Both device_id and passport_id are required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const { data, error } = await supabase
        .from("aquasense_device_mappings")
        .upsert(
          { device_id: deviceId, passport_id: passportId, updated_at: new Date().toISOString() },
          { onConflict: "device_id" },
        )
        .select("device_id, passport_id, updated_at")
        .single();

      if (error) {
        return new Response(
          JSON.stringify({ error: "Failed to register device mapping" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify({ ...data, message: "Device registered to passport successfully" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
