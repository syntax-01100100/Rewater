ALTER TABLE business_subscriptions ADD COLUMN IF NOT EXISTS trial_ends_at timestamp with time zone;
ALTER TABLE business_subscriptions ADD COLUMN IF NOT EXISTS cancelled_at timestamp with time zone;