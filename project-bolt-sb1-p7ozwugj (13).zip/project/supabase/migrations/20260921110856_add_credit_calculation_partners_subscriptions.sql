/*
# Water Credit calculation, partner tracking, business subscriptions, and ReWater revenue

## Summary
This migration adds the full Water Credit calculation system to the existing schema:
- Water Passports now record wastewater input, recovered water, treatment loss, and recovery rate
- Water Credit transactions track treatment partner, verification partner, net benefit, and the 70/20/10 credit split (company / HydroStation fund / ReWater)
- New `business_subscriptions` table for tiered access to ReWater features
- New `rewater_revenue` table to track ReWater's own revenue from service fees and subscriptions
- HydroStation dispensing records now store treatment/verification partners

## Changes to water_passports
- `input_water_litres` (numeric, nullable) — total wastewater input volume
- `recovered_water_litres` (numeric, nullable) — recovered water volume after treatment
- `treatment_loss_litres` (numeric, nullable) — water lost during treatment (input - recovered)
- `recovery_rate` (numeric, nullable) — percentage recovered = recovered / input × 100
- `treatment_partner` (text, nullable) — name of the treatment partner organization
- `verification_partner` (text, nullable) — name of the verification partner
- `net_benefit_aed` (numeric, nullable) — estimated net benefit in AED
- `company_share_aed` (numeric, nullable) — company's 70% share
- `hydrostation_fund_aed` (numeric, nullable) — HydroStation fund's 20% share
- `rewater_share_aed` (numeric, nullable) — ReWater's 10% share
- `credits_generated` (numeric, nullable) — total Water Credits generated from this passport

## Changes to water_credit_transactions
- `treatment_partner` (text, nullable) — treatment partner on this credit record
- `verification_partner` (text, nullable) — verification partner on this credit record
- `net_benefit_aed` (numeric, nullable) — net benefit that generated these credits
- `company_share_pct` (numeric, default 70) — company share percentage
- `hydrostation_fund_pct` (numeric, default 20) — HydroStation fund percentage
- `rewater_share_pct` (numeric, default 10) — ReWater percentage
- `credits_remaining` (numeric, nullable) — remaining credits after this transaction
- `purpose` (text, nullable) — purpose of the credit record

## Changes to hydro_station_dispensing
- `treatment_partner` (text, nullable)
- `verification_partner` (text, nullable)

## New table: business_subscriptions
Tracks which businesses have access to which ReWater features.
- `id` (uuid PK)
- `user_id` (uuid, FK to auth.users, defaults to auth.uid())
- `plan` (text: 'free' | 'essential' | 'professional' | 'enterprise', default 'free')
- `status` (text: 'active' | 'expired' | 'cancelled', default 'active')
- `features` (jsonb) — list of enabled features
- `started_at` (timestamptz)
- `expires_at` (timestamptz, nullable)
- `created_at`, `updated_at`

## New table: rewater_revenue
Tracks ReWater's own revenue from service fees and subscriptions.
- `id` (uuid PK)
- `user_id` (uuid, FK to auth.users)
- `source` (text: 'service_fee' | 'subscription' | 'transaction_fee')
- `amount_aed` (numeric)
- `description` (text)
- `passport_id` (text, nullable) — related passport if applicable
- `created_at`

## Security
- RLS enabled on both new tables with owner-scoped CRUD policies
- All policies use `auth.uid()` with `DEFAULT auth.uid()` on user_id columns
*/

-- ── Water Passports: add credit calculation fields ──────────────
ALTER TABLE water_passports
  ADD COLUMN IF NOT EXISTS input_water_litres numeric,
  ADD COLUMN IF NOT EXISTS recovered_water_litres numeric,
  ADD COLUMN IF NOT EXISTS treatment_loss_litres numeric,
  ADD COLUMN IF NOT EXISTS recovery_rate numeric,
  ADD COLUMN IF NOT EXISTS treatment_partner text,
  ADD COLUMN IF NOT EXISTS verification_partner text,
  ADD COLUMN IF NOT EXISTS net_benefit_aed numeric,
  ADD COLUMN IF NOT EXISTS company_share_aed numeric,
  ADD COLUMN IF NOT EXISTS hydrostation_fund_aed numeric,
  ADD COLUMN IF NOT EXISTS rewater_share_aed numeric,
  ADD COLUMN IF NOT EXISTS credits_generated numeric;

-- ── Water Credit Transactions: add partner and split fields ─────
ALTER TABLE water_credit_transactions
  ADD COLUMN IF NOT EXISTS treatment_partner text,
  ADD COLUMN IF NOT EXISTS verification_partner text,
  ADD COLUMN IF NOT EXISTS net_benefit_aed numeric,
  ADD COLUMN IF NOT EXISTS company_share_pct numeric NOT NULL DEFAULT 70,
  ADD COLUMN IF NOT EXISTS hydrostation_fund_pct numeric NOT NULL DEFAULT 20,
  ADD COLUMN IF NOT EXISTS rewater_share_pct numeric NOT NULL DEFAULT 10,
  ADD COLUMN IF NOT EXISTS credits_remaining numeric,
  ADD COLUMN IF NOT EXISTS purpose text;

-- ── Hydro Station Dispensing: add partner fields ────────────────
ALTER TABLE hydro_station_dispensing
  ADD COLUMN IF NOT EXISTS treatment_partner text,
  ADD COLUMN IF NOT EXISTS verification_partner text;

-- ── Business Subscriptions table ────────────────────────────────
CREATE TABLE IF NOT EXISTS business_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'essential', 'professional', 'enterprise')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'cancelled')),
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  started_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE business_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_subscription" ON business_subscriptions;
CREATE POLICY "select_own_subscription" ON business_subscriptions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_subscription" ON business_subscriptions;
CREATE POLICY "insert_own_subscription" ON business_subscriptions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_subscription" ON business_subscriptions;
CREATE POLICY "update_own_subscription" ON business_subscriptions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_subscription" ON business_subscriptions;
CREATE POLICY "delete_own_subscription" ON business_subscriptions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── ReWater Revenue table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS rewater_revenue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  source text NOT NULL DEFAULT 'service_fee' CHECK (source IN ('service_fee', 'subscription', 'transaction_fee')),
  amount_aed numeric NOT NULL DEFAULT 0,
  description text NOT NULL DEFAULT '',
  passport_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE rewater_revenue ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_revenue" ON rewater_revenue;
CREATE POLICY "select_own_revenue" ON rewater_revenue FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_revenue" ON rewater_revenue;
CREATE POLICY "insert_own_revenue" ON rewater_revenue FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_revenue" ON rewater_revenue;
CREATE POLICY "delete_own_revenue" ON rewater_revenue FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
