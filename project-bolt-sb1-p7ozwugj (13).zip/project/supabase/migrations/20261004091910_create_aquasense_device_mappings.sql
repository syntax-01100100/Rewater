/*
# Create aquasense_device_mappings table

## Purpose
Stores the mapping between an AquaSense ESP32 device (identified by device_id)
and a ReWater Water Passport (identified by passport_id). This lets the ESP32
look up which passport its readings should be linked to, without hardcoding
the passport_id in firmware — the user can change it through the edge function
at any time.

## New Table
- `aquasense_device_mappings`
  - `id` (uuid, primary key)
  - `device_id` (text, unique, not null) — e.g. "AQUASENSE-01"
  - `passport_id` (text, not null) — e.g. "RW-WP-2026-00001"
  - `updated_at` (timestamptz, defaults to now())
  - `created_at` (timestamptz, defaults to now())

## Security
- RLS enabled.
- CRUD allowed for anon + authenticated (the ESP32 uses the anon key to
  register and look up its mapping via the edge function, which uses the
  service role key internally so RLS is bypassed for edge function calls).
  The anon policies are a fallback for direct REST access if needed.

## Important notes
1. The edge function `aquasense-register` uses the service role key, so it
   bypasses RLS. The anon policies exist for direct client access.
2. device_id has a unique constraint, so each device maps to exactly one
   passport at a time. Upserting with the same device_id updates the passport.
*/

CREATE TABLE IF NOT EXISTS aquasense_device_mappings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  passport_id text NOT NULL,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE aquasense_device_mappings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_device_mappings" ON aquasense_device_mappings;
CREATE POLICY "anon_select_device_mappings"
ON aquasense_device_mappings FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_device_mappings" ON aquasense_device_mappings;
CREATE POLICY "anon_insert_device_mappings"
ON aquasense_device_mappings FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_device_mappings" ON aquasense_device_mappings;
CREATE POLICY "anon_update_device_mappings"
ON aquasense_device_mappings FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_device_mappings" ON aquasense_device_mappings;
CREATE POLICY "anon_delete_device_mappings"
ON aquasense_device_mappings FOR DELETE
TO anon, authenticated USING (true);
