ALTER TABLE water_passports
  ADD COLUMN IF NOT EXISTS credit_eligible_litres numeric;
