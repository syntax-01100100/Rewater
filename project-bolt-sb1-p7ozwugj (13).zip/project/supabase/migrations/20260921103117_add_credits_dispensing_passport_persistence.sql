-- Add dispensing cost columns, minimum balance, and credit transaction ledger
-- Also add water_passports table for persistence

-- Extend hydro_stations with dispensing costs and minimum balance
ALTER TABLE hydro_stations
  ADD COLUMN IF NOT EXISTS dispense_cost_250ml numeric NOT NULL DEFAULT 0.25,
  ADD COLUMN IF NOT EXISTS dispense_cost_500ml numeric NOT NULL DEFAULT 0.50,
  ADD COLUMN IF NOT EXISTS dispense_cost_750ml numeric NOT NULL DEFAULT 0.75,
  ADD COLUMN IF NOT EXISTS dispense_cost_1l numeric NOT NULL DEFAULT 1.00,
  ADD COLUMN IF NOT EXISTS minimum_balance numeric NOT NULL DEFAULT 20;

-- Change credit_balance to numeric to support fractional credits
ALTER TABLE hydro_stations ALTER COLUMN credit_balance TYPE numeric USING credit_balance::numeric;

-- Water Credit transaction ledger
CREATE TABLE IF NOT EXISTS water_credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  transaction_type text NOT NULL CHECK (transaction_type IN ('earned', 'donated', 'used', 'assigned')),
  amount numeric NOT NULL DEFAULT 0,
  balance_after numeric NOT NULL DEFAULT 0,
  station_id uuid REFERENCES hydro_stations(id) ON DELETE SET NULL,
  station_name text,
  passport_id text,
  sponsor text,
  initiative text,
  description text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE water_credit_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_credit_tx" ON water_credit_transactions;
CREATE POLICY "select_own_credit_tx" ON water_credit_transactions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_credit_tx" ON water_credit_transactions;
CREATE POLICY "insert_own_credit_tx" ON water_credit_transactions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_credit_tx" ON water_credit_transactions;
CREATE POLICY "update_own_credit_tx" ON water_credit_transactions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_credit_tx" ON water_credit_transactions;
CREATE POLICY "delete_own_credit_tx" ON water_credit_transactions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Dispensing records (replaces/augments hydro_station_visits with credit info)
CREATE TABLE IF NOT EXISTS hydro_station_dispensing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  station_id uuid NOT NULL REFERENCES hydro_stations(id) ON DELETE CASCADE,
  station_name text NOT NULL DEFAULT '',
  amount_ml integer NOT NULL DEFAULT 500,
  credits_used numeric NOT NULL DEFAULT 0,
  sponsor text NOT NULL DEFAULT '',
  initiative text NOT NULL DEFAULT '',
  worker_token text,
  dispensed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hydro_station_dispensing ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_dispensing" ON hydro_station_dispensing;
CREATE POLICY "select_own_dispensing" ON hydro_station_dispensing FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_dispensing" ON hydro_station_dispensing;
CREATE POLICY "insert_own_dispensing" ON hydro_station_dispensing FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_dispensing" ON hydro_station_dispensing;
CREATE POLICY "delete_own_dispensing" ON hydro_station_dispensing FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Water Passports table for persistence
CREATE TABLE IF NOT EXISTS water_passports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  passport_id text UNIQUE NOT NULL,
  source text NOT NULL DEFAULT '',
  source_type text NOT NULL DEFAULT '',
  collection_date timestamptz DEFAULT now(),
  quantity numeric,
  unit text NOT NULL DEFAULT 'L',
  intended_use text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed', 'ongoing', 'awaiting_retest', 'treatment_required')),
  current_stage text NOT NULL DEFAULT 'collected',
  measurements jsonb NOT NULL DEFAULT '[]'::jsonb,
  profile jsonb,
  events jsonb NOT NULL DEFAULT '[]'::jsonb,
  recovery_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  reuse_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  treatment_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  last_updated timestamptz DEFAULT now()
);

ALTER TABLE water_passports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_passports" ON water_passports;
CREATE POLICY "select_own_passports" ON water_passports FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_passports" ON water_passports;
CREATE POLICY "insert_own_passports" ON water_passports FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_passports" ON water_passports;
CREATE POLICY "update_own_passports" ON water_passports FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_passports" ON water_passports;
CREATE POLICY "delete_own_passports" ON water_passports FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
