/*
# Link AquaSense sensor readings to Water Passports

## Purpose
Adds a `passport_id` column to the existing `sensor_readings` table so that
real AquaSense ESP32 readings can be associated with a specific ReWater
Water Passport. This lets the website show a live sensor measurement as part
of a Water Passport's journey, rather than only simulated/demo data.

## Changes
1. New column: `sensor_readings.passport_id` (text, nullable)
   - Nullable because early readings may arrive before a passport is created.
   - No foreign key constraint because `water_passports.passport_id` is a
     text identifier (not a UUID PK), and we don't want to block inserts if
     a passport hasn't been created yet.
2. New index on `(passport_id, is_simulated, timestamp)` for fast lookup of
   the latest real reading per passport.

## Security
- No RLS policy changes. The existing anon + authenticated CRUD policies on
  `sensor_readings` remain unchanged.
- The ESP32 sends readings via the Supabase REST API using the anon key,
  which is already permitted by existing policies.

## Important notes
1. This migration does NOT modify any existing columns or data.
2. Existing simulated/demo readings are unaffected (passport_id will be NULL).
3. The ESP32 firmware should include `passport_id` in its JSON payload. If
   omitted, the reading is still stored but won't be linked to a passport.
*/

ALTER TABLE sensor_readings
  ADD COLUMN IF NOT EXISTS passport_id text;

CREATE INDEX IF NOT EXISTS idx_sensor_readings_passport_simulated_ts
  ON sensor_readings (passport_id, is_simulated, timestamp DESC);
