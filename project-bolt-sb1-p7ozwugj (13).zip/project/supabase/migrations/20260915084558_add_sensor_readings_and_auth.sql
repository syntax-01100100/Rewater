/*
# Add sensor_readings table for future AquaSense hardware integration

1. New Tables
- `sensor_readings` — stores readings from future AquaSense ESP32 devices
  - `id` (uuid, primary key)
  - `device_id` (text, identifies which AquaSense device sent the reading)
  - `sample_id` (text, optional, links to a water_samples record)
  - `timestamp` (timestamptz, when the reading was taken)
  - `ph` (real, pH value 0-14)
  - `tds` (real, total dissolved solids in ppm)
  - `ec` (real, electrical conductivity in µS/cm)
  - `turbidity` (real, turbidity in NTU)
  - `temperature` (real, temperature in °C)
  - `source` (text, water source type)
  - `status` (text, reading status: 'connected', 'disconnected', 'error')
  - `calibration_info` (jsonb, calibration metadata from device)
  - `is_simulated` (boolean, default false — flags demo/simulated data)
  - `created_at` (timestamptz, when the record was created in the database)
  - `user_id` (uuid, nullable, links to auth.users for owner-scoped readings)

2. Security
- Enable RLS on `sensor_readings`.
- Authenticated users can CRUD their own readings (scoped by user_id).
- Anon/authenticated can INSERT device readings (for future ESP32 API integration).
- All users can SELECT readings (for demo/competition display).

3. Notes
- This table is designed to receive data from ESP32 devices via a future API endpoint.
- The `is_simulated` flag ensures simulated data is never confused with real readings.
- `device_id` allows associating readings with a specific physical AquaSense device.
- `timestamp` stores when the measurement was taken, not when it was saved.
*/

CREATE TABLE IF NOT EXISTS sensor_readings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL,
  sample_id text,
  timestamp timestamptz DEFAULT now(),
  ph real,
  tds real,
  ec real,
  turbidity real,
  temperature real,
  source text,
  status text DEFAULT 'disconnected',
  calibration_info jsonb,
  is_simulated boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

ALTER TABLE sensor_readings ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read their own readings
DROP POLICY IF EXISTS "select_own_sensor_readings" ON sensor_readings;
CREATE POLICY "select_own_sensor_readings"
ON sensor_readings FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR user_id IS NULL);

-- Allow authenticated users to insert readings for their own device
DROP POLICY IF EXISTS "insert_own_sensor_readings" ON sensor_readings;
CREATE POLICY "insert_own_sensor_readings"
ON sensor_readings FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Allow anon to insert (for future ESP32 API endpoint with API key auth)
DROP POLICY IF EXISTS "anon_insert_sensor_readings" ON sensor_readings;
CREATE POLICY "anon_insert_sensor_readings"
ON sensor_readings FOR INSERT
TO anon
WITH CHECK (true);

-- Allow anon to read (for demo/competition display without login)
DROP POLICY IF EXISTS "anon_select_sensor_readings" ON sensor_readings;
CREATE POLICY "anon_select_sensor_readings"
ON sensor_readings FOR SELECT
TO anon
USING (true);

-- Allow authenticated users to update their own readings
DROP POLICY IF EXISTS "update_own_sensor_readings" ON sensor_readings;
CREATE POLICY "update_own_sensor_readings"
ON sensor_readings FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Allow authenticated users to delete their own readings
DROP POLICY IF EXISTS "delete_own_sensor_readings" ON sensor_readings;
CREATE POLICY "delete_own_sensor_readings"
ON sensor_readings FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- Index for querying by device
CREATE INDEX IF NOT EXISTS idx_sensor_readings_device_id ON sensor_readings(device_id);
CREATE INDEX IF NOT EXISTS idx_sensor_readings_timestamp ON sensor_readings(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_sensor_readings_user_id ON sensor_readings(user_id);