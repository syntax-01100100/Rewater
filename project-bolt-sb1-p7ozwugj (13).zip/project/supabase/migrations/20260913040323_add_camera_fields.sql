/*
# Add camera analysis fields to water_samples

1. Modified Tables
- `water_samples` — add columns for camera-based visual screening results

2. New Columns
- `cam_colour` text — apparent colour observed by camera
- `cam_cloudiness` text — cloudiness level observed
- `cam_visible_particles` boolean — visible particles detected
- `cam_sediment` boolean — sediment visible
- `cam_foam` boolean — foam observed
- `cam_oil_appearance` boolean — possible oil-like appearance
- `cam_surface_appearance` text — general surface appearance description
- `cam_confidence` text — confidence level of camera analysis
- `intended_use` text — intended reuse purpose

3. Security
- No policy changes — existing anon+authenticated CRUD policies cover new columns.
*/

ALTER TABLE water_samples
  ADD COLUMN IF NOT EXISTS cam_colour text,
  ADD COLUMN IF NOT EXISTS cam_cloudiness text,
  ADD COLUMN IF NOT EXISTS cam_visible_particles boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS cam_sediment boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS cam_foam boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS cam_oil_appearance boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS cam_surface_appearance text,
  ADD COLUMN IF NOT EXISTS cam_confidence text,
  ADD COLUMN IF NOT EXISTS intended_use text DEFAULT 'general';

ALTER TABLE water_samples
  ADD COLUMN IF NOT EXISTS before_sample_id uuid;

-- Treatment comparison columns for retest functionality
ALTER TABLE treatment_records
  ADD COLUMN IF NOT EXISTS before_sample_id uuid,
  ADD COLUMN IF NOT EXISTS after_sample_id uuid;
