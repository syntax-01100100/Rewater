/*
# ReWater Platform — Core Schema

1. New Tables
- `water_sources` — catalog of water sources (groundwater, surface, rain, wastewater, etc.) with location, type, quality info
- `water_samples` — user-created water sample records with measured parameters (pH, temp, turbidity, TDS, EC) and AI interpretation
- `water_brands` — bottled water brand database with published mineral composition
- `alerts` — prevention/early-warning alerts triggered by trend changes
- `scenarios` — water circularity simulator scenarios (home, school, hotel, farm, etc.)
- `impact_records` — impact dashboard data: water recovered, freshwater avoided, resources recovered
- `treatment_records` — before/after treatment comparison data linked to samples

2. Security
- Single-tenant app (no sign-in). RLS enabled on all tables with anon+authenticated CRUD.
- All data is intentionally shared/public across the app.

3. Important Notes
- No user_id columns or auth references — this is a no-auth app.
- All policies use TO anon, authenticated with USING (true) / WITH CHECK (true) because data is shared.
- UUIDs for all primary keys.
- Timestamps on all tables for tracking and trending.
*/

-- Water sources catalog
CREATE TABLE IF NOT EXISTS water_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL DEFAULT 'groundwater',
  latitude float8 NOT NULL DEFAULT 0,
  longitude float8 NOT NULL DEFAULT 0,
  quality text,
  ph float8,
  turbidity float8,
  tds float8,
  temperature float8,
  status text DEFAULT 'available',
  description text,
  is_hidden_water boolean DEFAULT false,
  recovery_potential text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE water_sources ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_water_sources" ON water_sources;
CREATE POLICY "anon_select_water_sources" ON water_sources FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_water_sources" ON water_sources;
CREATE POLICY "anon_insert_water_sources" ON water_sources FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_water_sources" ON water_sources;
CREATE POLICY "anon_update_water_sources" ON water_sources FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_water_sources" ON water_sources;
CREATE POLICY "anon_delete_water_sources" ON water_sources FOR DELETE TO anon, authenticated USING (true);

-- Water samples (from AquaSense / AquaCard)
CREATE TABLE IF NOT EXISTS water_samples (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_name text NOT NULL DEFAULT 'Unknown',
  source_type text DEFAULT 'tap',
  ph float8,
  temperature float8,
  turbidity float8,
  tds float8,
  ec float8,
  nitrate float8,
  nitrite float8,
  hardness float8,
  chlorine float8,
  notes text,
  ai_interpretation jsonb,
  status text DEFAULT 'completed',
  card_type text,
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE water_samples ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_water_samples" ON water_samples;
CREATE POLICY "anon_select_water_samples" ON water_samples FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_water_samples" ON water_samples;
CREATE POLICY "anon_insert_water_samples" ON water_samples FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_water_samples" ON water_samples;
CREATE POLICY "anon_update_water_samples" ON water_samples FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_water_samples" ON water_samples;
CREATE POLICY "anon_delete_water_samples" ON water_samples FOR DELETE TO anon, authenticated USING (true);

-- Water brands database
CREATE TABLE IF NOT EXISTS water_brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  brand text NOT NULL,
  source text,
  ph float8,
  calcium float8,
  magnesium float8,
  sodium float8,
  potassium float8,
  bicarbonate float8,
  sulfate float8,
  chloride float8,
  nitrate float8,
  tds float8,
  fluorine float8,
  country text,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE water_brands ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_water_brands" ON water_brands;
CREATE POLICY "anon_select_water_brands" ON water_brands FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_water_brands" ON water_brands;
CREATE POLICY "anon_insert_water_brands" ON water_brands FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_water_brands" ON water_brands;
CREATE POLICY "anon_update_water_brands" ON water_brands FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_water_brands" ON water_brands;
CREATE POLICY "anon_delete_water_brands" ON water_brands FOR DELETE TO anon, authenticated USING (true);

-- Alerts (prevention / early warning)
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sample_id uuid REFERENCES water_samples(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'warning',
  parameter text NOT NULL,
  message text NOT NULL,
  severity text DEFAULT 'medium',
  acknowledged boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_alerts" ON alerts;
CREATE POLICY "anon_select_alerts" ON alerts FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_alerts" ON alerts;
CREATE POLICY "anon_insert_alerts" ON alerts FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_alerts" ON alerts;
CREATE POLICY "anon_update_alerts" ON alerts FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_alerts" ON alerts;
CREATE POLICY "anon_delete_alerts" ON alerts FOR DELETE TO anon, authenticated USING (true);

-- Circularity scenarios
CREATE TABLE IF NOT EXISTS scenarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL DEFAULT 'home',
  water_demand float8 DEFAULT 0,
  rainfall float8 DEFAULT 0,
  catchment_area float8 DEFAULT 0,
  ac_condensate float8 DEFAULT 0,
  wastewater float8 DEFAULT 0,
  greywater float8 DEFAULT 0,
  renewable_energy float8 DEFAULT 0,
  recovered_water float8 DEFAULT 0,
  freshwater_avoided float8 DEFAULT 0,
  circularity_score float8 DEFAULT 0,
  sdg_contribution jsonb,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE scenarios ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_scenarios" ON scenarios;
CREATE POLICY "anon_select_scenarios" ON scenarios FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_scenarios" ON scenarios;
CREATE POLICY "anon_insert_scenarios" ON scenarios FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_scenarios" ON scenarios;
CREATE POLICY "anon_update_scenarios" ON scenarios FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_scenarios" ON scenarios;
CREATE POLICY "anon_delete_scenarios" ON scenarios FOR DELETE TO anon, authenticated USING (true);

-- Impact records
CREATE TABLE IF NOT EXISTS impact_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  water_recovered float8 DEFAULT 0,
  freshwater_avoided float8 DEFAULT 0,
  resources_recovered float8 DEFAULT 0,
  samples_monitored int DEFAULT 0,
  contamination_trends int DEFAULT 0,
  by_products_identified int DEFAULT 0,
  brine_recovery float8 DEFAULT 0,
  ac_condensate_recovered float8 DEFAULT 0,
  rainwater_captured float8 DEFAULT 0,
  energy_used float8 DEFAULT 0,
  sdg jsonb,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE impact_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_impact_records" ON impact_records;
CREATE POLICY "anon_select_impact_records" ON impact_records FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_impact_records" ON impact_records;
CREATE POLICY "anon_insert_impact_records" ON impact_records FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_impact_records" ON impact_records;
CREATE POLICY "anon_update_impact_records" ON impact_records FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_impact_records" ON impact_records;
CREATE POLICY "anon_delete_impact_records" ON impact_records FOR DELETE TO anon, authenticated USING (true);

-- Treatment records (before/after comparison)
CREATE TABLE IF NOT EXISTS treatment_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sample_id uuid REFERENCES water_samples(id) ON DELETE CASCADE,
  pathway text NOT NULL DEFAULT 'standard',
  before_ph float8,
  after_ph float8,
  before_turbidity float8,
  after_turbidity float8,
  before_tds float8,
  after_tds float8,
  water_recovered float8,
  by_products text,
  energy_required float8,
  status text DEFAULT 'planned',
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE treatment_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_treatment_records" ON treatment_records;
CREATE POLICY "anon_select_treatment_records" ON treatment_records FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_treatment_records" ON treatment_records;
CREATE POLICY "anon_insert_treatment_records" ON treatment_records FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_treatment_records" ON treatment_records;
CREATE POLICY "anon_update_treatment_records" ON treatment_records FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_treatment_records" ON treatment_records;
CREATE POLICY "anon_delete_treatment_records" ON treatment_records FOR DELETE TO anon, authenticated USING (true);
