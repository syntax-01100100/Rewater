/*
# Create HydroStations and Worker Access tables

## Purpose
Adds the HydroStation concept to ReWater. HydroStations are participating drinking-water
stations that provide separately verified safe drinking water to eligible workers. Water
Credits from recovered water can sponsor HydroStations. The station's own drinking-water
supply is independent from the recovered water — recovered water does NOT become drinking
water automatically.

## New Tables

### hydro_stations
- `id` (uuid, PK)
- `user_id` (uuid, owner = the business sponsoring the station, defaults to auth.uid())
- `station_id` (text, unique human-readable ID e.g. "HS-001")
- `name` (text, station name)
- `location` (text, station location description)
- `latitude` (numeric, optional)
- `longitude` (numeric, optional)
- `water_status` (text: 'available' | 'limited' | 'offline')
- `safe_water_supply` (text, description of the verified drinking-water source)
- `supported_initiative` (text, the program name)
- `sponsor_company` (text, sponsoring company name)
- `credit_balance` (integer, available Water Credits allocated to this station)
- `total_litres_dispensed` (integer, cumulative litres dispensed)
- `total_worker_visits` (integer, cumulative verified worker visits)
- `program_hydration_rate` (numeric, L per worker per day as defined by the program)
- `created_at` (timestamptz)

### hydro_station_visits
- `id` (uuid, PK)
- `station_id` (uuid, FK to hydro_stations)
- `user_id` (uuid, owner of the station, defaults to auth.uid())
- `worker_token` (text, anonymous demo token — NOT a real Emirates ID)
- `litres_dispensed` (numeric, litres given to the worker)
- `visit_date` (timestamptz)
- `created_at` (timestamptz)

## Security
- Both tables have RLS enabled.
- Owner-scoped CRUD via auth.uid() = user_id.
- Only the station owner can create/update/delete stations and log visits.
*/

CREATE TABLE IF NOT EXISTS hydro_stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  station_id text UNIQUE NOT NULL,
  name text NOT NULL,
  location text NOT NULL,
  latitude numeric,
  longitude numeric,
  water_status text NOT NULL DEFAULT 'available',
  safe_water_supply text NOT NULL DEFAULT 'Municipal verified supply',
  supported_initiative text NOT NULL DEFAULT 'Worker Hydration Program',
  sponsor_company text NOT NULL DEFAULT '',
  credit_balance integer NOT NULL DEFAULT 0,
  total_litres_dispensed integer NOT NULL DEFAULT 0,
  total_worker_visits integer NOT NULL DEFAULT 0,
  program_hydration_rate numeric NOT NULL DEFAULT 3.5,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hydro_stations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_stations" ON hydro_stations;
CREATE POLICY "select_own_stations" ON hydro_stations FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_stations" ON hydro_stations;
CREATE POLICY "insert_own_stations" ON hydro_stations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_stations" ON hydro_stations;
CREATE POLICY "update_own_stations" ON hydro_stations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_stations" ON hydro_stations;
CREATE POLICY "delete_own_stations" ON hydro_stations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS hydro_station_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  station_id uuid NOT NULL REFERENCES hydro_stations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  worker_token text NOT NULL,
  litres_dispensed numeric NOT NULL DEFAULT 0,
  visit_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hydro_station_visits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_visits" ON hydro_station_visits;
CREATE POLICY "select_own_visits" ON hydro_station_visits FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_visits" ON hydro_station_visits;
CREATE POLICY "insert_own_visits" ON hydro_station_visits FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_visits" ON hydro_station_visits;
CREATE POLICY "update_own_visits" ON hydro_station_visits FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_visits" ON hydro_station_visits;
CREATE POLICY "delete_own_visits" ON hydro_station_visits FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
