import { Droplets, LogIn, UserPlus, Sparkles, X } from 'lucide-react';
import { useAuthGuard } from '@/lib/authGuard';
import { useAuth } from '@/lib/auth';

export function AuthGuardModal() {
  const { showGuard, pendingFeature, dismiss, triggerAuth, authedCallback } = useAuthGuard();
  const { signInDemo } = useAuth();

  if (!showGuard) return null;

  const handleDemo = async () => {
    await signInDemo();
    dismiss();
    if (authedCallback) authedCallback();
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ocean-950/50 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md animate-fade-slide">
        <div className="card p-8 text-center">
          <button
            onClick={dismiss}
            className="absolute top-4 right-4 text-slatey/40 hover:text-slatey transition-colors"
            aria-label="Close"
          >
            <X size={20} />
          </button>

          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-aqua-100 to-teal-100 flex items-center justify-center mx-auto mb-5">
            <Droplets size={32} className="text-aqua-600" />
          </div>

          <h2 className="font-display font-bold text-xl text-slatey mb-2">
            Your water journey starts here.
          </h2>
          <p className="text-sm text-slatey/60 mb-1">
            Sign in or create a free account to use
          </p>
          <p className="text-sm font-semibold text-aqua-600 mb-6">
            {pendingFeature}
          </p>

          <div className="space-y-3">
            <button
              onClick={() => triggerAuth('signin')}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-ocean-600 text-white font-medium hover:bg-ocean-700 transition-all"
            >
              <LogIn size={16} /> Sign In
            </button>
            <button
              onClick={() => triggerAuth('signup')}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-white border border-ocean-200 text-ocean-600 font-medium hover:bg-aqua-50 transition-all"
            >
              <UserPlus size={16} /> Sign Up
            </button>
            <button
              onClick={handleDemo}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-aqua-400 to-teal-400 text-white font-medium hover:shadow-float transition-all"
            >
              <Sparkles size={16} /> Try Demo Account
            </button>
          </div>

          <p className="text-xs text-slatey/40 mt-5">
            The demo account lets you explore all features with pre-populated sample data.
          </p>
        </div>
      </div>
    </div>
  );
}
