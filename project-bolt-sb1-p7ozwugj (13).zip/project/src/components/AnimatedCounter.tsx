import { useCountUp, useInView } from '@/hooks/useAnimations';
import { formatNumber } from '@/lib/utils';

interface AnimatedCounterProps {
  target: number;
  label?: string;
  unit?: string;
  className?: string;
  icon?: React.ReactNode;
}

export function AnimatedCounter({ target, label, unit = '', className = '', icon }: AnimatedCounterProps) {
  const [ref, inView] = useInView<HTMLDivElement>();
  const value = useCountUp(target, 1800, inView);

  return (
    <div ref={ref} className={`text-center ${className}`}>
      {icon && <div className="flex justify-center mb-3">{icon}</div>}
      <div className="font-display font-bold text-3xl sm:text-4xl text-ocean-600 tabular-nums">
        {formatNumber(value)}
        <span className="text-lg text-aqua-400 ml-1">{unit}</span>
      </div>
      {label && <div className="text-sm text-slatey/70 mt-1">{label}</div>}
    </div>
  );
}
