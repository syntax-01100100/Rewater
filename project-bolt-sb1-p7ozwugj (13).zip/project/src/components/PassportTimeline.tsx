import { Droplets, MapPin, Beaker, Cpu, FlaskConical, RefreshCw, CheckCircle, AlertCircle, Recycle, ArrowRight } from 'lucide-react';
import type { PassportEvent, PassportStage, WaterPassport } from '@/lib/waterPassport';
import { stageLabel, stageOrder, statusColor } from '@/lib/waterPassport';

function stageIcon(stage: PassportStage) {
  switch (stage) {
    case 'collected': return <Droplets size={14} />;
    case 'identified': return <MapPin size={14} />;
    case 'profiled': return <Beaker size={14} />;
    case 'analyzed': return <Cpu size={14} />;
    case 'pathway_identified': return <ArrowRight size={14} />;
    case 'treated': return <FlaskConical size={14} />;
    case 'retest_required': return <RefreshCw size={14} />;
    case 'verified': return <CheckCircle size={14} />;
    case 'not_verified': return <AlertCircle size={14} />;
    case 'reuse_pathway': return <Recycle size={14} />;
    default: return <Droplets size={14} />;
  }
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function PassportTimeline({ events }: { events: PassportEvent[] }) {
  if (events.length === 0) {
    return <p className="text-sm text-slatey/50 text-center py-4">No events recorded yet.</p>;
  }

  return (
    <div className="relative pl-6">
      <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-aqua-100" />
      <div className="space-y-4">
        {events.map((event, i) => (
          <div key={i} className="relative">
            <div className="absolute -left-[18px] top-0.5 w-4 h-4 rounded-full bg-aqua-400 border-2 border-white flex items-center justify-center text-white">
              {stageIcon(event.stage)}
            </div>
            <div className="ml-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-slatey">{event.label}</span>
                <span className="text-xs text-slatey/40">{formatTime(event.timestamp)}</span>
              </div>
              <p className="text-xs text-slatey/60 mt-0.5">{event.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PassportCard({ passport, onClick, compact }: {
  passport: WaterPassport;
  onClick?: () => void;
  compact?: boolean;
}) {
  const stageNum = stageOrder(passport.currentStage);
  const sc = statusColor;

  return (
    <div
      onClick={onClick}
      className={`card p-5 ${onClick ? 'cursor-pointer hover:shadow-float transition-all' : ''}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-aqua-50 text-aqua-600 flex items-center justify-center">
            <Droplets size={18} />
          </div>
          <div>
            <h3 className="font-display font-bold text-sm text-slatey">{passport.waterId}</h3>
            <p className="text-xs text-slatey/50">{passport.source}</p>
          </div>
        </div>
        <div className="text-right">
          <span className={`text-xs font-medium text-${sc(passport.measurements[0]?.status ?? 'SIMULATED')}-600`}>
            {stageLabel(passport.currentStage)}
          </span>
          <p className="text-xs text-slatey/40 mt-0.5">{formatDate(passport.collectionDate)}</p>
        </div>
      </div>

      {!compact && (
        <>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs text-slatey/50">Stage {stageNum + 1}/10</span>
            <div className="flex-1 h-1.5 bg-softgrey rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-aqua-300 to-teal-400 rounded-full transition-all duration-500"
                style={{ width: `${((stageNum + 1) / 10) * 100}%` }}
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 mb-3">
            {passport.measurements.slice(0, 5).map((m, i) => (
              <span key={i} className="text-xs px-2 py-0.5 rounded-full bg-mist text-slatey/70">
                {m.name}: {m.value}{m.unit}
              </span>
            ))}
            {passport.measurements.length > 5 && (
              <span className="text-xs px-2 py-0.5 text-slatey/40">+{passport.measurements.length - 5} more</span>
            )}
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slatey/50">{passport.events.length} events</span>
            {passport.isDemo && (
              <span className="text-amber-600 font-medium">DEMO</span>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export function PassportList({ passports, onSelect }: {
  passports: WaterPassport[];
  onSelect?: (id: string) => void;
  selectedId?: string | null;
}) {
  if (passports.length === 0) {
    return (
      <div className="card p-8 text-center">
        <Droplets size={32} className="mx-auto mb-3 text-aqua-200" />
        <p className="text-sm text-slatey/60">No Water Passports yet.</p>
        <p className="text-xs text-slatey/40 mt-1">Create one by checking a water sample.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {passports.map((p) => (
        <PassportCard
          key={p.waterId}
          passport={p}
          compact
          onClick={() => onSelect?.(p.waterId)}
        />
      ))}
    </div>
  );
}
