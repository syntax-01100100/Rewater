interface WaterFlowBgProps {
  className?: string;
  variant?: 'hero' | 'subtle' | 'ocean' | 'sky';
  density?: 'low' | 'medium' | 'high';
}

export function WaterFlowBg({ className = '', variant = 'hero', density = 'medium' }: WaterFlowBgProps) {
  const waveCount = density === 'high' ? 5 : density === 'low' ? 2 : 3;
  const bubbleCount = density === 'high' ? 15 : density === 'low' ? 5 : 10;

  const bgClass =
    variant === 'hero' ? 'bg-gradient-hero'
    : variant === 'ocean' ? 'bg-gradient-ocean'
    : variant === 'sky' ? 'bg-gradient-to-b from-aqua-100 via-mist to-white'
    : 'bg-gradient-mist';

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${bgClass} ${className}`}>
      {/* Flowing wave SVGs */}
      <svg className="absolute bottom-0 left-0 w-full" viewBox="0 0 1440 320" preserveAspectRatio="none" style={{ height: '40%' }}>
        {[...Array(waveCount)].map((_, i) => (
          <path
            key={i}
            d={`M0,${80 + i * 30} C320,${120 + i * 30} 640,${40 + i * 30} 960,${80 + i * 30} C1280,${120 + i * 30} 1440,${60 + i * 30} 1440,${60 + i * 30} L1440,320 L0,320 Z`}
            fill={variant === 'hero' || variant === 'ocean'
              ? `rgba(255,255,255,${0.05 + i * 0.03})`
              : `rgba(31,167,200,${0.03 + i * 0.02})`}
            className="animate-wave"
            style={{ animationDelay: `${i * 0.8}s`, animationDuration: `${4 + i}s` }}
          />
        ))}
      </svg>

      {/* Floating bubbles */}
      {[...Array(bubbleCount)].map((_, i) => {
        const size = 8 + Math.random() * 30;
        const left = Math.random() * 100;
        const delay = Math.random() * 6;
        const duration = 6 + Math.random() * 6;
        return (
          <div
            key={`bubble-${i}`}
            className="absolute rounded-full"
            style={{
              width: size,
              height: size,
              left: `${left}%`,
              bottom: '-5%',
              background: variant === 'hero' || variant === 'ocean'
                ? 'rgba(255,255,255,0.08)'
                : 'rgba(31,167,200,0.1)',
              animation: `float ${duration}s ease-in-out ${delay}s infinite`,
            }}
          />
        );
      })}

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/20 via-transparent to-transparent" />
    </div>
  );
}
