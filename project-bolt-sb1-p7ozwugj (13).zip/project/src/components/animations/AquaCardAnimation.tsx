import { useState, useEffect, useRef } from 'react';

export function AquaCardAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const cycleDur = 10;
  const t = (tick * 0.012) % cycleDur;
  const phase = t / cycleDur;

  // Phases: 0-0.15 strip approaches, 0.15-0.35 strip dips & color develops, 0.35-0.55 camera moves in, 0.55-0.75 scanning, 0.75-1.0 result
  const stripY = phase < 0.15 ? 80 + (1 - phase / 0.15) * 60 : phase > 0.3 ? 80 + Math.min((phase - 0.3) / 0.05, 1) * 60 : 140;
  const colorProgress = phase < 0.15 ? 0 : phase < 0.35 ? (phase - 0.15) / 0.2 : 1;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 280" className="w-full">
        <defs>
          <linearGradient id="acWater" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#7FD3E6" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.3" />
          </linearGradient>
          <filter id="acGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Water sample cup */}
        <g>
          <path d="M 130 150 L 130 210 Q 130 218 138 218 L 192 218 Q 200 218 200 210 L 200 150"
            fill="none" stroke="#18323D" strokeWidth="2.5" strokeLinejoin="round" />
          <line x1="125" y1="150" x2="205" y2="150" stroke="#18323D" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 132 170 L 198 170 L 198 210 Q 198 216 192 216 L 138 216 Q 132 216 132 210 Z" fill="url(#acWater)" />
          <ellipse cx="165" cy="170" rx="32" ry="2.5" fill="#7FD3E6" opacity="0.4">
            <animate attributeName="rx" values="28;34;28" dur="3s" repeatCount="indefinite" />
          </ellipse>
        </g>

        {/* Test strip entering water */}
        <g>
          <rect x="155" y={stripY} width="20" height="70" rx="2" fill="white" stroke="#18323D" strokeWidth="1.5" />
          {/* Pads on strip */}
          {['#F2B84B', '#48B7A5', '#D95C5C', '#1FA7C8'].map((baseColor, i) => {
            const padY = stripY + 10 + i * 15;
            const inWater = padY > 170 && padY < 210;
            const colorIntensity = inWater ? Math.min(colorProgress, 1) : 0;
            if (colorIntensity > 0) {
              return (
                <rect
                  key={i}
                  x="157" y={padY}
                  width="16" height="10" rx="1"
                  fill={baseColor}
                  opacity={colorIntensity * 0.8}
                >
                  <animate attributeName="opacity" values={`${colorIntensity * 0.5};${colorIntensity * 0.9};${colorIntensity * 0.5}`} dur="1.5s" repeatCount="indefinite" />
                </rect>
              );
            }
            return <rect key={i} x="157" y={padY} width="16" height="10" rx="1" fill="#E8E8E8" />;
          })}
        </g>

        {/* Phone camera moving in */}
        {phase >= 0.35 && (
          <g transform={`translate(${280 + Math.min((phase - 0.35) / 0.2, 1) * 20},${80 + Math.sin(t * 2) * 3})`}>
            <rect x="-25" y="-35" width="50" height="80" rx="8" fill="#18323D" />
            <rect x="-20" y="-28" width="40" height="60" rx="3" fill="#0a1a2a" />
            {/* Camera lens */}
            <circle cx="0" cy="0" r="10" fill="#1a2a3a" stroke="#48B7A5" strokeWidth="1.5" />
            <circle cx="0" cy="0" r="6" fill="#0E7A93" opacity="0.5" />
            <circle cx="0" cy="0" r="3" fill="#48B7A5">
              {phase >= 0.55 && phase < 0.75 && (
                <animate attributeName="opacity" values="0.5;1;0.5" dur="0.5s" repeatCount="indefinite" />
              )}
            </circle>
            {/* Scan beam */}
            {phase >= 0.55 && phase < 0.75 && (
              <g>
                <line x1="-15" y1="-20" x2="15" y2="-20" stroke="#48B7A5" strokeWidth="1" opacity="0.5">
                  <animate attributeName="y1" values="-20;20;-20" dur="1.5s" repeatCount="indefinite" />
                  <animate attributeName="y2" values="-20;20;-20" dur="1.5s" repeatCount="indefinite" />
                </line>
              </g>
            )}
          </g>
        )}

        {/* Scanning connection line */}
        {phase >= 0.55 && phase < 0.75 && (
          <line x1="175" y1="140" x2="280" y2="80" stroke="#48B7A5" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.4">
            <animate attributeName="stroke-dashoffset" from="0" to="-12" dur="0.5s" repeatCount="indefinite" />
          </line>
        )}

        {/* Reference color scale */}
        {phase >= 0.6 && (
          <g transform="translate(380, 120)" opacity={Math.min((phase - 0.6) / 0.1, 1)}>
            <rect x="0" y="0" width="12" height="80" rx="2" fill="white" stroke="#18323D" strokeWidth="1" />
            {['#E8D080', '#F2B84B', '#D4A020', '#48B7A5', '#1FA7C8'].map((c, i) => (
              <rect key={i} x="1" y={2 + i * 16} width="10" height="14" rx="1" fill={c} opacity="0.7" />
            ))}
            <text x="20" y="45" fontSize="6" fill="#18323D" fontWeight="600">Reference</text>
          </g>
        )}

        {/* Result display */}
        {phase >= 0.75 && (
          <g transform="translate(250, 200)" opacity={Math.min((phase - 0.75) / 0.1, 1)}>
            <rect x="-60" y="-20" width="120" height="40" rx="8" fill="white" stroke="#48B7A5" strokeWidth="2" filter="url(#acGlow)" />
            <text x="0" y="-5" textAnchor="middle" fontSize="8" fill="#48B7A5" fontWeight="700">Estimated Value</text>
            <text x="0" y="8" textAnchor="middle" fontSize="7" fill="#18323D" opacity="0.6">NO3: ~25 mg/L</text>
            <text x="0" y="16" textAnchor="middle" fontSize="5" fill="#F2B84B">Observed · Not lab-confirmed</text>
          </g>
        )}

        <text x="250" y="265" textAnchor="middle" fontSize="10" fill="#18323D" fontWeight="600" opacity="0.6">
          AquaCard: dip → color change → scan → estimated result
        </text>
      </svg>
    </div>
  );
}
