import { useState, useEffect, useRef } from 'react';

export function ResourceRecoveryAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.012;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 280" className="w-full">
        <defs>
          <linearGradient id="rrInput" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#7FD3E6" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.4" />
          </linearGradient>
          <filter id="rrGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Input stream pipe */}
        <g>
          <rect x="0" y="120" width="120" height="20" fill="#18323D" opacity="0.1" rx="3" />
          <rect x="0" y="123" width="120" height="14" fill="url(#rrInput)" rx="2" />
          {/* Flowing dashes */}
          <line x1="0" y1="130" x2="120" y2="130" stroke="#48B7A5" strokeWidth="2" strokeDasharray="6 4" opacity="0.5">
            <animate attributeName="stroke-dashoffset" from="0" to="-20" dur="1s" repeatCount="indefinite" />
          </line>
        </g>

        {/* Separation chamber */}
        <g transform="translate(120, 80)">
          <path d="M 0 60 L 0 40 Q 0 20 30 20 L 90 20 Q 120 20 120 40 L 120 60" fill="none" stroke="#18323D" strokeWidth="2.5" />
          {/* Internal dividing funnel */}
          <path d="M 10 50 L 60 80 L 110 50" fill="url(#rrInput)" opacity="0.2" />
          {/* Separation animation — particles diverging */}
          {[0, 1, 2, 3, 4, 5, 6, 7].map(i => {
            const p = ((t * 0.5 + i * 0.15) % 1);
            const startY = 50;
            const goUp = i % 3 === 0;
            const goMid = i % 3 === 1;
            const targetY = goUp ? 20 : goMid ? 80 : 50;
            const x = 10 + p * 100;
            const y = startY + (targetY - startY) * p;
            const colors = ['#7FD3E6', '#F2B84B', '#48B7A5'];
            return (
              <circle
                key={i}
                cx={x} cy={y}
                r={3 + (i % 2)}
                fill={colors[i % 3]}
                opacity={(1 - p) * 0.7}
              />
            );
          })}
        </g>

        {/* Three output paths */}
        {/* Water recovery (top) */}
        <g>
          <path d="M 240 100 L 350 70 L 450 70" fill="none" stroke="#1FA7C8" strokeWidth="12" opacity="0.1" strokeLinecap="round" />
          <path d="M 240 100 L 350 70 L 450 70" fill="none" stroke="#1FA7C8" strokeWidth="8" opacity="0.3" strokeLinecap="round" strokeDasharray="8 4">
            <animate attributeName="stroke-dashoffset" from="0" to="-24" dur="1.5s" repeatCount="indefinite" />
          </path>
          {/* Water droplets traveling */}
          {[0, 1, 2].map(i => {
            const p = ((t * 0.3 + i * 0.2) % 1);
            const x = 240 + p * 210;
            const y = 100 + (70 - 100) * Math.min(p * 1.5, 1);
            return <circle key={i} cx={x} cy={y} r="4" fill="#7FD3E6" opacity={(1 - p * 0.5) * 0.8} filter="url(#rrGlow)" />;
          })}
          {/* Output label */}
          <g transform="translate(450, 70)">
            <rect x="-5" y="-18" width="50" height="36" rx="6" fill="white" stroke="#1FA7C8" strokeWidth="1.5" />
            <path d="M 20 -8 Q 14 -2 20 4 Q 26 -2 20 -8 Z" fill="#1FA7C8" />
            <text x="20" y="12" textAnchor="middle" fontSize="6" fill="#0E7A93" fontWeight="600">Water</text>
          </g>
        </g>

        {/* Salts/minerals (middle) */}
        <g>
          <line x1="240" y1="140" x2="450" y2="140" stroke="#F2B84B" strokeWidth="12" opacity="0.1" strokeLinecap="round" />
          <line x1="240" y1="140" x2="450" y2="140" stroke="#F2B84B" strokeWidth="8" opacity="0.3" strokeLinecap="round" strokeDasharray="6 4">
            <animate attributeName="stroke-dashoffset" from="0" to="-20" dur="2s" repeatCount="indefinite" />
          </line>
          {[0, 1, 2].map(i => {
            const p = ((t * 0.25 + i * 0.25) % 1);
            const x = 240 + p * 210;
            return (
              <g key={i}>
                <rect x={x - 3} y="137" width="6" height="6" rx="1" fill="#F2B84B" opacity={(1 - p * 0.5) * 0.7} transform={`rotate(45 ${x} 140)`} />
              </g>
            );
          })}
          <g transform="translate(450, 140)">
            <rect x="-5" y="-18" width="50" height="36" rx="6" fill="white" stroke="#F2B84B" strokeWidth="1.5" />
            <rect x="14" y="-10" width="12" height="12" rx="2" fill="#F2B84B" opacity="0.5" />
            <text x="20" y="12" textAnchor="middle" fontSize="6" fill="#C99420" fontWeight="600">Salts</text>
          </g>
        </g>

        {/* Nutrients (bottom) */}
        <g>
          <path d="M 240 180 L 350 210 L 450 210" fill="none" stroke="#48B7A5" strokeWidth="12" opacity="0.1" strokeLinecap="round" />
          <path d="M 240 180 L 350 210 L 450 210" fill="none" stroke="#48B7A5" strokeWidth="8" opacity="0.3" strokeLinecap="round" strokeDasharray="7 4">
            <animate attributeName="stroke-dashoffset" from="0" to="-22" dur="1.8s" repeatCount="indefinite" />
          </path>
          {[0, 1, 2].map(i => {
            const p = ((t * 0.28 + i * 0.22) % 1);
            const x = 240 + p * 210;
            const y = 180 + (210 - 180) * Math.min(p * 1.5, 1);
            return <circle key={i} cx={x} cy={y} r="4" fill="#48B7A5" opacity={(1 - p * 0.5) * 0.7} />;
          })}
          <g transform="translate(450, 210)">
            <rect x="-5" y="-18" width="50" height="36" rx="6" fill="white" stroke="#48B7A5" strokeWidth="1.5" />
            <path d="M 20 -10 L 14 -2 L 26 -2 Z" fill="#48B7A5" opacity="0.5" />
            <text x="20" y="12" textAnchor="middle" fontSize="6" fill="#2A8B7A" fontWeight="600">Nutrients</text>
          </g>
        </g>

        {/* Labels */}
        <text x="120" y="50" textAnchor="middle" fontSize="8" fill="#0E7A93" fontWeight="600" opacity="0.7">One input</text>
        <text x="450" y="250" textAnchor="middle" fontSize="8" fill="#48B7A5" fontWeight="600" opacity="0.7">Multiple potential outputs</text>
        <text x="250" y="265" textAnchor="middle" fontSize="8" fill="#18323D" opacity="0.5">Potential / theoretical — depends on concentration & economics</text>
      </svg>
    </div>
  );
}
