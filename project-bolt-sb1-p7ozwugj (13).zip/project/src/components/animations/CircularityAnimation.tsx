import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MotionPathPlugin } from 'gsap/MotionPathPlugin';

gsap.registerPlugin(ScrollTrigger, MotionPathPlugin);

const STAGES = [
  { label: 'SOURCE', desc: 'Water is drawn from its origin — utility supply, rainfall, or brackish aquifer.' },
  { label: 'CHECK', desc: 'Sensors measure pH, turbidity, and contaminants to baseline the stream.' },
  { label: 'UNDERSTAND', desc: 'AI models classify the water profile and select the optimal treatment pathway.' },
  { label: 'TREAT', desc: 'Targeted filtration, membrane, or biological processes bring water to spec.' },
  { label: 'RECOVER', desc: 'Valuable minerals and heat are extracted before the stream moves on.' },
  { label: 'REUSE', desc: 'Cleaned water is routed to irrigation, cooling, or process reuse.' },
  { label: 'RETEST', desc: 'The loop closes — quality is verified and the cycle begins again.' },
];

const CX = 300, CY = 300, R = 210;
const NODES = STAGES.map((_, i) => {
  const a = (i / STAGES.length) * Math.PI * 2 - Math.PI / 2;
  return { x: CX + R * Math.cos(a), y: CY + R * Math.sin(a) };
});
const PATH_D = `M ${NODES[0].x} ${NODES[0].y} ${NODES.map((_, i) => {
  const n = NODES[(i + 1) % STAGES.length];
  return `L ${n.x} ${n.y}`;
}).join(' ')} Z`;

export function CircularityAnimation() {
  const root = useRef<HTMLDivElement>(null);
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      const total = STAGES.length;
      const setActive = (p: number) => {
        const idx = Math.min(total - 1, Math.floor(p * total + 0.0001));
        setActiveIdx(idx);
        STAGES.forEach((_, i) => {
          const on = i === idx;
          gsap.to(`#c-node-${i}`, { scale: on ? 1.25 : 1, fill: on ? '#1FA7C8' : '#EAF4F9', stroke: on ? '#48B7A5' : '#7FD3E6', duration: 0.35, transformOrigin: 'center' });
          gsap.to(`#c-label-${i}`, { fill: on ? '#063B5C' : '#5E9BBF', fontWeight: on ? 700 : 500, duration: 0.3 });
        });
      };
      gsap.set('#c-drop', { autoAlpha: 1 });
      gsap.to('#c-drop', {
        motionPath: { path: '#c-path', align: '#c-path', alignOrigin: [0.5, 0.5], start: 0, end: 1 },
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top 70%',
          end: 'bottom 30%',
          scrub: 0.6,
          onUpdate: (st) => setActive(st.progress),
        },
      });
      setActive(0);
      ScrollTrigger.refresh();
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <div ref={root} className="w-full">
      <svg viewBox="0 0 600 600" className="w-full" style={{ maxHeight: 500 }}>
        <defs>
          <linearGradient id="c-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1FA7C8" /><stop offset="50%" stopColor="#48B7A5" /><stop offset="100%" stopColor="#7FD3E6" />
          </linearGradient>
          <radialGradient id="c-drop-grad"><stop offset="0%" stopColor="#EAF4F9" /><stop offset="60%" stopColor="#1FA7C8" /><stop offset="100%" stopColor="#063B5C" /></radialGradient>
          <filter id="c-glow"><feGaussianBlur stdDeviation="3" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
          <path id="c-path" d={PATH_D} fill="none" />
        </defs>

        <use href="#c-path" stroke="#7FD3E6" strokeWidth="3" opacity="0.25" fill="none" strokeDasharray="6 6" />
        <use href="#c-path" stroke="url(#c-grad)" strokeWidth="4" opacity="0.5" fill="none" />

        <text x={CX} y={CY - 6} textAnchor="middle" fontSize="20" fill="#063B5C" fontWeight="700" letterSpacing="2">Water</text>
        <text x={CX} y={CY + 18} textAnchor="middle" fontSize="20" fill="#1FA7C8" fontWeight="700" letterSpacing="2">Circularity</text>
        <text x={CX} y={CY + 42} textAnchor="middle" fontSize="10" fill="#48B7A5" fontWeight="500" letterSpacing="3">7-STAGE LOOP</text>

        {NODES.map((n, i) => (
          <g key={STAGES[i].label}>
            <circle id={`c-node-${i}`} cx={n.x} cy={n.y} r="26" fill="#EAF4F9" stroke="#7FD3E6" strokeWidth="2.5" />
            <text x={n.x} y={n.y + 5} textAnchor="middle" fontSize="11" fill="#1FA7C8" fontWeight="700">{i + 1}</text>
            <text id={`c-label-${i}`} x={n.x} y={n.y - 36} textAnchor="middle" fontSize="12" fill="#5E9BBF" fontWeight="500" letterSpacing="1">{STAGES[i].label}</text>
          </g>
        ))}

        <g id="c-drop" opacity={0}>
          <circle r="11" fill="url(#c-drop-grad)" filter="url(#c-glow)" />
          <circle r="5" fill="#EAF4F9" opacity="0.6" cx="-3" cy="-3" />
        </g>
      </svg>

      {/* Description shown as HTML below the SVG for readability */}
      <div className="mt-4 text-center min-h-[60px]">
        <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-aqua-50 mb-2">
          <span className="w-6 h-6 rounded-full bg-aqua-400 text-white flex items-center justify-center text-xs font-bold">{activeIdx + 1}</span>
          <span className="text-sm font-bold text-ocean-600 tracking-wide">{STAGES[activeIdx].label}</span>
        </div>
        <p className="text-sm text-slatey/70 max-w-lg mx-auto leading-relaxed">{STAGES[activeIdx].desc}</p>
      </div>
    </div>
  );
}
