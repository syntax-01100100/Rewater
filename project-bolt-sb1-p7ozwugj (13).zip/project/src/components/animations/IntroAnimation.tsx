import { useEffect, useRef, useCallback } from 'react';
import { gsap } from 'gsap';
import { MotionPathPlugin } from 'gsap/MotionPathPlugin';

gsap.registerPlugin(MotionPathPlugin);

export function IntroAnimation({ onComplete }: { onComplete?: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const doneRef = useRef(false);

  const finish = useCallback(() => {
    if (!doneRef.current) {
      doneRef.current = true;
      onComplete?.();
    }
  }, [onComplete]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ onComplete: finish });

      // Phase 1: Single droplet appears (0-1s)
      tl.set('#intro-droplet', { scale: 0, transformOrigin: 'center', opacity: 0 });
      tl.to('#intro-droplet', { scale: 1, opacity: 1, duration: 0.8, ease: 'back.out(1.7)' });

      // Phase 2: Droplet moves across screen (1-2.5s)
      tl.to('#intro-droplet', { x: 150, y: -20, duration: 1.2, ease: 'power2.inOut' }, '+=0.2');

      // Phase 3: Droplet splits into smaller droplets (2.5-3.5s)
      tl.to('#intro-droplet', { opacity: 0, scale: 0.5, duration: 0.3, ease: 'power2.out' }, '+=0.1');
      tl.set('.split-drop', { opacity: 0, scale: 0 });
      tl.to('.split-drop', { opacity: 1, scale: 1, duration: 0.5, stagger: 0.08, ease: 'back.out(2)' }, '<');

      // Phase 4: Droplets travel along paths forming circle (3.5-5.5s)
      tl.to('.split-drop', {
        motionPath: {
          path: '#circle-path',
          align: '#circle-path',
          alignOrigin: [0.5, 0.5],
          start: 0,
          end: 1,
        },
        duration: 1.8,
        stagger: 0.1,
        ease: 'power1.inOut',
      }, '+=0.2');

      // Phase 5: Circle transforms into logo (5.5-7s)
      tl.to('.split-drop', { opacity: 0, scale: 0, duration: 0.4, ease: 'power2.in' });
      tl.to('#logo-ring-1', { opacity: 1, scale: 1, duration: 0.6, ease: 'back.out(1.5)' }, '<');
      tl.to('#logo-ring-2', { opacity: 1, scale: 1, duration: 0.5, ease: 'back.out(1.5)' }, '-=0.3');
      tl.to('#logo-droplet', { opacity: 1, scale: 1, duration: 0.5, ease: 'back.out(2)' }, '-=0.2');

      // Phase 6: Slogan appears (7-8.5s)
      tl.to('#slogan-text', { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' }, '+=0.3');
      tl.to({}, { duration: 0.8 });

      // Phase 7: Flow into website (8.5-10s)
      tl.to('#intro-overlay', { opacity: 0, duration: 0.8, ease: 'power2.inOut' });
    }, container);

    return () => ctx.revert();
  }, [finish]);

  return (
    <div ref={containerRef} id="intro-overlay" className="fixed inset-0 z-50 overflow-hidden" style={{ background: 'linear-gradient(180deg, #032838 0%, #063B5C 40%, #0E7A93 100%)' }}>
      <svg viewBox="0 0 800 600" className="absolute inset-0 w-full h-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <radialGradient id="introDropGrad">
            <stop offset="0%" stopColor="#C8EEF5" stopOpacity="1" />
            <stop offset="60%" stopColor="#1FA7C8" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#0E7A93" stopOpacity="0.5" />
          </radialGradient>
          <linearGradient id="introWaterFlow" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1FA7C8" stopOpacity="0.9" />
            <stop offset="50%" stopColor="#48B7A5" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#7FD3E6" stopOpacity="0.5" />
          </linearGradient>
          <filter id="introGlowFilter">
            <feGaussianBlur stdDeviation="3" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <path id="circle-path" d="M 400 150 A 130 130 0 1 1 399 150" fill="none" />
        </defs>

        {/* Background ripples */}
        {[0, 1, 2].map(i => (
          <circle key={i} cx={400} cy={300} r={100 + i * 80} fill="none" stroke="#7FD3E6" strokeWidth="1" opacity={0.05} />
        ))}

        {/* Phase 1-2: Main droplet */}
        <g id="intro-droplet" filter="url(#introGlowFilter)">
          <path d="M 0 -28 Q -20 5 0 28 Q 20 5 0 -28 Z" fill="url(#introDropGrad)" transform="translate(250, 400)" />
          <ellipse cx={250 - 6} cy={400 - 10} rx="4" ry="8" fill="white" opacity="0.3" />
        </g>

        {/* Phase 3-4: Split droplets that travel along circle path */}
        {[0, 1, 2, 3, 4, 5].map(i => (
          <circle key={i} className="split-drop" cx={250} cy={400} r={6} fill="url(#introDropGrad)" opacity={0} filter="url(#introGlowFilter)" />
        ))}

        {/* Phase 5: Logo */}
        <g id="logo-group" transform="translate(400, 280)">
          <circle id="logo-ring-1" cx="0" cy="0" r="55" fill="none" stroke="#48B7A5" strokeWidth="3" opacity="0" />
          <circle id="logo-ring-2" cx="0" cy="0" r="45" fill="url(#introDropGrad)" opacity="0" />
          <path id="logo-droplet" d="M 0 -28 Q -20 5 0 28 Q 20 5 0 -28 Z" fill="url(#introDropGrad)" opacity="0" filter="url(#introGlowFilter)" />
        </g>

        {/* Phase 6: Slogan */}
        <text id="slogan-text" x="400" y="400" textAnchor="middle" fontSize="18" fill="#7FD3E6" fontWeight="400" letterSpacing="2" opacity="0" style={{ transform: 'translateY(20px)' }}>
          Every drop has a journey
        </text>
        <text x="400" y="430" textAnchor="middle" fontSize="14" fill="white" fontWeight="700" letterSpacing="2" opacity="0.8">
          ReWater
        </text>
      </svg>

      <button
        onClick={finish}
        className="absolute top-4 right-4 sm:top-6 sm:right-6 z-60 text-white/50 hover:text-white/80 text-xs sm:text-sm font-medium transition-colors bg-white/10 backdrop-blur-sm rounded-full px-4 py-2"
      >
        Skip Intro ›
      </button>
    </div>
  );
}
