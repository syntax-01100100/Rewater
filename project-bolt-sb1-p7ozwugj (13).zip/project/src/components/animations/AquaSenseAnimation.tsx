import { useEffect, useRef } from 'react';
import * as THREE from 'three';

const OCEAN = 0x063b5c, AQUA = 0x1fa7c8, TEAL = 0x48b7a5, LIGHT = 0x7fd3e6;
const hex = (c: number) => `#${c.toString(16).padStart(6, '0')}`;

const MEASUREMENTS = [
  { label: 'pH 7.2', color: TEAL },
  { label: 'TDS 340', color: AQUA },
  { label: 'NTU 2.1', color: LIGHT },
  { label: '24.5°C', color: 0xf2b84b },
];

function makeLabel(text: string, color: number): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = 'rgba(6, 59, 92, 0.85)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = hex(color);
  ctx.lineWidth = 2;
  ctx.strokeRect(4, 4, 248, 56);
  ctx.fillStyle = hex(color);
  ctx.font = 'bold 30px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 128, 32);
  const tex = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  sprite.scale.set(1.4, 0.35, 1);
  return sprite;
}

function makeFlow(count: number, color: number, size: number, opacity: number) {
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(count * 3);
  const vel: number[] = [];
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    color, size, transparent: true, opacity,
    blending: THREE.AdditiveBlending, depthWrite: false,
  }));
  return { geo, pos, vel, pts };
}

export function AquaSenseAnimation() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(OCEAN);
    scene.fog = new THREE.Fog(OCEAN, 8, 22);

    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight, 0.1, 100);
    camera.position.set(0, 1.5, 9);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0x88aabb, 0.6));
    const dir = new THREE.DirectionalLight(0xffffff, 1.1);
    dir.position.set(5, 8, 6);
    scene.add(dir);
    const rim = new THREE.DirectionalLight(LIGHT, 0.5);
    rim.position.set(-6, 2, -4);
    scene.add(rim);

    // Sensor cylinder body + rings + core
    const cylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 2.4, 48, 1, true),
      new THREE.MeshStandardMaterial({
        color: AQUA, transparent: true, opacity: 0.28, side: THREE.DoubleSide,
        metalness: 0.4, roughness: 0.25, emissive: AQUA, emissiveIntensity: 0.15,
      }));
    scene.add(cylinder);

    const ringGeo = new THREE.TorusGeometry(0.9, 0.04, 12, 48);
    const ringMat = new THREE.MeshStandardMaterial({
      color: TEAL, emissive: TEAL, emissiveIntensity: 0.4, metalness: 0.6, roughness: 0.3,
    });
    const ringTop = new THREE.Mesh(ringGeo, ringMat);
    ringTop.rotation.x = Math.PI / 2;
    ringTop.position.y = 1.2;
    const ringBot = ringTop.clone();
    ringBot.position.y = -1.2;
    cylinder.add(ringTop, ringBot);

    const core = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.3, 2.2, 24),
      new THREE.MeshBasicMaterial({ color: LIGHT, transparent: true, opacity: 0.15 }),
    );
    cylinder.add(core);

    // Particle systems: inflow (water → sensor) and outflow (sensor → ReWater)
    const IN_COUNT = 400, OUT_COUNT = 300;
    const inflow = makeFlow(IN_COUNT, LIGHT, 0.08, 0.7);
    const outflow = makeFlow(OUT_COUNT, TEAL, 0.06, 0.6);
    for (let i = 0; i < IN_COUNT; i++) {
      inflow.pos[i * 3] = -5 - Math.random() * 3;
      inflow.pos[i * 3 + 1] = (Math.random() - 0.5) * 1.4;
      inflow.pos[i * 3 + 2] = (Math.random() - 0.5) * 1.4;
      inflow.vel[i] = 0.015 + Math.random() * 0.02;
    }
    for (let i = 0; i < OUT_COUNT; i++) {
      outflow.pos[i * 3] = 1.2 + Math.random() * 0.4;
      outflow.pos[i * 3 + 1] = (Math.random() - 0.5) * 1.2;
      outflow.pos[i * 3 + 2] = (Math.random() - 0.5) * 1.2;
      outflow.vel[i] = 0.02 + Math.random() * 0.025;
    }
    inflow.geo.setAttribute('position', new THREE.BufferAttribute(inflow.pos, 3));
    outflow.geo.setAttribute('position', new THREE.BufferAttribute(outflow.pos, 3));
    scene.add(inflow.pts, outflow.pts);

    // Measurement labels orbiting the cylinder
    const labels = MEASUREMENTS.map((m, i) => {
      const s = makeLabel(m.label, m.color);
      const angle = (i / MEASUREMENTS.length) * Math.PI * 2;
      s.position.set(Math.cos(angle) * 1.8, 0.6 - i * 0.4, Math.sin(angle) * 1.8);
      scene.add(s);
      return { sprite: s, angle, baseY: 0.6 - i * 0.4 };
    });

    const rewater = makeLabel('ReWater', TEAL);
    rewater.scale.set(1.8, 0.45, 1);
    rewater.position.set(5.2, 0, 0);
    scene.add(rewater);

    const sample = makeLabel('Water Sample', LIGHT);
    sample.scale.set(1.8, 0.45, 1);
    sample.position.set(-5.2, 0, 0);
    scene.add(sample);

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    let rotSpeed = reduce.matches ? 0.0008 : 0.005;
    const onMotionChange = () => { rotSpeed = reduce.matches ? 0.0008 : 0.005; };
    reduce.addEventListener?.('change', onMotionChange);

    let raf = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      raf = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();
      cylinder.rotation.y += rotSpeed;
      (core.material as THREE.MeshBasicMaterial).opacity = 0.12 + Math.sin(t * 2) * 0.06;

      const a = inflow.geo.attributes.position.array as Float32Array;
      for (let i = 0; i < IN_COUNT; i++) {
        a[i * 3] += inflow.vel[i];
        if (a[i * 3] > 1.2) {
          a[i * 3] = -5 - Math.random() * 3;
          a[i * 3 + 1] = (Math.random() - 0.5) * 1.4;
          a[i * 3 + 2] = (Math.random() - 0.5) * 1.4;
        }
      }
      inflow.geo.attributes.position.needsUpdate = true;

      const b = outflow.geo.attributes.position.array as Float32Array;
      for (let i = 0; i < OUT_COUNT; i++) {
        b[i * 3] += outflow.vel[i];
        b[i * 3 + 1] += Math.sin(t * 2 + i) * 0.004;
        if (b[i * 3] > 5.2) {
          b[i * 3] = 1.2 + Math.random() * 0.4;
          b[i * 3 + 1] = (Math.random() - 0.5) * 1.2;
          b[i * 3 + 2] = (Math.random() - 0.5) * 1.2;
        }
      }
      outflow.geo.attributes.position.needsUpdate = true;

      labels.forEach((l, i) => {
        const ang = l.angle + t * 0.3;
        l.sprite.position.set(Math.cos(ang) * 1.8, l.baseY + Math.sin(t * 1.5 + i) * 0.1, Math.sin(ang) * 1.8);
        (l.sprite.material as THREE.SpriteMaterial).opacity = 0.6 + Math.sin(t * 2 + i) * 0.3;
      });

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      reduce.removeEventListener?.('change', onMotionChange);
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Points) {
          obj.geometry.dispose();
          if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
          else (obj.material as THREE.Material).dispose();
        }
        if (obj instanceof THREE.Sprite) {
          obj.material.map?.dispose();
          obj.material.dispose();
        }
      });
      renderer.dispose();
      renderer.domElement.parentNode?.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full" style={{ minHeight: 360 }} />;
}
