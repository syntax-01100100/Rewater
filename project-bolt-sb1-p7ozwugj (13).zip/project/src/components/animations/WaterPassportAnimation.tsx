import { useState, useEffect, useRef } from 'react';

const PASSPORT_STAGES = [
  { label: 'Water Source', icon: 'source' },
  { label: 'Sample ID', icon: 'id' },
  { label: 'Sensor Check', icon: 'sensor' },
  { label: 'Treatment', icon: 'treat' },
  { label: 'Retest', icon: 'retest' },
  { label: 'Reuse Route', icon: 'reuse' },
];

export function WaterPassportAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.012;
  const cycleDur = 8;
  const phase = (t % cycleDur) / cycleDur;
  const activeIdx = Math.floor(phase * PASSPORT_STAGES.length);
  const stageProgress = (phase * PASSPORT_STAGES.length) - activeIdx;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 280" className="w-full">
        <defs>
          <linearGradient id="wpCard" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F0F7FA" stopOpacity="1" />
            <stop offset="100%" stopColor="#E0F0F5" stopOpacity="0.9" />
          </linearGradient>
          <linearGradient id="wpWater" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#7FD3E6" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.4" />
          </linearGradient>
          <filter id="wpGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Passport document taking shape */}
        <g transform="translate(250, 120)">
          {/* Card background */}
          <rect x="-90" y="-80" width="180" height="160" rx="10" fill="url(#wpCard)" stroke="#1FA7C8" strokeWidth="2" filter="url(#wpGlow)" />
          {/* Header bar */}
          <rect x="-90" y="-80" width="180" height="20" rx="10" fill="#1FA7C8" opacity="0.15" />
          <rect x="-90" y="-70" width="180" height="10" fill="#1FA7C8" opacity="0.15" />
          <text x="0" y="-66" textAnchor="middle" fontSize="8" fill="#0E7A93" fontWeight="700">Water Passport</text>

          {/* Water droplet stamp */}
          <g transform="translate(-65, -50)">
            <path d="M 0 -8 Q -6 0 0 6 Q 6 0 0 -8 Z" fill="#1FA7C8" opacity="0.3" />
            <text x="0" y="2" textAnchor="middle" fontSize="5" fill="white" fontWeight="700">RW</text>
          </g>

          {/* Stages appearing sequentially */}
          {PASSPORT_STAGES.map((stage, i) => {
            const isVisible = i < activeIdx || (i === activeIdx && stageProgress > 0.1);
            const isStamping = i === activeIdx && stageProgress < 0.3;
            const stampScale = isStamping ? 1.5 - stageProgress * 2 : 1;
            const y = -35 + i * 20;
            return (
              <g key={i} opacity={isVisible ? 1 : 0.2}>
                {/* Verified checkmark */}
                <g transform={`translate(-70, ${y}) scale(${stampScale})`} style={{ transition: 'transform 0.3s' }}>
                  <circle cx="0" cy="0" r="6" fill={isVisible ? '#48B7A5' : '#D4D4D4'} opacity={isVisible ? 0.8 : 0.3} />
                  {isVisible && (
                    <path d="M -3 0 L -1 2 L 3 -2" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
                  )}
                </g>
                {/* Stage label */}
                <text x="-55" y={y + 2} fontSize="7" fill="#18323D" fontWeight={isVisible ? 600 : 400} opacity={isVisible ? 0.8 : 0.3}>
                  {stage.label}
                </text>
                {/* Data value appearing */}
                {isVisible && i < activeIdx && (
                  <text x="70" y={y + 2} textAnchor="end" fontSize="6" fill="#48B7A5" opacity="0.6">
                    {['Tap water', 'RW-0042', 'pH 7.2', 'Filtered', 'Confirmed', 'Irrigation'][i]}
                  </text>
                )}
                {/* Stamping animation */}
                {isStamping && (
                  <circle
                    cx="-70" cy={y}
                    r={8 + (1 - stageProgress / 0.3) * 10}
                    fill="none"
                    stroke="#48B7A5"
                    strokeWidth="1"
                    opacity={(1 - stageProgress / 0.3) * 0.5}
                  />
                )}
              </g>
            );
          })}

          {/* Water flowing along left edge connecting stages */}
          <rect x="-85" y="-40" width="3" height={activeIdx * 20 + stageProgress * 20} fill="url(#wpWater)" rx="1" />
        </g>

        <text x="250" y="265" textAnchor="middle" fontSize="9" fill="#18323D" fontWeight="600" opacity="0.6">
          Water Source → Sample ID → Sensor → Treatment → Retest → Reuse
        </text>
      </svg>
    </div>
  );
}
