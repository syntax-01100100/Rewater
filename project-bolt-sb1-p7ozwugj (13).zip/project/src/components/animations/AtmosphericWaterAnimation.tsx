import { useState, useEffect, useRef } from 'react';

export function AtmosphericWaterAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.012;
  const phase = (t % 8) / 8;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 280" className="w-full">
        <defs>
          <linearGradient id="awCond" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#7FD3E6" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.5" />
          </linearGradient>
          <radialGradient id="awDrop">
            <stop offset="0%" stopColor="#A8E0F0" stopOpacity="1" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.7" />
          </radialGradient>
          <filter id="awGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Humidity vapor particles moving toward collection surface */}
        <g>
          {[0, 1, 2, 3, 4, 5, 6, 7].map(i => {
            const p = ((t * 0.3 + i * 0.12) % 1);
            const startX = 20 + i * 55;
            const startY = 30 + (i % 3) * 15;
            const targetX = 250;
            const targetY = 100;
            const x = startX + (targetX - startX) * p;
            const y = startY + (targetY - startY) * p;
            const r = 2 + p * 3;
            const opacity = (1 - p * 0.5) * 0.5;
            return (
              <g key={i}>
                <circle cx={x} cy={y} r={r} fill="#7FD3E6" opacity={opacity} />
                {/* Wavy tail */}
                <circle cx={x - (targetX - startX) * 0.02} cy={y - (targetY - startY) * 0.02} r={r * 0.6} fill="#7FD3E6" opacity={opacity * 0.5} />
              </g>
            );
          })}
        </g>

        {/* Collection surface (condensation coil/film) */}
        <g transform="translate(250, 100)">
          {/* Cooling surface */}
          <rect x="-50" y="-5" width="100" height="10" rx="3" fill="#1FA7C8" opacity="0.15" stroke="#1FA7C8" strokeWidth="1.5" />
          {/* Condensation droplets forming on surface */}
          {[0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => {
            const dropT = ((t * 0.4 + i * 0.1) % 1);
            const dropR = 1 + dropT * 4;
            const dropY = 5 + dropT * 3;
            return (
              <circle
                key={i}
                cx={-40 + i * 10}
                cy={dropY}
                r={dropR}
                fill="url(#awDrop)"
                opacity={dropT * 0.8}
                filter="url(#awGlow)"
              />
            );
          })}
          <text x="0" y="-12" textAnchor="middle" fontSize="7" fill="#0E7A93" fontWeight="600">Condensation Surface</text>
        </g>

        {/* Droplets falling into collection container */}
        <g>
          {[0, 1, 2, 3, 4].map(i => {
            const p = ((t * 0.5 + i * 0.15) % 1);
            if (p < 0.1 || p > 0.9) return null;
            const x = 230 + i * 10;
            const y = 115 + p * 70;
            return (
              <path
                key={i}
                d={`M ${x} ${y - 5} Q ${x - 3} ${y} ${x} ${y + 5} Q ${x + 3} ${y} ${x} ${y - 5} Z`}
                fill="url(#awDrop)"
                opacity={(1 - p) * 0.7}
              />
            );
          })}
        </g>

        {/* Collection container */}
        <g>
          <path d="M 200 190 L 200 240 Q 200 248 208 248 L 292 248 Q 300 248 300 240 L 300 190"
            fill="none" stroke="#18323D" strokeWidth="2.5" strokeLinejoin="round" />
          <line x1="195" y1="190" x2="305" y2="190" stroke="#18323D" strokeWidth="2.5" strokeLinecap="round" />
          {/* Water level rising based on phase */}
          <path
            d={`M 202 ${230 - Math.min(phase * 30, 25)} L 298 ${230 - Math.min(phase * 30, 25)} L 298 240 Q 298 246 292 246 L 208 246 Q 202 246 202 240 Z`}
            fill="url(#awCond)"
          />
          {/* Water surface */}
          <ellipse cx="250" cy={230 - Math.min(phase * 30, 25)} rx="46" ry="2" fill="#7FD3E6" opacity="0.4">
            <animate attributeName="rx" values="40;48;40" dur="3s" repeatCount="indefinite" />
          </ellipse>
        </g>

        {/* Pipe to treatment */}
        <g>
          <rect x="300" y="215" width="80" height="14" fill="#18323D" opacity="0.08" rx="2" />
          <rect x="300" y="218" width="80" height="8" fill="url(#awCond)" rx="1" />
          <line x1="300" y1="222" x2="380" y2="222" stroke="#48B7A5" strokeWidth="1.5" strokeDasharray="4 3" opacity="0.4">
            <animate attributeName="stroke-dashoffset" from="0" to="-14" dur="1s" repeatCount="indefinite" />
          </line>
        </g>

        {/* Quality check icon */}
        <g transform="translate(420, 222)">
          <circle cx="0" cy="0" r="18" fill="white" stroke="#48B7A5" strokeWidth="2" />
          <path d="M -7 0 L -2 5 L 7 -5" fill="none" stroke="#48B7A5" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <text x="0" y="28" textAnchor="middle" fontSize="6" fill="#0E7A93" fontWeight="600">Quality Check</text>
        </g>

        {/* Labels */}
        <text x="100" y="20" textAnchor="middle" fontSize="8" fill="#7FD3E6" fontWeight="600" opacity="0.6">Humidity</text>
        <text x="250" y="265" textAnchor="middle" fontSize="9" fill="#18323D" fontWeight="600" opacity="0.6">
          Humidity → condensation → collection → treatment → quality check
        </text>
      </svg>
    </div>
  );
}
