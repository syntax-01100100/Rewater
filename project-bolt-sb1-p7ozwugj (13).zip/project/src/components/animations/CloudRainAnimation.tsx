import { useState, useEffect, useRef } from 'react';

export function CloudRainAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.012;
  const phase = (t % 6) / 6;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 280" className="w-full">
        <defs>
          <linearGradient id="crCloud" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#B8D4E8" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#7DB3CE" stopOpacity="0.5" />
          </linearGradient>
          <radialGradient id="crDrop">
            <stop offset="0%" stopColor="#A8E0F0" stopOpacity="1" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.6" />
          </radialGradient>
          <linearGradient id="crWater" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#7FD3E6" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.3" />
          </linearGradient>
        </defs>

        {/* Atmospheric moisture particles forming cloud */}
        <g>
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(i => {
            const p = ((t * 0.2 + i * 0.1) % 1);
            const startX = 50 + i * 45;
            const startY = 20 + (i % 3) * 10;
            const cloudX = 250 + Math.sin(i * 1.5) * 60;
            const cloudY = 60 + Math.cos(i * 1.2) * 15;
            const x = startX + (cloudX - startX) * Math.min(p * 2, 1);
            const y = startY + (cloudY - startY) * Math.min(p * 2, 1);
            return (
              <circle key={i} cx={x} cy={y} r={2 + p * 3} fill="#B8D4E8" opacity={(1 - p * 0.3) * 0.4} />
            );
          })}
        </g>

        {/* Cloud forming */}
        <g transform="translate(250, 60)">
          {/* Cloud body — multiple overlapping circles */}
          {[
            { x: -50, y: 5, r: 20 },
            { x: -25, y: -5, r: 25 },
            { x: 0, y: -10, r: 28 },
            { x: 25, y: -5, r: 25 },
            { x: 50, y: 5, r: 20 },
          ].map((c, i) => (
            <circle
              key={i}
              cx={c.x} cy={c.y} r={c.r * Math.min(phase * 3, 1)}
              fill="url(#crCloud)"
              opacity={Math.min(phase * 3, 1) * 0.7}
              style={{ transition: 'r 0.5s ease' }}
            />
          ))}
          {/* Cloud darkening as it builds up */}
          {phase > 0.3 && (
            <ellipse cx="0" cy="10" rx="55" ry="15" fill="#5A8AAA" opacity={(phase - 0.3) * 0.4} />
          )}
        </g>

        {/* Rain falling */}
        {phase >= 0.35 && (
          <g>
            {Array.from({ length: 12 }).map((_, i) => {
              const p = ((t * 1.5 + i * 0.08) % 1);
              if (p < 0 || p > 1) return null;
              const x = 180 + i * 22 + Math.sin(i) * 10;
              const y = 85 + p * 90;
              if (y > 175) return null;
              return (
                <path
                  key={i}
                  d={`M ${x} ${y} L ${x - 1} ${y + 8}`}
                  stroke="#7FD3E6"
                  strokeWidth="1.5"
                  opacity={(1 - p) * 0.6}
                  strokeLinecap="round"
                />
              );
            })}
          </g>
        )}

        {/* Collection gutter/system */}
        <g>
          {/* Roof slope */}
          <path d="M 120 175 L 200 165 L 300 165 L 380 175 L 380 185 L 120 185 Z" fill="#18323D" opacity="0.08" />
          <path d="M 120 175 L 200 165 L 300 165 L 380 175" fill="none" stroke="#18323D" strokeWidth="2" opacity="0.3" />
          {/* Gutter */}
          <rect x="115" y="185" width="270" height="8" rx="2" fill="#18323D" opacity="0.1" />
          <rect x="115" y="187" width="270" height="4" rx="1" fill="url(#crWater)" />
        </g>

        {/* Pipe down to collection */}
        <g>
          <rect x="370" y="193" width="12" height="40" fill="#18323D" opacity="0.08" rx="2" />
          <rect x="372" y="193" width="8" height="40" fill="url(#crWater)" rx="1" />
          {/* Water flowing down */}
          {[0, 1, 2].map(i => {
            const p = ((t * 0.8 + i * 0.2) % 1);
            return <circle key={i} cx="376" cy={193 + p * 40} r="2" fill="#7FD3E6" opacity={(1 - p) * 0.6} />;
          })}
        </g>

        {/* Collection tank */}
        <g>
          <path d="M 340 230 L 340 255 Q 340 260 345 260 L 405 260 Q 410 260 410 255 L 410 230"
            fill="none" stroke="#18323D" strokeWidth="2" strokeLinejoin="round" />
          <line x1="335" y1="230" x2="415" y2="230" stroke="#18323D" strokeWidth="2" strokeLinecap="round" />
          <path d={`M 342 ${248 - Math.min(phase * 15, 12)} L 408 ${248 - Math.min(phase * 15, 12)} L 408 255 Q 408 258 405 258 L 345 258 Q 342 258 342 255 Z`}
            fill="url(#crWater)" />
        </g>

        {/* ReWater monitoring node */}
        <g transform="translate(375, 195)">
          <circle cx="0" cy="0" r="6" fill="#1FA7C8" opacity="0.8" />
          <circle cx="0" cy="0" r="3" fill="white" />
          <text x="0" y="-10" textAnchor="middle" fontSize="5" fill="#0E7A93" fontWeight="600">Monitor</text>
        </g>

        <text x="250" y="275" textAnchor="middle" fontSize="8" fill="#18323D" fontWeight="600" opacity="0.5">
          Atmospheric conditions → cloud formation → rainfall → collection → monitoring
        </text>
      </svg>
    </div>
  );
}
