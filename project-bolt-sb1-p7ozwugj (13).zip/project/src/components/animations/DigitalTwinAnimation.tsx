import { useState, useEffect, useRef } from 'react';

type FlowPath = 'municipal' | 'wastewater' | 'condensate' | 'reuse';

export function DigitalTwinAnimation({ activePath }: { activePath?: FlowPath }) {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.015;

  const highlight = activePath || 'municipal';

  return (
    <div className="w-full" style={{ maxWidth: 560, margin: '0 auto' }}>
      <svg viewBox="0 0 560 320" className="w-full">
        <defs>
          <linearGradient id="dtWater" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1FA7C8" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#48B7A5" stopOpacity="0.4" />
          </linearGradient>
          <linearGradient id="dtWaste" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#D95C5C" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#F2B84B" stopOpacity="0.3" />
          </linearGradient>
          <linearGradient id="dtCond" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#7FD3E6" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#1FA7C8" stopOpacity="0.3" />
          </linearGradient>
          <linearGradient id="dtReuse" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#48B7A5" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#2A8B7A" stopOpacity="0.3" />
          </linearGradient>
        </defs>

        {/* Building outline */}
        <g>
          <rect x="180" y="40" width="200" height="220" rx="4" fill="#F0F7FA" stroke="#18323D" strokeWidth="2" opacity="0.4" />
          {/* Floors */}
          {[0, 1, 2, 3].map(i => (
            <line key={i} x1="180" y1={95 + i * 45} x2="380" y2={95 + i * 45} stroke="#18323D" strokeWidth="0.5" opacity="0.15" />
          ))}
          {/* Rooms / zones */}
          {[0, 1, 2, 3].map(floor => [0, 1].map(room => (
            <rect key={`${floor}-${room}`} x={190 + room * 95} y={55 + floor * 45} width="80" height="35" rx="2" fill="white" stroke="#18323D" strokeWidth="0.5" opacity="0.1" />
          )))}
        </g>

        {/* Municipal input pipe (left, into building) */}
        <g opacity={highlight === 'municipal' ? 1 : 0.4}>
          <rect x="0" y="55" width="180" height="14" fill="#18323D" opacity="0.06" rx="2" />
          <rect x="0" y="58" width="180" height="8" fill="url(#dtWater)" rx="1" />
          <line x1="0" y1="62" x2="180" y2="62" stroke="#1FA7C8" strokeWidth="2" strokeDasharray="6 4" opacity="0.4">
            <animate attributeName="stroke-dashoffset" from="0" to="-20" dur="1s" repeatCount="indefinite" />
          </line>
          <text x="90" y="48" textAnchor="middle" fontSize="7" fill="#0E7A93" fontWeight="600">Municipal Input</text>
        </g>

        {/* Building use zone */}
        <g opacity={highlight === 'municipal' || highlight === 'wastewater' ? 1 : 0.4}>
          <rect x="210" y="60" width="140" height="30" rx="4" fill="#1FA7C8" opacity="0.08" />
          <text x="280" y="78" textAnchor="middle" fontSize="7" fill="#0E7A93" fontWeight="600">Building Use</text>
          {/* Water flowing through */}
          {[0, 1, 2].map(i => {
            const p = ((t * 0.3 + i * 0.2) % 1);
            return <circle key={i} cx={210 + p * 140} cy="75" r="2" fill="#1FA7C8" opacity={(1 - p) * 0.5} />;
          })}
        </g>

        {/* Wastewater pipe (going down) */}
        <g opacity={highlight === 'wastewater' ? 1 : 0.4}>
          <rect x="270" y="90" width="14" height="60" fill="#18323D" opacity="0.06" rx="2" />
          <rect x="272" y="90" width="10" height="60" fill="url(#dtWaste)" rx="1" />
          {[0, 1].map(i => {
            const p = ((t * 0.4 + i * 0.3) % 1);
            return <circle key={i} cx="277" cy={90 + p * 60} r="2" fill="#D95C5C" opacity={(1 - p) * 0.4} />;
          })}
        </g>

        {/* Treatment unit (lower level) */}
        <g opacity={highlight === 'wastewater' ? 1 : 0.4}>
          <rect x="220" y="150" width="120" height="35" rx="6" fill="white" stroke="#48B7A5" strokeWidth="1.5" />
          {/* Treatment process animation */}
          {[0, 1, 2, 3, 4].map(i => {
            const p = ((t * 0.5 + i * 0.1) % 1);
            return (
              <circle
                key={i}
                cx={230 + i * 24}
                cy={167 + Math.sin(t * 4 + i) * 3}
                r={3 - p}
                fill={i < 2 ? '#D95C5C' : '#48B7A5'}
                opacity={(1 - p) * 0.5}
              />
            );
          })}
          <text x="280" y="172" textAnchor="middle" fontSize="6" fill="#2A8B7A" fontWeight="600">Treatment</text>
        </g>

        {/* AC Condensate collection (top-right of building) */}
        <g opacity={highlight === 'condensate' ? 1 : 0.4}>
          {/* AC unit */}
          <rect x="340" y="50" width="35" height="20" rx="3" fill="#18323D" opacity="0.08" stroke="#18323D" strokeWidth="1" />
          <text x="357" y="63" textAnchor="middle" fontSize="5" fill="#18323D" fontWeight="600">AC</text>
          {/* Condensation droplets */}
          {[0, 1, 2, 3].map(i => {
            const p = ((t * 0.6 + i * 0.15) % 1);
            return (
              <path
                key={i}
                d={`M ${348 + i * 6} ${72 + p * 20} Q ${346 + i * 6} ${75 + p * 20} ${348 + i * 6} ${78 + p * 20} Q ${350 + i * 6} ${75 + p * 20} ${348 + i * 6} ${72 + p * 20} Z`}
                fill="#7FD3E6"
                opacity={(1 - p) * 0.5}
              />
            );
          })}
          {/* Condensate pipe going down */}
          <rect x="372" y="90" width="8" height="60" fill="#18323D" opacity="0.06" rx="1" />
          <rect x="373" y="90" width="6" height="60" fill="url(#dtCond)" rx="1" />
        </g>

        {/* Storage tank (bottom) */}
        <g opacity={highlight === 'wastewater' || highlight === 'condensate' || highlight === 'reuse' ? 1 : 0.4}>
          <path d="M 200 190 L 200 250 Q 200 256 206 256 L 354 256 Q 360 256 360 250 L 360 190"
            fill="none" stroke="#18323D" strokeWidth="2" strokeLinejoin="round" opacity="0.3" />
          <line x1="195" y1="190" x2="365" y2="190" stroke="#18323D" strokeWidth="2" strokeLinecap="round" opacity="0.3" />
          {/* Water in storage */}
          <path d="M 202 210 L 358 210 L 358 250 Q 358 254 354 254 L 206 254 Q 202 254 202 250 Z"
            fill="url(#dtReuse)" />
          <ellipse cx="280" cy="210" rx="76" ry="2.5" fill="#48B7A5" opacity="0.3">
            <animate attributeName="rx" values="70;80;70" dur="3s" repeatCount="indefinite" />
          </ellipse>
          <text x="280" y="235" textAnchor="middle" fontSize="7" fill="#2A8B7A" fontWeight="600">Storage</text>
        </g>

        {/* Reuse output pipe (right side, going out) */}
        <g opacity={highlight === 'reuse' ? 1 : 0.4}>
          <rect x="360" y="222" width="200" height="14" fill="#18323D" opacity="0.06" rx="2" />
          <rect x="360" y="225" width="200" height="8" fill="url(#dtReuse)" rx="1" />
          <line x1="360" y1="229" x2="560" y2="229" stroke="#48B7A5" strokeWidth="2" strokeDasharray="6 4" opacity="0.4">
            <animate attributeName="stroke-dashoffset" from="0" to="-20" dur="1s" repeatCount="indefinite" />
          </line>
          {/* Reuse droplets */}
          {[0, 1, 2].map(i => {
            const p = ((t * 0.3 + i * 0.2) % 1);
            return <circle key={i} cx={360 + p * 200} cy="229" r="2.5" fill="#48B7A5" opacity={(1 - p) * 0.5} />;
          })}
          <text x="460" y="248" textAnchor="middle" fontSize="7" fill="#2A8B7A" fontWeight="600">Reuse Output</text>
        </g>

        {/* Connection from treatment to storage */}
        <g opacity={highlight === 'wastewater' ? 1 : 0.4}>
          <rect x="272" y="185" width="14" height="10" fill="#18323D" opacity="0.06" rx="1" />
          <rect x="273" y="186" width="12" height="8" fill="url(#dtReuse)" rx="1" />
        </g>

        {/* Path selector buttons */}
        <g transform="translate(10, 290)">
          {(['municipal', 'wastewater', 'condensate', 'reuse'] as FlowPath[]).map((p, i) => (
            <g
              key={p}
              transform={`translate(${i * 130}, 0)`}
              style={{ cursor: 'pointer' }}
            >
              <rect
                x="0" y="-12" width="115" height="20" rx="4"
                fill={highlight === p ? '#1FA7C8' : 'white'}
                stroke="#1FA7C8" strokeWidth="1"
                opacity={highlight === p ? 0.9 : 0.5}
              />
              <text
                x="57" y="1"
                textAnchor="middle" fontSize="7"
                fill={highlight === p ? 'white' : '#0E7A93'}
                fontWeight="600"
              >
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </text>
            </g>
          ))}
        </g>
      </svg>
    </div>
  );
}
