import { useState, useEffect, useRef } from 'react';

export function PiezoelectricAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.012;
  const phase = (t % 7) / 7;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 280" className="w-full">
        <defs>
          <filter id="pzGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <linearGradient id="pzEnergy" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#F2B84B" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#48B7A5" stopOpacity="0.6" />
          </linearGradient>
        </defs>

        {/* Foot pressing down on floor (phase 0-0.15) */}
        <g transform="translate(100, 80)">
          {/* Shoe shape */}
          <ellipse
            cx="0" cy={phase < 0.15 ? 0 + (phase / 0.15) * 15 : 15}
            rx="25" ry="12"
            fill="#18323D"
            opacity={phase > 0.15 ? 0.3 : 0.8}
            style={{ transition: 'opacity 0.3s' }}
          />
          {/* Pressure waves */}
          {phase >= 0.1 && phase < 0.25 && (
            <g>
              {[0, 1, 2].map(i => (
                <ellipse
                  key={i}
                  cx="0" cy="25"
                  rx={20 + i * 12 + (phase * 50 % 15)}
                  ry={6 + i * 4}
                  fill="none"
                  stroke="#F2B84B"
                  strokeWidth="1.5"
                  opacity={0.5 - i * 0.15}
                >
                  <animate attributeName="rx" values={`${20 + i * 12};${35 + i * 12};${20 + i * 12}`} dur="1s" repeatCount="indefinite" />
                </ellipse>
              ))}
            </g>
          )}
        </g>

        {/* Piezoelectric floor */}
        <g transform="translate(100, 110)">
          <rect x="-40" y="0" width="80" height="20" rx="3" fill="#1FA7C8" opacity="0.15" stroke="#1FA7C8" strokeWidth="1.5" />
          {/* Crystal pattern inside floor */}
          {[0, 1, 2, 3].map(i => (
            <rect
              key={i}
              x={-35 + i * 18} y="3"
              width="14" height="14" rx="1"
              fill={phase >= 0.1 && phase < 0.3 ? '#F2B84B' : '#1FA7C8'}
              opacity={phase >= 0.1 && phase < 0.3 ? 0.5 + Math.sin(t * 10 + i) * 0.2 : 0.2}
              style={{ transition: 'fill 0.3s' }}
            />
          ))}
          <text x="0" y="38" textAnchor="middle" fontSize="7" fill="#0E7A93" fontWeight="600">Piezo Floor</text>
        </g>

        {/* Energy traveling through circuit (phase 0.2-0.5) */}
        {phase >= 0.2 && phase < 0.5 && (
          <g>
            {(() => {
              const eT = (phase - 0.2) / 0.3;
              const path = [
                { x: 100, y: 130 },
                { x: 100, y: 180 },
                { x: 200, y: 180 },
                { x: 200, y: 150 },
              ];
              const totalSegs = path.length - 1;
              const segIdx = Math.min(Math.floor(eT * totalSegs), totalSegs - 1);
              const segT = (eT * totalSegs) - segIdx;
              const cx = path[segIdx].x + (path[segIdx + 1].x - path[segIdx].x) * segT;
              const cy = path[segIdx].y + (path[segIdx + 1].y - path[segIdx].y) * segT;
              return (
                <g>
                  {/* Circuit path */}
                  <path d="M 100 130 L 100 180 L 200 180 L 200 150" fill="none" stroke="#18323D" strokeWidth="1.5" opacity="0.3" />
                  {/* Energy spark traveling */}
                  <circle cx={cx} cy={cy} r="5" fill="#F2B84B" filter="url(#pzGlow)">
                    <animate attributeName="r" values="3;6;3" dur="0.5s" repeatCount="indefinite" />
                  </circle>
                  {/* Trail */}
                  {[0, 1, 2].map(i => {
                    const trailT = Math.max(0, eT - i * 0.03);
                    if (trailT <= 0) return null;
                    const tSeg = Math.min(Math.floor(trailT * totalSegs), totalSegs - 1);
                    const tFrac = (trailT * totalSegs) - tSeg;
                    const tx = path[tSeg].x + (path[tSeg + 1].x - path[tSeg].x) * tFrac;
                    const ty = path[tSeg].y + (path[tSeg + 1].y - path[tSeg].y) * tFrac;
                    return <circle key={i} cx={tx} cy={ty} r={4 - i} fill="#F2B84B" opacity={(4 - i) / 8} />;
                  })}
                </g>
              );
            })()}
          </g>
        )}

        {/* Battery/storage unit */}
        <g transform="translate(200, 130)">
          <rect x="-20" y="-10" width="40" height="30" rx="4" fill="white" stroke="#48B7A5" strokeWidth="2" />
          <rect x="-5" y="-14" width="10" height="4" rx="1" fill="#48B7A5" />
          {/* Charge level */}
          <rect x="-16" y="-6" width={32 * Math.min(phase * 2, 1)} height="22" rx="2" fill="#48B7A5" opacity="0.3" />
          {phase >= 0.4 && (
            <text x="0" y="10" textAnchor="middle" fontSize="6" fill="#2A8B7A" fontWeight="700">
              {Math.floor(Math.min(phase * 150, 100))}%
            </text>
          )}
        </g>

        {/* Energy flowing to AquaSense (phase 0.5-0.7) */}
        {phase >= 0.5 && phase < 0.7 && (
          <g>
            <line x1="220" y1="145" x2="350" y2="145" stroke="#48B7A5" strokeWidth="2" strokeDasharray="4 3" opacity="0.5">
              <animate attributeName="stroke-dashoffset" from="0" to="-14" dur="0.5s" repeatCount="indefinite" />
            </line>
            {[0, 1].map(i => {
              const p = ((phase - 0.5) / 0.2 + i * 0.2) % 1;
              return <circle key={i} cx={220 + p * 130} cy="145" r="3" fill="#48B7A5" opacity={(1 - p) * 0.7} />;
            })}
          </g>
        )}

        {/* AquaSense device */}
        <g transform="translate(360, 130)">
          <rect x="-20" y="-15" width="40" height="30" rx="5" fill="#1FA7C8" opacity="0.9" stroke="#0E7A93" strokeWidth="1.5" />
          <rect x="-14" y="-10" width="28" height="14" rx="2" fill="#0a1a2a" />
          {phase >= 0.6 && (
            <g>
              <text x="-10" y="-3" fontSize="4" fill="#48B7A5" fontFamily="monospace">pH:7.2</text>
              <text x="-10" y="2" fontSize="4" fill="#7FD3E6" fontFamily="monospace">T:24°</text>
            </g>
          )}
          <circle cx="15" cy="-10" r="2" fill={phase >= 0.6 ? '#48B7A5' : '#D4A574'}>
            {phase >= 0.6 && <animate attributeName="opacity" values="0.5;1;0.5" dur="1s" repeatCount="indefinite" />}
          </circle>
          <text x="0" y="25" textAnchor="middle" fontSize="6" fill="#0E7A93" fontWeight="600">AquaSense</text>
        </g>

        {/* Data flowing to ReWater (phase 0.7-1.0) */}
        {phase >= 0.7 && (
          <g>
            <line x1="380" y1="145" x2="460" y2="145" stroke="#1FA7C8" strokeWidth="2" strokeDasharray="3 3" opacity="0.4">
              <animate attributeName="stroke-dashoffset" from="0" to="-12" dur="0.5s" repeatCount="indefinite" />
            </line>
            {[0, 1, 2].map(i => {
              const p = ((phase - 0.7) / 0.3 + i * 0.15) % 1;
              return (
                <rect key={i} x={380 + p * 75 - 3} y="142" width="6" height="6" rx="1" fill="#1FA7C8" opacity={(1 - p) * 0.6} />
              );
            })}
            {/* ReWater platform */}
            <g transform="translate(460, 130)">
              <rect x="-15" y="-10" width="35" height="30" rx="5" fill="white" stroke="#1FA7C8" strokeWidth="1.5" />
              <rect x="-12" y="-7" width="29" height="4" rx="1" fill="#1FA7C8" opacity="0.2" />
              <rect x="-12" y="-1" width="20" height="3" rx="1" fill="#48B7A5" opacity={phase > 0.85 ? 0.5 : 0.1} style={{ transition: 'opacity 0.3s' }} />
              <rect x="-12" y="3" width="25" height="3" rx="1" fill="#48B7A5" opacity={phase > 0.9 ? 0.5 : 0.1} style={{ transition: 'opacity 0.3s' }} />
              <text x="3" y="15" textAnchor="middle" fontSize="5" fill="#0E7A93" fontWeight="600">ReWater</text>
            </g>
          </g>
        )}

        <text x="250" y="265" textAnchor="middle" fontSize="9" fill="#18323D" fontWeight="600" opacity="0.6">
          Footstep → pressure → electricity → AquaSense → water data
        </text>
      </svg>
    </div>
  );
}
