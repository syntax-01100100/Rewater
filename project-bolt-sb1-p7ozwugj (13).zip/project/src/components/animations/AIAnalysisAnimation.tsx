import { useState, useEffect, useRef } from 'react';

const RAW_PARAMS = [
  { label: 'pH', value: '7.2', color: '#1FA7C8' },
  { label: 'EC/TDS', value: '340', color: '#48B7A5' },
  { label: 'Turbidity', value: '2.1', color: '#F2B84B' },
  { label: 'Temp', value: '24°C', color: '#D95C5C' },
];

const RESULT_CARDS = [
  { title: 'What does it mean?', text: 'Slightly alkaline, low turbidity', icon: 'info' },
  { title: 'Why does it matter?', text: 'Within typical range for reuse', icon: 'why' },
  { title: 'Possible next step', text: 'Filtration + disinfection', icon: 'next' },
  { title: 'Confidence', text: 'MEASURED · High', icon: 'conf' },
];

export function AIAnalysisAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const cycleDur = 8;
  const t = (tick * 0.012) % cycleDur;
  const phase = t / cycleDur;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 260" className="w-full">
        <defs>
          <filter id="aiGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <linearGradient id="aiFlow" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1FA7C8" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#48B7A5" stopOpacity="0.4" />
          </linearGradient>
        </defs>

        {/* Raw data chips on left */}
        <g>
          {RAW_PARAMS.map((param, i) => {
            const yPos = 40 + i * 45;
            const moveT = phase < 0.2 ? 0 : Math.min((phase - 0.2) / 0.2, 1);
            const x = 20 + moveT * 60;
            return (
              <g key={param.label} transform={`translate(${x},${yPos})`} opacity={phase > 0.05 ? 1 : 0.3}>
                <rect x="0" y="-15" width="70" height="30" rx="6" fill="white" stroke={param.color} strokeWidth="1.5" />
                <text x="35" y="-2" textAnchor="middle" fontSize="7" fill={param.color} fontWeight="600">{param.label}</text>
                <text x="35" y="8" textAnchor="middle" fontSize="9" fill="#18323D" fontWeight="700">{param.value}</text>
              </g>
            );
          })}
        </g>

        {/* Data flowing into analysis layer */}
        {phase >= 0.25 && phase < 0.5 && (
          <g>
            {RAW_PARAMS.map((param, i) => {
              const flowT = Math.max(0, Math.min((phase - 0.25 - i * 0.03) / 0.2, 1));
              if (flowT <= 0) return null;
              return (
                <line
                  key={i}
                  x1={80} y1={55 + i * 45}
                  x2={80 + flowT * 100} y2={55 + i * 45}
                  stroke={param.color} strokeWidth="2" strokeDasharray="4 3" opacity={flowT * 0.6}
                >
                  <animate attributeName="stroke-dashoffset" from="0" to="-14" dur="0.5s" repeatCount="indefinite" />
                </line>
              );
            })}
          </g>
        )}

        {/* Analysis layer — central processing */}
        <g transform="translate(220, 130)">
          <rect x="-50" y="-40" width="100" height="80" rx="10" fill="#F0F7FA" stroke="#1FA7C8" strokeWidth="2" opacity={phase > 0.3 ? 0.9 : 0.3} />
          {phase > 0.3 && (
            <g>
              {/* Pattern matching visualization */}
              {[0, 1, 2, 3].map(i => (
                <circle
                  key={i}
                  cx={-30 + i * 20}
                  cy={-15 + Math.sin(t * 3 + i) * 5}
                  r="5"
                  fill={RAW_PARAMS[i].color}
                  opacity="0.4"
                >
                  <animate attributeName="r" values="3;6;3" dur="1.5s" repeatCount="indefinite" />
                </circle>
              ))}
              {/* Connecting lines forming a network */}
              {[0, 1, 2].map(i => (
                <line
                  key={i}
                  x1={-30 + i * 20} y1={-15}
                  x2={-30 + (i + 1) * 20} y2={-15}
                  stroke="#48B7A5" strokeWidth="1" opacity="0.3"
                />
              ))}
              <text x="0" y="10" textAnchor="middle" fontSize="7" fill="#0E7A93" fontWeight="700">Analysis</text>
              <text x="0" y="22" textAnchor="middle" fontSize="5" fill="#48B7A5" opacity="0.7">Pattern recognition</text>
              {/* Processing indicator */}
              {phase > 0.3 && phase < 0.55 && (
                <rect x="-30" y="28" width="60" height="4" rx="2" fill="#1FA7C8" opacity="0.2" />
              )}
              {phase > 0.3 && phase < 0.55 && (
                <rect x="-30" y="28" width={60 * Math.min((phase - 0.3) / 0.25, 1)} height="4" rx="2" fill="#48B7A5" />
              )}
            </g>
          )}
        </g>

        {/* Output flowing to result cards */}
        {phase >= 0.5 && (
          <g>
            {[0, 1, 2, 3].map(i => {
              const flowT = Math.max(0, Math.min((phase - 0.5 - i * 0.04) / 0.2, 1));
              if (flowT <= 0) return null;
              return (
                <line
                  key={i}
                  x1={270} y1={130}
                  x2={270 + flowT * 80} y2={40 + i * 45}
                  stroke="url(#aiFlow)" strokeWidth="1.5" strokeDasharray="3 2" opacity={flowT * 0.5}
                >
                  <animate attributeName="stroke-dashoffset" from="0" to="-10" dur="0.5s" repeatCount="indefinite" />
                </line>
              );
            })}
          </g>
        )}

        {/* Result cards on right */}
        <g>
          {RESULT_CARDS.map((card, i) => {
            const yPos = 40 + i * 45;
            const appearT = Math.max(0, Math.min((phase - 0.6 - i * 0.05) / 0.1, 1));
            return (
              <g key={card.title} transform={`translate(${350 + (1 - appearT) * 30},${yPos})`} opacity={appearT}>
                <rect x="0" y="-15" width="130" height="30" rx="6" fill="white" stroke="#48B7A5" strokeWidth="1.5" filter="url(#aiGlow)" />
                <text x="8" y="-3" fontSize="6" fill="#0E7A93" fontWeight="700">{card.title}</text>
                <text x="8" y="8" fontSize="6" fill="#18323D" opacity="0.7">{card.text}</text>
              </g>
            );
          })}
        </g>

        <text x="250" y="245" textAnchor="middle" fontSize="9" fill="#18323D" fontWeight="600" opacity="0.6">
          Raw data → AI analysis → understandable explanation → suggested action
        </text>
      </svg>
    </div>
  );
}
