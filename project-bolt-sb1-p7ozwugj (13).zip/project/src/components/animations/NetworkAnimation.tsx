import { useState, useEffect, useRef } from 'react';

const BUILDINGS = [
  { x: 80, y: 100, label: 'A', status: 'normal' },
  { x: 200, y: 120, label: 'B', status: 'normal' },
  { x: 320, y: 95, label: 'C', status: 'warning' },
  { x: 440, y: 110, label: 'D', status: 'normal' },
];

export function NetworkAnimation() {
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      if (now - last > 40) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  const t = tick * 0.012;
  const cycleDur = 6;
  const phase = (t % cycleDur) / cycleDur;

  return (
    <div className="w-full" style={{ maxWidth: 560, margin: '0 auto' }}>
      <svg viewBox="0 0 560 280" className="w-full">
        <defs>
          <filter id="netGlow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <linearGradient id="netData" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1FA7C8" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#48B7A5" stopOpacity="0.5" />
          </linearGradient>
        </defs>

        {/* Buildings with AquaSense sensors */}
        {BUILDINGS.map((b, i) => {
          const isWarning = b.status === 'warning';
          const warningActive = isWarning && phase > 0.3 && phase < 0.7;
          return (
            <g key={i} transform={`translate(${b.x},${b.y})`}>
              {/* Building body */}
              <rect x="-25" y="0" width="50" height="70" rx="3" fill="#18323D" opacity="0.08" stroke="#18323D" strokeWidth="1.5" opacity-stroke="0.3" />
              {/* Windows */}
              {[0, 1, 2].map(row => [0, 1].map(col => (
                <rect key={`${row}-${col}`} x={-18 + col * 20} y={8 + row * 18} width="12" height="10" rx="1"
                  fill={warningActive ? '#F2B84B' : '#48B7A5'} opacity={warningActive ? 0.4 + Math.sin(t * 8) * 0.3 : 0.2} />
              )))}
              {/* AquaSense sensor on top */}
              <g transform="translate(0, -8)">
                <rect x="-8" y="-6" width="16" height="12" rx="2" fill={warningActive ? '#F2B84B' : '#1FA7C8'} opacity="0.9" />
                <circle cx="6" cy="-3" r="1.5" fill={warningActive ? '#D95C5C' : '#48B7A5'}>
                  <animate attributeName="opacity" values="0.5;1;0.5" dur="1s" repeatCount="indefinite" />
                </circle>
                {/* Antenna */}
                <line x1="0" y1="-6" x2="0" y2="-10" stroke="#0E7A93" strokeWidth="1" />
                <circle cx="0" cy="-11" r="1.5" fill={warningActive ? '#D95C5C' : '#48B7A5'} />
              </g>
              {/* Warning pulse */}
              {warningActive && (
                <g>
                  {[0, 1, 2].map(ri => (
                    <circle
                      key={ri}
                      cx="0" cy="-8"
                      r={10 + ri * 8 + (phase * 40 % 12)}
                      fill="none"
                      stroke="#F2B84B"
                      strokeWidth="1.5"
                      opacity={0.4 - ri * 0.1}
                    >
                      <animate attributeName="r" values={`${10 + ri * 8};${20 + ri * 8};${10 + ri * 8}`} dur="1.5s" repeatCount="indefinite" />
                    </circle>
                  ))}
                </g>
              )}
              <text x="0" y="85" textAnchor="middle" fontSize="8" fill="#18323D" fontWeight="600" opacity="0.5">{b.label}</text>
            </g>
          );
        })}

        {/* Data lines from buildings to central platform */}
        {BUILDINGS.map((b, i) => {
          const isWarning = b.status === 'warning';
          const dataT = (t * 0.5 + i * 0.2) % 1;
          const platformX = 280, platformY = 230;
          return (
            <g key={`line-${i}`}>
              <line
                x1={b.x} y1={b.y + 70}
                x2={platformX} y2={platformY}
                stroke={isWarning ? '#F2B84B' : '#1FA7C8'}
                strokeWidth="1.5"
                opacity="0.2"
                strokeDasharray="3 3"
              />
              {/* Data packet traveling */}
              <g>
                <circle
                  cx={b.x + (platformX - b.x) * dataT}
                  cy={b.y + 70 + (platformY - b.y - 70) * dataT}
                  r="3"
                  fill={isWarning ? '#F2B84B' : '#48B7A5'}
                  opacity={(1 - dataT) * 0.7}
                  filter="url(#netGlow)"
                />
              </g>
            </g>
          );
        })}

        {/* Central ReWater platform */}
        <g transform="translate(280, 230)">
          {/* Platform base */}
          <rect x="-40" y="-15" width="80" height="35" rx="8" fill="white" stroke="#1FA7C8" strokeWidth="2" filter="url(#netGlow)" />
          {/* Screen */}
          <rect x="-35" y="-12" width="70" height="8" rx="2" fill="#1FA7C8" opacity="0.15" />
          <rect x="-35" y="-12" width={70 * Math.min(phase * 2, 1)} height="8" rx="2" fill="#48B7A5" opacity="0.3" />
          {/* Status indicators */}
          {[0, 1, 2, 3].map(i => (
            <circle
              key={i}
              cx={-25 + i * 18} cy="5"
              r="3"
              fill={BUILDINGS[i].status === 'warning' && phase > 0.4 ? '#F2B84B' : '#48B7A5'}
              opacity={0.6 + Math.sin(t * 3 + i) * 0.2}
            />
          ))}
          <text x="0" y="14" textAnchor="middle" fontSize="7" fill="#0E7A93" fontWeight="700">ReWater Platform</text>
        </g>

        {/* Warning message */}
        {phase > 0.5 && phase < 0.85 && (
          <g transform="translate(320, 50)" opacity={Math.min((phase - 0.5) / 0.1, 1) * (1 - Math.max(0, (phase - 0.75) / 0.1))}>
            <rect x="-65" y="-12" width="130" height="24" rx="6" fill="#FFF8E8" stroke="#F2B84B" strokeWidth="1.5" />
            <circle cx="-50" cy="0" r="5" fill="#F2B84B" opacity="0.8">
              <animate attributeName="opacity" values="0.5;1;0.5" dur="0.8s" repeatCount="indefinite" />
            </circle>
            <text x="-40" y="-1" fontSize="6" fill="#C99420" fontWeight="600">Unusual reading</text>
            <text x="-40" y="7" fontSize="5" fill="#C99420" opacity="0.7">Investigation recommended</text>
          </g>
        )}

        <text x="280" y="272" textAnchor="middle" fontSize="8" fill="#18323D" fontWeight="600" opacity="0.5">
          Building network → data flows to central platform → warnings flagged for investigation
        </text>
      </svg>
    </div>
  );
}
