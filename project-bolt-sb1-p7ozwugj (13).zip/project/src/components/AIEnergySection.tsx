import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import * as THREE from 'three';
import {
  Cpu, Zap, Droplets, BarChart3, Recycle, ArrowRight, Info, Activity, Server, Thermometer,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const PALETTE = { ocean: '#063B5C', aqua: '#1FA7C8', teal: '#48B7A5', amber: '#F2B84B', coral: '#E8734B' };

const FLOW_STEPS: { label: string; tag: string }[] = [
  { label: 'Sensor Data', tag: 'Measured' },
  { label: 'AI Analysis', tag: 'Simulated' },
  { label: 'Pattern Detection', tag: 'Simulated' },
  { label: 'Water Demand Insight', tag: 'Estimated' },
  { label: 'Reuse Opportunity', tag: 'Projected' },
  { label: 'Action', tag: 'Projected' },
];

const PIEZO_STEPS = [
  'Footsteps', 'Mechanical Pressure', 'Piezoelectric Floor', 'Electrical Energy',
  'Energy Storage', 'Low-Power AquaSense', 'Water Monitoring', 'ReWater Data',
];

const METRICS = [
  { label: 'Water entering cooling', value: 1240, unit: 'kL/day', tag: 'Measured' },
  { label: 'Water reused', value: 780, unit: 'kL/day', tag: 'Measured' },
  { label: 'Water requiring treatment', value: 320, unit: 'kL/day', tag: 'Estimated' },
  { label: 'Est. freshwater demand', value: 140, unit: 'kL/day', tag: 'Estimated' },
  { label: 'Water-quality status', value: 96, unit: '% compliant', tag: 'Measured' },
];

const TAG_STYLES: Record<string, string> = {
  Measured: 'bg-teal-100 text-teal-700',
  Estimated: 'bg-amber-100 text-amber-500',
  Simulated: 'bg-aqua-100 text-aqua-600',
  Projected: 'bg-ocean-100 text-ocean-600',
};

function Tag({ kind }: { kind: string }) {
  return (
    <span className={`inline-block text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full ${TAG_STYLES[kind] ?? 'bg-ocean-100 text-ocean-600'}`}>
      {kind}
    </span>
  );
}

function SectionCard({ icon, title, subtitle, children }: {
  icon: React.ReactNode; title: string; subtitle?: string; children: React.ReactNode;
}) {
  return (
    <section className="bg-white rounded-2xl shadow-card border border-ocean-100 p-6 sm:p-8 reveal">
      <header className="flex items-start gap-3 mb-6">
        <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-ocean-50 flex items-center justify-center text-aqua-400">{icon}</div>
        <div>
          <h3 className="font-display font-bold text-xl text-ocean-600">{title}</h3>
          {subtitle && <p className="text-sm text-slatey/70 mt-0.5">{subtitle}</p>}
        </div>
      </header>
      {children}
    </section>
  );
}

function NoteLine({ color, children }: { color: string; children: React.ReactNode }) {
  return (
    <p className="mt-4 text-xs text-slatey/60 flex items-start gap-2">
      <Info className={`w-4 h-4 mt-0.5 flex-shrink-0 ${color}`} />
      {children}
    </p>
  );
}

export function AIEnergySection() {
  const root = useRef<HTMLDivElement>(null);
  const threeMount = useRef<HTMLDivElement>(null);
  const flowRef = useRef<HTMLDivElement>(null);
  const piezoRef = useRef<HTMLDivElement>(null);
  const pathwayRef = useRef<HTMLDivElement>(null);
  const countersRef = useRef<HTMLDivElement>(null);
  const reduced = useRef(
    typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  ).current;

  // ── Three.js data-centre scene ──────────────────────────────────────────
  useEffect(() => {
    const mount = threeMount.current;
    if (!mount) return;
    let renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.PerspectiveCamera;
    let raf = 0, alive = true;
    const cleanups: (() => void)[] = [];

    try {
      scene = new THREE.Scene();
      scene.background = new THREE.Color(0xeaf4f9);
      const w = mount.clientWidth, h = mount.clientHeight || 320;
      camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
      camera.position.set(7, 5, 9);
      camera.lookAt(0, 1, 0);
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(w, h);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      mount.appendChild(renderer.domElement);
      cleanups.push(() => { mount.removeChild(renderer.domElement); renderer.dispose(); });

      scene.add(new THREE.AmbientLight(0xffffff, 0.7));
      const dir = new THREE.DirectionalLight(0xffffff, 0.7);
      dir.position.set(5, 8, 5);
      scene.add(dir);

      // Floor
      const floor = new THREE.Mesh(
        new THREE.PlaneGeometry(14, 10),
        new THREE.MeshStandardMaterial({ color: 0xc9e0ec, roughness: 0.9 }),
      );
      floor.rotation.x = -Math.PI / 2;
      scene.add(floor);

      // Server racks with heat glow
      const heatMats: THREE.MeshBasicMaterial[] = [];
      for (let i = 0; i < 4; i++) {
        const rack = new THREE.Mesh(
          new THREE.BoxGeometry(1, 2.2, 0.7),
          new THREE.MeshStandardMaterial({ color: 0x063b5c, roughness: 0.6 }),
        );
        rack.position.set(-3.5 + i * 1.2, 1.1, -1.5);
        scene.add(rack);
        const heat = new THREE.Mesh(
          new THREE.BoxGeometry(1.05, 0.15, 0.75),
          new THREE.MeshBasicMaterial({ color: 0xe8734b, transparent: true, opacity: 0.5 }),
        );
        heat.position.set(rack.position.x, 2.4, rack.position.z);
        scene.add(heat);
        heatMats.push(heat.material as THREE.MeshBasicMaterial);
      }

      // Cooling pipes (cylinders)
      const pipeMat = new THREE.MeshStandardMaterial({ color: 0x1fa7c8, roughness: 0.4 });
      const pipeH = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 5, 16), pipeMat);
      pipeH.rotation.z = Math.PI / 2;
      pipeH.position.set(-1.5, 3, -1.5);
      scene.add(pipeH);
      const pipeV = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 2.5, 16), pipeMat);
      pipeV.position.set(0.5, 2.05, -1.5);
      scene.add(pipeV);

      // Cooling tower, quality sensor, ReWater AI unit
      const tower = new THREE.Mesh(
        new THREE.CylinderGeometry(0.5, 0.6, 1.6, 16),
        new THREE.MeshStandardMaterial({ color: 0x48b7a5, roughness: 0.5 }),
      );
      tower.position.set(3.2, 0.8, 1.5);
      scene.add(tower);
      const sensor = new THREE.Mesh(
        new THREE.SphereGeometry(0.18, 16, 16),
        new THREE.MeshStandardMaterial({ color: 0xf2b84b, emissive: 0xf2b84b, emissiveIntensity: 0.3 }),
      );
      sensor.position.set(1.5, 0.4, 1.5);
      scene.add(sensor);
      const ai = new THREE.Mesh(
        new THREE.BoxGeometry(1, 0.8, 1),
        new THREE.MeshStandardMaterial({ color: 0x2e77a0, roughness: 0.5 }),
      );
      ai.position.set(-3.2, 0.4, 2.2);
      scene.add(ai);

      // Flowing water particles along a closed loop
      const N = 40;
      const positions = new Float32Array(N * 3);
      const progress = new Float32Array(N);
      for (let i = 0; i < N; i++) progress[i] = i / N;
      const pGeo = new THREE.BufferGeometry();
      pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const points = new THREE.Points(pGeo, new THREE.PointsMaterial({ color: 0x7fd3e6, size: 0.14, transparent: true, opacity: 0.85 }));
      scene.add(points);

      const path = [
        new THREE.Vector3(-3.5, 3, -1.5), new THREE.Vector3(0.5, 3, -1.5),
        new THREE.Vector3(0.5, 2.05, -1.5), new THREE.Vector3(0.5, 0.4, -1.5),
        new THREE.Vector3(3.2, 0.4, 1.5), new THREE.Vector3(1.5, 0.4, 1.5),
        new THREE.Vector3(-3.2, 0.4, 2.2), new THREE.Vector3(-3.5, 0.4, -1.5),
      ];
      const segLens = path.slice(0, -1).map((p, i) => p.distanceTo(path[i + 1]));
      const totalLen = segLens.reduce((a, b) => a + b, 0) + path[7].distanceTo(path[0]);

      const pointAt = (t: number) => {
        const dist = (t % 1) * totalLen;
        let acc = 0;
        for (let i = 0; i < path.length; i++) {
          const a = path[i], b = path[(i + 1) % path.length];
          const seg = a.distanceTo(b);
          if (acc + seg >= dist) return a.clone().lerp(b, (dist - acc) / seg);
          acc += seg;
        }
        return path[0].clone();
      };

      const onResize = () => {
        if (!mount) return;
        const nw = mount.clientWidth, nh = mount.clientHeight || 320;
        camera.aspect = nw / nh;
        camera.updateProjectionMatrix();
        renderer.setSize(nw, nh);
      };
      window.addEventListener('resize', onResize);
      cleanups.push(() => window.removeEventListener('resize', onResize));

      const animate = () => {
        if (!alive) return;
        const t = performance.now() * 0.001;
        if (!reduced) {
          for (let i = 0; i < N; i++) {
            progress[i] = (progress[i] + 0.0015) % 1;
            const p = pointAt(progress[i]);
            positions[i * 3] = p.x;
            positions[i * 3 + 1] = p.y;
            positions[i * 3 + 2] = p.z;
          }
          pGeo.attributes.position.needsUpdate = true;
          heatMats.forEach((m, i) => { m.opacity = 0.35 + Math.sin(t * 2 + i) * 0.15; });
          camera.position.x = 7 + Math.sin(t * 0.15) * 0.8;
          camera.lookAt(0, 1, 0);
        }
        renderer.render(scene, camera);
        raf = requestAnimationFrame(animate);
      };
      animate();
    } catch {
      alive = false;
    }

    return () => { alive = false; cancelAnimationFrame(raf); cleanups.forEach((c) => c()); };
  }, [reduced]);

  // ── GSAP scroll reveals & flow animations ───────────────────────────────
  useEffect(() => {
    if (!root.current) return;
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal').forEach((el) => {
        gsap.from(el, { opacity: 0, y: 40, duration: 0.7, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } });
      });
      const animateRow = (container: HTMLElement, sel: string) => {
        gsap.from(sel, { opacity: 0, x: -20, scale: 0.9, stagger: 0.12, duration: 0.5, ease: 'back.out(1.4)', scrollTrigger: { trigger: container, start: 'top 80%' } });
        gsap.to(`${sel} .flow-bar`, { scaleX: 1, duration: 0.8, ease: 'power2.out', stagger: 0.12, scrollTrigger: { trigger: container, start: 'top 80%' } });
      };
      if (flowRef.current) animateRow(flowRef.current, '.flow-step');
      if (piezoRef.current) animateRow(piezoRef.current, '.piezo-step');
      if (pathwayRef.current) animateRow(pathwayRef.current, '.path-node');
      if (countersRef.current && !reduced) {
        gsap.utils.toArray<HTMLElement>('.metric-value').forEach((el) => {
          const target = parseFloat(el.dataset.value ?? '0');
          const obj = { v: 0 };
          gsap.to(obj, {
            v: target, duration: 1.6, ease: 'power2.out', snap: { v: 1 },
            scrollTrigger: { trigger: el, start: 'top 85%' },
            onUpdate: () => { const n = el.firstChild; if (n) n.textContent = Math.round(obj.v).toLocaleString(); },
          });
        });
      }
    }, root);
    return () => ctx.revert();
  }, [reduced]);

  const legend = [
    ['Server racks', PALETTE.ocean], ['Heat', PALETTE.coral],
    ['Cooling pipes', PALETTE.aqua], ['Cooling tower', PALETTE.teal],
    ['Quality sensor', PALETTE.amber], ['ReWater AI', '#2E77A0'],
  ] as const;

  return (
    <div ref={root} className="py-16 sm:py-24 bg-mist">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-10">
        {/* Header */}
        <header className="text-center max-w-3xl mx-auto reveal">
          <div className="inline-flex items-center gap-2 text-aqua-400 mb-4">
            <Activity className="w-5 h-5" />
            <span className="text-sm font-semibold uppercase tracking-wider">Intelligence</span>
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-5xl text-ocean-600">AI, Energy &amp; Water Intelligence</h2>
          <p className="text-lg text-slatey/70 mt-4">Using AI to reduce the water footprint of AI infrastructure</p>
          <div className="mt-6 flex items-start gap-2 justify-center text-sm text-slatey/60 max-w-2xl mx-auto">
            <Info className="w-4 h-4 mt-0.5 flex-shrink-0 text-aqua-400" />
            <p className="text-left">
              More AI means more computing, more heat, and greater cooling demand — which intensifies the
              water-management challenge. ReWater does not eliminate water use; it helps monitor, analyze,
              recover and reuse water more intelligently.
            </p>
          </div>
        </header>

        {/* 1. Three.js Data Centre */}
        <SectionCard icon={<Server className="w-6 h-6" />} title="Data-Centre Cooling Cycle"
          subtitle="Computing → Heat → Cooling → Water → Monitoring → AI Analysis → Recovery → Reuse">
          <div ref={threeMount} className="w-full h-[320px] sm:h-[400px] rounded-xl bg-ocean-50 overflow-hidden" aria-label="3D data-centre cooling cycle visualization" />
          <div className="mt-4 flex flex-wrap gap-2 text-xs">
            {legend.map(([l, c]) => (
              <span key={l} className="inline-flex items-center gap-1.5 bg-ocean-50 px-2.5 py-1 rounded-full text-ocean-600">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />{l}
              </span>
            ))}
          </div>
        </SectionCard>

        {/* 2. AI Water Intelligence Flow */}
        <SectionCard icon={<Cpu className="w-6 h-6" />} title="AI Water Intelligence Flow"
          subtitle="From measured sensor data to projected reuse actions — AI represented by data analysis, not a brain">
          <div ref={flowRef} className="flex flex-wrap items-stretch gap-3">
            {FLOW_STEPS.map((s, i) => (
              <div key={s.label} className="flow-step flex items-center gap-3">
                <div className="flex flex-col items-center min-w-[120px]">
                  <div className="w-full px-4 py-3 rounded-xl bg-ocean-50 border border-ocean-100 text-center">
                    <div className="font-semibold text-sm text-ocean-600">{s.label}</div>
                    <div className="mt-1.5"><Tag kind={s.tag} /></div>
                  </div>
                  <div className="flow-bar h-1 w-full bg-aqua-400 origin-left scale-x-0 rounded-full mt-1" />
                </div>
                {i < FLOW_STEPS.length - 1 && <ArrowRight className="w-5 h-5 text-aqua-300 flex-shrink-0" />}
              </div>
            ))}
          </div>
          <NoteLine color="text-aqua-400">
            Measured = direct sensor readings · Estimated = derived from partial data · Simulated = modelled
            by AI · Projected = forecast for future states.
          </NoteLine>
        </SectionCard>

        {/* 3. Piezoelectric Energy Flow */}
        <SectionCard icon={<Zap className="w-6 h-6" />} title="Piezoelectric Energy Flow"
          subtitle="Energy harvested from movement supports low-power distributed water sensors — not the whole data centre">
          <div ref={piezoRef} className="flex flex-wrap items-stretch gap-3">
            {PIEZO_STEPS.map((s, i) => (
              <div key={s} className="piezo-step flex items-center gap-3">
                <div className="flex flex-col items-center min-w-[110px]">
                  <div className="w-full px-3 py-3 rounded-xl bg-amber-100/40 border border-amber-100 text-center">
                    <div className="font-semibold text-xs text-ocean-600">{s}</div>
                  </div>
                  <div className="flow-bar h-1 w-full bg-amber-400 origin-left scale-x-0 rounded-full mt-1" />
                </div>
                {i < PIEZO_STEPS.length - 1 && <ArrowRight className="w-5 h-5 text-amber-400 flex-shrink-0" />}
              </div>
            ))}
          </div>
          <NoteLine color="text-amber-400">
            Piezoelectric flooring converts footsteps into small amounts of electrical energy. This supports
            low-power AquaSense water sensors — it does not power the data centre or the ReWater platform as a whole.
          </NoteLine>
        </SectionCard>

        {/* 4. Cooling-Water Circularity Dashboard */}
        <SectionCard icon={<BarChart3 className="w-6 h-6" />} title="Cooling-Water Circularity Dashboard"
          subtitle="Conceptual metrics — every value labeled by data type">
          <div ref={countersRef} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {METRICS.map((m) => (
              <div key={m.label} className="bg-ocean-50 rounded-xl p-4 text-center border border-ocean-100">
                <div className="metric-value font-display font-bold text-2xl sm:text-3xl text-ocean-600 tabular-nums" data-value={m.value}>
                  <span>0</span><span className="text-sm text-aqua-400 ml-1">{m.unit}</span>
                </div>
                <div className="text-xs text-slatey/70 mt-1.5 leading-tight">{m.label}</div>
                <div className="mt-2"><Tag kind={m.tag} /></div>
              </div>
            ))}
          </div>
          <NoteLine color="text-aqua-400">
            Values are conceptual and illustrative. ReWater reduces freshwater demand by reusing cooling
            water after treatment — it does not eliminate water use entirely.
          </NoteLine>
        </SectionCard>

        {/* 5. Water Reuse Decision Pathway */}
        <SectionCard icon={<Recycle className="w-6 h-6" />} title="Water Reuse Decision Pathway"
          subtitle="Quality-gated routing: suitable water is treated and reused; the rest goes to resource recovery">
          <div ref={pathwayRef} className="space-y-4">
            <div className="flex flex-wrap items-center justify-center gap-3">
              {['Cooling Water', 'Check Quality', 'Suitable for Reuse?'].map((s, i, arr) => (
                <div key={s} className="flex items-center gap-3">
                  <div className={`path-node px-4 py-2.5 rounded-xl font-semibold text-sm ${
                    i === 0 ? 'bg-aqua-100 text-aqua-600' : i === 1 ? 'bg-amber-100 text-amber-500' : 'bg-ocean-100 text-ocean-600'
                  }`}>{s}</div>
                  {i < arr.length - 1 && <ArrowRight className="w-5 h-5 text-aqua-300" />}
                </div>
              ))}
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="rounded-xl border border-teal-200 bg-teal-50/50 p-4">
                <div className="text-xs font-bold uppercase tracking-wide text-teal-600 mb-3 flex items-center gap-1.5">
                  <Droplets className="w-4 h-4" /> If Suitable
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {['Treat', 'Store', 'Reuse'].map((s, i, arr) => (
                    <div key={s} className="flex items-center gap-2">
                      <div className="path-node px-3 py-2 rounded-lg bg-white border border-teal-200 text-teal-600 text-sm font-medium">{s}</div>
                      {i < arr.length - 1 && <ArrowRight className="w-4 h-4 text-teal-400" />}
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-xl border border-coral-400/40 bg-coral-400/10 p-4">
                <div className="text-xs font-bold uppercase tracking-wide text-coral-500 mb-3 flex items-center gap-1.5">
                  <Thermometer className="w-4 h-4" /> If Not Suitable
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {['Further Treatment', 'Resource Recovery', 'Appropriate Mgmt.'].map((s, i, arr) => (
                    <div key={s} className="flex items-center gap-2">
                      <div className="path-node px-3 py-2 rounded-lg bg-white border border-coral-400/40 text-coral-500 text-sm font-medium">{s}</div>
                      {i < arr.length - 1 && <ArrowRight className="w-4 h-4 text-coral-400" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </SectionCard>

        {/* 6. Connection */}
        <SectionCard icon={<Activity className="w-6 h-6" />} title="How It All Connects"
          subtitle="Piezoelectric energy powers sensors whose data feeds AI, which informs cooling-water reuse decisions">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {([
              ['Piezoelectric Energy', 'bg-amber-100/60 text-amber-500'],
              ['AquaSense', 'bg-aqua-100 text-aqua-600'],
              ['Water Data', 'bg-aqua-100 text-aqua-600'],
              ['AI Analysis', 'bg-ocean-100 text-ocean-600'],
              ['Cooling-Water Insight', 'bg-teal-100 text-teal-700'],
              ['Reuse Decision', 'bg-teal-100 text-teal-700'],
            ] as const).map(([label, cls], i, arr) => (
              <div key={label} className="flex items-center gap-2 sm:gap-3">
                <div className={`px-3 py-2 rounded-lg font-semibold text-sm ${cls}`}>{label}</div>
                {i < arr.length - 1 && <ArrowRight className="w-4 h-4 text-slatey/40" />}
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
