interface ScanRingProps {
  size?: number;
  active?: boolean;
  label?: string;
  sublabel?: string;
}

export function ScanRing({ size = 200, active = false, label, sublabel }: ScanRingProps) {
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Pulse rings */}
      {active && (
        <>
          <div
            className="absolute rounded-full border-2 border-aqua-400 animate-pulse-ring"
            style={{ width: size * 0.6, height: size * 0.6 }}
          />
          <div
            className="absolute rounded-full border-2 border-aqua-400 animate-pulse-ring"
            style={{ width: size * 0.6, height: size * 0.6, animationDelay: '0.7s' }}
          />
          <div
            className="absolute rounded-full border-2 border-aqua-400 animate-pulse-ring"
            style={{ width: size * 0.6, height: size * 0.6, animationDelay: '1.4s' }}
          />
        </>
      )}

      {/* Main ring */}
      <svg width={size} height={size} viewBox="0 0 200 200" className="absolute">
        <circle cx="100" cy="100" r="80" fill="none" stroke="#E4EEF2" strokeWidth="4" />
        <circle
          cx="100"
          cy="100"
          r="80"
          fill="none"
          stroke={active ? '#1FA7C8' : '#97C2D9'}
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={active ? '502' : '0'}
          strokeDashoffset={active ? '0' : '502'}
          transform="rotate(-90 100 100)"
          style={{
            transition: active ? 'stroke-dashoffset 2s ease-in-out' : 'none',
            animation: active ? 'spin 3s linear infinite' : 'none',
          }}
        />
      </svg>

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center">
        {active ? (
          <div className="text-center">
            <div className="w-12 h-12 rounded-full bg-aqua-400/20 flex items-center justify-center mb-2 mx-auto">
              <div className="w-6 h-6 rounded-full bg-aqua-400 animate-pulse" />
            </div>
            <p className="text-sm font-medium text-aqua-600">Analysing</p>
          </div>
        ) : (
          <div className="text-center">
            <p className="text-sm font-medium text-slatey/60">{label || 'Ready'}</p>
            {sublabel && <p className="text-xs text-slatey/40 mt-1">{sublabel}</p>}
          </div>
        )}
      </div>

      {/* Scan line */}
      {active && (
        <div className="absolute inset-0 overflow-hidden rounded-full" style={{ width: size * 0.8, height: size * 0.8 }}>
          <div
            className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-aqua-400 to-transparent animate-scan-line"
            style={{ boxShadow: '0 0 10px rgba(31, 167, 200, 0.6)' }}
          />
        </div>
      )}
    </div>
  );
}
