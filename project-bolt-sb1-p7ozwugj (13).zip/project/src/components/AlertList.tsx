import { AlertTriangle, Info, XCircle, CheckCircle } from 'lucide-react';
import { formatRelative } from '@/lib/utils';
import type { Alert } from '@/lib/supabase';

interface AlertListProps {
  alerts: Alert[];
  compact?: boolean;
}

export function AlertList({ alerts, compact = false }: AlertListProps) {
  if (alerts.length === 0) {
    return (
      <div className="text-center py-8 text-slatey/50">
        <CheckCircle className="mx-auto mb-2 text-teal-400" size={28} />
        <p className="text-sm">No active alerts</p>
      </div>
    );
  }

  const iconFor = (severity: string) => {
    if (severity === 'high') return <XCircle size={18} className="text-coral-400" />;
    if (severity === 'medium') return <AlertTriangle size={18} className="text-amber-400" />;
    return <Info size={18} className="text-aqua-400" />;
  };

  const bgFor = (severity: string) => {
    if (severity === 'high') return 'bg-coral-400/8 border-coral-400/20';
    if (severity === 'medium') return 'bg-amber-400/8 border-amber-400/20';
    return 'bg-aqua-50 border-aqua-100';
  };

  return (
    <div className="space-y-2">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={`flex items-start gap-3 rounded-xl border p-3 ${bgFor(alert.severity)} ${compact ? '' : 'transition-all hover:shadow-soft'}`}
        >
          <div className="flex-shrink-0 mt-0.5">{iconFor(alert.severity)}</div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slatey">
              {alert.parameter.charAt(0).toUpperCase() + alert.parameter.slice(1)}
            </p>
            <p className="text-xs text-slatey/70 mt-0.5">{alert.message}</p>
            {!compact && (
              <p className="text-xs text-slatey/40 mt-1">{formatRelative(alert.created_at)}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
