import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ArrowRight, Cpu } from 'lucide-react';

export default function AquaSensePreview({ onOpen }: { onOpen: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [webglOk, setWebglOk] = useState(true);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    } catch {
      setWebglOk(false);
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;

    const BG = 0x020f1a;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(BG);
    scene.fog = new THREE.Fog(0x042235, 20, 42);
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    camera.position.set(9, 9, 9);
    camera.lookAt(0, 0.5, 0);

    scene.add(new THREE.HemisphereLight(0xc9e0ec, 0x052e47, 0.85 * Math.PI));
    const key = new THREE.DirectionalLight(0xeaf4f9, 1.25 * Math.PI);
    key.position.set(6, 14, 8);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -11, right: 11, top: 11, bottom: -11, near: 1, far: 40 });
    key.shadow.bias = -0.0004;
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x4dd2e3, 0.8 * Math.PI);
    rim.position.set(-8, 5, -8);
    scene.add(rim);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(90, 90),
      new THREE.MeshStandardMaterial({ color: 0x052e47, roughness: 0.92, metalness: 0.05 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);
    const grid = new THREE.GridHelper(60, 60, 0x1fa7c8, 0x0f5c85);
    grid.position.y = 0.004;
    const gm = grid.material as THREE.LineBasicMaterial;
    gm.transparent = true;
    gm.opacity = 0.18;
    scene.add(grid);

    const M = (color: number, rough = 0.6, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    const mat = {
      pcb: M(0x1f7a6c, 0.55, 0.1), black: M(0x052e47, 0.55, 0.2), white: M(0xf4fafc, 0.55),
      steel: M(0xc9e0ec, 0.28, 0.9), gold: M(0xf2b84b, 0.35, 0.9), blueBoard: M(0x063b5c, 0.5, 0.1),
      whitePlastic: M(0xeaf4f9, 0.4), blueProbe: M(0x0f5c85, 0.35, 0.3),
      clear: new THREE.MeshStandardMaterial({ color: 0xc2edf5, roughness: 0.1, transparent: true, opacity: 0.35 }),
      ledOn: new THREE.MeshStandardMaterial({ color: 0x4dd2e3, emissive: 0x4dd2e3, emissiveIntensity: 1.6 }),
    };

    const station = new THREE.Group();
    scene.add(station);
    const add = (geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, parent?: THREE.Object3D | null) => {
      const mesh = new THREE.Mesh(geo, m);
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      (parent || station).add(mesh);
      return mesh;
    };
    const box = (w: number, h: number, d: number, m: THREE.Material, x: number, y: number, z: number, parent?: THREE.Object3D | null) =>
      add(new THREE.BoxGeometry(w, h, d), m, x, y, z, parent);
    const cyl = (rt: number, rb: number, h: number, m: THREE.Material, x: number, y: number, z: number, parent?: THREE.Object3D | null, seg = 24) =>
      add(new THREE.CylinderGeometry(rt, rb, h, seg), m, x, y, z, parent);
    const canvasTex = (c: HTMLCanvasElement) => {
      const t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 4;
      return t;
    };

    type V3 = [number, number, number];
    const tube = (pts: V3[], color: number, radius: number, rough = 0.5) => {
      const curve = new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(p[0], p[1], p[2])));
      const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 48, radius, 8, false), M(color, rough, 0.05));
      mesh.castShadow = true;
      station.add(mesh);
    };
    const WIRE = [0xc94545, 0xf2b84b, 0x8ad8cc, 0x2e9d8c, 0x0f5c85, 0x1f7a6c, 0x052e47, 0x97c2d9];
    const wire = (a: V3, b: V3, ci: number, lift = 0.7) => {
      const mid: V3 = [(a[0] + b[0]) / 2, Math.max(a[1], b[1]) + lift, (a[2] + b[2]) / 2];
      tube([a, [a[0], a[1] + 0.25, a[2]], mid, [b[0], b[1] + 0.25, b[2]], b], WIRE[ci % WIRE.length], 0.035, 0.55);
    };

    box(3.8, 0.3, 5.8, mat.white, 0, 0.15, 0);
    {
      const c = document.createElement('canvas');
      c.width = 380; c.height = 580;
      const g = c.getContext('2d')!;
      g.fillStyle = '#f4fafc'; g.fillRect(0, 0, 380, 580);
      g.fillStyle = '#c9e0ec';
      for (let y = 24; y < 560; y += 18) {
        for (let x = 66; x < 314; x += 18) { if (x > 178 && x < 202) continue; g.fillRect(x, y, 5, 5); }
        for (let rx = 0; rx < 2; rx++) { g.fillRect(rx ? 338 : 30, y, 5, 5); g.fillRect(rx ? 352 : 16, y, 5, 5); }
      }
      g.fillStyle = '#5e9bbf'; g.fillRect(186, 0, 8, 580);
      g.fillStyle = '#c94545'; g.fillRect(12, 0, 3, 580); g.fillRect(348, 0, 3, 580);
      g.fillStyle = '#0f5c85'; g.fillRect(44, 0, 3, 580); g.fillRect(332, 0, 3, 580);
      const t = canvasTex(c); t.anisotropy = 8;
      const p = new THREE.Mesh(new THREE.PlaneGeometry(3.8, 5.8), new THREE.MeshStandardMaterial({ map: t, roughness: 0.6 }));
      p.rotation.x = -Math.PI / 2; p.position.y = 0.302; p.receiveShadow = true;
      station.add(p);
    }

    const ex = 0.75;
    box(1.3, 0.1, 2.7, mat.black, ex, 0.36, 0);
    box(0.07, 0.07, 2.5, mat.gold, ex - 0.55, 0.43, 0);
    box(0.07, 0.07, 2.5, mat.gold, ex + 0.55, 0.43, 0);
    box(0.75, 0.09, 0.95, mat.steel, ex, 0.45, -0.85);
    box(0.42, 0.05, 0.42, M(0x042235, 0.4, 0.3), ex, 0.43, 0.15);
    box(0.4, 0.2, 0.34, mat.steel, ex, 0.46, 1.42);
    {
      const c = document.createElement('canvas'); c.width = 440; c.height = 112;
      const g = c.getContext('2d')!;
      g.fillStyle = '#c9e0ec'; g.font = '600 54px Inter, Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText('ESP32 DevKit V1', 220, 56);
      const l = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.28), new THREE.MeshBasicMaterial({ map: canvasTex(c), transparent: true }));
      l.rotation.x = -Math.PI / 2; l.position.set(ex, 0.415, 0.75);
      station.add(l);
    }

    const OC = { x: -1.15, y: 0.5, z: -1.0 };
    box(1.9, 0.12, 1.2, mat.blueBoard, OC.x, OC.y, OC.z);
    box(1.62, 0.03, 0.9, M(0x031726, 0.3), OC.x, OC.y + 0.075, OC.z);
    for (let i = 0; i < 4; i++) box(0.09, 0.2, 0.09, mat.black, OC.x - 0.6 + i * 0.4, 0.4, OC.z + 0.52);
    const oledCanvas = document.createElement('canvas');
    oledCanvas.width = 512; oledCanvas.height = 256;
    const oledTex = canvasTex(oledCanvas);
    const oledScreen = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.75), new THREE.MeshBasicMaterial({ map: oledTex }));
    oledScreen.rotation.x = -Math.PI / 2;
    oledScreen.position.set(OC.x, OC.y + 0.095, OC.z);
    station.add(oledScreen);

    const tb = new THREE.Group(); tb.position.set(-3.3, 0.06, -3.3); tb.rotation.y = 0.35; station.add(tb);
    box(1.9, 0.1, 1.5, mat.pcb, 0, 0, 0, tb);
    box(0.9, 0.45, 0.8, mat.whitePlastic, -0.25, 0.28, -0.1, tb);
    box(0.5, 0.2, 0.36, M(0xc9e0ec, 0.5), -0.25, 0.4, -0.1, tb);
    for (let i = 0; i < 5; i++) box(0.08, 0.2, 0.08, mat.black, -0.4 + i * 0.2, 0.1, 0.68, tb);
    tube([[-3.7, 0.3, -4.1], [-4.6, 0.3, -4.8], [-5.8, 0.25, -5.2], [-7, 0.2, -4.4]], 0x052e47, 0.07, 0.6);

    const pb = new THREE.Group(); pb.position.set(2.6, 0.06, -3.1); station.add(pb);
    box(1.6, 0.1, 1.0, mat.pcb, 0, 0, 0, pb);
    cyl(0.2, 0.2, 0.75, mat.steel, 1.05, 0.28, 0, pb, 28).rotation.z = Math.PI / 2;
    cyl(0.13, 0.13, 0.2, mat.steel, 1.5, 0.28, 0, pb, 24).rotation.z = Math.PI / 2;
    for (let i = 0; i < 4; i++) box(0.08, 0.2, 0.08, mat.black, -0.55 + i * 0.25, 0.1, 0.4, pb);
    tube([[3.75, 0.34, -3.1], [4.0, 0.3, -2.4], [3.3, 0.3, -1.2], [3.0, 0.3, 0.6], [3.3, 0.3, 2.2], [3.35, 0.3, 3.0]], 0x0f5c85, 0.075, 0.45);
    const probe = new THREE.Group(); probe.position.set(3.0, 0.36, 4.0); probe.rotation.y = -0.45; station.add(probe);
    cyl(0.17, 0.17, 2.0, mat.clear, 0, 0, 0, probe, 24).rotation.x = Math.PI / 2;
    cyl(0.09, 0.09, 1.7, mat.blueProbe, 0, 0, 0.05, probe, 20).rotation.x = Math.PI / 2;

    const tdsG = new THREE.Group(); tdsG.position.set(-3.3, 0.06, 2.5); tdsG.rotation.y = 0.5; station.add(tdsG);
    box(1.9, 0.1, 1.1, mat.pcb, 0, 0, 0, tdsG);
    cyl(0.2, 0.2, 0.22, mat.steel, -0.6, 0.15, 0, tdsG, 20);
    for (let i = 0; i < 6; i++) box(0.08, 0.2, 0.08, mat.black, -0.2 + i * 0.17, 0.1, -0.48, tdsG);
    tube([[-2.35, 0.25, 3.25], [-2.2, 0.15, 4.0], [-2.7, 0.14, 4.7], [-3.4, 0.14, 4.8]], 0x052e47, 0.065, 0.6);
    cyl(0.14, 0.14, 2.1, mat.steel, -4.5, 0.16, 4.8, null, 24).rotation.z = Math.PI / 2;
    cyl(0.1, 0.1, 0.4, mat.black, -3.35, 0.16, 4.8, null, 16).rotation.z = Math.PI / 2;

    const pwr = new THREE.Group(); pwr.position.set(5.0, 0.38, 0.6); station.add(pwr);
    box(2.0, 0.76, 3.2, M(0x042235, 0.5, 0.15), 0, 0, 0, pwr);
    box(0.06, 0.18, 0.5, mat.steel, -1.0, 0.0, -0.8, pwr);
    for (let i = 0; i < 3; i++) add(new THREE.SphereGeometry(0.05, 12, 12), mat.ledOn, -0.45 + i * 0.22, 0.4, 1.2, pwr);
    tube([[0.75, 0.46, 1.6], [0.75, 0.4, 2.3], [1.4, 0.3, 3.3], [2.6, 0.3, 3.3], [3.4, 0.45, 2.6], [3.5, 0.5, 1.2], [3.95, 0.55, -0.2]], 0x97c2d9, 0.09, 0.35);

    wire([-3.0, 0.25, -2.7], [-1.6, 0.34, -0.1], 0, 0.9);
    wire([-2.9, 0.25, -2.7], [-1.7, 0.34, 0.4], 1, 1.0);
    wire([-2.8, 0.25, -2.7], [-1.5, 0.34, 1.1], 2, 0.8);
    wire([2.2, 0.2, -2.6], [1.7, 0.34, -1.4], 3, 0.8);
    wire([2.45, 0.2, -2.6], [1.65, 0.34, -0.9], 4, 0.9);
    wire([2.7, 0.2, -2.6], [1.6, 0.34, -0.3], 5, 1.0);
    wire([-2.9, 0.2, 1.8], [-1.3, 0.34, 1.6], 6, 0.7);
    wire([-2.7, 0.2, 1.9], [-1.4, 0.34, 2.1], 0, 0.8);
    wire([-2.5, 0.2, 2.0], [-1.5, 0.34, 2.5], 7, 0.7);
    wire([-1.5, 0.4, -0.45], [-0.2, 0.34, -0.5], 3, 0.7);
    wire([-1.1, 0.4, -0.45], [-0.15, 0.34, 0.1], 2, 0.9);
    wire([-0.7, 0.4, -0.45], [-0.1, 0.34, 0.7], 1, 1.0);

    const vals = { turb: 12.4, tds: 256, ph: 7.23, temp: 24.6 };
    const base = { ...vals };
    const drawOled = () => {
      const g = oledCanvas.getContext('2d')!;
      g.fillStyle = '#031726'; g.fillRect(0, 0, 512, 256);
      g.fillStyle = '#c2edf5'; g.font = '600 38px "Courier New", monospace'; g.textBaseline = 'middle';
      const lines = [`Turbidity: ${vals.turb.toFixed(1)} NTU`, `TDS: ${Math.round(vals.tds)} ppm`, `pH: ${vals.ph.toFixed(2)}`, `Temp: ${vals.temp.toFixed(1)} C`];
      lines.forEach((t, k) => g.fillText(t, 28, 40 + k * 58));
      oledTex.needsUpdate = true;
    };
    const jitter = () => {
      vals.turb = base.turb + (Math.random() - 0.5) * 0.6;
      vals.tds = base.tds + (Math.random() - 0.5) * 6;
      vals.ph = base.ph + (Math.random() - 0.5) * 0.06;
      vals.temp = base.temp + (Math.random() - 0.5) * 0.2;
      drawOled();
    };
    drawOled();
    const jitterId = reduce ? 0 : window.setInterval(jitter, 1600);

    let W = 1, H = 1;
    const resize = () => {
      const rect = container.getBoundingClientRect();
      W = rect.width; H = rect.height;
      if (W < 1 || H < 1) return;
      renderer.setSize(W, H, false);
      camera.aspect = W / H; camera.updateProjectionMatrix();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    let visible = false;
    const io = new IntersectionObserver((entries) => {
      visible = entries[0]?.isIntersecting ?? false;
    }, { threshold: 0.01 });
    io.observe(container);

    let userRotY = 0;
    let autoRot = reduce ? 0 : 0.15;
    let dragging = false;
    let lastX = 0;
    const onPointerDown = (e: PointerEvent) => {
      dragging = true; lastX = e.clientX;
      (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!dragging) return;
      userRotY += (e.clientX - lastX) * 0.01;
      lastX = e.clientX;
    };
    const onPointerUp = () => { dragging = false; };
    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('pointercancel', onPointerUp);

    let raf = 0;
    const t0 = performance.now();
    const frame = (now: number) => {
      const time = (now - t0) / 1000;
      if (!dragging) userRotY += autoRot * 0.016;
      station.rotation.y = userRotY;
      mat.ledOn.emissiveIntensity = 1.2 + (reduce ? 0.4 : Math.sin(time * 2.2) * 0.4);
      if (visible) renderer.render(scene, camera);
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      if (jitterId) window.clearInterval(jitterId);
      ro.disconnect();
      io.disconnect();
      canvas.removeEventListener('pointerdown', onPointerDown);
      canvas.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('pointerup', onPointerUp);
      canvas.removeEventListener('pointercancel', onPointerUp);
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        const mm = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mm)) mm.forEach((x) => x.dispose()); else mm?.dispose();
      });
      oledTex.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div className="rounded-3xl overflow-hidden bg-ocean-950 border border-white/10">
      <div className="grid md:grid-cols-2 gap-0">
        <div className="p-6 sm:p-8 flex flex-col justify-center">
          <span className="inline-flex items-center gap-2 self-start bg-amber-400/15 text-amber-400 rounded-full px-3 py-1 text-xs font-medium mb-4">
            <Cpu size={12} /> Concept prototype
          </span>
          <h3 className="font-display font-bold text-2xl text-white mb-3">Meet AquaSense</h3>
          <p className="text-white/90 text-sm leading-relaxed mb-5">
            A small ESP32 station that measures pH, TDS, turbidity and temperature, then sends the same reading to your Water Passport.
          </p>
          <div className="flex flex-wrap gap-2 mb-6">
            {['pH', 'TDS / EC', 'Turbidity + temperature'].map((chip) => (
              <span key={chip} className="bg-white/10 text-aqua-200 rounded-full px-3 py-1 text-xs font-medium">{chip}</span>
            ))}
          </div>
          <button
            onClick={onOpen}
            className="inline-flex items-center gap-2 bg-white text-ocean-600 rounded-xl px-5 py-2.5 text-sm font-medium border border-white/20 transition-all duration-200 hover:bg-aqua-100 hover:border-aqua-300 active:scale-95 self-start"
          >
            Explore the AquaSense model <ArrowRight size={16} />
          </button>
        </div>

        <div className="relative bg-ocean-950" ref={containerRef} style={{ aspectRatio: '4 / 3', minHeight: 280 }}>
          {webglOk ? (
            <>
              <canvas
                ref={canvasRef}
                className="absolute inset-0 w-full h-full"
                style={{ touchAction: 'pan-y', cursor: 'grab' }}
              />
              <p className="absolute bottom-2 right-3 text-xs text-white/40">Drag to rotate</p>
            </>
          ) : (
            <div className="absolute inset-0 grid place-items-center text-center p-6">
              <div>
                <Cpu size={32} className="text-aqua-300 mx-auto mb-2" />
                <p className="text-sm text-white/70">3D preview unavailable</p>
              </div>
            </div>
          )}
        </div>
      </div>
      <p className="px-6 sm:px-8 pb-5 text-xs text-white/40">AquaSense is future hardware. Readings shown are examples.</p>
    </div>
  );
}
