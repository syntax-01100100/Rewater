'use client';
import { ReactLenis } from 'lenis/react';
import 'lenis/dist/lenis.css';
import React, { forwardRef } from 'react';

type SmoothScrollProps = {
  children: React.ReactNode;
};

const SmoothScroll = forwardRef<HTMLElement, SmoothScrollProps>(({ children }, ref) => {
  return (
    <ReactLenis root options={{ duration: 1.2, smoothWheel: true, syncTouch: false }}>
      <main ref={ref as React.Ref<HTMLElement>}>{children}</main>
    </ReactLenis>
  );
});

SmoothScroll.displayName = 'SmoothScroll';

export default SmoothScroll;
