import { useEffect, useState, useRef } from 'react';

interface AnimationProps {
  stageId: string;
  sourceColor: string;
  reducedMotion?: boolean;
}

const colorMap: Record<string, { primary: string; light: string; dark: string }> = {
  aqua: { primary: '#1FA7C8', light: '#7FD3E6', dark: '#0E7A93' },
  teal: { primary: '#48B7A5', light: '#8FD9CE', dark: '#2A8B7A' },
  ocean: { primary: '#2E77A0', light: '#7DB3CE', dark: '#1A5278' },
  amber: { primary: '#F2B84B', light: '#F8D98E', dark: '#C99420' },
  coral: { primary: '#D95C5C', light: '#E89797', dark: '#B04040' },
};

export function WaterTreatmentAnimation({ stageId, sourceColor, reducedMotion = false }: AnimationProps) {
  const c = colorMap[sourceColor] || colorMap.aqua;
  const [tick, setTick] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (reducedMotion) return;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = now - last;
      if (dt > 50) {
        setTick(t => t + 1);
        last = now;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [reducedMotion]);

  const t = tick * 0.05;

  return (
    <div className="w-full" style={{ maxWidth: 500, margin: '0 auto' }}>
      <svg viewBox="0 0 500 240" className="w-full" style={{ overflow: 'visible' }}>
        <defs>
          <linearGradient id="waterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={c.light} stopOpacity="0.7" />
            <stop offset="100%" stopColor={c.primary} stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="cleanWaterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#8FD9CE" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#48B7A5" stopOpacity="0.4" />
          </linearGradient>
          <linearGradient id="dirtyWaterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#D4A574" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#B8860B" stopOpacity="0.4" />
          </linearGradient>
          <radialGradient id="bubbleGrad">
            <stop offset="0%" stopColor="white" stopOpacity="0.8" />
            <stop offset="100%" stopColor={c.light} stopOpacity="0.3" />
          </radialGradient>
          <clipPath id="tankClip">
            <rect x="0" y="0" width="500" height="240" rx="16" />
          </clipPath>
        </defs>

        <g clipPath="url(#tankClip)">
          {/* Background */}
          <rect x="0" y="0" width="500" height="240" fill="#F0F7FA" />

          {reducedMotion ? <StaticScene stageId={stageId} c={c} /> : <AnimatedScene stageId={stageId} c={c} t={t} />}
        </g>
      </svg>
    </div>
  );
}

// ─── Static scene for reduced motion ───────────────────────────────────────

function StaticScene({ stageId, c }: { stageId: string; c: { primary: string; light: string; dark: string } }) {
  return (
    <g>
      {/* Pipe */}
      <rect x="0" y="100" width="500" height="20" fill={c.primary} opacity="0.15" rx="4" />
      <TankBody c={c} />
      <WaterInTank c={c} level={120} />
      <StageIcon stageId={stageId} c={c} x={250} y={80} />
    </g>
  );
}

// ─── Animated scenes per stage ──────────────────────────────────────────────

function AnimatedScene({ stageId, c, t }: { stageId: string; c: { primary: string; light: string; dark: string }; t: number }) {
  switch (stageId) {
    case 'source': return <SourceAnimation c={c} t={t} />;
    case 'check': return <CheckAnimation c={c} t={t} />;
    case 'screen': return <ScreenAnimation c={c} t={t} />;
    case 'sediment': return <SedimentAnimation c={c} t={t} />;
    case 'filter': return <FilterAnimation c={c} t={t} />;
    case 'treat': return <TreatAnimation c={c} t={t} />;
    case 'membrane': return <MembraneAnimation c={c} t={t} />;
    case 'disinfect': return <DisinfectAnimation c={c} t={t} />;
    case 'recover': return <RecoverAnimation c={c} t={t} />;
    case 'reuse': return <ReuseAnimation c={c} t={t} />;
    case 'retest': return <RetestAnimation c={c} t={t} />;
    default: return <SourceAnimation c={c} t={t} />;
  }
}

// ─── Shared SVG elements ────────────────────────────────────────────────────

function TankBody({ c, x = 170, y = 50, w = 160, h = 140 }: { c: { primary: string; light: string; dark: string }; x?: number; y?: number; w?: number; h?: number }) {
  return (
    <g>
      {/* Tank walls */}
      <path d={`M ${x} ${y} L ${x} ${y + h} L ${x + w} ${y + h} L ${x + w} ${y}`} fill="none" stroke={c.dark} strokeWidth="3" strokeLinecap="round" />
      {/* Tank bottom rounded */}
      <path d={`M ${x} ${y + h} Q ${x + w / 2} ${y + h + 8} ${x + w} ${y + h}`} fill="none" stroke={c.dark} strokeWidth="3" strokeLinecap="round" />
      {/* Tank top open */}
      <line x1={x - 5} y1={y} x2={x + 5} y2={y} stroke={c.dark} strokeWidth="3" strokeLinecap="round" />
      <line x1={x + w - 5} y1={y} x2={x + w + 5} y2={y} stroke={c.dark} strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

function WaterInTank({ c, level, x = 172, w = 156, t = 0 }: { c: { primary: string; light: string; dark: string }; level: number; x?: number; w?: number; t?: number }) {
  const waveOffset = Math.sin(t) * 3;
  return (
    <g>
      <path
        d={`M ${x} ${level + waveOffset} 
            Q ${x + w / 4} ${level + waveOffset - 4} ${x + w / 2} ${level + waveOffset}
            T ${x + w} ${level + waveOffset}
            L ${x + w} 188 L ${x} 188 Z`}
        fill="url(#waterGrad)"
      />
      {/* Surface ripples */}
      <ellipse cx={x + w * 0.3} cy={level + waveOffset} rx="15" ry="2" fill={c.light} opacity="0.4">
        <animate attributeName="rx" values="10;20;10" dur="3s" repeatCount="indefinite" />
      </ellipse>
    </g>
  );
}

function Pipe({ x1, y1, x2, y2, c, flow = true, t = 0 }: { x1: number; y1: number; x2: number; y2: number; c: { primary: string; light: string; dark: string }; flow?: boolean; t?: number }) {
  const len = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
  const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
  const dashOffset = flow ? (t * 20) % 20 : 0;
  return (
    <g transform={`translate(${x1},${y1}) rotate(${angle})`}>
      {/* Pipe outer */}
      <rect x="0" y="-8" width={len} height="16" fill={c.dark} opacity="0.15" rx="3" />
      <rect x="0" y="-6" width={len} height="12" fill={c.primary} opacity="0.1" rx="2" />
      {/* Flowing water */}
      {flow && (
        <line x1="0" y1="0" x2={len} y2="0" stroke={c.primary} strokeWidth="6" strokeDasharray="8 4" strokeDashoffset={-dashOffset} opacity="0.6" strokeLinecap="round">
          <animate attributeName="stroke-dashoffset" from="0" to="-24" dur="1.5s" repeatCount="indefinite" />
        </line>
      )}
    </g>
  );
}

function Droplet({ cx, cy, r, color, t, delay = 0 }: { cx: number; cy: number; r: number; color: string; t: number; delay?: number }) {
  const yOffset = Math.sin(t + delay) * 4;
  return (
    <g transform={`translate(${cx},${cy + yOffset})`}>
      <path d={`M 0 ${-r} Q ${-r} ${r * 0.3} 0 ${r} Q ${r} ${r * 0.3} 0 ${-r} Z`} fill={color} opacity="0.8">
        <animate attributeName="opacity" values="0.6;0.9;0.6" dur="2s" repeatCount="indefinite" />
      </path>
    </g>
  );
}

function StageIcon({ stageId, c, x, y }: { stageId: string; c: { primary: string; light: string; dark: string }; x: number; y: number }) {
  const icons: Record<string, React.ReactNode> = {
    source: <circle cx={x} cy={y} r="20" fill={c.primary} opacity="0.2"><animate attributeName="r" values="18;22;18" dur="2s" repeatCount="indefinite" /></circle>,
    check: <rect x={x - 18} y={y - 18} width="36" height="36" rx="8" fill={c.primary} opacity="0.15" />,
    screen: <g><line x1={x - 15} y1={y - 15} x2={x - 15} y2={y + 15} stroke={c.dark} strokeWidth="2" /><line x1={x - 5} y1={y - 15} x2={x - 5} y2={y + 15} stroke={c.dark} strokeWidth="2" /><line x1={x + 5} y1={y - 15} x2={x + 5} y2={y + 15} stroke={c.dark} strokeWidth="2" /><line x1={x + 15} y1={y - 15} x2={x + 15} y2={y + 15} stroke={c.dark} strokeWidth="2" /></g>,
    filter: <g><rect x={x - 20} y={y - 15} width="40" height="6" fill={c.primary} opacity="0.2" rx="2" /><rect x={x - 20} y={y - 7} width="40" height="6" fill="#D4A574" opacity="0.3" rx="2" /><rect x={x - 20} y={y + 1} width="40" height="6" fill={c.primary} opacity="0.15" rx="2" /></g>,
  };
  return <g>{icons[stageId] || icons.source}</g>;
}

// ─── Individual stage animations ────────────────────────────────────────────

function SourceAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet pipe with flowing water */}
      <Pipe x1={0} y1={110} x2={170} y2={110} c={c} t={t} />
      {/* Tank */}
      <TankBody c={c} />
      <WaterInTank c={c} level={100} t={t} />
      {/* Droplets falling from pipe */}
      {[0, 1, 2].map(i => (
        <Droplet key={i} cx={140 + i * 10} cy={95 + Math.sin(t + i) * 5} r={4} color={c.primary} t={t} delay={i} />
      ))}
      {/* Bubbles in tank */}
      {[0, 1, 2, 3, 4].map(i => (
        <circle key={i} cx={200 + i * 20} cy={150 + Math.sin(t + i) * 10} r={3 + (i % 2)} fill="url(#bubbleGrad)">
          <animate attributeName="cy" values={`${150 + Math.sin(t + i) * 10};${130 + Math.sin(t + i) * 10};${150 + Math.sin(t + i) * 10}`} dur="3s" repeatCount="indefinite" />
        </circle>
      ))}
      {/* Outlet pipe */}
      <Pipe x1={330} y1={110} x2={500} y2={110} c={c} t={t} />
      {/* Label */}
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Water enters the system</text>
    </g>
  );
}

function CheckAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Water sample container */}
      <rect x="200" y="60" width="100" height="100" rx="8" fill="none" stroke={c.dark} strokeWidth="3" />
      <path d="M 202 120 Q 250 116 298 120 L 298 158 L 202 158 Z" fill="url(#waterGrad)" />
      {/* Sensor probe descending */}
      <g transform={`translate(250,${45 + Math.sin(t) * 3})`}>
        <line x1="0" y1="0" x2="0" y2="20" stroke={c.dark} strokeWidth="2" />
        <rect x="-12" y="20" width="24" height="16" rx="3" fill={c.primary} opacity="0.3" stroke={c.dark} strokeWidth="1.5" />
        <circle cx="0" cy="28" r="3" fill={c.primary}>
          <animate attributeName="opacity" values="0.5;1;0.5" dur="1.5s" repeatCount="indefinite" />
        </circle>
      </g>
      {/* Scanning wave */}
      {[0, 1, 2].map(i => (
        <ellipse key={i} cx="250" cy="110" rx={20 + i * 12 + Math.sin(t + i) * 4} ry={15 + i * 8 + Math.sin(t + i) * 3} fill="none" stroke={c.light} strokeWidth="1.5" opacity={0.4 - i * 0.1}>
          <animate attributeName="rx" values={`${20 + i * 12};${28 + i * 12};${20 + i * 12}`} dur="2s" repeatCount="indefinite" />
          <animate attributeName="ry" values={`${15 + i * 8};${21 + i * 8};${15 + i * 8}`} dur="2s" repeatCount="indefinite" />
        </ellipse>
      ))}
      {/* Check marks appearing */}
      {[0, 1, 2].map(i => (
        <g key={i} transform={`translate(${210 + i * 30},${175})`}>
          <circle cx="0" cy="0" r="8" fill="#48B7A5" opacity={0.3 + Math.sin(t + i * 2) * 0.2} />
          <path d="M -4 0 L -1 3 L 4 -3" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" />
        </g>
      ))}
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Testing what's in the water</text>
    </g>
  );
}

function ScreenAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet pipe */}
      <Pipe x1={0} y1={110} x2={160} y2={110} c={c} t={t} />
      {/* Screen bars */}
      <g>
        {[0, 1, 2, 3, 4, 5].map(i => (
          <line key={i} x1={170 + i * 8} y1="70" x2={170 + i * 8} y2="150" stroke={c.dark} strokeWidth="3" strokeLinecap="round" />
        ))}
      </g>
      {/* Large particles being caught */}
      {[0, 1, 2, 3].map(i => (
        <g key={i}>
          <circle cx={172 + i * 12} cy={80 + (i % 2) * 8} r={4 + (i % 2) * 2} fill="#8B7355" opacity="0.6">
            <animate attributeName="cy" values={`${80 + (i % 2) * 8};${75 + (i % 2) * 8};${80 + (i % 2) * 8}`} dur="2s" repeatCount="indefinite" />
          </circle>
        </g>
      ))}
      {/* Water flowing through screen */}
      {[0, 1, 2, 3, 4].map(i => (
        <Droplet key={i} cx={175 + i * 10} cy={110 + Math.sin(t + i) * 4} r={3} color={c.light} t={t} delay={i * 0.3} />
      ))}
      {/* Debris pile on left side */}
      <g>
        <circle cx="165" cy="148" r="5" fill="#8B7355" opacity="0.5" />
        <circle cx="172" cy="152" r="4" fill="#8B7355" opacity="0.4" />
        <circle cx="158" cy="150" r="3" fill="#8B7355" opacity="0.5" />
      </g>
      {/* Outlet pipe */}
      <Pipe x1={220} y1={110} x2={500} y2={110} c={c} t={t} />
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Large particles caught · Water passes through</text>
    </g>
  );
}

function SedimentAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet pipe at top */}
      <Pipe x1={0} y1={50} x2={200} y2={50} c={c} t={t} />
      <Droplet cx={195} cy={55} r={4} color={c.primary} t={t} />
      {/* Sedimentation tank */}
      <TankBody c={c} x={170} y={60} w={160} h={130} />
      {/* Water in tank */}
      <WaterInTank c={c} level={100} x={172} w={156} t={t} />
      {/* Particles settling — animated falling */}
      {[0, 1, 2, 3, 4, 5, 6].map(i => {
        const cycle = (t * 0.3 + i * 0.7) % 4;
        const yProgress = 100 + cycle * 25;
        return (
          <circle
            key={i}
            cx={190 + i * 18}
            cy={yProgress}
            r={3 + (i % 2)}
            fill="#8B7355"
            opacity={0.5 - cycle * 0.08}
          >
            <animate attributeName="cy" values={`${100};${180}`} dur={`${4 + i * 0.5}s`} repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.6;0.3;0.5" dur={`${4 + i * 0.5}s`} repeatCount="indefinite" />
          </circle>
        );
      })}
      {/* Settled sludge at bottom */}
      <g>
        <ellipse cx="210" cy="185" rx="40" ry="5" fill="#8B7355" opacity="0.4" />
        <ellipse cx="270" cy="186" rx="30" ry="4" fill="#8B7355" opacity="0.35" />
      </g>
      {/* Clear water zone indicator */}
      <rect x="175" y="105" width="150" height="4" fill={c.light} opacity="0.3" rx="2">
        <animate attributeName="opacity" values="0.2;0.4;0.2" dur="3s" repeatCount="indefinite" />
      </rect>
      {/* Outlet — clear water exits from top */}
      <Pipe x1={330} y1={90} x2={500} y2={90} c={c} t={t} />
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Particles settle · Clearer water moves on</text>
    </g>
  );
}

function FilterAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet pipe */}
      <Pipe x1={0} y1={60} x2={180} y2={60} c={c} t={t} />
      {/* Filter housing */}
      <g>
        <path d="M 180 55 L 180 90 L 220 100 L 280 100 L 320 90 L 320 55 Z" fill="none" stroke={c.dark} strokeWidth="3" strokeLinejoin="round" />
        {/* Filter layers */}
        <rect x="185" y="95" width="130" height="8" fill={c.primary} opacity="0.15" />
        <rect x="185" y="105" width="130" height="6" fill="#D4A574" opacity="0.25" />
        <rect x="185" y="113" width="130" height="8" fill={c.primary} opacity="0.1" />
        <rect x="185" y="123" width="130" height="6" fill="#48B7A5" opacity="0.15" />
        {/* Layer labels */}
        <text x="250" y="102" textAnchor="middle" fontSize="6" fill={c.dark} opacity="0.5">sand</text>
        <text x="250" y="111" textAnchor="middle" fontSize="6" fill="#8B7355" opacity="0.5">carbon</text>
        <text x="250" y="120" textAnchor="middle" fontSize="6" fill={c.dark} opacity="0.5">fine</text>
      </g>
      {/* Water entering filter — dirty */}
      {[0, 1, 2].map(i => (
        <Droplet key={i} cx={190 + i * 10} cy={75 + Math.sin(t + i) * 3} r={4} color={c.primary} t={t} delay={i} />
      ))}
      {/* Particles being trapped in filter */}
      {[0, 1, 2, 3].map(i => (
        <circle key={i} cx={195 + i * 30} cy={97 + (i % 2) * 3} r={2} fill="#8B7355" opacity="0.5" />
      ))}
      {/* Clean water exiting */}
      {[0, 1, 2].map(i => (
        <Droplet key={i} cx={260 + i * 10} cy={140 + Math.sin(t + i) * 3} r={4} color={c.light} t={t} delay={i} />
      ))}
      {/* Outlet pipe */}
      <Pipe x1={250} y1={150} x2={500} y2={150} c={c} t={t} />
      {/* Clean water label indicator */}
      <g transform="translate(380,170)">
        <circle cx="0" cy="0" r="10" fill="#48B7A5" opacity="0.2" />
        <path d="M -4 0 L -1 3 L 4 -3" fill="none" stroke="#48B7A5" strokeWidth="2" strokeLinecap="round" />
      </g>
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Layers trap particles · Cleaner water passes through</text>
    </g>
  );
}

function TreatAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Branching treatment paths */}
      <Pipe x1={0} y1={110} x2={120} y2={110} c={c} t={t} />
      {/* Branch point */}
      <circle cx="120" cy="110" r="4" fill={c.dark} />
      {/* Upper branch — Clarification */}
      <g opacity={0.6 + Math.sin(t) * 0.2}>
        <path d="M 120 110 L 120 70 L 220 70" fill="none" stroke={c.dark} strokeWidth="2" strokeDasharray="4 3" />
        <rect x="220" y="55" width="70" height="30" rx="6" fill={c.primary} opacity="0.12" stroke={c.dark} strokeWidth="1.5" />
        <text x="255" y="74" textAnchor="middle" fontSize="8" fill={c.dark}>Clarify</text>
      </g>
      {/* Middle branch — Adsorption */}
      <g opacity={0.6 + Math.sin(t + 2) * 0.2}>
        <line x1="120" y1="110" x2="220" y2="110" stroke={c.dark} strokeWidth="2" strokeDasharray="4 3" />
        <rect x="220" y="95" width="70" height="30" rx="6" fill={c.primary} opacity="0.12" stroke={c.dark} strokeWidth="1.5" />
        <text x="255" y="114" textAnchor="middle" fontSize="8" fill={c.dark}>Adsorb</text>
      </g>
      {/* Lower branch — Membrane */}
      <g opacity={0.6 + Math.sin(t + 4) * 0.2}>
        <path d="M 120 110 L 120 150 L 220 150" fill="none" stroke={c.dark} strokeWidth="2" strokeDasharray="4 3" />
        <rect x="220" y="135" width="70" height="30" rx="6" fill={c.primary} opacity="0.12" stroke={c.dark} strokeWidth="1.5" />
        <text x="255" y="154" textAnchor="middle" fontSize="8" fill={c.dark}>Membrane</text>
      </g>
      {/* Converging pipes */}
      <Pipe x1={290} y1={70} x2={380} y2={70} c={c} t={t} />
      <Pipe x1={290} y1={110} x2={380} y2={110} c={c} t={t} />
      <Pipe x1={290} y1={150} x2={380} y2={150} c={c} t={t} />
      {/* Convergence */}
      <path d="M 380 70 L 400 70 L 420 110 M 380 110 L 420 110 M 380 150 L 400 150 L 420 110" fill="none" stroke={c.dark} strokeWidth="2" opacity="0.3" />
      <Pipe x1={420} y1={110} x2={500} y2={110} c={c} t={t} />
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Treatment branches based on what was detected</text>
    </g>
  );
}

function MembraneAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet */}
      <Pipe x1={0} y1={110} x2={160} y2={110} c={c} t={t} />
      {/* Membrane housing */}
      <g>
        <rect x="160" y="60" width="80" height="120" rx="8" fill="none" stroke={c.dark} strokeWidth="3" />
        {/* Membrane sheets */}
        {[0, 1, 2, 3].map(i => (
          <line key={i} x1={175 + i * 14} y1="70" x2={175 + i * 14} y2="170" stroke={c.primary} strokeWidth="2" opacity="0.3" strokeDasharray="3 2" />
        ))}
        {/* Water molecules passing through */}
        {[0, 1, 2, 3, 4].map(i => (
          <circle key={i} cx={175 + (i % 3) * 14 + Math.sin(t + i) * 3} cy={80 + ((t * 15 + i * 30) % 80)} r={2.5} fill={c.light} opacity="0.7">
            <animate attributeName="cy" values="80;170" dur={`${2 + i * 0.3}s`} repeatCount="indefinite" />
          </circle>
        ))}
        {/* Salt ions blocked */}
        {[0, 1, 2].map(i => (
          <g key={i}>
            <circle cx={170 + i * 20} cy={100 + (i % 2) * 20} r={3} fill="#F2B84B" opacity="0.6">
              <animate attributeName="cx" values={`${170 + i * 20};${170 + i * 20 + 3};${170 + i * 20}`} dur="2s" repeatCount="indefinite" />
            </circle>
          </g>
        ))}
      </g>
      {/* Clean water outlet (top) */}
      <Pipe x1={240} y1={80} x2={500} y2={80} c={c} t={t} />
      {/* Brine outlet (bottom) */}
      <Pipe x1={240} y1={160} x2={350} y2={160} c={c} t={t} />
      {/* Brine collection */}
      <rect x="350" y="145" width="60" height="30" rx="4" fill="#F2B84B" opacity="0.15" stroke="#C99420" strokeWidth="1.5" />
      <text x="380" y="164" textAnchor="middle" fontSize="8" fill="#C99420">Brine</text>
      {/* Clean water label */}
      <g transform="translate(420,55)">
        <text textAnchor="middle" fontSize="8" fill="#48B7A5" fontWeight="600">Clean water</text>
      </g>
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Membrane separates water from salts</text>
    </g>
  );
}

function DisinfectAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet */}
      <Pipe x1={0} y1={110} x2={170} y2={110} c={c} t={t} />
      {/* UV chamber */}
      <g>
        <rect x="170" y="70" width="160" height="80" rx="10" fill={c.primary} opacity="0.05" stroke={c.dark} strokeWidth="3" />
        {/* UV lamp */}
        <rect x="235" y="78" width="30" height="8" rx="4" fill="#48B7A5" opacity="0.6">
          <animate attributeName="opacity" values="0.4;0.8;0.4" dur="1.5s" repeatCount="indefinite" />
        </rect>
        {/* UV rays */}
        {[0, 1, 2, 3, 4, 5].map(i => (
          <g key={i}>
            <line x1={240 + i * 4} y1="88" x2={240 + i * 4} y2={135} stroke="#48B7A5" strokeWidth="1.5" opacity={0.3 + Math.sin(t + i) * 0.2}>
              <animate attributeName="opacity" values="0.1;0.5;0.1" dur="1s" repeatCount="indefinite" />
            </line>
          </g>
        ))}
        {/* Pathogen particles being destroyed */}
        {[0, 1, 2, 3].map(i => {
          const phase = (t + i * 1.5) % 4;
          const opacity = phase < 2 ? 0.6 - phase * 0.3 : 0;
          return (
            <g key={i} transform={`translate(${190 + i * 30},${110 + Math.sin(t + i) * 5})`}>
              <circle cx="0" cy="0" r="5" fill="#D95C5C" opacity={opacity} />
              {phase < 2 && (
                <g>
                  <line x1="-3" y1="-3" x2="3" y2="3" stroke="white" strokeWidth="1" opacity="0.5" />
                  <line x1="-3" y1="3" x2="3" y2="-3" stroke="white" strokeWidth="1" opacity="0.5" />
                </g>
              )}
              {/* Burst effect */}
              {phase >= 1.5 && phase < 2.5 && (
                <circle cx="0" cy="0" r={5 + (phase - 1.5) * 8} fill="none" stroke="#D95C5C" strokeWidth="1" opacity={0.4 - (phase - 1.5) * 0.3} />
              )}
            </g>
          );
        })}
        {/* Clean water droplets exiting */}
        {[0, 1, 2].map(i => (
          <Droplet key={i} cx={300 + i * 8} cy={110} r={4} color="#48B7A5" t={t} delay={i} />
        ))}
      </g>
      {/* Outlet */}
      <Pipe x1={330} y1={110} x2={500} y2={110} c={c} t={t} />
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Pathogens neutralized · Water is safer</text>
    </g>
  );
}

function RecoverAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet — waste stream */}
      <Pipe x1={0} y1={110} x2={140} y2={110} c={c} t={t} />
      {/* Separation chamber */}
      <g>
        <rect x="140" y="60" width="100" height="120" rx="8" fill="none" stroke={c.dark} strokeWidth="3" />
        {/* Separation funnel shape */}
        <path d="M 150 100 L 190 140 L 230 100" fill={c.primary} opacity="0.08" />
        {/* Separating components */}
        {/* Water rising to top */}
        {[0, 1, 2].map(i => (
          <circle key={`w${i}`} cx={170 + i * 20} cy={90 + Math.sin(t + i) * 4} r={4} fill={c.light} opacity="0.7">
            <animate attributeName="cy" values="130;80;130" dur={`${3 + i}s`} repeatCount="indefinite" />
          </circle>
        ))}
        {/* Salts sinking to bottom */}
        {[0, 1, 2].map(i => (
          <circle key={`s${i}`} cx={165 + i * 20} cy={150 + Math.sin(t + i) * 3} r={3} fill="#F2B84B" opacity="0.6">
            <animate attributeName="cy" values="120;160;120" dur={`${3 + i * 0.5}s`} repeatCount="indefinite" />
          </circle>
        ))}
        {/* Nutrients */}
        {[0, 1].map(i => (
          <circle key={`n${i}`} cx={180 + i * 20} cy={130 + Math.sin(t + i * 2) * 5} r={3} fill="#48B7A5" opacity="0.5" />
        ))}
      </g>
      {/* Output streams */}
      {/* Water (top) */}
      <Pipe x1={240} y1={75} x2={350} y2={75} c={c} t={t} />
      <g transform="translate(370,75)">
        <circle cx="0" cy="0" r="14" fill={c.light} opacity="0.15" />
        <path d="M 0 -8 Q -6 2 0 8 Q 6 2 0 -8 Z" fill={c.primary} opacity="0.6" />
        <text x="0" y="24" textAnchor="middle" fontSize="8" fill={c.dark}>Water</text>
      </g>
      {/* Salts (bottom) */}
      <Pipe x1={240} y1={160} x2={350} y2={160} c={c} t={t} />
      <g transform="translate(370,160)">
        <circle cx="0" cy="0" r="14" fill="#F2B84B" opacity="0.15" />
        <rect x="-5" y="-5" width="10" height="10" rx="2" fill="#F2B84B" opacity="0.5" />
        <text x="0" y="24" textAnchor="middle" fontSize="8" fill="#C99420">Salts</text>
      </g>
      {/* Nutrients (middle) */}
      <Pipe x1={240} y1={115} x2={430} y2={115} c={c} t={t} />
      <g transform="translate(450,115)">
        <circle cx="0" cy="0" r="14" fill="#48B7A5" opacity="0.15" />
        <path d="M 0 -6 L -5 4 L 5 4 Z" fill="#48B7A5" opacity="0.5" />
        <text x="0" y="24" textAnchor="middle" fontSize="8" fill="#2A8B7A">Nutrients</text>
      </g>
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Waste becomes resources · Nothing is just discarded</text>
    </g>
  );
}

function ReuseAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Inlet */}
      <Pipe x1={0} y1={110} x2={130} y2={110} c={c} t={t} />
      {/* Distribution point */}
      <circle cx="135" cy="110" r="6" fill={c.dark} opacity="0.3" />
      {/* Four reuse paths */}
      {[
        { y: 60, label: 'Irrigation', icon: 'plant', color: '#48B7A5' },
        { y: 95, label: 'Cleaning', icon: 'drop', color: c.primary },
        { y: 130, label: 'Industrial', icon: 'factory', color: c.dark },
        { y: 165, label: 'Toilet', icon: 'drop', color: c.light },
      ].map((path, i) => (
        <g key={i}>
          {/* Pipe to destination */}
          <line x1="135" y1="110" x2="220" y2={path.y} stroke={path.color} strokeWidth="2" opacity="0.3" strokeDasharray="4 3">
            <animate attributeName="stroke-dashoffset" from="0" to="-14" dur="1.5s" repeatCount="indefinite" />
          </line>
          {/* Destination icon */}
          <g transform={`translate(${240 + Math.sin(t + i) * 2},${path.y})`}>
            <rect x="-25" y="-18" width="50" height="36" rx="8" fill={path.color} opacity="0.1" stroke={path.color} strokeWidth="1.5" />
            {path.icon === 'plant' && (
              <g>
                <path d="M 0 5 L 0 -5 M -5 0 L 0 -5 L 5 0" fill="none" stroke={path.color} strokeWidth="2" strokeLinecap="round" />
                <line x1="0" y1="5" x2="0" y2="10" stroke={path.color} strokeWidth="2" />
              </g>
            )}
            {path.icon === 'drop' && (
              <path d="M 0 -8 Q -6 2 0 8 Q 6 2 0 -8 Z" fill={path.color} opacity="0.5" />
            )}
            {path.icon === 'factory' && (
              <g>
                <rect x="-8" y="-2" width="16" height="10" fill={path.color} opacity="0.4" />
                <rect x="-5" y="-8" width="4" height="6" fill={path.color} opacity="0.4" />
                <rect x="3" y="-6" width="4" height="4" fill={path.color} opacity="0.4" />
              </g>
            )}
            <text x="0" y="28" textAnchor="middle" fontSize="8" fill={path.color} fontWeight="600">{path.label}</text>
          </g>
          {/* Flowing droplets along path */}
          {[0, 1].map(j => (
            <circle key={j} cx={135 + ((t * 20 + j * 30 + i * 15) % 85)} cy={110 + (path.y - 110) * ((t * 20 + j * 30 + i * 15) % 85) / 85} r={2.5} fill={path.color} opacity="0.5" />
          ))}
        </g>
      ))}
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Water goes to an appropriate reuse pathway</text>
    </g>
  );
}

function RetestAnimation({ c, t }: { c: { primary: string; light: string; dark: string }; t: number }) {
  return (
    <g>
      {/* Two test tubes side by side */}
      {/* Before (left) */}
      <g>
        <rect x="120" y="60" width="40" height="110" rx="6" fill="none" stroke={c.dark} strokeWidth="3" />
        <rect x="122" y="90" width="36" height="78" rx="4" fill="#D4A574" opacity="0.3" />
        {/* Particles in before sample */}
        {[0, 1, 2, 3, 4].map(i => (
          <circle key={i} cx={128 + i * 6} cy={110 + (i % 2) * 15} r={2.5} fill="#8B7355" opacity="0.5" />
        ))}
        <text x="140" y="185" textAnchor="middle" fontSize="9" fill="#D95C5C" fontWeight="600">BEFORE</text>
      </g>
      {/* Arrow */}
      <g transform={`translate(${185 + Math.sin(t) * 3},115)`}>
        <line x1="0" y1="0" x2="30" y2="0" stroke={c.dark} strokeWidth="2" markerEnd="url(#arrowhead)" />
        <polygon points="30,0 25,-4 25,4" fill={c.dark} />
      </g>
      {/* After (right) */}
      <g>
        <rect x="230" y="60" width="40" height="110" rx="6" fill="none" stroke={c.dark} strokeWidth="3" />
        <rect x="232" y="90" width="36" height="78" rx="4" fill="url(#cleanWaterGrad)" />
        {/* Clean — no particles */}
        {/* Sparkle */}
        <g transform={`translate(${250},${100 + Math.sin(t) * 5})`}>
          <path d="M 0 -6 L 1 -1 L 6 0 L 1 1 L 0 6 L -1 1 L -6 0 L -1 -1 Z" fill="white" opacity="0.7">
            <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" />
          </path>
        </g>
        <text x="250" y="185" textAnchor="middle" fontSize="9" fill="#48B7A5" fontWeight="600">AFTER</text>
      </g>
      {/* Comparison check */}
      <g transform="translate(320,115)">
        <circle cx="0" cy="0" r="20" fill="#48B7A5" opacity="0.1" stroke="#48B7A5" strokeWidth="2" />
        <path d="M -8 0 L -3 5 L 8 -5" fill="none" stroke="#48B7A5" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <text x="250" y="215" textAnchor="middle" fontSize="11" fill={c.dark} fontWeight="600">Compare results · Confirm treatment worked</text>
    </g>
  );
}
