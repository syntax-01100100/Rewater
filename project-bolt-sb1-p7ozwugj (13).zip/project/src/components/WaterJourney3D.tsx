import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CircularityAnimation } from '@/components/animations/CircularityAnimation';
import { Droplets } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const STAGES = [
  {
    text: 'Water starts somewhere.',
    sub: 'Every drop has a source.',
    image: 'https://images.pexels.com/photos/8349867/pexels-photo-8349867.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    text: 'It gets used.',
    sub: 'Water flows through our daily lives.',
    image: 'https://images.pexels.com/photos/5294114/pexels-photo-5294114.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    text: 'It can be recovered.',
    sub: 'Wastewater enters treatment.',
    image: 'https://images.pexels.com/photos/17882790/pexels-photo-17882790.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    text: 'Treatment works.',
    sub: 'Water is purified and cleaned.',
    image: 'https://images.pexels.com/photos/5712211/pexels-photo-5712211.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    text: 'It can be reused.',
    sub: 'Clean water ready for a new purpose.',
    image: 'https://images.pexels.com/photos/9749/hands-water-poor-poverty.jpg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    text: 'And its journey can be tracked.',
    sub: 'Every step is recorded.',
    image: 'https://images.pexels.com/photos/36006040/pexels-photo-36006040.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    text: 'ReWater — Every drop has a future.',
    sub: 'A connected network of water impact.',
    image: 'https://images.pexels.com/photos/28101461/pexels-photo-28101461.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];

type FallbackType = 'none' | 'reduced-motion' | 'images-failed';

export function WaterJourney3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [fallback, setFallback] = useState<FallbackType>('none');
  const [activeStage, setActiveStage] = useState(0);
  const [progress, setProgress] = useState(0);
  const [loadedImages, setLoadedImages] = useState<Set<number>>(new Set());
  const imageRefs = useRef<(HTMLImageElement | null)[]>([]);
  const failedCount = useRef(0);

  // Preload images and detect failures
  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) {
      setFallback('reduced-motion');
      return;
    }

    STAGES.forEach((stage, i) => {
      const img = new Image();
      img.onload = () => setLoadedImages(prev => new Set(prev).add(i));
      img.onerror = () => {
        failedCount.current += 1;
        if (failedCount.current >= STAGES.length) {
          setFallback('images-failed');
        }
      };
      img.src = stage.image;
    });
  }, []);

  // Scroll progress via GSAP ScrollTrigger
  useEffect(() => {
    if (fallback !== 'none') return;
    const container = containerRef.current;
    if (!container) return;

    const st = ScrollTrigger.create({
      trigger: container,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 0.8,
      onUpdate: (self) => {
        setProgress(self.progress);
        const stageIndex = Math.min(
          Math.floor(self.progress * STAGES.length),
          STAGES.length - 1,
        );
        setActiveStage(stageIndex);
      },
    });

    return () => { st.kill(); };
  }, [fallback]);

  // Update image opacity based on scroll progress
  useEffect(() => {
    if (fallback !== 'none') return;
    STAGES.forEach((_, i) => {
      const img = imageRefs.current[i];
      if (!img) return;

      // Each image is visible in its stage band, with crossfade transitions
      const stageStart = i / STAGES.length;
      const stageEnd = (i + 1) / STAGES.length;
      const transitionWidth = 0.08; // 8% of total scroll for crossfade

      let opacity = 0;
      if (progress < stageStart - transitionWidth) {
        opacity = 0;
      } else if (progress >= stageStart - transitionWidth && progress < stageStart + transitionWidth) {
        // Fade in
        opacity = (progress - (stageStart - transitionWidth)) / (transitionWidth * 2);
      } else if (progress >= stageStart + transitionWidth && progress < stageEnd - transitionWidth) {
        opacity = 1;
      } else if (progress >= stageEnd - transitionWidth && progress < stageEnd + transitionWidth) {
        // Fade out
        opacity = 1 - (progress - (stageEnd - transitionWidth)) / (transitionWidth * 2);
      } else {
        opacity = 0;
      }

      // Last stage stays visible
      if (i === STAGES.length - 1 && progress > stageStart + transitionWidth) {
        opacity = 1;
      }

      img.style.opacity = String(Math.max(0, Math.min(1, opacity)));

      // Subtle zoom/pan effect via scale and translate
      const stageProgress = Math.max(0, Math.min(1, (progress - stageStart) / (stageEnd - stageStart)));
      const scale = 1.05 + stageProgress * 0.1;
      const panX = (stageProgress - 0.5) * 30;
      const panY = (stageProgress - 0.5) * 20;
      img.style.transform = `scale(${scale}) translateX(${panX}px) translateY(${panY}px)`;
    });
  }, [progress, fallback]);

  // ── Fallback: reduced motion ──────────────────────────────────────
  if (fallback === 'reduced-motion') {
    return (
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-6">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-2">
            The Water Journey
          </h2>
          <p className="text-sm text-slatey/60 max-w-xl mx-auto">
            Follow water from source to impact — every drop has a future.
          </p>
        </div>
        <div className="card p-6">
          <CircularityAnimation />
        </div>
      </section>
    );
  }

  // ── Fallback: images failed to load ───────────────────────────────
  if (fallback === 'images-failed') {
    return (
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-6">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-2">
            The Water Circularity Cycle
          </h2>
          <p className="text-sm text-slatey/60 max-w-xl mx-auto">
            Water doesn't just disappear after use. Follow it through the full circular journey.
          </p>
        </div>
        <div className="card p-6">
          <CircularityAnimation />
        </div>
      </section>
    );
  }

  // ── Main scroll section ───────────────────────────────────────────
  return (
    <section ref={containerRef} className="relative" style={{ height: '600vh' }}>
      {/* Sticky container */}
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-ocean-900">
        {/* Background images with crossfade */}
        {STAGES.map((stage, i) => (
          <img
            key={i}
            ref={(el) => { imageRefs.current[i] = el; }}
            src={stage.image}
            alt={stage.text}
            className="absolute inset-0 w-full h-full object-cover"
            style={{
              opacity: i === 0 && loadedImages.has(0) ? 1 : 0,
              transition: 'opacity 0.1s linear',
              willChange: 'opacity, transform',
            }}
            loading={i === 0 ? 'eager' : 'lazy'}
          />
        ))}

        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-ocean-900/70 via-ocean-900/40 to-ocean-900/80" />
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-ocean-900/50 via-transparent to-ocean-900/50" />

        {/* Loading state */}
        {loadedImages.size === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white/60 text-sm flex items-center gap-2">
              <Droplets size={18} className="animate-pulse text-aqua-400" />
              Loading water journey...
            </div>
          </div>
        )}

        {/* Scroll progress indicator */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-48 h-1 bg-white/20 rounded-full overflow-hidden z-10">
          <div
            className="h-full bg-aqua-400 rounded-full transition-all duration-100"
            style={{ width: `${progress * 100}%` }}
          />
        </div>

        {/* Stage text overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <div className="text-center max-w-2xl px-6">
            {STAGES.map((stage, i) => (
              <div
                key={i}
                className="absolute left-1/2 -translate-x-1/2 transition-all duration-700"
                style={{
                  opacity: activeStage === i ? 1 : 0,
                  transform: `translate(-50%, ${activeStage === i ? '0' : '20px'})`,
                }}
              >
                <div className="inline-flex items-center gap-2 mb-3" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}>
                  <Droplets size={16} className="text-aqua-400" />
                  <span className="text-xs font-bold text-aqua-300 uppercase tracking-wider">
                    Stage {i + 1} / {STAGES.length}
                  </span>
                </div>
                <h2 className={`font-display font-bold text-white mb-2 ${
                  i === STAGES.length - 1 ? 'text-3xl sm:text-5xl' : 'text-2xl sm:text-4xl'
                }`} style={{ textShadow: '0 2px 16px rgba(0,0,0,0.8)' }}>
                  {stage.text}
                </h2>
                <p className="text-sm sm:text-lg text-white/95" style={{ textShadow: '0 1px 12px rgba(0,0,0,0.8)' }}>
                  {stage.sub}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll hint at bottom (only at start) */}
        {progress < 0.02 && (
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/90 text-sm flex flex-col items-center gap-2 animate-bounce z-10" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}>
            <span>Scroll to explore</span>
            <div className="w-6 h-10 border-2 border-white/40 rounded-full flex justify-center pt-2">
              <div className="w-1 h-2 bg-white/60 rounded-full" />
            </div>
          </div>
        )}

        {/* Stage dots indicator on the right */}
        <div className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-10">
          {STAGES.map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                activeStage === i
                  ? 'bg-aqua-400 scale-125'
                  : activeStage > i
                    ? 'bg-aqua-400/40'
                    : 'bg-white/30'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
