import { useId } from 'react';

interface LogoProps {
  size?: number;
  className?: string;
  showText?: boolean;
  textClassName?: string;
}

export function Logo({ size = 40, className = '', showText = true, textClassName = '' }: LogoProps) {
  const uid = useId();
  const gradId = `logoGradient-${uid}`;
  const accentId = `logoAccent-${uid}`;
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0"
      >
        <defs>
          <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#063B5C" />
            <stop offset="60%" stopColor="#0F5C85" />
            <stop offset="100%" stopColor="#1FA7C8" />
          </linearGradient>
          <linearGradient id={accentId} x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#48B7A5" />
            <stop offset="100%" stopColor="#1FA7C8" />
          </linearGradient>
        </defs>
        {/* Water drop */}
        <path
          d="M24 4C24 4 12 18 12 28C12 35.7 17.3 41 24 41C30.7 41 36 35.7 36 28C36 18 24 4 24 4Z"
          fill={`url(#${gradId})`}
        />
        {/* Circular arrow */}
        <path
          d="M17 30C17 30 19 36 24 36C29 36 31 30 31 30"
          stroke={`url(#${accentId})`}
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M31 30L33.5 28.5M31 30L29.5 27.5"
          stroke={`url(#${accentId})`}
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />
        {/* Small highlight */}
        <ellipse cx="20" cy="22" rx="3" ry="4.5" fill="white" opacity="0.25" transform="rotate(-20 20 22)" />
      </svg>
      {showText && (
        <span className={`font-display font-bold text-slatey ${textClassName}`} style={{ fontSize: size * 0.5 }}>
          Re<span className="text-aqua-400">Water</span>
        </span>
      )}
    </div>
  );
}
