import { Home, Map, Beaker, RefreshCw, BarChart3, FlaskConical, Droplets, Menu, X, LogIn, BookOpen, UserCircle, Settings, LogOut, ChevronDown, Sparkles, Building2, Droplet } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { Logo } from './Logo';
import { useAuth } from '@/lib/auth';


export type PageId = 'home' | 'map' | 'check' | 'circular' | 'impact' | 'future' | 'aquasense' | 'brands' | 'passport' | 'account' | 'business' | 'water-credits' | 'hydro-stations';

interface NavProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
  onShowAuth: (mode?: 'signin' | 'signup') => void;
  onShowTutorial: () => void;
  isLoggedIn: boolean;
}

const mainNav: { id: PageId; label: string; icon: React.ReactNode }[] = [
  { id: 'home', label: 'Home', icon: <Home size={18} /> },
  { id: 'map', label: 'Map', icon: <Map size={18} /> },
  { id: 'check', label: 'Check', icon: <Beaker size={18} /> },
  { id: 'circular', label: 'Water Journey', icon: <RefreshCw size={18} /> },
  { id: 'impact', label: 'Impact', icon: <BarChart3 size={18} /> },
];

const secondaryNav: { id: PageId; label: string; icon: React.ReactNode }[] = [
  { id: 'future', label: 'Future Lab', icon: <FlaskConical size={18} /> },
  { id: 'brands', label: 'Brands', icon: <Droplets size={18} /> },
];

function AvatarMenu({ user, onNavigate, onSignOut }: {
  user: { email: string; isDemo: boolean };
  onNavigate: (page: PageId) => void;
  onSignOut: () => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const initials = user.email.slice(0, 2).toUpperCase();

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 transition-transform hover:scale-105"
        aria-label="Account menu"
      >
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-ocean-500 to-aqua-400 flex items-center justify-center text-white text-xs font-bold shadow-soft">
          {initials}
        </div>
        <ChevronDown size={14} className={`text-slatey/50 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-60 bg-white rounded-2xl shadow-float border border-softgrey overflow-hidden animate-fade-slide z-50">
          <div className="px-4 py-3 border-b border-softgrey bg-mist">
            <p className="text-sm font-medium text-slatey truncate">{user.email}</p>
            {user.isDemo && (
              <span className="inline-block mt-1 text-xs font-bold text-amber-600 bg-amber-100 px-2 py-0.5 rounded">DEMO ACCOUNT</span>
            )}
          </div>
          <div className="py-1">
            <button
              onClick={() => { onNavigate('account'); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slatey hover:bg-mist transition-colors"
            >
              <UserCircle size={16} className="text-ocean-600" /> Account / Profile
            </button>
            <button
              onClick={() => { onNavigate('circular'); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slatey hover:bg-mist transition-colors"
            >
              <RefreshCw size={16} className="text-teal-600" /> Water Journey
            </button>
            <button
              onClick={() => { onNavigate('passport'); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slatey hover:bg-mist transition-colors"
            >
              <Droplets size={16} className="text-aqua-600" /> Water Passport
            </button>
            <button
              onClick={() => { onNavigate('water-credits'); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slatey hover:bg-mist transition-colors"
            >
              <Sparkles size={16} className="text-aqua-600" /> Water Credits
            </button>
            <button
              onClick={() => { onNavigate('hydro-stations'); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slatey hover:bg-mist transition-colors"
            >
              <Droplet size={16} className="text-teal-600" /> HydroStations
            </button>
            <button
              onClick={() => { onNavigate('business'); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slatey hover:bg-mist transition-colors"
            >
              <Building2 size={16} className="text-teal-600" /> Business Profile
            </button>
          </div>
          <div className="border-t border-softgrey py-1">
            <button
              onClick={() => { onSignOut(); setOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-coral-500 hover:bg-coral-50 transition-colors"
            >
              <LogOut size={16} /> Sign Out
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function Navigation({ current, onNavigate, onShowAuth, onShowTutorial, isLoggedIn }: NavProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, signOut } = useAuth();

  const handleNavigate = (page: PageId) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <button onClick={() => handleNavigate('home')} className="flex items-center gap-2.5 transition-transform hover:scale-105" aria-label="ReWater home">
            <Logo size={36} textClassName="text-lg" />
          </button>

          <nav className="hidden md:flex items-center gap-1" aria-label="Main navigation">
            {mainNav.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                aria-current={current === item.id ? 'page' : undefined}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  current === item.id
                    ? 'bg-ocean-600 text-white shadow-soft'
                    : 'text-slatey/70 hover:bg-mist hover:text-ocean-600'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
            {secondaryNav.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                aria-current={current === item.id || (item.id === 'future' && current === 'aquasense') ? 'page' : undefined}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  current === item.id || (item.id === 'future' && current === 'aquasense')
                    ? 'bg-teal-400 text-white shadow-soft'
                    : 'text-slatey/70 hover:bg-mist hover:text-teal-600'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <button
              onClick={onShowTutorial}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slatey/70 hover:bg-mist hover:text-ocean-600 transition-all"
            >
              <BookOpen size={16} />
              How It Works
            </button>
            {isLoggedIn && user ? (
              <AvatarMenu user={user} onNavigate={handleNavigate} onSignOut={signOut} />
            ) : (
              <button
                onClick={() => onShowAuth('signin')}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-ocean-600 text-white hover:bg-ocean-700 transition-all shadow-soft"
              >
                <LogIn size={16} />
                Sign In
              </button>
            )}
          </div>

          <button
            className="md:hidden p-2 rounded-lg text-slatey hover:bg-mist"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-ocean-900/40 backdrop-blur-sm" onClick={() => setMobileOpen(false)} aria-hidden="true" />
          <div className="absolute top-16 left-0 right-0 bg-white shadow-float border-t border-softgrey animate-fade-slide">
            <nav className="flex flex-col p-4 gap-1" aria-label="Mobile navigation">
              {[...mainNav, ...secondaryNav].map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavigate(item.id)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    current === item.id || (item.id === 'future' && current === 'aquasense')
                      ? 'bg-ocean-600 text-white'
                      : 'text-slatey hover:bg-mist'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              ))}
              <div className="h-px bg-softgrey my-2" />
              <button
                onClick={() => { onShowTutorial(); setMobileOpen(false); }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slatey hover:bg-mist"
              >
                <BookOpen size={18} /> How It Works
              </button>
              {isLoggedIn && user ? (
                <>
                  <button
                    onClick={() => { handleNavigate('account'); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slatey hover:bg-mist"
                  >
                    <UserCircle size={18} className="text-ocean-600" /> Account / Profile
                  </button>
                  <button
                    onClick={() => { handleNavigate('passport'); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slatey hover:bg-mist"
                  >
                    <Droplets size={18} className="text-aqua-600" /> Water Passport
                  </button>
                  <button
                    onClick={() => { handleNavigate('water-credits'); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slatey hover:bg-mist"
                  >
                    <Sparkles size={18} className="text-aqua-600" /> Water Credits
                  </button>
                  <button
                    onClick={() => { handleNavigate('hydro-stations'); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slatey hover:bg-mist"
                  >
                    <Droplet size={18} className="text-teal-600" /> HydroStations
                  </button>
                  <button
                    onClick={() => { handleNavigate('business'); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slatey hover:bg-mist"
                  >
                    <Building2 size={18} className="text-teal-600" /> Business Profile
                  </button>
                  <div className="flex items-center gap-3 px-4 py-3 text-sm text-slatey/60">
                    {user.isDemo && <span className="text-xs font-bold text-amber-600 bg-amber-100 px-1.5 py-0.5 rounded">DEMO</span>}
                    {user.email}
                  </div>
                  <button
                    onClick={() => { signOut(); setMobileOpen(false); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-coral-500 hover:bg-mist"
                  >
                    <LogOut size={18} /> Sign Out
                  </button>
                </>
              ) : (
                <button
                  onClick={() => { onShowAuth('signin'); setMobileOpen(false); }}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium bg-ocean-600 text-white"
                >
                  <LogIn size={18} /> Sign In
                </button>
              )}
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
