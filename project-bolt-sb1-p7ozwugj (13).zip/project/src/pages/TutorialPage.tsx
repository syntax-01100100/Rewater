import { useState } from 'react';
import {
  BookOpen, Map, Beaker, RefreshCw, BarChart3, FlaskConical,
  ArrowRight, ChevronRight,
  Target, Users, Lightbulb, Droplets, Recycle, Cpu, TestTube
} from 'lucide-react';

interface TutorialPageProps {
  onNavigate: (page: string) => void;
  onClose: () => void;
}

const sections = [
  {
    id: 'what',
    title: 'What is ReWater?',
    icon: <BookOpen size={20} />,
    content: [
      { heading: 'Our Mission', text: 'ReWater gives water a digital identity. It collects information about a water source, builds a continuously updated Water Profile, analyzes its condition and history, and identifies pathways for treatment, resource recovery and reuse.' },
      { heading: 'Who Is This For?', text: 'Students, researchers, environmental professionals, and anyone curious about water sustainability in the Gulf. You do not need a science background to use it.' },
      { heading: 'The Core Concept', text: 'Water enters the system, data is collected, a Water Profile is created, the water gets a persistent digital identity called a Water Passport, the data is analyzed, treatment and reuse pathways are identified, treatment occurs, the water is retested, and the Passport is updated. The water can then circulate again.' },
      { heading: 'Why We Built This', text: 'The Gulf faces extreme water scarcity. Most freshwater comes from desalination, which is energy-intensive. ReWater explores how overlooked water sources — AC condensate, rainwater, greywater — could reduce that pressure by giving them a digital identity and tracking them through circular reuse pathways.' },
    ],
  },
  {
    id: 'check',
    title: 'Check Water',
    icon: <Beaker size={20} />,
    content: [
      { heading: 'What It Does', text: 'Creates a Water Passport for a water sample. The workflow has 8 steps: Source, Collect Data, Build Profile, Analyze, Pathway, Save Passport, Retest, and Updated Passport. You do not have to complete every step — you can skip steps if you do not have hardware.' },
      { heading: 'Step 1 — Source', text: 'Enter what type of water this is (tap, groundwater, rainwater, AC condensate, etc.) and your intended use (drinking, irrigation, toilet flushing, cleaning, industrial, or general assessment).' },
      { heading: 'Step 2 — Collect Data', text: 'Choose your data collection methods: AquaSense (electronic sensors, future hardware — simulated in the prototype), AquaCard (chemical test card with camera colour analysis), Camera (visual water inspection), or Manual observations. You can use any combination.' },
      { heading: 'Steps 3-5 — Profile, Analyze, Pathway', text: 'The system combines your data into a Water Profile. AI interprets the available data to identify patterns and possible concerns. The Circularity Engine then identifies potential treatment, resource recovery, and reuse pathways based on the profile.' },
      { heading: 'Steps 6-8 — Passport, Retest, Updated Passport', text: 'The water receives a unique Water ID (e.g. RW-0248) and a digital Passport is saved. After treatment, you can enter new measurements as a Retest. The system shows a before/after comparison and updates the Passport history. Every measurement is labelled by its data status: MEASURED, ESTIMATED, OBSERVED, SIMULATED, or LAB VERIFIED.' },
      { heading: 'Demo Mode', text: 'Demo Mode is clearly labelled with a persistent badge. Simulated readings are never made to look indistinguishable from real measurements. Every reading shows its status so you always know whether data is real or simulated.' },
    ],
  },
  {
    id: 'passport',
    title: 'Water Passport',
    icon: <Droplets size={20} />,
    content: [
      { heading: 'What It Is', text: 'The Water Passport is the persistent digital record of a water sample. It follows the water through its entire lifecycle. It contains: Water ID, source, collection date, quantity, current condition, measurements, observations, previous uses, treatment history, recovery history, reuse history, current suitability, recommended next pathway, retest status, and last updated.' },
      { heading: 'How It Works', text: 'Each Passport has a unique Water ID (e.g. RW-0248). As the water moves through the system, events are added to the Passport timeline: collected, source identified, screening recorded, profile generated, pathway identified, treatment recorded, retest requested, new measurements recorded.' },
      { heading: 'Passport Stages', text: 'A Passport moves through stages: Collected, Profile Created, Analyzed, Pathway Identified, Treated, Retest Required, Verified or Not Verified, and Reuse Pathway. Each stage is stamped into the Passport history.' },
      { heading: 'Why It Matters', text: 'The Passport makes the concept of "digital identity follows the water" tangible. Instead of treating each water test as a one-off, the Passport builds a history that helps you understand the water over time and across multiple cycles of use.' },
    ],
  },
  {
    id: 'circular',
    title: 'Circularity Engine',
    icon: <Recycle size={20} />,
    content: [
      { heading: 'What It Does', text: 'The Circularity Engine takes the Water Profile and history, and identifies potential treatment pathways, resource recovery opportunities, and reuse options. Different water sources have different characteristics, so the pathways are tailored to the specific water.' },
      { heading: 'How It Works', text: 'The engine evaluates: Source + Current Profile + History. It then branches into three areas: Treatment (what steps could bring the water to spec), Recovery (what resources could potentially be recovered), and Reuse (what the water could be used for after treatment). The loop closes with Retest and Passport Update.' },
      { heading: 'Scientific Honesty', text: 'The Circularity Engine identifies potential pathways — it does not guarantee outcomes. Every recommendation is labelled as a potential pathway, not an automatic guarantee. Reuse is always described as "potential use subject to appropriate verification and standards."' },
      { heading: 'Why It Matters', text: 'Instead of just testing water and discarding it, the Circularity Engine helps you see what could happen next. This turns water testing from a one-time check into part of a circular system where water stays in use for as long as practical.' },
    ],
  },
  {
    id: 'map',
    title: 'Water Map',
    icon: <Map size={20} />,
    content: [
      { heading: 'What It Does', text: 'Shows water sources across the UAE on an interactive map. When you select a source, you can see its type, status, available profile information, and potential pathway. The map connects geographic context to the Water Passport.' },
      { heading: 'How To Use It', text: 'Click any marker to see water quality data. Use the search bar to find a location. Filter by source type using the sidebar. If the map fails to load, a fallback view with source data is shown instead of a blank page.' },
      { heading: 'Why It Matters', text: 'Many water sources are overlooked. Seeing them on a map helps you understand where reusable water already exists in your area, and connects each source to the ReWater system through its Water Passport.' },
    ],
  },
  {
    id: 'impact',
    title: 'Impact',
    icon: <BarChart3 size={20} />,
    content: [
      { heading: 'What It Does', text: 'Shows what ReWater could achieve. Instead of presenting fake exact savings, every number is clearly labelled by its data type: Measured, Calculated, Estimated, or Scenario. Scenario calculations show things like "If X litres are reused instead of discharged, the theoretical avoided demand is X litres."' },
      { heading: 'How It Connects', text: 'Impact data comes from Water Passport data, aggregated into site-level insight, which produces circularity metrics. This means the impact page is connected to the actual samples you create, not just random numbers.' },
      { heading: 'Why It Matters', text: 'Understanding potential helps justify investment in water circularity. The numbers are estimates, clearly labelled with their assumptions, based on UAE climate and water infrastructure data.' },
    ],
  },
  {
    id: 'future',
    title: 'Future Lab',
    icon: <FlaskConical size={20} />,
    content: [
      { heading: 'What It Does', text: 'Explores technologies that could contribute to water circularity in the Gulf. Organized into six areas: AquaSense (planned sensor hardware), Piezoelectric Monitoring (future low-energy power for sensors), Atmospheric Water, Cloud/Rain Capture, Digital Twins, and Advanced Treatment.' },
      { heading: 'Status Labels', text: 'Every concept is labelled by maturity: CURRENT PROTOTYPE, PLANNED, RESEARCH CONCEPT, or FUTURE. This prevents the impression that all technologies are already deployed. AquaSense is clearly described as future hardware with simulated readings in the prototype.' },
      { heading: 'How To Use It', text: 'Each concept explains what it does, how it works, why it matters, and how it could connect to ReWater. Interactive elements let you explore UAE climate data and theoretical yields.' },
      { heading: 'Why It Matters', text: 'The Gulf needs new water solutions. The Future Lab shows what is possible — not what is already working. This helps researchers and students understand the landscape of future water technologies.' },
    ],
  },
  {
    id: 'brands',
    title: 'Water Awareness',
    icon: <TestTube size={20} />,
    content: [
      { heading: 'What It Does', text: 'Compares the published composition of common water brands available in the UAE. Shows pH, TDS, calcium, magnesium, sodium, potassium, bicarbonate, chloride, and sulfate levels for each brand.' },
      { heading: 'Hover To Learn', text: 'When you expand a brand and hover over any parameter name (like Magnesium or pH), a popup appears explaining what that parameter means, why it matters, and how to interpret the value. This helps you understand water composition without needing a chemistry background.' },
      { heading: 'Why It Matters', text: 'Knowing what we drink matters. Awareness is the first step toward using water resources more responsibly. ReWater connects this awareness to the larger circular water system — understanding composition leads to better decisions about treatment, reuse, and recovery.' },
    ],
  },
];

export function TutorialPage({ onNavigate, onClose }: TutorialPageProps) {
  const [activeSection, setActiveSection] = useState('what');

  const current = sections.find(s => s.id === activeSection) || sections[0];

  return (
    <div className="min-h-screen pt-16 bg-gradient-mist">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-bold text-2xl text-ocean-600">How ReWater Works</h1>
            <p className="text-sm text-slatey/60 mt-1">A guided tour of the water intelligence system</p>
          </div>
          <button onClick={onClose} className="btn-secondary text-sm">
            Skip Tutorial
          </button>
        </div>

        {/* System overview visual */}
        <div className="card p-6 mb-6 bg-gradient-to-r from-ocean-50 via-mist to-teal-50">
          <h2 className="font-display font-semibold text-sm text-slatey mb-4 text-center">
            The ReWater Loop — One System, One Water Record, One Continuous Cycle
          </h2>
          <div className="flex items-center justify-center gap-1 sm:gap-2 flex-wrap">
            {[
              { label: 'Water', icon: <Droplets size={14} /> },
              { label: 'Collect', icon: <Beaker size={14} /> },
              { label: 'Profile', icon: <TestTube size={14} /> },
              { label: 'Analyze', icon: <Cpu size={14} /> },
              { label: 'Decide', icon: <Recycle size={14} /> },
              { label: 'Circulate', icon: <RefreshCw size={14} /> },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-1 sm:gap-2">
                <div className="flex flex-col items-center gap-1">
                  <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center ${i === 0 ? 'bg-ocean-100 text-ocean-600' : i === 5 ? 'bg-teal-100 text-teal-600' : 'bg-aqua-100 text-aqua-600'}`}>
                    {step.icon}
                  </div>
                  <span className="text-xs text-slatey/70 font-medium text-center">{step.label}</span>
                </div>
                {i < 5 && <ArrowRight size={14} className="text-slatey/30 hidden sm:block" />}
              </div>
            ))}
            <div className="flex items-center gap-1 text-teal-500 font-bold text-lg">
              <RefreshCw size={14} className="rotate-180" />
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-[260px_1fr] gap-6">
          {/* Sidebar */}
          <div className="space-y-2">
            {sections.map((s) => (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                  activeSection === s.id
                    ? 'bg-ocean-600 text-white shadow-soft'
                    : 'bg-white text-slatey/70 hover:bg-mist'
                }`}
              >
                <span className={activeSection === s.id ? 'text-white' : 'text-slatey/40'}>
                  {s.icon}
                </span>
                <span className="text-sm font-medium">{s.title}</span>
                {activeSection === s.id && <ChevronRight size={14} className="ml-auto" />}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="card p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-aqua-50 text-aqua-600 flex items-center justify-center">
                {current.icon}
              </div>
              <h2 className="font-display font-bold text-xl text-slatey">{current.title}</h2>
            </div>

            <div className="space-y-6">
              {current.content.map((item, i) => (
                <div key={i} className="animate-fade-slide" style={{ animationDelay: `${i * 0.1}s` }}>
                  <h3 className="font-display font-semibold text-sm text-ocean-600 mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-aqua-100 text-aqua-600 flex items-center justify-center text-xs font-bold">
                      {i + 1}
                    </span>
                    {item.heading}
                  </h3>
                  <p className="text-sm text-slatey/70 leading-relaxed pl-8">{item.text}</p>
                </div>
              ))}
            </div>

            {/* Action buttons for specific sections */}
            {current.id !== 'what' && (
              <div className="mt-6 pt-6 border-t border-softgrey">
                <button
                  onClick={() => onNavigate(current.id)}
                  className="btn-primary text-sm flex items-center gap-2"
                >
                  Try {current.title} <ArrowRight size={14} />
                </button>
              </div>
            )}

            {current.id === 'what' && (
              <div className="mt-6 pt-6 border-t border-softgrey grid sm:grid-cols-3 gap-4">
                <div className="bg-mist rounded-xl p-4">
                  <Target size={20} className="text-aqua-600 mb-2" />
                  <p className="text-xs font-medium text-slatey">Goal</p>
                  <p className="text-xs text-slatey/60 mt-1">Give water a digital identity and keep it circulating through treatment, recovery, and reuse.</p>
                </div>
                <div className="bg-mist rounded-xl p-4">
                  <Users size={20} className="text-teal-600 mb-2" />
                  <p className="text-xs font-medium text-slatey">For</p>
                  <p className="text-xs text-slatey/60 mt-1">Students, researchers, professionals, and curious minds</p>
                </div>
                <div className="bg-mist rounded-xl p-4">
                  <Lightbulb size={20} className="text-ocean-600 mb-2" />
                  <p className="text-xs font-medium text-slatey">Why</p>
                  <p className="text-xs text-slatey/60 mt-1">The Gulf needs new water solutions — understanding is the first step toward circularity</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom nav */}
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => {
              const idx = sections.findIndex(s => s.id === activeSection);
              if (idx > 0) setActiveSection(sections[idx - 1].id);
            }}
            className="text-sm text-slatey/50 hover:text-ocean-600 transition-colors disabled:opacity-30"
            disabled={activeSection === 'what'}
          >
            Previous
          </button>
          <button
            onClick={() => {
              const idx = sections.findIndex(s => s.id === activeSection);
              if (idx < sections.length - 1) setActiveSection(sections[idx + 1].id);
              else onClose();
            }}
            className="text-sm text-ocean-600 hover:text-ocean-700 font-medium flex items-center gap-1"
          >
            {sections.findIndex(s => s.id === activeSection) === sections.length - 1 ? 'Finish' : 'Next'}
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
