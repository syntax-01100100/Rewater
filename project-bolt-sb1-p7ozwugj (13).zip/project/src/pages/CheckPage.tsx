import { useEffect, useState } from 'react';
import {
  Beaker, Droplets, Thermometer, Waves, Zap, Camera,
  ChevronRight, RotateCcw, Info, AlertTriangle, CheckCircle,
  FlaskConical, ArrowRight, ArrowLeft, Shield, Recycle, Eye,
  Cpu, WifiOff, Play, Settings, CameraOff, FileText
} from 'lucide-react';
import { supabase, type WaterSample } from '@/lib/supabase';
import {
  generateWaterProfile, recoverabilityMeta,
  type WaterProfile, type AquaSenseData, type AquaCardData, type CameraData,
  type Severity,
} from '@/lib/waterAnalysis';
import { formatDate } from '@/lib/utils';
import { saveSimulatedReading } from '@/lib/sensorData';
import { AquaSenseAnimation, AquaCardAnimation, AIAnalysisAnimation } from '@/components/animations';
import { useWaterPassport, type PassportMeasurement } from '@/lib/waterPassport';
import { useAuth } from '@/lib/auth';
import { useAuthGuard } from '@/lib/authGuard';
import { PassportTimeline, PassportCard } from '@/components/PassportTimeline';
import type { PageId } from '@/components/Navigation';
import { loadLocalSamples, saveLocalSample, generateLocalId } from '@/lib/localPersistence';

type Stage = 'choose' | 'aquasense' | 'senseResults' | 'aquacard' | 'cardResults' | 'combine' | 'profile' | 'retest';

const severityBadge: Record<Severity, string> = {
  normal: 'badge-teal',
  watch: 'badge-aqua',
  elevated: 'badge-amber',
  high: 'badge-amber',
  critical: 'badge-coral',
};

const sourceLabels: Record<string, string> = {
  tap: 'Tap Water', bottled: 'Bottled Water', groundwater: 'Groundwater',
  rainwater: 'Rainwater', surface: 'Surface Water', wastewater: 'Wastewater',
  greywater: 'Greywater', seawater: 'Seawater', condensate: 'AC Condensate', other: 'Other',
};

const useOptions = [
  { value: 'drinking', label: 'Drinking Water' },
  { value: 'irrigation', label: 'Irrigation / Landscaping' },
  { value: 'toilet', label: 'Toilet Flushing' },
  { value: 'cleaning', label: 'Cleaning / Wash-down' },
  { value: 'industrial', label: 'Industrial Use' },
  { value: 'general', label: 'General Assessment' },
];

export function CheckPage({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  const [stage, setStage] = useState<Stage>('choose');
  const [sense, setSense] = useState<AquaSenseData | null>(null);
  const [card, setCard] = useState<AquaCardData | null>(null);
  const [camera, setCamera] = useState<CameraData | null>(null);
  const [profile, setProfile] = useState<WaterProfile | null>(null);
  const [samples, setSamples] = useState<WaterSample[]>([]);
  const [sourceName, setSourceName] = useState('');
  const [sourceType, setSourceType] = useState('tap');
  const [intendedUse, setIntendedUse] = useState('general');
  const [waterQuantity, setWaterQuantity] = useState<number | ''>('');
  const [savedSampleId, setSavedSampleId] = useState<string | null>(null);
  const [demoMode, setDemoMode] = useState(false);
  const [showTimeline, setShowTimeline] = useState(false);

  const { user } = useAuth();
  const { requireAuth } = useAuthGuard();
  const { passport, createPassport, addEvent, selectPassport } = useWaterPassport();

  useEffect(() => {
    if (user) {
      (async () => {
        const { data, error } = await supabase.from('water_samples').select('*').order('created_at', { ascending: false }).limit(20);
        if (!error) setSamples(data || []);
      })();
    } else {
      setSamples(loadLocalSamples());
    }
  }, [stage, user]);

  const ctx = { sourceName, sourceType, intendedUse };

  const handleDemoScan = () => {
    setStage('aquasense');
    setTimeout(() => {
      const reading: AquaSenseData = {
        ph: Math.round((6.2 + Math.random() * 2.8) * 10) / 10,
        temperature: Math.round((18 + Math.random() * 14) * 10) / 10,
        turbidity: Math.round(Math.random() * 18 * 10) / 10,
        tds: Math.round((40 + Math.random() * 900) * 10) / 10,
        ec: 0,
      };
      setSense(reading);
      setStage('senseResults');
      saveSimulatedReading({
        device_id: 'demo-device',
        sample_id: null,
        timestamp: new Date().toISOString(),
        ph: reading.ph,
        tds: reading.tds,
        ec: reading.ec,
        turbidity: reading.turbidity,
        temperature: reading.temperature,
        source: sourceType,
        status: 'simulated',
        calibration_info: null,
      }).catch(() => {});
    }, 3000);
  };

  const handleCardComplete = (cardData: AquaCardData, camData: CameraData | null) => {
    setCard(cardData);
    if (camData) setCamera(camData);
    setStage('cardResults');
  };

  const buildProfile = (): WaterProfile => {
    return generateWaterProfile(sense, card, camera, ctx);
  };

  const handleGenerateProfile = () => {
    const p = buildProfile();
    setProfile(p);
    setStage('profile');
  };

  const handleSaveSample = async (): Promise<string | null> => {
    const p = buildProfile();

    // Build passport measurements from collected data
    const measurements: PassportMeasurement[] = [];
    if (sense) {
      measurements.push({ name: 'pH', value: sense.ph, unit: '', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquasense' });
      measurements.push({ name: 'Temperature', value: sense.temperature, unit: '°C', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquasense' });
      measurements.push({ name: 'Turbidity', value: sense.turbidity, unit: 'NTU', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquasense' });
      measurements.push({ name: 'TDS', value: sense.tds, unit: 'mg/L', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquasense' });
    }
    if (card) {
      measurements.push({ name: 'Nitrate', value: card.nitrate, unit: 'mg/L', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquacard' });
      measurements.push({ name: 'Nitrite', value: card.nitrite, unit: 'mg/L', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquacard' });
      measurements.push({ name: 'Hardness', value: card.hardness, unit: 'mg/L', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquacard' });
      measurements.push({ name: 'Chlorine', value: card.chlorine, unit: 'mg/L', status: demoMode ? 'SIMULATED' : 'MEASURED', origin: 'aquacard' });
    }

    // Create Water Passport — use waterId as fallback name so nothing is ever "Untitled"
    const tempId = `RW-${String(Date.now()).slice(-6)}`;
    const newPassport = createPassport({
      source: sourceName || tempId,
      sourceType,
      intendedUse,
      measurements,
      observations: camera ? [`Visual: ${camera.colour}, ${camera.cloudiness}`] : [],
      profile: p,
      isDemo: demoMode || !user,
      quantity: typeof waterQuantity === 'number' && waterQuantity > 0 ? waterQuantity : null,
      unit: 'L',
    });

    // Add timeline events
    addEvent(newPassport.waterId, 'profiled', 'Profile generated', `${measurements.length} measurements collected`);
    addEvent(newPassport.waterId, 'analyzed', 'AI analysis complete', `${p.findings.length} findings identified`);
    addEvent(newPassport.waterId, 'pathway_identified', 'Pathway identified', `${p.treatmentPathway.length} treatment stages recommended`);
    selectPassport(newPassport.waterId);

    // Save to Supabase if signed in, otherwise save locally
    if (user) {
      const { data, error } = await supabase.from('water_samples').insert({
        source_name: sourceName || newPassport.waterId,
        source_type: sourceType,
        intended_use: intendedUse,
        ph: sense?.ph || null,
        temperature: sense?.temperature || null,
        turbidity: sense?.turbidity || null,
        tds: sense?.tds || null,
        ec: sense?.ec || null,
        nitrate: card?.nitrate || null,
        nitrite: card?.nitrite || null,
        hardness: card?.hardness || null,
        chlorine: card?.chlorine || null,
        cam_colour: camera?.colour || null,
        cam_cloudiness: camera?.cloudiness || null,
        cam_visible_particles: camera?.visibleParticles || false,
        cam_sediment: camera?.sediment || false,
        cam_foam: camera?.foam || false,
        cam_oil_appearance: camera?.oilAppearance || false,
        cam_surface_appearance: camera?.surfaceAppearance || null,
        cam_confidence: camera?.confidence || null,
        ai_interpretation: p as unknown as Record<string, unknown>,
        status: 'completed',
        card_type: card ? 'multiparameter-v1' : null,
      }).select('*').single();
      if (error) return null;
      return data?.id || null;
    } else {
      // Save locally for demo mode
      const localSample: WaterSample = {
        id: generateLocalId(),
        source_name: sourceName || newPassport.waterId,
        source_type: sourceType,
        intended_use: intendedUse,
        ph: sense?.ph || null,
        temperature: sense?.temperature || null,
        turbidity: sense?.turbidity || null,
        tds: sense?.tds || null,
        ec: sense?.ec || null,
        nitrate: card?.nitrate || null,
        nitrite: card?.nitrite || null,
        hardness: card?.hardness || null,
        chlorine: card?.chlorine || null,
        notes: null,
        ai_interpretation: p as unknown as Record<string, unknown>,
        status: 'completed',
        card_type: card ? 'multiparameter-v1' : null,
        image_url: null,
        cam_colour: camera?.colour || null,
        cam_cloudiness: camera?.cloudiness || null,
        cam_visible_particles: camera?.visibleParticles || false,
        cam_sediment: camera?.sediment || false,
        cam_foam: camera?.foam || false,
        cam_oil_appearance: camera?.oilAppearance || false,
        cam_surface_appearance: camera?.surfaceAppearance || null,
        cam_confidence: camera?.confidence || null,
        before_sample_id: null,
        created_at: new Date().toISOString(),
      };
      saveLocalSample(localSample);
      setSamples(prev => [localSample, ...prev]);
      return localSample.id;
    }
  };

  const handleReset = () => {
    setSense(null);
    setCard(null);
    setCamera(null);
    setProfile(null);
    setSavedSampleId(null);
    setStage('choose');
  };

  return (
    <div className="min-h-screen pt-16 bg-gradient-mist">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <ProgressBar stage={stage} />

        {/* Demo mode banner */}
        {demoMode && (
          <div className="mb-6 max-w-3xl mx-auto">
            <div className="flex items-center gap-2 bg-amber-400/10 rounded-xl px-4 py-2.5 border border-amber-400/20">
              <AlertTriangle size={16} className="text-amber-500 flex-shrink-0" />
              <p className="text-xs text-amber-700">
                <span className="font-semibold">SIMULATED DATA</span> — All readings are demo values. No physical AquaSense device is connected.
              </p>
              <button onClick={() => setDemoMode(false)} className="ml-auto text-xs text-amber-600 font-medium underline">
                Exit Demo
              </button>
            </div>
          </div>
        )}

        {stage === 'choose' && (
          <ChooseStage
            sourceName={sourceName} setSourceName={setSourceName}
            sourceType={sourceType} setSourceType={setSourceType}
            intendedUse={intendedUse} setIntendedUse={setIntendedUse}
            waterQuantity={waterQuantity} setWaterQuantity={setWaterQuantity}
            sense={sense} card={card} camera={camera}
            onAquaSense={() => requireAuth('AquaSense Sensor Analysis', () => setStage('aquasense'))}
            onAquaCard={() => requireAuth('AquaCard Chemical Analysis', () => setStage('aquacard'))}
            onGenerateProfile={handleGenerateProfile}
            samples={samples}
            demoMode={demoMode}
            canDemo={!!user?.isDemo}
            onToggleDemo={() => setDemoMode(!demoMode)}
            onNavigate={onNavigate}
            onSampleClick={(s) => {
              if (s.ph) setSense({ ph: s.ph, temperature: s.temperature || 20, turbidity: s.turbidity || 0, tds: s.tds || 0, ec: s.ec || 0 });
              if (s.nitrate) setCard({ nitrate: s.nitrate, nitrite: s.nitrite || 0, hardness: s.hardness || 0, chlorine: s.chlorine || 0 });
              if (s.cam_colour) setCamera({ colour: s.cam_colour, cloudiness: s.cam_cloudiness || 'Clear', visibleParticles: s.cam_visible_particles || false, sediment: s.cam_sediment || false, foam: s.cam_foam || false, oilAppearance: s.cam_oil_appearance || false, surfaceAppearance: s.cam_surface_appearance || 'Normal', confidence: s.cam_confidence as 'Medium' || 'Medium' });
              setStage('profile');
              handleGenerateProfile();
            }}
          />
        )}

        {stage === 'aquasense' && (
          <AquaSenseStage
            onScan={handleDemoScan}
            onBack={() => setStage('choose')}
            demoMode={demoMode}
          />
        )}
        {stage === 'senseResults' && sense && (
          <SenseResults sense={sense} isSimulated={demoMode} onNext={() => setStage('choose')} onRetest={handleDemoScan} />
        )}
        {stage === 'aquacard' && (
          <AquaCardStage onComplete={handleCardComplete} onBack={() => setStage('choose')} demoMode={demoMode} />
        )}
        {stage === 'cardResults' && card && (
          <CardResults card={card} camera={camera} isSimulated={demoMode} onNext={() => setStage('choose')} onRetest={() => setStage('aquacard')} />
        )}
        {stage === 'profile' && profile && (
          <ProfileStage
            profile={profile}
            sourceName={sourceName} sourceType={sourceType}
            onSave={async () => { const id = await handleSaveSample(); if (id) setSavedSampleId(id); }}
            onReset={handleReset}
            savedSampleId={savedSampleId}
            isSimulated={demoMode}
            passport={passport}
            showTimeline={showTimeline}
            onToggleTimeline={() => setShowTimeline(!showTimeline)}
            onViewPassport={onNavigate ? () => onNavigate('passport') : undefined}
          />
        )}
      </div>
    </div>
  );
}

function ProgressBar({ stage }: { stage: Stage }) {
  const steps = [
    { id: 'choose', label: 'Collect' },
    { id: 'aquasense', label: 'AquaSense' },
    { id: 'aquacard', label: 'AquaCard' },
    { id: 'profile', label: 'Profile' },
  ];
  const order: Stage[] = ['choose', 'aquasense', 'senseResults', 'aquacard', 'cardResults', 'profile'];
  const idx = order.indexOf(stage);

  return (
    <div className="flex items-center justify-center mb-8 gap-1 sm:gap-3 flex-wrap">
      {steps.map((step, i) => {
        const stepIdx = order.indexOf(step.id as Stage);
        const isActive = stepIdx <= idx;
        return (
          <div key={step.id} className="flex items-center gap-1 sm:gap-3">
            <div className={'flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ' + (isActive ? 'bg-aqua-400 text-white' : 'bg-white text-slatey/40 border border-softgrey')}>
              <div className={'w-5 h-5 rounded-full flex items-center justify-center text-xs ' + (isActive ? 'bg-white/20' : 'bg-softgrey')}>
                {i + 1}
              </div>
              <span className="hidden sm:inline">{step.label}</span>
            </div>
            {i < steps.length - 1 && <ChevronRight size={14} className="text-slatey/30" />}
          </div>
        );
      })}
    </div>
  );
}

function ChooseStage({
  sourceName, setSourceName, sourceType, setSourceType,
  intendedUse, setIntendedUse,
  waterQuantity, setWaterQuantity,
  sense, card, camera,
  onAquaSense, onAquaCard, onGenerateProfile,
  samples, onSampleClick,
  demoMode, canDemo, onToggleDemo,
  onNavigate,
}: {
  sourceName: string; setSourceName: (v: string) => void;
  sourceType: string; setSourceType: (v: string) => void;
  intendedUse: string; setIntendedUse: (v: string) => void;
  waterQuantity: number | ''; setWaterQuantity: (v: number | '') => void;
  sense: AquaSenseData | null; card: AquaCardData | null; camera: CameraData | null;
  onAquaSense: () => void; onAquaCard: () => void;
  onGenerateProfile: () => void;
  samples: WaterSample[]; onSampleClick: (s: WaterSample) => void;
  demoMode: boolean; canDemo: boolean; onToggleDemo: () => void;
  onNavigate?: (page: import('@/components/Navigation').PageId) => void;
}) {
  const collected = [sense && 'AquaSense', card && 'AquaCard', camera && 'Camera'].filter(Boolean);

  return (
    <div className="space-y-6">
      {/* Source info */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-lg text-slatey mb-4">Water Source Information</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-medium text-slatey/60 block mb-1.5">Source Name</label>
            <input
              type="text"
              value={sourceName}
              onChange={(e) => setSourceName(e.target.value)}
              placeholder="e.g. Kitchen Tap"
              className="w-full px-3 py-2 rounded-lg border border-softgrey bg-white text-sm text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slatey/60 block mb-1.5">Source Type</label>
            <select value={sourceType} onChange={(e) => setSourceType(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-softgrey bg-white text-sm text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400">
              {Object.entries(sourceLabels).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slatey/60 block mb-1.5">Intended Use</label>
            <select value={intendedUse} onChange={(e) => setIntendedUse(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-softgrey bg-white text-sm text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400">
              {useOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>

        {/* Water Quantity */}
        <div className="mt-4">
          <label className="text-xs font-medium text-slatey/60 block mb-1.5 flex items-center gap-1.5">
            <Droplets size={12} /> Water Quantity (Litres)
          </label>
          <input
            type="number"
            min="0"
            step="1"
            value={waterQuantity}
            onChange={(e) => setWaterQuantity(e.target.value === '' ? '' : parseFloat(e.target.value) || 0)}
            placeholder="e.g. 10000"
            className="w-full px-3 py-2 rounded-lg border border-softgrey bg-white text-sm text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400"
          />
          <p className="text-xs text-slatey/40 mt-1">
            Enter the measured amount of water. Credits are only generated after testing is complete and the water is eligible for recovery, reuse, or conservation (1 Credit = 1,000 L).
          </p>
        </div>
      </div>

      {/* Analysis methods */}
      <div className="grid sm:grid-cols-2 gap-4">
        {/* AquaSense */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-ocean-50 text-ocean-600 flex items-center justify-center">
                <Cpu size={20} />
              </div>
              <div>
                <h3 className="font-display font-semibold text-slatey">AquaSense</h3>
                <p className="text-xs text-slatey/50">Electronic sensor readings</p>
              </div>
            </div>
            {sense ? (
              <span className="badge-teal text-xs">Done</span>
            ) : (
              <span className="badge-amber text-xs">Future Hardware</span>
            )}
          </div>
          <p className="text-xs text-slatey/60 mb-4">
            Measures pH, temperature, turbidity, TDS, and electrical conductivity. AquaSense is a future device — not yet connected.
          </p>
          <button onClick={onAquaSense} className="w-full btn-secondary text-sm flex items-center justify-center gap-2">
            <Cpu size={14} /> {sense ? 'Retest' : 'Open AquaSense'}
          </button>
        </div>

        {/* AquaCard */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                <FlaskConical size={20} />
              </div>
              <div>
                <h3 className="font-display font-semibold text-slatey">AquaCard + Camera</h3>
                <p className="text-xs text-slatey/50">Chemical test card with photo analysis</p>
              </div>
            </div>
            {card ? (
              <span className="badge-teal text-xs">Done</span>
            ) : (
              <span className="text-xs text-slatey/40">Ready</span>
            )}
          </div>
          <p className="text-xs text-slatey/60 mb-4">
            Dip the test card in water, then use your camera to photograph it. The app analyzes the colour changes for nitrate, nitrite, hardness, and chlorine.
          </p>
          <button onClick={onAquaCard} className="w-full btn-secondary text-sm flex items-center justify-center gap-2">
            <FlaskConical size={14} /> {card ? 'Retest' : 'Open AquaCard'}
          </button>
        </div>
      </div>

      {/* Demo mode toggle — demo accounts only */}
      {canDemo && (
        <div className="card p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={'w-10 h-10 rounded-xl flex items-center justify-center ' + (demoMode ? 'bg-amber-100 text-amber-600' : 'bg-mist text-slatey/40')}>
              <Settings size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-slatey">Demo / Simulation Mode</p>
              <p className="text-xs text-slatey/50">Generate simulated readings for competition demonstration</p>
            </div>
          </div>
          <button
            onClick={onToggleDemo}
            role="switch"
            aria-checked={demoMode}
            aria-label="Toggle demo simulation mode"
            className={'relative w-12 h-6 rounded-full transition-colors ' + (demoMode ? 'bg-amber-400' : 'bg-softgrey')}
          >
            <div className={'absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ' + (demoMode ? 'translate-x-6' : 'translate-x-0.5')} />
          </button>
        </div>
      )}
      {!canDemo && (
        <div className="card p-4 bg-mist">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-mist text-slatey/30">
              <Settings size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-slatey/60">Simulation Mode</p>
              <p className="text-xs text-slatey/40">Simulated readings are only available in the demo account. Sign in with the demo account to try the simulation.</p>
            </div>
          </div>
        </div>
      )}

      {/* Generate profile */}
      {(sense || card || camera) && (
        <div className="card p-6 text-center">
          <p className="text-sm text-slatey/60 mb-4">
            Collected: {collected.join(', ')}
          </p>
          <button onClick={onGenerateProfile} className="btn-primary flex items-center gap-2 mx-auto">
            Generate Water Profile <ArrowRight size={16} />
          </button>
        </div>
      )}

      {/* Create Water Passport link */}
      <div className="card p-5 bg-gradient-to-r from-aqua-50 to-teal-50 border-softgrey">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white text-aqua-600 flex items-center justify-center shadow-soft">
              <Droplets size={20} />
            </div>
            <div>
              <p className="text-sm font-semibold text-slatey">Water Passport</p>
              <p className="text-xs text-slatey/60">View or create a digital water identity and track its circular journey</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate?.('passport')}
            className="btn-aqua text-sm flex items-center gap-2"
          >
            Open Water Passport <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {/* Previous samples */}
      {samples.length > 0 && (
        <div className="card p-6">
          <h3 className="font-display font-semibold text-sm text-slatey mb-3">Previous Samples</h3>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {samples.map((s) => (
              <button
                key={s.id}
                onClick={() => onSampleClick(s)}
                className="w-full flex items-center justify-between p-3 bg-mist rounded-xl hover:bg-softgrey transition-colors text-left"
              >
                <div>
                  <span className="text-sm font-medium text-slatey">{s.source_name}</span>
                  <span className="text-xs text-slatey/40 ml-2">{formatDate(s.created_at)}</span>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  {s.ph && <span className="text-ocean-600 font-medium">pH {s.ph}</span>}
                  {s.tds && <span className="text-aqua-600 font-medium">TDS {s.tds}</span>}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AquaSenseStage({ onScan, onBack, demoMode }: { onScan: () => void; onBack: () => void; demoMode: boolean }) {

  return (
    <div className="card p-8 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-ocean-50 text-ocean-600 flex items-center justify-center">
          <Cpu size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-lg text-slatey">AquaSense</h2>
          <p className="text-sm text-slatey/50">Electronic water quality sensor</p>
        </div>
      </div>

      <div className="mb-6">
        <AquaSenseAnimation />
      </div>

      {/* Device status */}
      <div className="bg-mist rounded-xl p-6 mb-6 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-100 text-amber-700 mb-3">
          <WifiOff size={16} />
          <span className="text-sm font-medium">AquaSense — Not Connected</span>
        </div>
        <p className="text-sm text-slatey/60 mb-2">
          AquaSense is a future hardware device. It is not yet available.
        </p>
        <p className="text-xs text-slatey/40">
          When developed, AquaSense will connect via Wi-Fi and send real sensor readings directly to this page.
        </p>
      </div>

      {/* What it will measure */}
      <div className="space-y-2 mb-6">
        <p className="text-xs font-medium text-slatey/60 mb-2">What AquaSense Will Measure:</p>
        {[
          { param: 'pH', icon: <Droplets size={16} />, range: '0-14', unit: '' },
          { param: 'TDS', icon: <Zap size={16} />, range: '0-2000', unit: 'ppm' },
          { param: 'EC', icon: <Waves size={16} />, range: '0-4000', unit: 'µS/cm' },
          { param: 'Turbidity', icon: <Beaker size={16} />, range: '0-1000', unit: 'NTU' },
          { param: 'Temperature', icon: <Thermometer size={16} />, range: '0-80', unit: '°C' },
        ].map((s) => (
          <div key={s.param} className="flex items-center justify-between bg-mist rounded-lg p-3">
            <div className="flex items-center gap-2">
              <span className="text-ocean-600">{s.icon}</span>
              <span className="text-sm text-slatey">{s.param}</span>
            </div>
            <span className="text-xs text-slatey/50">{s.range} {s.unit}</span>
          </div>
        ))}
      </div>

      {/* Architecture */}
      <div className="bg-ocean-50 rounded-xl p-4 mb-6">
        <p className="text-xs font-medium text-ocean-600 mb-2">Data Flow (When Connected):</p>
        <p className="text-xs text-slatey/60">AquaSense Sensors → ESP32 → Wi-Fi → API → Database → This Website</p>
      </div>

      {/* Demo button */}
      {demoMode ? (
        <div className="space-y-3">
          <div className="flex items-center gap-2 bg-amber-50 rounded-xl px-4 py-2.5 border border-amber-200">
            <AlertTriangle size={14} className="text-amber-500 flex-shrink-0" />
            <p className="text-xs text-amber-700">
              Demo mode is ON. The next scan will generate <span className="font-semibold">simulated</span> readings.
            </p>
          </div>
          <button onClick={onScan} className="w-full btn-primary flex items-center justify-center gap-2">
            <Play size={16} /> Run Simulated Scan
          </button>
        </div>
      ) : (
        <div className="bg-mist rounded-xl p-6 text-center">
          <p className="text-sm text-slatey/50 mb-3">
            Enable Demo Mode from the Collect screen to generate simulated readings for competition demonstration.
          </p>
        </div>
      )}

      <button onClick={onBack} className="w-full text-sm text-slatey/50 hover:text-ocean-600 mt-4">
        Back to Collect
      </button>
    </div>
  );
}

function SenseResults({ sense, isSimulated, onNext, onRetest }: {
  sense: AquaSenseData; isSimulated: boolean; onNext: () => void; onRetest: () => void;
}) {
  const readings = [
    { name: 'pH', value: sense.ph, unit: '', icon: <Droplets size={18} />, color: 'ocean' },
    { name: 'Temperature', value: sense.temperature, unit: '°C', icon: <Thermometer size={18} />, color: 'teal' },
    { name: 'Turbidity', value: sense.turbidity, unit: 'NTU', icon: <Beaker size={18} />, color: 'aqua' },
    { name: 'TDS', value: sense.tds, unit: 'mg/L', icon: <Zap size={18} />, color: 'amber' },
  ];

  return (
    <div className="card p-8 max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display font-bold text-lg text-slatey">AquaSense Readings</h2>
        {isSimulated && (
          <span className="text-xs px-3 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">SIMULATED</span>
        )}
      </div>

      <div className="grid sm:grid-cols-2 gap-4 mb-6">
        {readings.map((r) => (
          <div key={r.name} className="bg-mist rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-${r.color}-600`}>{r.icon}</span>
              <span className="text-sm text-slatey/60">{r.name}</span>
            </div>
            <div className="font-display font-bold text-2xl text-slatey">
              {r.value}<span className="text-sm text-slatey/40 ml-1">{r.unit}</span>
            </div>
          </div>
        ))}
      </div>

      {isSimulated && (
        <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3 mb-6">
          <Info size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            These values are simulated for demonstration. Real AquaSense readings will appear here when the device is connected.
          </p>
        </div>
      )}

      <div className="flex gap-3">
        <button onClick={onRetest} className="btn-secondary text-sm flex items-center gap-2">
          <RotateCcw size={14} /> Retest
        </button>
        <button onClick={onNext} className="btn-primary text-sm flex items-center gap-2 flex-1 justify-center">
          Continue <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}

function AquaCardStage({ onComplete, onBack, demoMode }: {
  onComplete: (card: AquaCardData, camera: CameraData | null) => void;
  onBack: () => void;
  demoMode: boolean;
}) {
  const [step, setStep] = useState<'instructions' | 'dipping' | 'camera' | 'analyzing'>('instructions');

  const handleSimulatedCard = () => {
    const cardData: AquaCardData = {
      nitrate: Math.round((Math.random() * 55) * 10) / 10,
      nitrite: Math.round((Math.random() * 5) * 10) / 10,
      hardness: Math.round((40 + Math.random() * 320) * 10) / 10,
      chlorine: Math.round((Math.random() * 5) * 100) / 100,
    };
    const camData: CameraData = {
      colour: ['Clear', 'Slightly yellow', 'Clear', 'Clear'][Math.floor(Math.random() * 4)],
      cloudiness: ['Clear', 'Clear', 'Slight', 'Clear'][Math.floor(Math.random() * 4)],
      visibleParticles: Math.random() > 0.7,
      sediment: Math.random() > 0.8,
      foam: Math.random() > 0.8,
      oilAppearance: Math.random() > 0.9,
      surfaceAppearance: 'Normal',
      confidence: 'Medium',
    };
    onComplete(cardData, camData);
  };

  if (step === 'instructions') {
    return (
      <div className="card p-8 max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <FlaskConical size={24} />
          </div>
          <div>
            <h2 className="font-display font-bold text-lg text-slatey">AquaCard + Camera</h2>
            <p className="text-sm text-slatey/50">Chemical test card with photo analysis</p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <div className="flex items-start gap-3 bg-mist rounded-xl p-4">
            <span className="w-7 h-7 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center text-sm font-bold flex-shrink-0">1</span>
            <div>
              <p className="text-sm font-medium text-slatey">Dip the test card</p>
              <p className="text-xs text-slatey/60 mt-1">Submerge the AquaCard in your water sample for the time specified on the card packaging (usually 30-60 seconds).</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-mist rounded-xl p-4">
            <span className="w-7 h-7 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center text-sm font-bold flex-shrink-0">2</span>
            <div>
              <p className="text-sm font-medium text-slatey">Photograph the card</p>
              <p className="text-xs text-slatey/60 mt-1">Use the camera to take a clear photo of the colour pads. The app will analyze the colour changes to estimate nitrate, nitrite, hardness, and chlorine levels.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-mist rounded-xl p-4">
            <span className="w-7 h-7 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center text-sm font-bold flex-shrink-0">3</span>
            <div>
              <p className="text-sm font-medium text-slatey">Visual water inspection</p>
              <p className="text-xs text-slatey/60 mt-1">The camera also captures a visual assessment of the water itself — colour, cloudiness, particles, foam, and surface appearance.</p>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <button onClick={onBack} className="btn-secondary text-sm">Back</button>
          {demoMode ? (
            <button onClick={handleSimulatedCard} className="btn-primary text-sm flex items-center gap-2 flex-1 justify-center">
              <Play size={14} /> Run Simulated Card Scan
            </button>
          ) : (
            <button onClick={() => setStep('dipping')} className="btn-primary text-sm flex items-center gap-2 flex-1 justify-center">
              Start <ArrowRight size={14} />
            </button>
          )}
        </div>

        {demoMode && (
          <p className="text-xs text-amber-600 text-center mt-3">
            Demo mode: simulated card readings will be generated.
          </p>
        )}
      </div>
    );
  }

  if (step === 'dipping') {
    return (
      <div className="card p-8 max-w-2xl mx-auto text-center">
        <div className="mb-6">
          <AquaCardAnimation />
        </div>
        <h2 className="font-display font-bold text-lg text-slatey mb-2">Dip the test card</h2>
        <p className="text-sm text-slatey/60 mb-6">Submerge the card in your water sample. Wait for the colour pads to develop.</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button onClick={onBack} className="btn-secondary text-sm flex items-center gap-2">
            <ArrowLeft size={16} /> Back to Collect
          </button>
          <button onClick={() => setStep('camera')} className="btn-primary text-sm flex items-center gap-2">
            Card is ready <ArrowRight size={16} />
          </button>
        </div>
        {demoMode && (
          <button onClick={handleSimulatedCard} className="mt-3 text-xs text-aqua-600 hover:text-aqua-700 font-medium">
            Skip to demo results →
          </button>
        )}
      </div>
    );
  }

  if (step === 'camera') {
    return <CameraPermissionStep onCapture={() => setStep('analyzing')} onBack={() => setStep('dipping')} onBackToStart={onBack} />;
  }

  // analyzing
  return <AnalyzingCard onDone={handleSimulatedCard} />;
}

function AnalyzingCard({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onDone, 2500);
    return () => clearTimeout(timer);
  }, [onDone]);
  return (
    <div className="card p-8 max-w-2xl mx-auto text-center">
      <div className="mx-auto mb-6 w-16 h-16 rounded-full border-4 border-teal-400/20 border-t-teal-400 animate-spin" />
      <h2 className="font-display font-bold text-lg text-slatey mb-2">Analyzing...</h2>
      <p className="text-sm text-slatey/60">Reading colour changes and assessing water clarity</p>
    </div>
  );
}

type CamState = 'permission' | 'ready' | 'denied' | 'unsupported';

function CameraPermissionStep({ onCapture, onBack, onBackToStart }: { onCapture: () => void; onBack: () => void; onBackToStart: () => void }) {
  const [camState, setCamState] = useState<CamState>('permission');
  const [stream, setStream] = useState<MediaStream | null>(null);

  const requestCamera = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setCamState('unsupported');
      return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      setStream(s);
      setCamState('ready');
    } catch {
      setCamState('denied');
    }
  };

  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, [stream]);

  if (camState === 'permission') {
    return (
      <div className="card p-8 max-w-2xl mx-auto text-center">
        <div className="w-16 h-16 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-4">
          <Camera size={32} />
        </div>
        <h2 className="font-display font-bold text-lg text-slatey mb-2">Camera Permission Needed</h2>
        <p className="text-sm text-slatey/60 mb-6">
          ReWater needs access to your camera to photograph the AquaCard and assess water clarity. Your camera feed is never stored or uploaded — it is analyzed in real time on your device.
        </p>
        <div className="flex gap-3 justify-center">
          <button onClick={onBack} className="btn-secondary text-sm">Back</button>
          <button onClick={requestCamera} className="btn-primary text-sm flex items-center gap-2" aria-label="Allow camera access">
            <Camera size={16} /> Allow Camera
          </button>
        </div>
      </div>
    );
  }

  if (camState === 'denied') {
    return (
      <div className="card p-8 max-w-2xl mx-auto text-center">
        <div className="w-16 h-16 rounded-2xl bg-coral-50 text-coral-500 flex items-center justify-center mx-auto mb-4">
          <CameraOff size={32} />
        </div>
        <h2 className="font-display font-bold text-lg text-slatey mb-2">Camera Access Denied</h2>
        <p className="text-sm text-slatey/60 mb-6">
          Camera access was denied. You have two options:
        </p>
        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          <div className="bg-aqua-50 rounded-xl p-4 text-left">
            <div className="flex items-center gap-2 mb-2">
              <Play size={18} className="text-aqua-600" />
              <span className="text-sm font-semibold text-slatey">Use Demo Data</span>
            </div>
            <p className="text-xs text-slatey/60">Continue with simulated camera assessment. The app will generate realistic water quality readings for you.</p>
          </div>
          <div className="bg-mist rounded-xl p-4 text-left">
            <div className="flex items-center gap-2 mb-2">
              <ArrowLeft size={18} className="text-slatey/60" />
              <span className="text-sm font-semibold text-slatey">Back to Check Page</span>
            </div>
            <p className="text-xs text-slatey/60">Go back to the main check page and choose a different method to test your water.</p>
          </div>
        </div>
        <div className="flex gap-3 justify-center">
          <button onClick={onBackToStart} className="btn-secondary text-sm flex items-center gap-2">
            <ArrowLeft size={16} /> Back to Check Page
          </button>
          <button onClick={onCapture} className="btn-primary text-sm flex items-center gap-2" aria-label="Continue without camera using simulated data">
            <Play size={16} /> Use Demo Data
          </button>
        </div>
        <button onClick={onBack} className="mt-3 text-xs text-slatey/40 hover:text-slatey/60">
          Try camera again
        </button>
      </div>
    );
  }

  if (camState === 'unsupported') {
    return (
      <div className="card p-8 max-w-2xl mx-auto text-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center mx-auto mb-4">
          <CameraOff size={32} />
        </div>
        <h2 className="font-display font-bold text-lg text-slatey mb-2">Camera Not Available</h2>
        <p className="text-sm text-slatey/60 mb-6">
          Your device or browser does not support camera access. You have two options:
        </p>
        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          <div className="bg-aqua-50 rounded-xl p-4 text-left">
            <div className="flex items-center gap-2 mb-2">
              <Play size={18} className="text-aqua-600" />
              <span className="text-sm font-semibold text-slatey">Use Demo Data</span>
            </div>
            <p className="text-xs text-slatey/60">Continue with simulated camera assessment. The app will generate realistic water quality readings for you.</p>
          </div>
          <div className="bg-mist rounded-xl p-4 text-left">
            <div className="flex items-center gap-2 mb-2">
              <ArrowLeft size={18} className="text-slatey/60" />
              <span className="text-sm font-semibold text-slatey">Back to Check Page</span>
            </div>
            <p className="text-xs text-slatey/60">Go back to the main check page and choose a different method to test your water.</p>
          </div>
        </div>
        <div className="flex gap-3 justify-center">
          <button onClick={onBackToStart} className="btn-secondary text-sm flex items-center gap-2">
            <ArrowLeft size={16} /> Back to Check Page
          </button>
          <button onClick={onCapture} className="btn-primary text-sm flex items-center gap-2" aria-label="Continue with simulated camera data">
            <Play size={16} /> Use Demo Data
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="card p-8 max-w-2xl mx-auto text-center">
      <h2 className="font-display font-bold text-lg text-slatey mb-2">Photograph the AquaCard</h2>
      <p className="text-sm text-slatey/60 mb-6">Position the test card within the frame. Ensure good lighting and focus.</p>

      <div className="relative mx-auto mb-6 rounded-2xl overflow-hidden bg-black" style={{ maxWidth: 360, aspectRatio: '4/3' }}>
        <video
          ref={(el) => {
            if (el && stream && el.srcObject !== stream) el.srcObject = stream;
          }}
          autoPlay
          playsInline
          muted
          aria-label="Live camera feed for AquaCard capture"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 pointer-events-none">
          {[
            { key: 'tl', cls: 'top-4 left-4 border-t-4 border-l-4 rounded-tl-xl' },
            { key: 'tr', cls: 'top-4 right-4 border-t-4 border-r-4 rounded-tr-xl' },
            { key: 'bl', cls: 'bottom-4 left-4 border-b-4 border-l-4 rounded-bl-xl' },
            { key: 'br', cls: 'bottom-4 right-4 border-b-4 border-r-4 rounded-br-xl' },
          ].map((c) => (
            <div key={c.key} className={'absolute w-8 h-8 border-teal-400 ' + c.cls} />
          ))}
        </div>
      </div>

      <div className="flex gap-3 justify-center">
        <button onClick={onBack} className="btn-secondary text-sm">Back</button>
        <button onClick={onCapture} className="btn-primary text-sm flex items-center gap-2">
          <Camera size={16} /> Capture Photo
        </button>
      </div>
    </div>
  );
}

function CardResults({ card, camera, isSimulated, onNext, onRetest }: {
  card: AquaCardData; camera: CameraData | null; isSimulated: boolean;
  onNext: () => void; onRetest: () => void;
}) {
  const readings = [
    { name: 'Nitrate (NO₃)', value: card.nitrate, unit: 'mg/L', icon: <Beaker size={18} /> },
    { name: 'Nitrite (NO₂)', value: card.nitrite, unit: 'mg/L', icon: <FlaskConical size={18} /> },
    { name: 'Hardness', value: card.hardness, unit: 'mg/L CaCO₃', icon: <Droplets size={18} /> },
    { name: 'Chlorine', value: card.chlorine, unit: 'mg/L', icon: <Shield size={18} /> },
  ];

  return (
    <div className="card p-8 max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display font-bold text-lg text-slatey">AquaCard Results</h2>
        {isSimulated && (
          <span className="text-xs px-3 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">SIMULATED</span>
        )}
      </div>

      <div className="grid sm:grid-cols-2 gap-4 mb-6">
        {readings.map((r) => (
          <div key={r.name} className="bg-mist rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-teal-600">{r.icon}</span>
              <span className="text-sm text-slatey/60">{r.name}</span>
            </div>
            <div className="font-display font-bold text-2xl text-slatey">
              {r.value}<span className="text-sm text-slatey/40 ml-1">{r.unit}</span>
            </div>
          </div>
        ))}
      </div>

      {camera && (
        <div className="bg-mist rounded-xl p-4 mb-6">
          <h3 className="text-sm font-medium text-slatey mb-3 flex items-center gap-2">
            <Camera size={16} className="text-teal-600" /> Camera Assessment
          </h3>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div><span className="text-slatey/50">Colour:</span> <span className="text-slatey font-medium">{camera.colour}</span></div>
            <div><span className="text-slatey/50">Cloudiness:</span> <span className="text-slatey font-medium">{camera.cloudiness}</span></div>
            <div><span className="text-slatey/50">Particles:</span> <span className="text-slatey font-medium">{camera.visibleParticles ? 'Visible' : 'None'}</span></div>
            <div><span className="text-slatey/50">Sediment:</span> <span className="text-slatey font-medium">{camera.sediment ? 'Present' : 'None'}</span></div>
            <div><span className="text-slatey/50">Foam:</span> <span className="text-slatey font-medium">{camera.foam ? 'Present' : 'None'}</span></div>
            <div><span className="text-slatey/50">Oil:</span> <span className="text-slatey font-medium">{camera.oilAppearance ? 'Possible' : 'None'}</span></div>
          </div>
        </div>
      )}

      {isSimulated && (
        <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3 mb-6">
          <Info size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            These values are simulated for demonstration. Real AquaCard readings require a physical test card and camera capture.
          </p>
        </div>
      )}

      <div className="flex gap-3">
        <button onClick={onRetest} className="btn-secondary text-sm flex items-center gap-2">
          <RotateCcw size={14} /> Retest
        </button>
        <button onClick={onNext} className="btn-primary text-sm flex items-center gap-2 flex-1 justify-center">
          Continue <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}

function ProfileStage({
  profile, sourceName, sourceType,
  onSave, onReset, savedSampleId, isSimulated,
  passport, showTimeline, onToggleTimeline, onViewPassport,
}: {
  profile: WaterProfile;
  sourceName: string; sourceType: string;
  onSave: () => Promise<void>; onReset: () => void;
  savedSampleId: string | null; isSimulated: boolean;
  passport: import('@/lib/waterPassport').WaterPassport | null;
  showTimeline: boolean;
  onToggleTimeline: () => void;
  onViewPassport?: () => void;
}) {
  const [activeTab, setActiveTab] = useState<'findings' | 'treatment' | 'reuse' | 'prevention'>('findings');

  const recMeta = recoverabilityMeta[profile.recoverability];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card p-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="font-display font-bold text-xl text-slatey">Water Quality Profile</h2>
            <p className="text-sm text-slatey/50 mt-1">
              {sourceName || passport?.waterId || sourceLabels[sourceType] || sourceType} · {sourceLabels[sourceType] || sourceType}
            </p>
          </div>
          <div className="text-right">
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium bg-${recMeta.color}-50 text-${recMeta.color}-600`}>
              <Recycle size={14} /> {recMeta.label}
            </div>
            {isSimulated && (
              <span className="block text-xs text-amber-600 mt-1">Based on simulated data</span>
            )}
          </div>
        </div>
        <p className="text-xs text-slatey/50 mt-3">{profile.recoverabilityReasoning}</p>
      </div>

      <div className="mb-6">
        <AIAnalysisAnimation />
      </div>

      {/* Parameters */}
      {profile.parameters.length > 0 && (
        <div className="card p-6">
          <h3 className="font-display font-semibold text-sm text-slatey mb-4">Measured Parameters</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {profile.parameters.map((p, i) => (
              <div key={i} className="bg-mist rounded-xl p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slatey/60">{p.name}</span>
                  <span className={severityBadge[p.severity] + ' text-xs'}>{p.status}</span>
                </div>
                <div className="font-display font-bold text-lg text-slatey">
                  {p.value}{p.unit && <span className="text-xs text-slatey/40 ml-1">{p.unit}</span>}
                </div>
                <div className="text-xs text-slatey/40 mt-1">Ref: {p.refRange}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="card p-6">
        <div className="flex gap-2 mb-6 overflow-x-auto" role="tablist" aria-label="Profile details">
          {[
            { id: 'findings', label: 'Findings', icon: <AlertTriangle size={14} /> },
            { id: 'treatment', label: 'Treatment Pathway', icon: <Beaker size={14} /> },
            { id: 'reuse', label: 'Reuse Options', icon: <Recycle size={14} /> },
            { id: 'prevention', label: 'Prevention', icon: <Shield size={14} /> },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              role="tab"
              aria-selected={activeTab === t.id}
              className={'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ' + (activeTab === t.id ? 'bg-ocean-600 text-white' : 'bg-mist text-slatey/60 hover:bg-softgrey')}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {activeTab === 'findings' && (
          <div className="space-y-3">
            {profile.findings.length === 0 ? (
              <p className="text-sm text-slatey/50 text-center py-4">No findings — all parameters within normal range.</p>
            ) : (
              profile.findings.map((f, i) => (
                <div key={i} className={'rounded-xl p-4 ' + (
                  f.level === 'alert' ? 'bg-coral-50 border border-coral-200' :
                  f.level === 'warning' ? 'bg-amber-50 border border-amber-200' :
                  f.level === 'good' ? 'bg-teal-50' : 'bg-mist'
                )}>
                  <div className="flex items-center gap-2 mb-1">
                    {f.level === 'good' ? <CheckCircle size={16} className="text-teal-500" /> :
                     f.level === 'alert' ? <AlertTriangle size={16} className="text-coral-500" /> :
                     <Info size={16} className="text-amber-500" />}
                    <span className="text-sm font-medium text-slatey">{f.title}</span>
                    <span className="text-xs text-slatey/40 ml-auto">Confidence: {f.confidence}</span>
                  </div>
                  <p className="text-xs text-slatey/60 pl-6">{f.detail}</p>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'treatment' && (
          <div className="space-y-3">
            {profile.treatmentPathway.length === 0 ? (
              <p className="text-sm text-slatey/50 text-center py-4">No treatment stages needed.</p>
            ) : (
              profile.treatmentPathway.map((stage, i) => (
                <div key={i} className="bg-mist rounded-xl p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="w-7 h-7 rounded-full bg-ocean-100 text-ocean-600 flex items-center justify-center text-sm font-bold flex-shrink-0">{i + 1}</span>
                    <h4 className="font-display font-semibold text-sm text-slatey">{stage.name}</h4>
                  </div>
                  <div className="pl-10 space-y-2">
                    <p className="text-xs text-slatey/60"><span className="font-medium text-slatey/70">Addresses:</span> {stage.addresses}</p>
                    <p className="text-xs text-slatey/60"><span className="font-medium text-slatey/70">Why needed:</span> {stage.whyNeeded}</p>
                    <p className="text-xs text-teal-600"><span className="font-medium">Can remove:</span> {stage.canRemove}</p>
                    <p className="text-xs text-coral-500"><span className="font-medium">Cannot remove:</span> {stage.cannotRemove}</p>
                    <p className="text-xs text-slatey/60"><span className="font-medium text-slatey/70">Test after:</span> {stage.mustTestAfter}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'reuse' && (
          <div className="space-y-3">
            {profile.reusePathways.map((p, i) => (
              <div key={i} className="bg-mist rounded-xl p-4">
                <h4 className="font-display font-semibold text-sm text-slatey mb-2 flex items-center gap-2">
                  <Recycle size={14} className="text-teal-500" /> {p.category}
                </h4>
                <p className="text-xs text-slatey/60 mb-1"><span className="font-medium text-slatey/70">Treatment required:</span> {p.treatmentRequired}</p>
                <p className="text-xs text-slatey/60"><span className="font-medium text-slatey/70">Verification needed:</span> {p.verificationNeeded}</p>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'prevention' && (
          <div className="space-y-3">
            <div className="bg-mist rounded-xl p-4">
              <p className="text-xs text-slatey/60 mb-1"><span className="font-medium text-slatey/70">Problem detected:</span> {profile.preventionPlan.problemDetected}</p>
              <p className="text-xs text-slatey/60 mb-1"><span className="font-medium text-slatey/70">Possible source:</span> {profile.preventionPlan.possibleSource}</p>
              <p className="text-xs text-slatey/60 mb-1"><span className="font-medium text-slatey/70">Monitor:</span> {profile.preventionPlan.monitorWhat}</p>
              <p className="text-xs text-slatey/60 mb-1"><span className="font-medium text-slatey/70">Frequency:</span> {profile.preventionPlan.monitoringFrequency}</p>
              <p className="text-xs text-slatey/60 mb-1"><span className="font-medium text-slatey/70">Early warning:</span> {profile.preventionPlan.earlyWarningTrigger}</p>
              <p className="text-xs text-slatey/60"><span className="font-medium text-slatey/70">Action:</span> {profile.preventionPlan.preventionAction}</p>
            </div>
          </div>
        )}
      </div>

      {/* Verification */}
      <div className="card p-6">
        <h3 className="font-display font-semibold text-sm text-slatey mb-3 flex items-center gap-2">
          <Eye size={16} className="text-aqua-600" /> Laboratory Verification Needed
        </h3>
        <div className="space-y-2">
          {profile.needsVerification.map((v, i) => (
            <div key={i} className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-aqua-400 mt-1.5 flex-shrink-0" />
              <p className="text-xs text-slatey/60">{v}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 flex items-start gap-2 bg-amber-50 rounded-xl p-3">
          <AlertTriangle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            ReWater is a screening tool, not a certified laboratory. These results help you understand water quality — they do not replace professional testing.
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="card p-6 text-center">
        {savedSampleId ? (
          <div>
            <CheckCircle size={32} className="mx-auto text-teal-500 mb-3" />
            <p className="text-sm font-medium text-slatey mb-4">Sample saved successfully!</p>
            {passport && (
              <div className="max-w-md mx-auto mb-4">
                <PassportCard passport={passport} />
              </div>
            )}
            <div className="flex gap-3 justify-center flex-wrap">
              <button onClick={onToggleTimeline} className="btn-secondary text-sm flex items-center gap-2">
                {showTimeline ? 'Hide' : 'Show'} Timeline
              </button>
              {onViewPassport && (
                <button onClick={onViewPassport} className="btn-secondary text-sm flex items-center gap-2">
                  <FileText size={14} /> View Water Passport
                </button>
              )}
              <button onClick={onReset} className="btn-primary flex items-center gap-2">
                <RotateCcw size={16} /> Start New Test
              </button>
            </div>
            {showTimeline && passport && (
              <div className="mt-6 max-w-md mx-auto text-left">
                <h4 className="font-display font-semibold text-sm text-slatey mb-3 text-center">Passport Timeline — {passport.waterId}</h4>
                <PassportTimeline events={passport.events} />
              </div>
            )}
          </div>
        ) : (
          <div className="flex gap-3 justify-center">
            <button onClick={onReset} className="btn-secondary text-sm">Discard</button>
            <button onClick={onSave} className="btn-primary text-sm flex items-center gap-2">
              Save Sample <ArrowRight size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
