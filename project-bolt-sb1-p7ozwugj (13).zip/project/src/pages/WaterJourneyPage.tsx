import { useState, useEffect, useRef } from 'react';
import {
  Droplets, Beaker, FlaskConical, Filter, Shield, Recycle,
  Sprout, Factory, Waves, Cloud, ArrowRight, ArrowLeft,
  Play, Pause, RotateCcw, ChevronRight, Info,
  Thermometer, AlertTriangle, CheckCircle,
  Wind, Mountain, Cpu, TestTube, Leaf,
  Building2, Sparkles, ChevronDown,
  Map as MapIcon, BarChart3
} from 'lucide-react';
import { WaterTreatmentAnimation } from '@/components/WaterTreatmentAnimation';
import { useWaterPassport, passportStatusLabel, passportStatusColor, type PassportStatus } from '@/lib/waterPassport';
import { useAuth } from '@/lib/auth';
import { PassportCard } from '@/components/PassportTimeline';
import { HandHeart, Droplet } from 'lucide-react';

type PageId = 'home' | 'map' | 'check' | 'circular' | 'impact' | 'future' | 'brands' | 'passport' | 'account' | 'business' | 'water-credits' | 'hydro-stations';

type SourceId = 'condensate' | 'greywater' | 'wastewater' | 'rainwater' | 'brine' | 'agricultural' | 'industrial' | 'groundwater';

interface WaterSource {
  id: SourceId;
  label: string;
  icon: React.ReactNode;
  color: string;
  description: string;
  startQuality: string;
  typicalPathway: string[];
  recoveryPotential: string[];
}

const sources: WaterSource[] = [
  {
    id: 'condensate', label: 'AC Condensate', icon: <Factory size={28} />, color: 'aqua',
    description: 'Water collected when humid air contacts a cold AC surface.',
    startQuality: 'Relatively clean — low mineral content, but may contain metals from coils.',
    typicalPathway: ['source', 'check', 'filter', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Water for irrigation', 'Cooling tower make-up'],
  },
  {
    id: 'greywater', label: 'Greywater', icon: <Droplets size={28} />, color: 'teal',
    description: 'Water from showers, sinks, and washing machines — not toilets.',
    startQuality: 'Moderate contamination — soap, organics, particles. No fecal matter.',
    typicalPathway: ['source', 'check', 'screen', 'filter', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Irrigation', 'Toilet flushing', 'Cleaning'],
  },
  {
    id: 'wastewater', label: 'Wastewater', icon: <AlertTriangle size={28} />, color: 'coral',
    description: 'Water requiring substantial treatment before any reuse.',
    startQuality: 'High contamination — organics, nutrients, pathogens, solids.',
    typicalPathway: ['source', 'check', 'screen', 'sediment', 'filter', 'treat', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Treated effluent for landscaping', 'Nutrients for agriculture', 'Biogas potential'],
  },
  {
    id: 'rainwater', label: 'Rainwater', icon: <Cloud size={28} />, color: 'ocean',
    description: 'Rain collected from suitable surfaces like rooftops.',
    startQuality: 'Generally clean — may pick up debris, dust, bird droppings from surfaces.',
    typicalPathway: ['source', 'check', 'screen', 'filter', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Irrigation', 'Non-potable cleaning', 'Groundwater recharge'],
  },
  {
    id: 'brine', label: 'Desalination Brine', icon: <Waves size={28} />, color: 'amber',
    description: 'Concentrated saltwater left after desalination.',
    startQuality: 'Very high salinity — concentrated salts and minerals.',
    typicalPathway: ['source', 'check', 'treat', 'recover', 'reuse', 'retest'],
    recoveryPotential: ['Salt recovery', 'Mineral extraction', 'Potential industrial use'],
  },
  {
    id: 'agricultural', label: 'Agricultural Runoff', icon: <Sprout size={28} />, color: 'teal',
    description: 'Water affected by soil, nutrients, and agricultural activity.',
    startQuality: 'Contains fertilizers, pesticides, soil particles, organics.',
    typicalPathway: ['source', 'check', 'sediment', 'filter', 'treat', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Irrigation (after treatment)', 'Nutrient recovery'],
  },
  {
    id: 'industrial', label: 'Industrial Water', icon: <Building2 size={28} />, color: 'ocean',
    description: 'Water whose treatment depends heavily on the industrial process.',
    startQuality: 'Highly variable — depends on industry. May contain chemicals, metals, heat.',
    typicalPathway: ['source', 'check', 'screen', 'treat', 'filter', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Industrial reuse', 'Heat recovery', 'Chemical recovery'],
  },
  {
    id: 'groundwater', label: 'Groundwater', icon: <Mountain size={28} />, color: 'aqua',
    description: 'Subsurface water that requires source-specific testing.',
    startQuality: 'Variable — may contain minerals, metals, or contamination depending on aquifer.',
    typicalPathway: ['source', 'check', 'filter', 'treat', 'disinfect', 'reuse', 'retest'],
    recoveryPotential: ['Irrigation', 'Industrial use', 'Drinking (with full treatment)'],
  },
];

interface StageInfo {
  id: string;
  label: string;
  icon: React.ReactNode;
  whatHappens: string;
  why: string;
  whatNext: string;
  detail: string;
}

const allStages: Record<string, StageInfo> = {
  source: {
    id: 'source', label: 'Source', icon: <Droplets size={20} />,
    whatHappens: 'Water enters the system from its source.',
    why: 'The quality and possible reuse pathway depend on where the water came from and what it contains.',
    whatNext: 'Testing determines what treatment is needed.',
    detail: 'Different sources have different starting qualities. AC condensate is relatively clean. Wastewater needs extensive treatment. Industrial water varies by process.',
  },
  check: {
    id: 'check', label: 'Check', icon: <Beaker size={20} />,
    whatHappens: 'Water is tested using AquaSense, AquaCard, and available laboratory information.',
    why: 'You cannot choose a treatment pathway without knowing what is in the water.',
    whatNext: 'Results determine which treatment stages are needed.',
    detail: 'AquaSense measures pH, TDS, EC, turbidity, and temperature electronically. AquaCard tests nitrate, nitrite, hardness, and chlorine chemically. Camera assesses visual properties. Results are labelled MEASURED, ESTIMATED, OBSERVED, or SIMULATED — never invented.',
  },
  screen: {
    id: 'screen', label: 'Screen', icon: <Filter size={20} />,
    whatHappens: 'Large particles and debris are removed by screens or grates.',
    why: 'Removing large material protects downstream equipment and improves treatment efficiency.',
    whatNext: 'Water moves to finer treatment stages.',
    detail: 'Screens catch leaves, plastic, hair, and other visible debris. This is physical removal — no chemistry involved. The material caught here is disposed of separately.',
  },
  sediment: {
    id: 'sediment', label: 'Settle', icon: <Mountain size={20} />,
    whatHappens: 'Water sits in a tank so heavier particles settle to the bottom by gravity.',
    why: 'Many suspended particles are denser than water and will settle given time.',
    whatNext: 'Clearer water moves to filtration. Settled sludge is handled separately.',
    detail: 'Sedimentation tanks give particles time to settle. The process is passive — no energy needed beyond pumping. Chemicals called coagulants can help smaller particles clump together and settle faster.',
  },
  filter: {
    id: 'filter', label: 'Filter', icon: <Filter size={20} />,
    whatHappens: 'Water passes through filter media — sand, membranes, or cartridges — to remove fine particles.',
    why: 'Filtration reduces suspended particles and turbidity. Different filter technologies remove different contaminants.',
    whatNext: 'Water may need specialized treatment depending on what was detected.',
    detail: 'Sand filters catch particles down to ~20 microns. Membrane filters (microfiltration, ultrafiltration) catch much smaller particles. No single filter removes everything — the choice depends on what the water contains.',
  },
  treat: {
    id: 'treat', label: 'Treat', icon: <FlaskConical size={20} />,
    whatHappens: 'Source-specific treatment targets detected problems — high turbidity, dissolved contaminants, salinity, or nutrients.',
    why: 'Different contaminants need different treatment. One process does not work for everything.',
    whatNext: 'Water moves to disinfection or membrane treatment.',
    detail: 'High turbidity → clarification. Dissolved contaminants → adsorption or ion exchange. High salinity → membrane/desalination. Nutrients → biological nutrient removal or recovery. The treatment branch depends on what the Check stage found.',
  },
  membrane: {
    id: 'membrane', label: 'Membrane', icon: <Waves size={20} />,
    whatHappens: 'Water is forced through a membrane that separates it from dissolved salts and other constituents.',
    why: 'When salinity is high, membrane processes can produce lower-salinity water plus a concentrated brine stream.',
    whatNext: 'The brine stream is investigated for resource recovery instead of being discarded.',
    detail: 'Reverse osmosis uses pressure to push water through a semi-permeable membrane. The result is two streams: cleaner water and concentrated brine. The brine contains the salts and minerals that were removed.',
  },
  disinfect: {
    id: 'disinfect', label: 'Disinfect', icon: <Shield size={20} />,
    whatHappens: 'Pathogens are neutralized using UV light, chlorination, or ozonation.',
    why: 'Microbial safety is essential before any reuse involving human contact.',
    whatNext: 'Water is ready for reuse — but must be retested first.',
    detail: 'UV light damages microorganism DNA. Chlorine oxidizes cell structures. Ozone is a powerful oxidant. Prototype screening (AquaSense, AquaCard, camera) cannot detect bacteria — microbial safety requires appropriate validated treatment and laboratory testing.',
  },
  recover: {
    id: 'recover', label: 'Recover', icon: <Recycle size={20} />,
    whatHappens: 'The waste stream is separated into potentially recoverable resources — water, salts, nutrients, and other materials.',
    why: 'Circularity means thinking about both the water and what remains behind. Waste from one process can be a resource for another.',
    whatNext: 'Recovered resources go to appropriate reuse pathways.',
    detail: 'From desalination brine: salts and minerals. From wastewater: nutrients (phosphorus, nitrogen) for fertilizer. From industrial water: heat or chemicals. Resource recovery is a potential pathway, not a guaranteed result — it depends on concentration and economics.',
  },
  reuse: {
    id: 'reuse', label: 'Reuse', icon: <Sprout size={20} />,
    whatHappens: 'Treated water goes to a reuse pathway appropriate for its quality.',
    why: 'The reuse recommendation depends on the source, treatment applied, and applicable regulations.',
    whatNext: 'Water must be retested to confirm treatment performance.',
    detail: 'Possible pathways: irrigation, non-potable cleaning, industrial reuse, toilet flushing, or further treatment for higher-grade use. The website never automatically says water is safe to drink — that requires full treatment and certified laboratory confirmation.',
  },
  retest: {
    id: 'retest', label: 'Retest', icon: <TestTube size={20} />,
    whatHappens: 'Treated water is tested again using AquaSense, AquaCard, or laboratory analysis.',
    why: 'You cannot confirm treatment worked without comparing before and after measurements.',
    whatNext: 'If results meet the standard, water goes to reuse. If not, it returns for further treatment.',
    detail: 'Before and after values are compared for pH, TDS, turbidity, and other parameters. If there is no post-treatment measurement, the page says "Retesting required before confirming treatment performance." No improvement is ever faked.',
  },
};

export function WaterJourneyPage({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  const [selectedSource, setSelectedSource] = useState<SourceId | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const playRef = useRef<number | null>(null);

  const { passport, passports } = useWaterPassport();
  const { user } = useAuth();

  const source = sources.find(s => s.id === selectedSource) || null;
  const pathway = source?.typicalPathway || [];
  const activeStage = pathway[currentStep] ? allStages[pathway[currentStep]] : null;

  // Auto-play
  useEffect(() => {
    if (isPlaying && currentStep < pathway.length - 1) {
      playRef.current = window.setTimeout(() => setCurrentStep(c => c + 1), 4000);
    } else if (isPlaying && currentStep >= pathway.length - 1) {
      setIsPlaying(false);
    }
    return () => {
      if (playRef.current) window.clearTimeout(playRef.current);
    };
  }, [isPlaying, currentStep, pathway.length]);

  const handleSourceSelect = (id: SourceId) => {
    setSelectedSource(id);
    setCurrentStep(0);
    setIsPlaying(false);
    setShowWhy(false);
  };

  const handleRestart = () => {
    setCurrentStep(0);
    setIsPlaying(false);
    setShowWhy(false);
  };

  const handleNext = () => {
    if (currentStep < pathway.length - 1) setCurrentStep(c => c + 1);
    setShowWhy(false);
  };

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep(c => c - 1);
    setShowWhy(false);
  };

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-b from-ocean-50 via-mist to-mist">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-aqua-50 rounded-full px-4 py-1.5 mb-4">
            <Droplets size={14} className="text-aqua-600" />
            <span className="text-sm text-aqua-700 font-medium">Interactive Treatment Journey</span>
          </div>
          <h1 className="font-display font-bold text-3xl text-ocean-600 mb-2">Water Journey</h1>
          <p className="text-slatey/60 max-w-2xl mx-auto">
            Follow water from source to treatment, recovery and reuse. See exactly what happens at every stage.
          </p>
        </div>

        {/* Current passport recognition — only when signed in */}
        {user && passport && (
          <div className="mb-6 max-w-2xl mx-auto">
            <div className="flex items-center gap-2 mb-2">
              <Droplets size={16} className="text-aqua-600" />
              <p className="text-sm font-medium text-aqua-700">Your Water Passport is being tracked</p>
            </div>
            <PassportCard passport={passport} compact />
          </div>
        )}

        {/* All valid Water Passports as journey cards — only when signed in */}
        {user && passports.length > 0 && (
          <div className="mb-8">
            <div className="text-center mb-5">
              <h2 className="font-display font-bold text-xl text-slatey mb-1">Your Water Journey History</h2>
              <p className="text-sm text-slatey/50">Water Passports from samples you've tested through the ReWater system</p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {passports.map((p) => {
                const status: PassportStatus =
                  p.currentStage === 'verified' || p.currentStage === 'reuse_pathway' ? 'completed' :
                  p.currentStage === 'retest_required' ? 'awaiting_retest' :
                  p.currentStage === 'not_verified' ? 'treatment_required' : 'ongoing';
                return (
                  <div key={p.waterId} className="relative">
                    <PassportCard passport={p} compact />
                    <div className="mt-2 flex items-center gap-2">
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${passportStatusColor(status)}`}>
                        {passportStatusLabel(status)}
                      </span>
                      <span className="text-xs text-slatey/40 font-mono">{p.waterId}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {user && passports.length === 0 && !passport && (
          <div className="mb-8 max-w-lg mx-auto">
            <div className="card p-6 text-center bg-aqua-50">
              <Beaker className="mx-auto mb-3 text-aqua-400" size={28} />
              <p className="text-sm font-medium text-slatey mb-1">No Water Passports yet</p>
              <p className="text-xs text-slatey/50">
                Test a water sample on the Check Water page and complete the analysis to create your first Water Passport.
                A passport is only created after testing — not when you sign in.
              </p>
            </div>
          </div>
        )}

        {/* Source selection or journey */}
        {!selectedSource ? (
          <SourceSelection onSelect={handleSourceSelect} />
        ) : source ? (
          <div className="space-y-6">
            {/* Source header + change button */}
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl bg-${source.color}-50 text-${source.color}-600 flex items-center justify-center`}>
                  {source.icon}
                </div>
                <div>
                  <h2 className="font-display font-bold text-lg text-slatey">{source.label}</h2>
                  <p className="text-xs text-slatey/50">{source.description}</p>
                </div>
              </div>
              <button onClick={() => setSelectedSource(null)} className="btn-secondary text-sm flex items-center gap-2">
                <RotateCcw size={14} /> Choose Different Source
              </button>
            </div>

            {/* Journey visualization */}
            <JourneyVisualization
              pathway={pathway}
              currentStep={currentStep}
              onStepClick={(i) => { setCurrentStep(i); setIsPlaying(false); setShowWhy(false); }}
              isPlaying={isPlaying}
              source={source}
            />

            {/* Controls */}
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <button onClick={handlePrev} disabled={currentStep === 0} className="btn-secondary text-sm flex items-center gap-1.5 disabled:opacity-30">
                <ArrowLeft size={14} /> Previous
              </button>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="btn-primary text-sm flex items-center gap-1.5"
              >
                {isPlaying ? <><Pause size={14} /> Pause</> : <><Play size={14} /> Play Journey</>}
              </button>
              <button onClick={handleNext} disabled={currentStep >= pathway.length - 1} className="btn-secondary text-sm flex items-center gap-1.5 disabled:opacity-30">
                Next Step <ArrowRight size={14} />
              </button>
              <button onClick={handleRestart} className="btn-secondary text-sm flex items-center gap-1.5">
                <RotateCcw size={14} /> Restart
              </button>
            </div>

            {/* Active stage detail */}
            {activeStage && (
              <StageDetail stage={activeStage} showWhy={showWhy} setShowWhy={setShowWhy} source={source} currentStep={currentStep} />
            )}

            {/* What was removed */}
            {currentStep >= pathway.indexOf('filter') && currentStep < pathway.indexOf('reuse') && (
              <WhatWasRemoved source={source} />
            )}

            {/* Resource recovery */}
            {currentStep >= pathway.indexOf('recover') - 1 && pathway.includes('recover') && (
              <ResourceRecovery source={source} />
            )}

            {/* Before/After retest */}
            {currentStep === pathway.length - 1 && (
              <RetestSection />
            )}

            {/* Not all water follows the same path */}
            <DifferentPathsSection />

            {/* Circular loop */}
            <CircularLoopSection />

            {/* Connect to other features */}
            <ConnectFeaturesSection />

            {/* After reuse — link to HydroStations */}
            {onNavigate && currentStep === pathway.length - 1 && (
              <div className="card p-6 bg-gradient-to-br from-aqua-50 to-teal-50 border border-aqua-200">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-aqua-500 to-teal-400 flex items-center justify-center text-white flex-shrink-0 shadow-soft">
                    <Droplet size={28} />
                  </div>
                  <div className="flex-1 text-center sm:text-left">
                    <h3 className="font-display font-bold text-base text-slatey mb-1">Water Reused — Now Fund a HydroStation</h3>
                    <p className="text-xs text-slatey/60 leading-relaxed">
                      Turn recovered water into real impact. Donate your Water Credits to a HydroStation that provides drinking water to workers.
                    </p>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button onClick={() => onNavigate('water-credits')}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white text-aqua-700 text-sm font-medium hover:bg-aqua-50 transition-colors border border-aqua-200">
                      <Sparkles size={16} /> Water Credits
                    </button>
                    <button onClick={() => onNavigate('hydro-stations')}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors">
                      <HandHeart size={16} /> Donate to Station
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}

// ─── Source Selection ──────────────────────────────────────────────────────

function SourceSelection({ onSelect }: { onSelect: (id: SourceId) => void }) {
  return (
    <div>
      <h2 className="font-display font-bold text-xl text-slatey text-center mb-2">Choose Your Water</h2>
      <p className="text-sm text-slatey/50 text-center mb-8">Select a water source to begin the journey</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {sources.map((s, i) => (
          <button
            key={s.id}
            onClick={() => onSelect(s.id)}
            className="card p-6 text-center hover:shadow-float transition-all duration-300 hover:-translate-y-1 group animate-fade-slide"
            style={{ animationDelay: `${i * 0.05}s` }}
          >
            <div className={`w-16 h-16 rounded-2xl bg-${s.color}-50 text-${s.color}-600 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform`}>
              {s.icon}
            </div>
            <h3 className="font-display font-semibold text-sm text-slatey mb-1">{s.label}</h3>
            <p className="text-xs text-slatey/50 leading-relaxed">{s.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Journey Visualization ──────────────────────────────────────────────────

function JourneyVisualization({
  pathway, currentStep, onStepClick, isPlaying, source,
}: {
  pathway: string[];
  currentStep: number;
  onStepClick: (i: number) => void;
  isPlaying: boolean;
  source: WaterSource;
}) {
  return (
    <div className="card p-6 overflow-hidden">
      {/* Droplet guide */}
      <div className="flex items-center gap-2 mb-6 bg-aqua-50 rounded-xl px-4 py-2.5">
        <div className="relative">
          <Droplets size={24} className="text-aqua-500 animate-float" />
        </div>
        <p className="text-sm text-aqua-700 font-medium">
          {currentStep === 0 ? "Let's follow this water from the very beginning." :
           currentStep === pathway.length - 1 ? "We've reached the end of the journey. Let's check the results." :
           `Now at: ${allStages[pathway[currentStep]]?.label}. Let's see what happens next.`}
        </p>
      </div>

      {/* Pipeline — horizontal on desktop, vertical on mobile */}
      <div className="flex lg:flex-row flex-col lg:items-center gap-1 lg:gap-0">
        {pathway.map((stageId, i) => {
          const stage = allStages[stageId];
          const isActive = i === currentStep;
          const isPast = i < currentStep;

          return (
            <div key={stageId} className="flex lg:flex-row flex-col items-center lg:flex-1">
              <button
                onClick={() => onStepClick(i)}
                className={`relative flex flex-col items-center gap-2 p-3 rounded-2xl transition-all duration-300 w-full lg:w-auto ${
                  isActive ? 'scale-110' : 'hover:scale-105'
                }`}
              >
                {/* Node circle */}
                <div className={`relative w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isActive ? `bg-${source.color}-500 text-white shadow-glow` :
                  isPast ? `bg-${source.color}-100 text-${source.color}-600` :
                  'bg-softgrey text-slatey/30'
                }`}>
                  {stage.icon}
                  {isActive && (
                    <div className={`absolute inset-0 rounded-full animate-ripple ${isPlaying ? 'bg-' + source.color + '-400' : ''}`} />
                  )}
                  {isPast && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-teal-400 flex items-center justify-center">
                      <CheckCircle size={12} className="text-white" />
                    </div>
                  )}
                </div>
                {/* Label */}
                <span className={`text-xs font-medium transition-colors ${
                  isActive ? 'text-slatey' : isPast ? 'text-slatey/60' : 'text-slatey/30'
                }`}>
                  {stage.label}
                </span>
              </button>

              {/* Connector */}
              {i < pathway.length - 1 && (
                <div className="flex lg:flex-1 items-center justify-center lg:px-1 py-1 lg:py-0">
                  <div className="hidden lg:block flex-1 h-0.5 bg-softgrey relative overflow-hidden rounded-full">
                    <div
                      className={`absolute inset-y-0 left-0 transition-all duration-1000 bg-${source.color}-400 rounded-full`}
                      style={{ width: isPast ? '100%' : '0%' }}
                    />
                  </div>
                  <ChevronRight size={16} className="lg:hidden text-slatey/20" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Animated facility scene */}
      <div className="mt-6">
        <FacilityScene stage={allStages[pathway[currentStep]]} source={source} />
      </div>
    </div>
  );
}

// ─── Animated Facility Scene ────────────────────────────────────────────────

function FacilityScene({ stage, source }: { stage: StageInfo; source: WaterSource }) {
  if (!stage) return null;

  return (
    <div className="relative bg-gradient-to-b from-ocean-50 to-mist rounded-2xl overflow-hidden py-6">
      <WaterTreatmentAnimation stageId={stage.id} sourceColor={source.color} />
    </div>
  );
}

// ─── Stage Detail ───────────────────────────────────────────────────────────

function StageDetail({ stage, showWhy, setShowWhy, source, currentStep }: {
  stage: StageInfo; showWhy: boolean; setShowWhy: (v: boolean) => void; source: WaterSource; currentStep: number;
}) {
  return (
    <div className="card p-6 animate-fade-slide">
      <div className="flex items-center gap-3 mb-4">
        <div className={`w-10 h-10 rounded-xl bg-${source.color}-50 text-${source.color}-600 flex items-center justify-center`}>
          {stage.icon}
        </div>
        <h3 className="font-display font-bold text-lg text-slatey">{stage.label}</h3>
        <span className="ml-auto text-xs text-slatey/40">Step {currentStep + 1}</span>
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mb-4">
        <div className="bg-mist rounded-xl p-4">
          <p className="text-xs font-semibold text-ocean-600 mb-1">What Happens?</p>
          <p className="text-xs text-slatey/60 leading-relaxed">{stage.whatHappens}</p>
        </div>
        <div className="bg-mist rounded-xl p-4">
          <p className="text-xs font-semibold text-aqua-600 mb-1">Why?</p>
          <p className="text-xs text-slatey/60 leading-relaxed">{stage.why}</p>
        </div>
        <div className="bg-mist rounded-xl p-4">
          <p className="text-xs font-semibold text-teal-600 mb-1">What Could Come Next?</p>
          <p className="text-xs text-slatey/60 leading-relaxed">{stage.whatNext}</p>
        </div>
      </div>

      <div className="bg-aqua-50 rounded-xl p-4">
        <p className="text-xs text-slatey/70 leading-relaxed">{stage.detail}</p>
      </div>

      <button
        onClick={() => setShowWhy(!showWhy)}
        className="text-sm text-aqua-600 hover:text-aqua-700 font-medium mt-3 flex items-center gap-1"
      >
        <Info size={14} />
        {showWhy ? 'Hide' : 'Show'} scientific explanation
        <ChevronDown size={14} className={`transition-transform ${showWhy ? 'rotate-180' : ''}`} />
      </button>
      {showWhy && (
        <div className="mt-3 p-4 bg-ocean-50 rounded-xl animate-fade-slide">
          <p className="text-xs text-slatey/70 leading-relaxed">{stage.detail}</p>
        </div>
      )}

      {/* Special note for Check stage */}
      {stage.id === 'check' && (
        <div className="mt-4 flex items-start gap-2 bg-amber-50 rounded-xl p-3">
          <AlertTriangle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            AquaSense is future hardware — currently not connected. AquaCard and camera results are used when available. All readings are labelled MEASURED, ESTIMATED, OBSERVED, or SIMULATED. No values are invented.
          </p>
        </div>
      )}

      {/* Special note for Disinfect stage */}
      {stage.id === 'disinfect' && (
        <div className="mt-4 flex items-start gap-2 bg-amber-50 rounded-xl p-3">
          <AlertTriangle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            Prototype screening (AquaSense, AquaCard, camera) cannot detect bacteria. Microbial safety requires appropriate validated treatment and laboratory microbiological analysis.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── What Was Removed ───────────────────────────────────────────────────────

function WhatWasRemoved({ source }: { source: WaterSource }) {
  const removed: Record<string, { label: string; icon: React.ReactNode }[]> = {
    condensate: [{ label: 'Coil metals', icon: <Factory size={16} /> }, { label: 'Dust', icon: <Wind size={16} /> }],
    greywater: [{ label: 'Soap residue', icon: <Droplets size={16} /> }, { label: 'Hair & lint', icon: <Filter size={16} /> }, { label: 'Organics', icon: <Leaf size={16} /> }],
    wastewater: [{ label: 'Solids', icon: <Mountain size={16} /> }, { label: 'Organics', icon: <Leaf size={16} /> }, { label: 'Pathogens', icon: <Shield size={16} /> }, { label: 'Nutrients', icon: <Sprout size={16} /> }],
    rainwater: [{ label: 'Leaves & debris', icon: <Filter size={16} /> }, { label: 'Dust', icon: <Wind size={16} /> }, { label: 'Bird droppings', icon: <AlertTriangle size={16} /> }],
    brine: [{ label: 'Excess salt', icon: <Waves size={16} /> }, { label: 'Minerals', icon: <Mountain size={16} /> }],
    agricultural: [{ label: 'Soil particles', icon: <Mountain size={16} /> }, { label: 'Fertilizer residue', icon: <Sprout size={16} /> }, { label: 'Pesticides', icon: <AlertTriangle size={16} /> }],
    industrial: [{ label: 'Chemicals', icon: <FlaskConical size={16} /> }, { label: 'Metals', icon: <Factory size={16} /> }, { label: 'Heat', icon: <Thermometer size={16} /> }],
    groundwater: [{ label: 'Iron & manganese', icon: <Mountain size={16} /> }, { label: 'Dissolved minerals', icon: <Waves size={16} /> }],
  };

  const items = removed[source.id] || [];

  return (
    <div className="card p-6 animate-fade-slide">
      <h3 className="font-display font-semibold text-sm text-slatey mb-3 flex items-center gap-2">
        <Filter size={16} className="text-aqua-600" /> What Was Removed?
      </h3>
      <div className="flex flex-wrap gap-2">
        {items.map((item, i) => (
          <div key={i} className="flex items-center gap-2 bg-coral-50 text-coral-500 px-3 py-1.5 rounded-full text-xs">
            {item.icon} {item.label}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Resource Recovery ──────────────────────────────────────────────────────

function ResourceRecovery({ source }: { source: WaterSource }) {
  return (
    <div className="card p-6 animate-fade-slide">
      <h3 className="font-display font-semibold text-sm text-slatey mb-4 flex items-center gap-2">
        <Recycle size={16} className="text-teal-500" /> What We Could Recover
      </h3>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-aqua-50 rounded-xl p-4 text-center">
          <Droplets size={24} className="text-aqua-500 mx-auto mb-2 animate-float" />
          <p className="text-sm font-medium text-slatey">Water</p>
          <p className="text-xs text-slatey/50 mt-1">The treated water itself — for reuse</p>
        </div>
        <div className="bg-amber-50 rounded-xl p-4 text-center">
          <div className="text-2xl mb-2">🧂</div>
          <p className="text-sm font-medium text-slatey">Salts / Minerals</p>
          <p className="text-xs text-slatey/50 mt-1">{source.id === 'brine' ? 'From concentrated brine' : 'If present in concentrate'}</p>
        </div>
        <div className="bg-teal-50 rounded-xl p-4 text-center">
          <Sprout size={24} className="text-teal-500 mx-auto mb-2 animate-float" style={{ animationDelay: '0.3s' }} />
          <p className="text-sm font-medium text-slatey">Nutrients</p>
          <p className="text-xs text-slatey/50 mt-1">{source.id === 'wastewater' || source.id === 'agricultural' ? 'Nitrogen & phosphorus' : 'If present in source'}</p>
        </div>
        <div className="bg-ocean-50 rounded-xl p-4 text-center">
          <Recycle size={24} className="text-ocean-500 mx-auto mb-2 animate-float" style={{ animationDelay: '0.6s' }} />
          <p className="text-sm font-medium text-slatey">Other</p>
          <p className="text-xs text-slatey/50 mt-1">Source-specific recoverable materials</p>
        </div>
      </div>
      <div className="mt-3 flex items-start gap-2 bg-amber-50 rounded-xl p-3">
        <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-700">
          Resource recovery is a potential pathway, not a guaranteed result. It depends on concentration, volume, and economics.
        </p>
      </div>
    </div>
  );
}

// ─── Retest Section ──────────────────────────────────────────────────────────

function RetestSection() {
  return (
    <div className="card p-6 animate-fade-slide">
      <h3 className="font-display font-semibold text-sm text-slatey mb-4 flex items-center gap-2">
        <TestTube size={16} className="text-aqua-600" /> Before & After Comparison
      </h3>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="bg-coral-50 rounded-xl p-4">
          <p className="text-xs font-medium text-coral-500 mb-3">BEFORE TREATMENT</p>
          <div className="space-y-2">
            {[
              { label: 'pH', value: '—' },
              { label: 'TDS', value: '—' },
              { label: 'Turbidity', value: '—' },
              { label: 'Temperature', value: '—' },
            ].map((p) => (
              <div key={p.label} className="flex items-center justify-between">
                <span className="text-xs text-slatey/50">{p.label}</span>
                <span className="text-xs font-medium text-slatey/40">Not yet measured</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-teal-50 rounded-xl p-4">
          <p className="text-xs font-medium text-teal-500 mb-3">AFTER TREATMENT</p>
          <div className="space-y-2">
            {[
              { label: 'pH', value: '—' },
              { label: 'TDS', value: '—' },
              { label: 'Turbidity', value: '—' },
              { label: 'Temperature', value: '—' },
            ].map((p) => (
              <div key={p.label} className="flex items-center justify-between">
                <span className="text-xs text-slatey/50">{p.label}</span>
                <span className="text-xs font-medium text-slatey/40">Not yet measured</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-4 flex items-start gap-2 bg-amber-50 rounded-xl p-3">
        <AlertTriangle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-700">
          Retesting required before confirming treatment performance. No improvement is shown until actual before and after measurements are available from AquaSense, AquaCard, or laboratory testing.
        </p>
      </div>
      <p className="text-xs text-slatey/40 mt-2">
        When you run a water check on the Check page, those results will appear here automatically.
      </p>
    </div>
  );
}

// ─── Different Paths Section ─────────────────────────────────────────────────

function DifferentPathsSection() {
  return (
    <div className="card p-6">
      <h3 className="font-display font-semibold text-sm text-slatey mb-2 flex items-center gap-2">
        <Info size={16} className="text-ocean-600" /> Not All Water Follows the Same Path
      </h3>
      <p className="text-xs text-slatey/60 mb-4">Different sources need different treatment. Here is how pathways compare:</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {[
          { source: 'AC Condensate', path: 'Source → Check → Filter → Disinfect → Reuse', color: 'aqua' },
          { source: 'Greywater', path: 'Source → Check → Screen → Filter → Disinfect → Reuse', color: 'teal' },
          { source: 'Wastewater', path: 'Source → Check → Screen → Settle → Filter → Treat → Disinfect → Reuse', color: 'coral' },
          { source: 'Desalination Brine', path: 'Source → Check → Treat → Recover → Reuse', color: 'amber' },
          { source: 'Industrial Water', path: 'Source → Check → Screen → Treat → Filter → Disinfect → Reuse', color: 'ocean' },
        ].map((p, i) => (
          <div key={i} className="p-4 bg-mist rounded-xl">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-2.5 h-2.5 rounded-full bg-${p.color}-400 flex-shrink-0`} />
              <span className="text-xs font-semibold text-slatey">{p.source}</span>
            </div>
            <p className="text-xs text-slatey/50 leading-relaxed">{p.path}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Circular Loop Section ───────────────────────────────────────────────────

function CircularLoopSection() {
  return (
    <div className="card p-8 text-center">
      <h3 className="font-display font-bold text-lg text-slatey mb-2">The Circular Loop</h3>
      <p className="text-sm text-slatey/60 mb-6">Circularity means keeping water and useful resources in circulation for as long as practical.</p>
      <div className="relative mx-auto" style={{ maxWidth: 400 }}>
        <svg viewBox="0 0 300 300" className="w-full">
          {/* Circular path */}
          <circle cx="150" cy="150" r="110" fill="none" stroke="#1FA7C8" strokeWidth="2" strokeDasharray="5 5" className="animate-spin-slow" style={{ transformOrigin: 'center' }} />
          {/* Nodes */}
          {[
            { x: 150, y: 40, label: 'Use', icon: '💧' },
            { x: 260, y: 150, label: 'Treat', icon: '🔬' },
            { x: 150, y: 260, label: 'Recover', icon: '♻️' },
            { x: 40, y: 150, label: 'Reuse', icon: '🌱' },
          ].map((node, i) => (
            <g key={i}>
              <circle cx={node.x} cy={node.y} r="28" fill="white" stroke="#1FA7C8" strokeWidth="2" />
              <text x={node.x} y={node.y - 2} textAnchor="middle" fontSize="20">{node.icon}</text>
              <text x={node.x} y={node.y + 14} textAnchor="middle" fontSize="10" fill="#18323D" fontWeight="600">{node.label}</text>
            </g>
          ))}
          {/* Center text */}
          <text x="150" y="145" textAnchor="middle" fontSize="11" fill="#063B5C" fontWeight="700">Water</text>
          <text x="150" y="158" textAnchor="middle" fontSize="11" fill="#063B5C" fontWeight="700">Circularity</text>
        </svg>
      </div>
      <p className="text-xs text-slatey/50 mt-4 max-w-md mx-auto">
        Instead of using water once and discarding it, circularity keeps water in the system — treating, recovering resources, and reusing it for as long as practical.
      </p>
    </div>
  );
}

// ─── Connect to Other Features ──────────────────────────────────────────────

function ConnectFeaturesSection() {
  return (
    <div className="card p-6">
      <h3 className="font-display font-semibold text-sm text-slatey mb-2 flex items-center gap-2">
        <Sparkles size={16} className="text-aqua-600" /> How This Connects to ReWater
      </h3>
      <p className="text-xs text-slatey/60 mb-4">The Water Journey is one part of the ReWater system. Here is how it fits together:</p>
      <div className="space-y-2">
        {[
          { icon: <MapIcon size={16} />, label: 'Find Water', desc: 'Where did we find this water?' },
          { icon: <Cpu size={16} />, label: 'AquaSense', desc: 'What did we measure?' },
          { icon: <FlaskConical size={16} />, label: 'AquaCard', desc: 'What did the test indicate?' },
          { icon: <Beaker size={16} />, label: 'AI Analysis', desc: 'What problems might require investigation?' },
          { icon: <Recycle size={16} />, label: 'Water Journey', desc: 'What treatment/reuse pathways could apply?' },
          { icon: <BarChart3 size={16} />, label: 'Impact', desc: 'What could happen if this pathway were implemented at scale?' },
          { icon: <FlaskConical size={16} />, label: 'Future Lab', desc: 'What emerging technologies could improve these pathways?' },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-3 p-3 bg-mist rounded-xl">
            <span className="text-aqua-600 flex-shrink-0">{item.icon}</span>
            <span className="text-xs font-medium text-slatey w-32 flex-shrink-0">{item.label}</span>
            <span className="text-xs text-slatey/50">{item.desc}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
