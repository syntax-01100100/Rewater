import { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { Search, MapPin, Filter, Droplets, Waves, Thermometer, Zap, X, Navigation, AlertCircle, Sun, Flame } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { supabase, type WaterSource } from '@/lib/supabase';
import { sourceTypeLabels, sourceTypeColors, phLabel, tdsLabel, turbidityLabel } from '@/lib/utils';

const filterOptions = [
  { id: 'all', label: 'All Sources' },
  { id: 'groundwater', label: 'Groundwater' },
  { id: 'surface', label: 'Surface Water' },
  { id: 'rainwater', label: 'Rainwater' },
  { id: 'wastewater', label: 'Wastewater' },
  { id: 'greywater', label: 'Greywater' },
  { id: 'condensate', label: 'AC Condensate' },
  { id: 'stormwater', label: 'Stormwater' },
  { id: 'seawater', label: 'Seawater' },
  { id: 'atmospheric', label: 'Atmospheric' },
];

const dataLabelColors: Record<string, string> = {
  VERIFIED: '#2E9D8C',
  ESTIMATED: '#1FA7C8',
  MODELLED: '#2E77A0',
  OBSERVED: '#48B7A5',
  'FUTURE CONCEPT': '#F2B84B',
};

const DEMO_WATER_SOURCES: WaterSource[] = [
  {
    id: 'demo-ac-condensate', name: 'Dubai AC Condensate', type: 'condensate',
    latitude: 25.2048, longitude: 55.2708, quality: 'Relatively clean; screening required',
    ph: 7.1, turbidity: 1.2, tds: 45, temperature: 24, status: 'estimated',
    description: 'Illustrative building-level AC condensate recovery opportunity.',
    is_hidden_water: true, recovery_potential: 'Irrigation and cooling make-up', created_at: new Date(0).toISOString(),
  },
  {
    id: 'demo-greywater-abu-dhabi', name: 'Abu Dhabi Greywater', type: 'greywater',
    latitude: 24.4539, longitude: 54.3773, quality: 'Requires treatment before reuse',
    ph: 7.4, turbidity: 8, tds: 420, temperature: 27, status: 'estimated',
    description: 'Illustrative residential and commercial greywater source.',
    is_hidden_water: true, recovery_potential: 'Toilet flushing and landscaping', created_at: new Date(0).toISOString(),
  },
  {
    id: 'demo-rainwater-al-ain', name: 'Al Ain Rainwater Capture', type: 'rainwater',
    latitude: 24.1916, longitude: 55.7609, quality: 'Seasonal source; filtration required',
    ph: 6.9, turbidity: 3.5, tds: 35, temperature: 22, status: 'estimated',
    description: 'Illustrative rooftop rainwater collection opportunity.',
    is_hidden_water: true, recovery_potential: 'Irrigation and non-potable cleaning', created_at: new Date(0).toISOString(),
  },
  {
    id: 'demo-treated-wastewater-sharjah', name: 'Sharjah Treated Wastewater', type: 'wastewater',
    latitude: 25.3463, longitude: 55.4209, quality: 'Treatment and verification required',
    ph: 7.6, turbidity: 4.2, tds: 680, temperature: 29, status: 'estimated',
    description: 'Illustrative treated effluent reuse opportunity.',
    is_hidden_water: false, recovery_potential: 'Landscaping and industrial reuse', created_at: new Date(0).toISOString(),
  },
  {
    id: 'demo-groundwater-fujairah', name: 'Fujairah Groundwater', type: 'groundwater',
    latitude: 25.1288, longitude: 56.3265, quality: 'Source-specific testing required',
    ph: 7.8, turbidity: 1.8, tds: 510, temperature: 26, status: 'estimated',
    description: 'Illustrative groundwater source for screening and monitoring.',
    is_hidden_water: false, recovery_potential: 'Irrigation or industrial use after verification', created_at: new Date(0).toISOString(),
  },
];

// UAE heat / water-need zones — simulated current conditions (September 2026)
// Based on typical UAE summer temperature ranges and outdoor worker density
const heatZones = [
  { name: 'Abu Dhabi City', lat: 24.4539, lng: 54.3773, temp: 43, need: 'high', workers: 180000, radius: 25000 },
  { name: 'Dubai (Deira/Bur Dubai)', lat: 25.2048, lng: 55.2708, temp: 44, need: 'critical', workers: 320000, radius: 22000 },
  { name: 'Dubai Marina / JBR', lat: 25.0805, lng: 55.1403, temp: 43, need: 'high', workers: 95000, radius: 12000 },
  { name: 'Sharjah Industrial Area', lat: 25.2854, lng: 55.4632, temp: 45, need: 'critical', workers: 140000, radius: 18000 },
  { name: 'Al Ain', lat: 24.1916, lng: 55.7609, temp: 46, need: 'high', workers: 65000, radius: 20000 },
  { name: 'Jebel Ali Industrial', lat: 25.0125, lng: 55.0833, temp: 44, need: 'critical', workers: 210000, radius: 20000 },
  { name: 'Ras Al Khaimah', lat: 25.6747, lng: 55.9414, temp: 42, need: 'moderate', workers: 38000, radius: 15000 },
  { name: 'Fujairah / Dibba', lat: 25.1166, lng: 56.3260, temp: 41, need: 'moderate', workers: 28000, radius: 14000 },
  { name: 'Liwa / Western Region', lat: 23.1260, lng: 53.7660, temp: 47, need: 'high', workers: 22000, radius: 30000 },
  { name: 'Ruweis / Ghuwaifat', lat: 24.1870, lng: 51.6090, temp: 46, need: 'moderate', workers: 15000, radius: 18000 },
];

const needColors: Record<string, string> = {
  critical: '#EF4444',
  high: '#F59E0B',
  moderate: '#EAB308',
};

const needLabels: Record<string, string> = {
  critical: 'Critical',
  high: 'High',
  moderate: 'Moderate',
};

export function MapPage() {
  const [sources, setSources] = useState<WaterSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<WaterSource | null>(null);
  const [showHiddenOnly, setShowHiddenOnly] = useState(false);
  const [showHeatZones, setShowHeatZones] = useState(false);

  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const heatLayerRef = useRef<L.LayerGroup | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const loadSources = useCallback(async () => {
    setLoading(true);
    setLoadError(false);

    try {
      const { data, error } = await supabase.from('water_sources').select('*').order('name');
      if (error) throw error;
      setSources(data || []);
    } catch {
      setSources(DEMO_WATER_SOURCES);
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSources();
  }, [loadSources]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [24.5, 54.0],
      zoom: 7,
      scrollWheelZoom: true,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(map);

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  const filtered = useMemo(() => {
    return sources.filter((s) => {
      if (filter !== 'all' && s.type !== filter) return false;
      if (showHiddenOnly && !s.is_hidden_water) return false;
      if (search && !s.name.toLowerCase().includes(search.toLowerCase()) && !s.description?.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [sources, filter, search, showHiddenOnly]);

  useEffect(() => {
    if (!mapRef.current) return;

    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    filtered.forEach((source) => {
      const color = sourceTypeColors[source.type] || '#1FA7C8';
      const icon = L.divIcon({
        className: 'rewater-marker',
        html: `${source.is_hidden_water ? '<div class="rewater-pulse"></div>' : ''}<div class="rewater-pin" style="background:${color}"></div>`,
        iconSize: [20, 20],
        iconAnchor: [10, 10],
      });
      const marker = L.marker([source.latitude, source.longitude], { icon })
        .addTo(mapRef.current!)
        .on('click', () => setSelected(source));
      markersRef.current.push(marker);
    });
  }, [filtered]);

  // Heat zones layer
  useEffect(() => {
    if (!mapRef.current) return;

    if (!showHeatZones) {
      if (heatLayerRef.current) {
        heatLayerRef.current.remove();
        heatLayerRef.current = null;
      }
      return;
    }

    const layer = L.layerGroup();
    heatZones.forEach((zone) => {
      const color = needColors[zone.need] || '#F59E0B';
      // Heat circle
      L.circle([zone.lat, zone.lng], {
        radius: zone.radius,
        color,
        fillColor: color,
        fillOpacity: 0.15,
        weight: 1.5,
        dashArray: '4 4',
      }).addTo(layer);

      // Temperature label marker
      const labelIcon = L.divIcon({
        className: 'rewater-heat-label',
        html: `<div style="background:${color};color:white;padding:2px 6px;border-radius:6px;font-size:10px;font-weight:700;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,0.2);">${zone.temp}°C · ${needLabels[zone.need]}</div>`,
        iconSize: [80, 16],
        iconAnchor: [40, 8],
      });
      L.marker([zone.lat, zone.lng], { icon: labelIcon }).addTo(layer);
    });
    layer.addTo(mapRef.current);
    heatLayerRef.current = layer;

    return () => {
      layer.remove();
      heatLayerRef.current = null;
    };
  }, [showHeatZones]);

  useEffect(() => {
    if (selected && mapRef.current) {
      mapRef.current.flyTo([selected.latitude, selected.longitude], 10, { duration: 0.8 });
    }
  }, [selected]);

  return (
    <div className="min-h-screen pt-16 bg-gradient-mist">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-6">
          <h1 className="font-display font-bold text-3xl text-ocean-600 mb-2">Water Source Map</h1>
          <p className="text-slatey/60">Explore water sources and recovery opportunities across the UAE</p>
          {loadError && !loading && (
            <div className="mt-4 flex items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-left">
              <div className="flex items-start gap-2">
                <AlertCircle size={16} className="mt-0.5 flex-shrink-0 text-amber-600" />
                <p className="text-xs text-amber-800">
                  Live source data is unavailable, so the map is showing labelled demo sources.
                </p>
              </div>
              <button onClick={() => void loadSources()} className="btn-secondary flex-shrink-0 px-3 py-1.5 text-xs">
                Retry
              </button>
            </div>
          )}
        </div>

        {/* Heat zones toggle */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <button
            onClick={() => setShowHeatZones(!showHeatZones)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              showHeatZones
                ? 'bg-coral-500 text-white shadow-soft'
                : 'bg-white text-slatey border border-softgrey hover:bg-mist'
            }`}
          >
            <Sun size={16} /> {showHeatZones ? 'Hide' : 'Show'} Heat & Water-Need Zones
          </button>
          {showHeatZones && (
            <span className="text-xs text-slatey/50">
              Simulated current temperatures (Sep 2026) · Red = critical hydration need
            </span>
          )}
        </div>

        <div className="grid lg:grid-cols-[1fr_360px] gap-6">
          {/* Map */}
          <div className="card p-0 overflow-hidden">
            <div className="relative" style={{ height: '500px' }}>
              <div ref={containerRef} className="w-full h-full" />

              {/* Legend overlay */}
              <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-md rounded-xl p-3 shadow-soft max-w-[200px] z-[1000] pointer-events-none">
                <p className="text-xs font-medium text-slatey mb-2">Water Source Types</p>
                <div className="grid grid-cols-2 gap-1">
                  {Object.entries(sourceTypeLabels).slice(0, 8).map(([key, label]) => (
                    <div key={key} className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ background: sourceTypeColors[key] }} />
                      <span className="text-xs text-slatey/60">{label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Data labels legend */}
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md rounded-xl p-3 shadow-soft z-[1000] pointer-events-none">
                <p className="text-xs font-medium text-slatey mb-2">Data Labels</p>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(dataLabelColors).map(([label, color]) => (
                    <span key={label} className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ color, border: `1px solid ${color}40` }}>
                      {label}
                    </span>
                  ))}
                </div>
              </div>

              {/* Compass */}
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md rounded-full w-10 h-10 flex items-center justify-center shadow-soft z-[1000] pointer-events-none">
                <Navigation size={16} className="text-ocean-600" />
              </div>

              {/* Heat zones legend */}
              {showHeatZones && (
                <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-md rounded-xl p-3 shadow-soft z-[1000] pointer-events-none max-w-[180px]">
                  <p className="text-xs font-medium text-slatey mb-2 flex items-center gap-1.5">
                    <Flame size={12} className="text-coral-500" /> Water-Need Level
                  </p>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <div className="w-3 h-3 rounded-full" style={{ background: needColors.critical }} />
                      <span className="text-xs text-slatey/60">Critical (43°C+)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-3 h-3 rounded-full" style={{ background: needColors.high }} />
                      <span className="text-xs text-slatey/60">High (41-42°C)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-3 h-3 rounded-full" style={{ background: needColors.moderate }} />
                      <span className="text-xs text-slatey/60">Moderate (&lt;41°C)</span>
                    </div>
                  </div>
                </div>
              )}

              {loading && (
                <div className="absolute inset-0 flex items-center justify-center bg-mist/80 z-[1001]">
                  <div className="text-center">
                    <div className="inline-block w-8 h-8 border-3 border-aqua-400 border-t-transparent rounded-full animate-spin mb-2" />
                    <div className="text-sm text-slatey/60">Loading map...</div>
                  </div>
                </div>
              )}


            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Search */}
            <div className="card p-4">
              <div className="relative">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slatey/40" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by name or location..."
                  className="input-field pl-10"
                />
              </div>
            </div>

            {/* Filters */}
            <div className="card p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-slatey flex items-center gap-2">
                  <Filter size={16} className="text-aqua-400" /> Filters
                </span>
                <button
                  onClick={() => { setFilter('all'); setSearch(''); setShowHiddenOnly(false); }}
                  className="text-xs text-slatey/50 hover:text-slatey"
                >
                  Clear
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {filterOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setFilter(opt.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      filter === opt.id
                        ? 'bg-ocean-600 text-white'
                        : 'bg-mist text-slatey/60 hover:bg-softgrey'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showHiddenOnly}
                  onChange={(e) => setShowHiddenOnly(e.target.checked)}
                  className="w-4 h-4 rounded accent-teal-400"
                />
                <span className="text-sm text-slatey/70">Hidden water sources only</span>
              </label>
            </div>

            {/* Source list */}
            <div className="card p-4 max-h-[400px] overflow-y-auto">
              <p className="text-sm font-medium text-slatey mb-3">{filtered.length} sources found</p>
              <div className="space-y-2">
                {filtered.map((source) => (
                  <button
                    key={source.id}
                    onClick={() => setSelected(source)}
                    className={`w-full text-left p-3 rounded-xl transition-all ${
                      selected?.id === source.id ? 'bg-aqua-50 border border-aqua-200' : 'hover:bg-mist border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: sourceTypeColors[source.type] || '#1FA7C8' }} />
                      <span className="text-sm font-medium text-slatey flex-1 truncate">{source.name}</span>
                      {source.is_hidden_water && <span className="badge-teal text-xs">Hidden</span>}
                    </div>
                    <p className="text-xs text-slatey/50 mt-1 ml-4">{sourceTypeLabels[source.type] || source.type}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Heat zones panel */}
            {showHeatZones && (
              <div className="card p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Sun size={16} className="text-amber-500" />
                  <span className="text-sm font-medium text-slatey">Water-Need Zones</span>
                </div>
                <p className="text-xs text-slatey/50 mb-3">
                  Areas where high temperatures and outdoor worker density create the greatest hydration demand.
                  Water Credits from recovered water can support these zones.
                </p>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {heatZones.sort((a, b) => b.temp - a.temp).map((zone) => (
                    <div key={zone.name} className="flex items-center justify-between p-2 rounded-lg bg-mist">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: needColors[zone.need] }} />
                        <span className="text-xs font-medium text-slatey">{zone.name}</span>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <span className="text-xs font-bold text-slatey">{zone.temp}°C</span>
                        <span className="text-xs text-slatey/40 ml-1.5">~{(zone.workers / 1000).toFixed(0)}k workers</span>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-amber-600/70 mt-2">
                  Simulated data based on typical UAE September conditions. Actual temperatures vary daily.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Detail modal */}
        {selected && (
          <div className="fixed inset-0 z-[2000] flex items-end sm:items-center justify-center p-4">
            <div className="absolute inset-0 bg-ocean-900/40 backdrop-blur-sm" onClick={() => setSelected(null)} />
            <div className="relative card max-w-lg w-full p-6 animate-fade-slide max-h-[80vh] overflow-y-auto">
              <button onClick={() => setSelected(null)} className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-mist">
                <X size={18} className="text-slatey/50" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${sourceTypeColors[selected.type]}20` }}>
                  <MapPin size={24} style={{ color: sourceTypeColors[selected.type] }} />
                </div>
                <div>
                  <h2 className="font-display font-bold text-xl text-slatey">{selected.name}</h2>
                  <p className="text-sm text-slatey/50">{sourceTypeLabels[selected.type] || selected.type}</p>
                </div>
              </div>

              {selected.is_hidden_water && (
                <div className="badge-teal mb-4">
                  <Droplets size={12} /> Hidden Water Source
                </div>
              )}

              {/* Data label */}
              <div className="mb-4">
                <span className="text-xs px-3 py-1 rounded-full font-medium" style={{
                  color: dataLabelColors['ESTIMATED'],
                  border: `1px solid ${dataLabelColors['ESTIMATED']}40`,
                  background: `${dataLabelColors['ESTIMATED']}10`,
                }}>
                  ESTIMATED
                </span>
              </div>

              {selected.quality && (
                <div className="mb-4 p-3 bg-mist rounded-xl">
                  <p className="text-sm text-slatey/70">{selected.quality}</p>
                </div>
              )}

              {selected.description && (
                <p className="text-sm text-slatey/60 mb-4">{selected.description}</p>
              )}

              {/* Quality data */}
              {(selected.ph || selected.tds || selected.turbidity || selected.temperature) && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                  {selected.ph && (
                    <div className="bg-mist rounded-lg p-3 text-center">
                      <Droplets size={16} className="mx-auto text-ocean-400 mb-1" />
                      <div className="text-xs text-slatey/40">pH</div>
                      <div className="font-display font-bold text-lg text-slatey">{selected.ph}</div>
                      <span className={`badge-${phLabel(selected.ph).color} text-xs mt-1`}>{phLabel(selected.ph).label}</span>
                    </div>
                  )}
                  {selected.temperature && (
                    <div className="bg-mist rounded-lg p-3 text-center">
                      <Thermometer size={16} className="mx-auto text-aqua-400 mb-1" />
                      <div className="text-xs text-slatey/40">Temp</div>
                      <div className="font-display font-bold text-lg text-slatey">{selected.temperature}°C</div>
                    </div>
                  )}
                  {selected.turbidity !== null && (
                    <div className="bg-mist rounded-lg p-3 text-center">
                      <Waves size={16} className="mx-auto text-teal-400 mb-1" />
                      <div className="text-xs text-slatey/40">Turbidity</div>
                      <div className="font-display font-bold text-lg text-slatey">{selected.turbidity}</div>
                      <span className={`badge-${turbidityLabel(selected.turbidity).color} text-xs mt-1`}>{turbidityLabel(selected.turbidity).label}</span>
                    </div>
                  )}
                  {selected.tds && (
                    <div className="bg-mist rounded-lg p-3 text-center">
                      <Zap size={16} className="mx-auto text-ocean-400 mb-1" />
                      <div className="text-xs text-slatey/40">TDS</div>
                      <div className="font-display font-bold text-lg text-slatey">{selected.tds}</div>
                      <span className={`badge-${tdsLabel(selected.tds).color} text-xs mt-1`}>{tdsLabel(selected.tds).label}</span>
                    </div>
                  )}
                </div>
              )}

              {selected.recovery_potential && (
                <div className="p-3 bg-gradient-to-r from-teal-50 to-aqua-50 rounded-xl border border-teal-100">
                  <p className="text-xs text-teal-600 font-medium mb-1">Recovery Potential</p>
                  <p className="text-sm text-slatey/70">{selected.recovery_potential}</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
