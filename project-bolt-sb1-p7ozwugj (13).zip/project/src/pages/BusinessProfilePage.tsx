import { useState, useEffect, useCallback } from 'react';
import {
  Building2, ArrowLeft, Save, Check, MapPin, Phone, Mail,
  Droplets, Recycle, Sparkles, HandHeart, Users, BarChart3,
  FileBarChart, Download, Calendar, TrendingUp,
  Shield, Info, Camera, Briefcase, Droplet, ArrowRight,
  Coins, History, Wallet, FlaskConical, BadgeCheck, Target,
  Lock, Crown,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useWaterPassport, passportStatusLabel, passportStatusColor, type PassportStatus } from '@/lib/waterPassport';
import { supabase, type HydroStation, type WaterCreditTransaction, type BusinessSubscription, type ReWaterRevenue } from '@/lib/supabase';
import {
  fetchCreditTransactions, fetchCreditBalance, type CreditBalance,
  calculateRecoveryRate, calculateCreditEligible, calculateCredits, CREDIT_CONFIG,
  SUBSCRIPTION_PLANS, type SubscriptionPlan, fetchSubscription, updateSubscription, cancelSubscription, hasFeatureAccess,
  isSubscriptionInTrial, trialDaysRemaining,
  fetchReWaterRevenue,
} from '@/lib/waterCredits';
import { type PageId } from '@/components/Navigation';

interface BusinessProfilePageProps {
  onNavigate: (page: PageId) => void;
}

const FEATURE_LABELS: Record<string, string> = {
  water_passports: 'Water Passports',
  water_journey: 'Water Journey',
  water_credits: 'Water Credit Tracking',
  impact_reporting: 'Impact Reporting',
  analytics: 'Analytics',
  predictive_mapping: 'Predictive Mapping',
  esg_export: 'ESG Data Export',
  priority_support: 'Priority Support',
  custom_integrations: 'Custom Integrations',
};

export function BusinessProfilePage({ onNavigate }: BusinessProfilePageProps) {
  const { user } = useAuth();
  const { passports } = useWaterPassport();
  const [stations, setStations] = useState<HydroStation[]>([]);
  const [transactions, setTransactions] = useState<WaterCreditTransaction[]>([]);
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [subscription, setSubscription] = useState<BusinessSubscription | null>(null);
  const [revenue, setRevenue] = useState<ReWaterRevenue[]>([]);

  const [businessName, setBusinessName] = useState('');
  const [industry, setIndustry] = useState('Manufacturing');
  const [facility, setFacility] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [saved, setSaved] = useState(false);
  const [showPlans, setShowPlans] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    const [{ data: stationData }, txns, bal, sub, rev] = await Promise.all([
      supabase.from('hydro_stations').select('*').order('created_at', { ascending: false }),
      fetchCreditTransactions(user.id),
      fetchCreditBalance(user.id),
      fetchSubscription(user.id),
      fetchReWaterRevenue(user.id),
    ]);
    setStations(stationData || []);
    setTransactions(txns);
    setBalance(bal);
    setSubscription(sub);
    setRevenue(rev);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  const getPassportLitres = (p: typeof passports[0]): number => {
    if (p.inputWaterLitres != null) return p.inputWaterLitres;
    if (!p.quantity || p.quantity <= 0) return 0;
    if (p.unit === 'mL') return p.quantity / 1000;
    if (p.unit === 'm³' || p.unit === 'm3') return p.quantity * 1000;
    return p.quantity;
  };

  const getRecoveredLitres = (p: typeof passports[0]): number => {
    return p.recoveredWaterLitres ?? 0;
  };

  const isPassportActive = (p: typeof passports[0]): boolean =>
    p.recoveryHistory.length > 0 || p.reuseHistory.length > 0 ||
    p.currentStage === 'treated' || p.currentStage === 'verified' || p.currentStage === 'reuse_pathway';

  const isPassportVerified = (p: typeof passports[0]): boolean =>
    p.currentStage === 'verified' || p.currentStage === 'reuse_pathway';

  const totalInput = passports.reduce((sum, p) => sum + (isPassportActive(p) ? getPassportLitres(p) : 0), 0);
  const litresRecovered = passports.reduce((sum, p) => sum + (isPassportActive(p) ? getRecoveredLitres(p) : 0), 0);
  const totalLoss = totalInput > 0 && litresRecovered > 0 ? totalInput - litresRecovered : 0;
  const recoveryRate = totalInput > 0 ? calculateRecoveryRate(totalInput, litresRecovered) : 0;
  const litresReused = passports.reduce((sum, p) => sum + (p.reuseHistory.length > 0 ? getPassportLitres(p) : 0), 0);

  // Business return: credit-eligible water and credits
  const totalCreditEligible = passports.reduce((sum, p) => sum + (isPassportActive(p) ? calculateCreditEligible(getRecoveredLitres(p)) : 0), 0);
  const totalCreditsFromWater = calculateCredits(litresRecovered).creditsGenerated;

  const totalLitresDispensed = stations.reduce((s, st) => s + st.total_litres_dispensed, 0);
  const totalWorkerVisits = stations.reduce((s, st) => s + st.total_worker_visits, 0);

  const creditsEarned = balance?.earned ?? 0;
  const creditsUsed = balance?.used ?? 0;
  const creditsAssigned = balance?.assigned ?? 0;
  const creditsDonated = balance?.donated ?? 0;
  const currentBalance = balance?.current ?? 0;

  const totalReWaterRevenue = revenue.reduce((s, r) => s + r.amount_aed, 0);
  const subscriptionRevenue = revenue.filter(r => r.source === 'subscription').reduce((s, r) => s + r.amount_aed, 0);
  const serviceFeeRevenue = revenue.filter(r => r.source === 'service_fee').reduce((s, r) => s + r.amount_aed, 0);

  const fmtL = (n: number) => n > 0 ? `${n.toLocaleString()} L` : '0 L';
  const fmtAed = (n: number) => `AED ${n.toFixed(2)}`;

  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  const handleExport = () => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const lines: string[] = [];
    lines.push('REWATER IMPACT REPORT');
    lines.push('=====================');
    lines.push(`Generated: ${now.toLocaleString()}`);
    lines.push('');
    lines.push(`Business: ${businessName || 'Business Profile'}`);
    lines.push(`Industry: ${industry}`);
    lines.push(`Facility: ${facility}`);
    lines.push('');
    lines.push('--- BUSINESS RETURN ---');
    lines.push(`Water Recovered: ${fmtL(litresRecovered)}`);
    lines.push(`Recovery Rate: ${recoveryRate.toFixed(1)}%`);
    lines.push(`Credit-Eligible Water: ${totalCreditEligible.toFixed(1)} L`);
    lines.push(`Credits Generated: ${creditsEarned}`);
    lines.push(`Credits Donated: ${creditsDonated}`);
    lines.push(`HydroStations Supported: ${stations.length}`);
    lines.push(`Impact Created (Dispensed): ${fmtL(totalLitresDispensed)}`);
    lines.push('');
    lines.push('--- ENVIRONMENTAL METRICS ---');
    lines.push(`Total Water Input: ${fmtL(totalInput)}`);
    lines.push(`Total Water Recovered: ${fmtL(litresRecovered)}`);
    lines.push(`Total Treatment Loss: ${fmtL(totalLoss)}`);
    lines.push(`Recovery Rate: ${recoveryRate.toFixed(1)}%`);
    lines.push(`Total Water Reused: ${fmtL(litresReused)}`);
    lines.push(`Active Passports: ${passports.length}`);
    lines.push('');
    lines.push('--- HYDRATION FUNDING (WATER CREDITS) ---');
    lines.push(`Credits Earned: ${creditsEarned}`);
    lines.push(`Credits Assigned: ${creditsAssigned}`);
    lines.push(`Credits Used: ${creditsUsed.toFixed(2)}`);
    lines.push(`Credits Donated: ${creditsDonated}`);
    lines.push(`Current Balance: ${currentBalance.toFixed(2)}`);
    lines.push(`Stations Supported: ${stations.length}`);
    lines.push(`Drinking Water Dispensed: ${fmtL(totalLitresDispensed)}`);
    lines.push(`Verified Worker Visits: ${totalWorkerVisits}`);
    lines.push('');
    lines.push('--- REWATER REVENUE ---');
    lines.push(`Total Revenue: ${fmtAed(totalReWaterRevenue)}`);
    lines.push(`From Subscriptions: ${fmtAed(subscriptionRevenue)}`);
    lines.push(`From Service Fees: ${fmtAed(serviceFeeRevenue)}`);
    lines.push('');
    lines.push('--- SUBSCRIPTION ---');
    if (subscription) {
      lines.push(`Plan: ${SUBSCRIPTION_PLANS[subscription.plan as SubscriptionPlan]?.name ?? subscription.plan}`);
      lines.push(`Status: ${subscription.status}`);
      if (isSubscriptionInTrial(subscription)) {
        lines.push(`Trial: ${trialDaysRemaining(subscription)} days remaining`);
      }
      lines.push(`Features: ${subscription.features.join(', ')}`);
      if (subscription.started_at) lines.push(`Started: ${new Date(subscription.started_at).toLocaleDateString()}`);
      if (subscription.cancelled_at) lines.push(`Cancelled: ${new Date(subscription.cancelled_at).toLocaleDateString()}`);
    } else {
      lines.push('Plan: Free');
      lines.push('Status: No subscription');
    }
    lines.push('');
    lines.push('--- CREDIT TRANSACTION HISTORY ---');
    if (transactions.length === 0) {
      lines.push('No transactions yet.');
    } else {
      transactions.forEach((t, i) => {
        lines.push(`  ${i + 1}. [${t.transaction_type.toUpperCase()}] ${t.amount} credits — ${t.description}`);
        if (t.station_name) lines.push(`     Station: ${t.station_name}`);
        if (t.sponsor) lines.push(`     Sponsor: ${t.sponsor}`);
        if (t.treatment_partner) lines.push(`     Treatment Partner: ${t.treatment_partner}`);
        if (t.verification_partner) lines.push(`     Verification Partner: ${t.verification_partner}`);
        lines.push(`     Date: ${new Date(t.created_at).toLocaleString()}`);
        lines.push(`     Balance After: ${t.balance_after}`);
      });
    }
    lines.push('');
    lines.push('--- WATER PASSPORTS ---');
    if (passports.length === 0) {
      lines.push('No passports yet.');
    } else {
      passports.forEach((p, i) => {
        const status = passportStatusLabel(
          p.currentStage === 'verified' || p.currentStage === 'reuse_pathway' ? 'completed' :
          p.currentStage === 'retest_required' ? 'awaiting_retest' :
          p.currentStage === 'not_verified' ? 'treatment_required' : 'ongoing'
        );
        lines.push(`  ${i + 1}. ${p.waterId} — ${status}`);
        lines.push(`     Source: ${p.source}`);
        if (p.inputWaterLitres != null) lines.push(`     Input: ${p.inputWaterLitres} L`);
        if (p.recoveredWaterLitres != null) lines.push(`     Recovered: ${p.recoveredWaterLitres} L`);
        if (p.recoveryRate) lines.push(`     Recovery Rate: ${p.recoveryRate}%`);
        if (p.creditsGenerated) lines.push(`     Credits: ${p.creditsGenerated}`);
      });
    }
    lines.push('');
    lines.push('=== END OF REPORT ===');
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rewater-impact-report-${dateStr}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUpgrade = async (plan: SubscriptionPlan) => {
    if (!user) return;
    const ok = await updateSubscription(user.id, plan);
    if (ok) {
      await loadData();
      setShowPlans(false);
    }
  };

  const handleCancel = async () => {
    if (!user) return;
    const ok = await cancelSubscription(user.id);
    if (ok) {
      await loadData();
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slatey/60 mb-4">Please sign in to view your business profile.</p>
          <button onClick={() => onNavigate('home')} className="btn-primary">Back to Home</button>
        </div>
      </div>
    );
  }

  const currentPlan = subscription?.plan ?? 'free';

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-b from-teal-50 via-mist to-mist">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-sm text-slatey/50 hover:text-ocean-600 transition-colors">
            <ArrowLeft size={16} /> Back to Home
          </button>
        </div>

        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-500 to-ocean-400 flex items-center justify-center text-white mx-auto mb-4 shadow-float">
            <Building2 size={36} />
          </div>
          <h1 className="font-display font-bold text-2xl text-ocean-600">Business Profile</h1>
          <p className="text-sm text-slatey/60 mt-1">
            Track your organization's water recovery, contributions, and impact.
          </p>
          {user.isDemo && (
            <span className="inline-block mt-2 text-xs font-bold text-amber-600 bg-amber-100 px-3 py-1 rounded-full">DEMO ACCOUNT</span>
          )}
        </div>

        {/* Separation notice */}
        <div className="card p-4 mb-6 bg-aqua-50 border-aqua-100">
          <div className="flex items-start gap-3">
            <Info size={18} className="text-aqua-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-aqua-800">
              Your environmental contribution and your hydration funding are tracked separately.
            </p>
          </div>
        </div>

        {/* Business Information */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Briefcase size={20} className="text-teal-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Business Information</h2>
          </div>
          <div className="flex items-center gap-4 mb-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-ocean-400 flex items-center justify-center text-white shadow-soft">
              <Building2 size={28} />
            </div>
            <div>
              <button className="text-sm text-teal-600 hover:text-teal-700 font-medium flex items-center gap-2">
                <Camera size={14} /> Upload logo
              </button>
              <p className="text-xs text-slatey/40 mt-1">Optional — a default icon is used</p>
            </div>
          </div>
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Business Name</label>
                <input type="text" value={businessName} onChange={e => setBusinessName(e.target.value)} placeholder="Your organization name"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Industry</label>
                <select value={industry} onChange={e => setIndustry(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all">
                  {['Manufacturing','Construction','Hospitality','Real Estate','Agriculture','Logistics','Other'].map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5"><MapPin size={14} /> Facility / Location</label>
              <input type="text" value={facility} onChange={e => setFacility(e.target.value)} placeholder="e.g. Dubai Industrial Park, Building 7"
                className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all" />
            </div>
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Contact Name</label>
                <input type="text" value={contactName} onChange={e => setContactName(e.target.value)} placeholder="Contact person"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5"><Mail size={14} /> Email</label>
                <input type="email" value={contactEmail} onChange={e => setContactEmail(e.target.value)} placeholder="contact@business.com"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5"><Phone size={14} /> Phone</label>
                <input type="tel" value={contactPhone} onChange={e => setContactPhone(e.target.value)} placeholder="+971 50 000 0000"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all" />
              </div>
            </div>
          </div>
        </section>

        {/* Business Return */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <TrendingUp size={20} className="text-teal-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Business Return</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {[
              { label: 'Water Recovered', value: fmtL(litresRecovered), icon: <Droplets size={18} /> },
              { label: 'Recovery Rate', value: `${recoveryRate.toFixed(1)}%`, icon: <Recycle size={18} /> },
              { label: 'Credit-Eligible Water', value: `${totalCreditEligible.toFixed(1)} L`, icon: <Sparkles size={18} /> },
              { label: 'Credits Earned', value: creditsEarned.toFixed(2), icon: <Coins size={18} /> },
            ].map((item) => (
              <div key={item.label} className="bg-mist rounded-xl p-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-teal-600">{item.icon}</span>
                  <span className="text-sm font-medium text-slatey">{item.label}</span>
                </div>
                <p className="font-display font-bold text-xl text-slatey ml-6">{item.value}</p>
              </div>
            ))}
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Credits Generated', value: creditsEarned.toFixed(0), icon: <Sparkles size={18} /> },
              { label: 'Credits Donated', value: creditsDonated.toFixed(0), icon: <HandHeart size={18} /> },
              { label: 'HydroStations Supported', value: String(stations.length), icon: <Droplet size={18} /> },
              { label: 'Impact Created', value: fmtL(totalLitresDispensed), icon: <Target size={18} /> },
            ].map((item) => (
              <div key={item.label} className="bg-mist rounded-xl p-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-aqua-600">{item.icon}</span>
                  <span className="text-sm font-medium text-slatey">{item.label}</span>
                </div>
                <p className="font-display font-bold text-xl text-slatey ml-6">{item.value}</p>
              </div>
            ))}
          </div>
          {/* Credit calculation breakdown */}
          <div className="bg-gradient-to-br from-aqua-50 to-teal-50 rounded-xl p-4 mt-4">
            <p className="text-xs font-semibold text-slatey mb-3">Credit Calculation (Prototype Partnership Model)</p>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center">
                <p className="font-display font-bold text-lg text-teal-700">{fmtL(litresRecovered)}</p>
                <p className="text-xs text-slatey/50">Water Recovered</p>
              </div>
              <div className="text-center">
                <p className="font-display font-bold text-lg text-aqua-700">{totalCreditEligible.toFixed(1)} L</p>
                <p className="text-xs text-slatey/50">Credit-Eligible ({Math.round(CREDIT_CONFIG.partnershipShare * 100)}%)</p>
              </div>
              <div className="text-center">
                <p className="font-display font-bold text-lg text-ocean-700">{totalCreditsFromWater.toFixed(2)}</p>
                <p className="text-xs text-slatey/50">Credits (÷{CREDIT_CONFIG.creditUnitSizeLitres} L)</p>
              </div>
            </div>
          </div>
        </section>

        {/* Environmental Metrics */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Droplets size={20} className="text-ocean-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Environmental Impact (Water Recovery)</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Total Water Input', value: fmtL(totalInput), icon: <Droplets size={18} />, color: 'ocean' },
              { label: 'Water Recovered', value: fmtL(litresRecovered), icon: <Recycle size={18} />, color: 'teal' },
              { label: 'Treatment Loss', value: fmtL(totalLoss), icon: <Droplets size={18} />, color: 'coral' },
              { label: 'Water Reused', value: fmtL(litresReused), icon: <Recycle size={18} />, color: 'aqua' },
            ].map((item) => (
              <div key={item.label} className="bg-mist rounded-xl p-4">
                <div className={`inline-flex p-2 rounded-lg bg-${item.color}-50 text-${item.color}-600 mb-2`}>{item.icon}</div>
                <p className="font-display font-bold text-2xl text-slatey">{item.value}</p>
                <p className="text-xs text-slatey/60">{item.label}</p>
              </div>
            ))}
          </div>
          <div className="bg-ocean-50 rounded-xl p-3 mt-4 flex items-start gap-2">
            <Info size={14} className="text-ocean-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-slatey/70">
              These are environmental metrics — litres of water actually recovered or reused through verified processes.
              They are separate from Water Credits, which represent sponsor-funded contributions.
            </p>
          </div>
        </section>

        {/* Sponsorship Metrics */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Wallet size={20} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Hydration Funding (Water Credits)</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: 'Water Credits Contributed', value: creditsEarned.toFixed(0), icon: <Coins size={18} />, color: 'aqua' },
              { label: 'Credits Assigned to Stations', value: creditsAssigned.toFixed(0), icon: <Building2 size={18} />, color: 'teal' },
              { label: 'Credits Used (Dispensing)', value: creditsUsed.toFixed(2), icon: <Droplet size={18} />, color: 'ocean' },
              { label: 'Credits Donated', value: creditsDonated.toFixed(0), icon: <HandHeart size={18} />, color: 'aqua' },
              { label: 'Current Balance', value: currentBalance.toFixed(2), icon: <Sparkles size={18} />, color: 'teal' },
              { label: 'HydroStations Supported', value: String(stations.length), icon: <Droplet size={18} />, color: 'ocean' },
            ].map((item) => (
              <div key={item.label} className="bg-mist rounded-xl p-4">
                <div className={`inline-flex p-2 rounded-lg bg-${item.color}-50 text-${item.color}-600 mb-2`}>{item.icon}</div>
                <p className="font-display font-bold text-2xl text-slatey">{item.value}</p>
                <p className="text-xs text-slatey/60">{item.label}</p>
              </div>
            ))}
          </div>
          <div className="bg-aqua-50 rounded-xl p-3 mt-4 flex items-start gap-2">
            <Info size={14} className="text-aqua-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-slatey/70">
              1 Water Credit = {CREDIT_CONFIG.creditUnitSizeLitres} L of credit-eligible water (recovered × {Math.round(CREDIT_CONFIG.partnershipShare * 100)}% partnership share).
              Credits persist across sign-in/sign-out — they are not reset.
            </p>
          </div>
        </section>

        {/* HydroStation Impact */}
        <section className="card p-6 mb-6">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Droplet size={20} className="text-aqua-600" />
              <h2 className="font-display font-semibold text-lg text-slatey">HydroStation Impact</h2>
            </div>
            <button onClick={() => onNavigate('hydro-stations')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-aqua-600 hover:text-aqua-700 transition-colors">
              Manage Stations <ArrowRight size={12} />
            </button>
          </div>

          {/* Flow diagram */}
          <div className="flex flex-wrap items-center gap-2 mb-5 p-4 bg-gradient-to-r from-aqua-50 to-teal-50 rounded-xl">
            {[
              { label: 'Wastewater', icon: <Droplets size={16} /> },
              { label: 'Treat', icon: <FlaskConical size={16} /> },
              { label: 'Recover', icon: <Recycle size={16} /> },
              { label: 'Verify', icon: <Shield size={16} /> },
              { label: 'Net Benefit', icon: <TrendingUp size={16} /> },
              { label: 'Credits', icon: <Coins size={16} /> },
              { label: 'Station', icon: <Droplet size={16} /> },
              { label: 'Impact', icon: <Target size={16} /> },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 bg-white rounded-lg px-2.5 py-1.5 shadow-soft">
                  <span className="text-aqua-600">{step.icon}</span>
                  <span className="text-xs font-medium text-slatey">{step.label}</span>
                </div>
                {i < 7 && <ArrowRight size={11} className="text-slatey/30" />}
              </div>
            ))}
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
            {[
              { label: 'Stations Supported', value: String(stations.length), icon: <Droplet size={18} />, color: 'aqua' },
              { label: 'Drinking Water Dispensed', value: fmtL(totalLitresDispensed), icon: <Droplets size={18} />, color: 'teal' },
              { label: 'Worker Visits', value: String(totalWorkerVisits), icon: <Users size={18} />, color: 'ocean' },
            ].map((item) => (
              <div key={item.label} className="bg-mist rounded-xl p-4">
                <div className={`inline-flex p-2 rounded-lg bg-${item.color}-50 text-${item.color}-600 mb-2`}>{item.icon}</div>
                <p className="font-display font-bold text-2xl text-slatey">{item.value}</p>
                <p className="text-xs text-slatey/60">{item.label}</p>
              </div>
            ))}
          </div>

          {stations.length > 0 ? (
            <div className="space-y-3">
              <p className="text-xs font-medium text-slatey/60 mb-2">Initiative Locations</p>
              {stations.map((st) => (
                <div key={st.id} className="flex items-center justify-between p-3 bg-mist rounded-xl gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-aqua-100 flex items-center justify-center text-aqua-600 flex-shrink-0">
                      <Droplet size={18} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slatey truncate">{st.name}</p>
                      <p className="text-xs text-slatey/50 flex items-center gap-1"><MapPin size={10} /> {st.location}</p>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs font-medium text-teal-700">{fmtL(st.total_litres_dispensed)}</p>
                    <p className="text-xs text-slatey/40">{st.total_worker_visits} visits</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 text-slatey/40">
              <Droplet size={24} className="mx-auto mb-2 opacity-40" />
              <p className="text-xs">No HydroStations yet.</p>
              <button onClick={() => onNavigate('hydro-stations')}
                className="mt-2 text-xs text-aqua-600 hover:text-aqua-700 font-medium">Create your first station</button>
            </div>
          )}

          <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3 mt-4">
            <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 leading-relaxed">
              Drinking water dispensed at HydroStations comes from a separately verified safe supply — not from
              the recovered water itself. The {fmtL(litresRecovered)} recovered and the {fmtL(totalLitresDispensed)} dispensed are independent metrics.
            </p>
          </div>
        </section>

        {/* Business Subscription */}
        <section className="card p-6 mb-6">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Crown size={20} className="text-aqua-600" />
              <h2 className="font-display font-semibold text-lg text-slatey">Business Subscription</h2>
            </div>
            <span className={`text-xs px-3 py-1 rounded-full font-medium ${currentPlan === 'free' ? 'bg-mist text-slatey/60' : 'bg-teal-100 text-teal-700'}`}>
              {SUBSCRIPTION_PLANS[currentPlan].name} Plan
            </span>
          </div>

          {/* Trial banner */}
          {isSubscriptionInTrial(subscription) && (
            <div className="flex items-center gap-3 p-3 bg-aqua-50 rounded-xl mb-4 border border-aqua-200">
              <Sparkles size={18} className="text-aqua-600 flex-shrink-0" />
              <p className="text-sm text-aqua-800">
                Your 7-day free trial is active — <span className="font-bold">{trialDaysRemaining(subscription)} days remaining</span>.
                No payment required during the trial. Cancel anytime.
              </p>
            </div>
          )}
          {subscription?.status === 'cancelled' && (
            <div className="flex items-center gap-3 p-3 bg-coral-50 rounded-xl mb-4 border border-coral-200">
              <Info size={18} className="text-coral-600 flex-shrink-0" />
              <p className="text-sm text-coral-800">
                Your subscription was cancelled on {new Date(subscription.cancelled_at!).toLocaleDateString()}.
                Upgrade again to regain access to premium features.
              </p>
            </div>
          )}

          {/* Feature access list */}
          <div className="grid sm:grid-cols-2 gap-3 mb-5">
            {Object.entries(FEATURE_LABELS).map(([key, label]) => {
              const hasAccess = hasFeatureAccess(subscription, key);
              return (
                <div key={key} className={`flex items-center gap-2 p-3 rounded-xl ${hasAccess ? 'bg-teal-50' : 'bg-mist opacity-60'}`}>
                  {hasAccess ? <Check size={14} className="text-teal-600" /> : <Lock size={14} className="text-slatey/40" />}
                  <span className={`text-sm ${hasAccess ? 'text-slatey' : 'text-slatey/50'}`}>{label}</span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <button onClick={() => setShowPlans(!showPlans)}
              className="btn-aqua inline-flex items-center gap-2">
              <Crown size={16} /> {currentPlan === 'free' ? 'Upgrade Plan' : 'Change Plan'}
            </button>
            {subscription && subscription.status === 'active' && currentPlan !== 'free' && (
              <button onClick={handleCancel}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-coral-600 border border-coral-200 hover:bg-coral-50 transition-colors">
                Cancel Subscription
              </button>
            )}
          </div>

          {showPlans && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
              {(Object.keys(SUBSCRIPTION_PLANS) as SubscriptionPlan[]).map(planKey => {
                const plan = SUBSCRIPTION_PLANS[planKey];
                const isCurrent = planKey === currentPlan;
                return (
                  <div key={planKey} className={`rounded-xl p-4 border-2 ${isCurrent ? 'border-teal-400 bg-teal-50' : 'border-softgrey bg-white'}`}>
                    <p className="font-display font-bold text-slatey">{plan.name}</p>
                    <p className="font-display font-bold text-2xl text-ocean-600 mt-1">AED {plan.price}<span className="text-xs font-normal text-slatey/50">/mo</span></p>
                    {planKey !== 'free' && (
                      <p className="text-xs text-aqua-600 font-medium mt-1">7-day free trial</p>
                    )}
                    <div className="mt-3 space-y-1">
                      {plan.features.map(f => (
                        <p key={f} className="text-xs text-slatey/60 flex items-center gap-1">
                          <Check size={10} className="text-teal-500" /> {FEATURE_LABELS[f] || f}
                        </p>
                      ))}
                    </div>
                    <button onClick={() => handleUpgrade(planKey)} disabled={isCurrent}
                      className={`w-full mt-3 py-2 rounded-lg text-sm font-medium transition-colors ${isCurrent ? 'bg-mist text-slatey/40 cursor-not-allowed' : 'bg-aqua-600 text-white hover:bg-aqua-700'}`}>
                      {isCurrent ? 'Current' : 'Select'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* ReWater Revenue */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Coins size={20} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">ReWater Revenue</h2>
          </div>
          <div className="grid sm:grid-cols-3 gap-4 mb-4">
            <div className="bg-mist rounded-xl p-4">
              <div className="inline-flex p-2 rounded-lg bg-aqua-50 text-aqua-600 mb-2"><Coins size={18} /></div>
              <p className="font-display font-bold text-2xl text-slatey">{fmtAed(totalReWaterRevenue)}</p>
              <p className="text-xs text-slatey/60">Total Revenue</p>
            </div>
            <div className="bg-mist rounded-xl p-4">
              <div className="inline-flex p-2 rounded-lg bg-teal-50 text-teal-600 mb-2"><Crown size={18} /></div>
              <p className="font-display font-bold text-2xl text-slatey">{fmtAed(subscriptionRevenue)}</p>
              <p className="text-xs text-slatey/60">From Subscriptions</p>
            </div>
            <div className="bg-mist rounded-xl p-4">
              <div className="inline-flex p-2 rounded-lg bg-ocean-50 text-ocean-600 mb-2"><Briefcase size={18} /></div>
              <p className="font-display font-bold text-2xl text-slatey">{fmtAed(serviceFeeRevenue)}</p>
              <p className="text-xs text-slatey/60">From Service Fees</p>
            </div>
          </div>
          <p className="text-xs text-slatey/50">
            ReWater earns subscription fees from businesses. The partnership share and credit unit size are configurable prototype assumptions.
          </p>
        </section>

        {/* Complete Credit Transaction History */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <History size={20} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Credit Transaction History</h2>
          </div>

          {transactions.length === 0 ? (
            <div className="text-center py-6">
              <Wallet size={28} className="mx-auto text-slatey/30 mb-2" />
              <p className="text-xs text-slatey/50">No credit transactions yet. Contribute credits after verifying water recovery.</p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between p-3 bg-aqua-50 rounded-xl mb-4">
                <span className="text-sm font-medium text-slatey">Current Balance</span>
                <span className="font-display font-bold text-xl text-aqua-700">{currentBalance.toFixed(2)} Credits</span>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {transactions.map((tx) => {
                  const isPositive = tx.transaction_type === 'earned' || tx.transaction_type === 'donated';
                  const label = tx.transaction_type === 'earned' ? 'Credits Generated' :
                    tx.transaction_type === 'donated' ? 'Credit Donation' :
                    tx.transaction_type === 'assigned' ? 'Station Sponsorship' :
                    'HydroStation Dispensing';
                  return (
                    <div key={tx.id} className="p-3 bg-mist rounded-xl">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isPositive ? 'bg-teal-50 text-teal-600' : 'bg-aqua-50 text-aqua-600'}`}>
                            {tx.transaction_type === 'earned' ? <Coins size={14} /> :
                             tx.transaction_type === 'donated' ? <HandHeart size={14} /> :
                             tx.transaction_type === 'assigned' ? <Building2 size={14} /> :
                             <Droplet size={14} />}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-slatey truncate">{label}</p>
                            <p className="text-xs text-slatey/50 truncate">{tx.description}</p>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className={`text-sm font-bold ${isPositive ? 'text-teal-600' : 'text-aqua-600'}`}>
                            {isPositive ? '+' : '-'}{tx.amount} Credits
                          </p>
                          <p className="text-xs text-slatey/40">Bal: {tx.balance_after}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2 ml-11">
                        {tx.sponsor && (
                          <span className="text-xs bg-ocean-50 text-ocean-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Building2 size={10} /> {tx.sponsor}
                          </span>
                        )}
                        {tx.treatment_partner && (
                          <span className="text-xs bg-aqua-50 text-aqua-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <FlaskConical size={10} /> {tx.treatment_partner}
                          </span>
                        )}
                        {tx.verification_partner && (
                          <span className="text-xs bg-teal-50 text-teal-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <BadgeCheck size={10} /> {tx.verification_partner}
                          </span>
                        )}
                        {tx.station_name && (
                          <span className="text-xs bg-mist text-slatey/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Droplet size={10} /> {tx.station_name}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </section>

        {/* Verified Initiative Outcomes */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Target size={20} className="text-ocean-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Verified Initiative Outcomes</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
            {[
              { label: 'Water Recovered', value: fmtL(litresRecovered), icon: <Droplets size={18} /> },
              { label: 'Recovery Rate', value: `${recoveryRate.toFixed(1)}%`, icon: <Recycle size={18} /> },
              { label: 'Drinking Water Dispensed', value: fmtL(totalLitresDispensed), icon: <Droplet size={18} /> },
              { label: 'Water Credits Contributed', value: creditsEarned.toFixed(0), icon: <Coins size={18} /> },
              { label: 'Credits Used', value: creditsUsed.toFixed(2), icon: <Sparkles size={18} /> },
              { label: 'HydroStations Supported', value: String(stations.length), icon: <Building2 size={18} /> },
            ].map((item) => (
              <div key={item.label} className="bg-mist rounded-xl p-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-teal-600">{item.icon}</span>
                  <span className="text-sm font-medium text-slatey">{item.label}</span>
                </div>
                <p className="text-xs text-slatey/50 ml-6">{item.value}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-slatey/40">
            Your environmental contribution (litres recovered) and your hydration funding (Water Credits) are tracked separately.
            Recovered water is not the same as drinking water dispensed at HydroStations.
          </p>
        </section>

        {/* Reporting */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <FileBarChart size={20} className="text-teal-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Reporting</h2>
          </div>
          <p className="text-sm text-slatey/60 mb-4">
            Export a summary of your recorded water-impact data, including environmental metrics, Water Credits,
            HydroStation impact, and complete credit transaction history.
          </p>
          <button onClick={handleExport} className="btn-aqua inline-flex items-center gap-2">
            <Download size={16} /> Export Impact Summary
          </button>
          <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3 mt-4">
            <Shield size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700">
              This export is a summary of recorded data for internal use. It is not automatically a legally
              compliant ESG report for any specific jurisdiction.
            </p>
          </div>
        </section>

        {/* Save */}
        <div className="flex items-center justify-end gap-3 mb-6">
          <button onClick={handleSave}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium transition-all ${saved ? 'bg-teal-400 text-white' : 'btn-primary'}`}>
            {saved ? <><Check size={16} /> Saved</> : <><Save size={16} /> Save Business Profile</>}
          </button>
        </div>

        {user.isDemo && (
          <div className="card p-5 bg-amber-50 border-amber-200">
            <div className="flex items-start gap-3">
              <Info size={18} className="text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-800">Demo Account</p>
                <p className="text-xs text-amber-700 mt-1">
                  You are using a demo account. Water Passports and Water Credits persist in the database and are not reset when you sign out.
                </p>
              </div>
            </div>
          </div>
        )}

        <p className="text-xs text-slatey/40 text-center mt-6">
          ReWater is a screening prototype. 1 Water Credit = {CREDIT_CONFIG.creditUnitSizeLitres} L of credit-eligible water (Prototype Partnership Model).
        </p>
      </div>
    </div>
  );
}
