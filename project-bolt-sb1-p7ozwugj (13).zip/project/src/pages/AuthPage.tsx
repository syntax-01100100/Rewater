import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { Logo } from '@/components/Logo';
import { LogIn, UserPlus, Sparkles, ArrowRight, Home } from 'lucide-react';

interface AuthPageProps {
  onSuccess: () => void;
  onHome?: () => void;
  initialMode?: 'signin' | 'signup';
}

export function AuthPage({ onSuccess, onHome, initialMode = 'signin' }: AuthPageProps) {
  const { signIn, signUp, signInDemo } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const result = mode === 'signin'
      ? await signIn(email, password)
      : await signUp(email, password);

    setLoading(false);

    if (result.error) {
      setError(result.error);
    } else {
      onSuccess();
    }
  };

  const handleDemo = async () => {
    setError(null);
    setLoading(true);
    const result = await signInDemo();
    setLoading(false);
    if (result.error) {
      setError(result.error);
    } else {
      onSuccess();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-ocean-50 to-mist px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          {onHome && (
            <button
              onClick={onHome}
              className="inline-flex items-center gap-2 text-sm text-slatey/50 hover:text-ocean-600 transition-colors mb-4"
            >
              <Home size={16} /> Back to Home
            </button>
          )}
          <Logo size={48} textClassName="text-2xl" />
          <p className="text-sm text-slatey/60 mt-3">
            AI-Powered Water Circularity Platform
          </p>
        </div>

        <div className="card p-8">
          <div className="flex gap-2 mb-6 bg-mist rounded-xl p-1" role="tablist" aria-label="Authentication mode">
            <button
              onClick={() => setMode('signin')}
              role="tab"
              aria-selected={mode === 'signin'}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
                mode === 'signin' ? 'bg-white text-ocean-600 shadow-soft' : 'text-slatey/50'
              }`}
            >
              <LogIn size={16} /> Sign In
            </button>
            <button
              onClick={() => setMode('signup')}
              role="tab"
              aria-selected={mode === 'signup'}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
                mode === 'signup' ? 'bg-white text-ocean-600 shadow-soft' : 'text-slatey/50'
              }`}
            >
              <UserPlus size={16} /> Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4" aria-label={mode === 'signin' ? 'Sign in form' : 'Sign up form'}>
            <div>
              <label className="text-sm font-medium text-slatey/70 block mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                aria-label="Email address"
                className="w-full px-4 py-3 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-slatey/70 block mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                aria-label="Password"
                className="w-full px-4 py-3 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
                placeholder="At least 6 characters"
              />
            </div>

            {error && (
              <div className="bg-coral-50 text-coral-600 text-sm rounded-xl px-4 py-3">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Please wait...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
              {!loading && <ArrowRight size={16} />}
            </button>
          </form>

          <div className="my-5 flex items-center gap-3">
            <div className="flex-1 h-px bg-softgrey" />
            <span className="text-xs text-slatey/40">or</span>
            <div className="flex-1 h-px bg-softgrey" />
          </div>

          <button
            onClick={handleDemo}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-aqua-400 to-teal-400 text-white font-medium hover:shadow-float transition-all disabled:opacity-50"
          >
            <Sparkles size={16} />
            Try Demo Account
          </button>

          <p className="text-xs text-slatey/40 text-center mt-4">
            The demo account lets you explore all features instantly — no signup, no password, no waiting.
            Demo data is clearly labeled throughout.
          </p>
        </div>

        <p className="text-xs text-slatey/40 text-center mt-6">
          ReWater is a screening prototype, not a certified drinking-water analyzer.
        </p>
      </div>
    </div>
  );
}
