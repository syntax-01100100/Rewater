import {
  Droplets, Info, Beaker,
  MapPin, FlaskConical, BookOpen, ArrowRight,
  Atom, Thermometer, Waves, Shield,
  ChevronLeft, ChevronRight, RotateCcw
} from 'lucide-react';
import { useState, useCallback } from 'react';

type Brand = {
  name: string;
  source: string;
  origin: string;
  ph: number | null;
  tds: number | null;
  calcium: number | null;
  magnesium: number | null;
  sodium: number | null;
  potassium: number | null;
  bicarbonate: number | null;
  chloride: number | null;
  sulfate: number | null;
};

const BRANDS: Brand[] = [
  {
    name: 'Evian',
    source: 'Spring water (French Alps)',
    origin: 'Évian-les-Bains, France',
    ph: 7.2,
    tds: 320,
    calcium: 80,
    magnesium: 26,
    sodium: 6.5,
    potassium: 1,
    bicarbonate: 360,
    chloride: 13,
    sulfate: 53,
  },
  {
    name: 'Masafi',
    source: 'Natural mineral water',
    origin: 'Masafi, UAE (Hajar Mountains)',
    ph: 7.8,
    tds: 285,
    calcium: 78,
    magnesium: 24,
    sodium: 8,
    potassium: 2,
    bicarbonate: 220,
    chloride: 12,
    sulfate: 40,
  },
  {
    name: 'Aquafina',
    source: 'Purified tap water (RO)',
    origin: 'Various (UAE plants)',
    ph: 6.5,
    tds: 10,
    calcium: 0,
    magnesium: 0,
    sodium: 2,
    potassium: 0,
    bicarbonate: 5,
    chloride: 2,
    sulfate: 0,
  },
  {
    name: 'Nestlé Pure Life',
    source: 'Purified water (RO + minerals)',
    origin: 'Various (UAE plants)',
    ph: 7.4,
    tds: 130,
    calcium: 20,
    magnesium: 10,
    sodium: 15,
    potassium: 1,
    bicarbonate: 60,
    chloride: 20,
    sulfate: 25,
  },
  {
    name: 'Al Ain Water',
    source: 'Natural mineral water',
    origin: 'Al Ain, UAE',
    ph: 7.6,
    tds: 250,
    calcium: 65,
    magnesium: 20,
    sodium: 10,
    potassium: 2,
    bicarbonate: 180,
    chloride: 15,
    sulfate: 35,
  },
  {
    name: 'Crystal Geyser',
    source: 'Spring water',
    origin: 'Olancha, California, USA',
    ph: 7.0,
    tds: 180,
    calcium: 40,
    magnesium: 12,
    sodium: 5,
    potassium: 1,
    bicarbonate: 130,
    chloride: 8,
    sulfate: 20,
  },
];

const PARAM_INFO = [
  {
    key: 'ph' as keyof Brand,
    label: 'pH',
    icon: <Thermometer size={16} />,
    unit: '',
    max: 14,
    explain: 'pH measures how acidic or basic water is on a scale of 0–14. A pH of 7 is neutral. Below 7 is acidic, above 7 is basic. Most drinking water sits between 6.5 and 8.5. pH alone does not tell you if water is safe — it is one characteristic used when understanding water.',
  },
  {
    key: 'tds' as keyof Brand,
    label: 'TDS',
    icon: <Beaker size={16} />,
    unit: ' mg/L',
    max: 500,
    explain: 'Total Dissolved Solids (TDS) represents the total amount of dissolved substances (mainly minerals) in water. It does NOT by itself mean water is safe or unsafe. Low TDS water (like RO-purified) has very few minerals. Higher TDS water has more dissolved minerals, which can affect taste. TDS is a descriptive measure, not a safety measure.',
  },
  {
    key: 'calcium' as keyof Brand,
    label: 'Calcium',
    icon: <Atom size={16} />,
    unit: ' mg/L',
    max: 120,
    explain: 'Calcium is a mineral that dissolves naturally into water as it passes through rocks like limestone. It is one of the main causes of water "hardness." Calcium is essential for human health (bones, teeth, muscles). In water, it affects taste and can leave deposits in pipes and kettles.',
  },
  {
    key: 'magnesium' as keyof Brand,
    label: 'Magnesium',
    icon: <Atom size={16} />,
    unit: ' mg/L',
    max: 40,
    explain: 'Magnesium is another mineral that dissolves into water from rocks. It contributes to water hardness alongside calcium. Magnesium is important for the human body (nerve and muscle function). The amount in drinking water varies by source.',
  },
  {
    key: 'sodium' as keyof Brand,
    label: 'Sodium',
    icon: <Waves size={16} />,
    unit: ' mg/L',
    max: 30,
    explain: 'Sodium is a mineral present in most water. The amount varies by source — seawater and brackish water have very high sodium, while mountain spring water usually has low sodium. Knowing the sodium level is useful for general awareness, especially for people monitoring their sodium intake.',
  },
  {
    key: 'potassium' as keyof Brand,
    label: 'Potassium',
    icon: <Atom size={16} />,
    unit: ' mg/L',
    max: 5,
    explain: 'Potassium is a mineral present in small amounts in most drinking water. It is essential for human health. The amount in water is usually very small compared to what we get from food.',
  },
  {
    key: 'bicarbonate' as keyof Brand,
    label: 'Bicarbonate',
    icon: <FlaskConical size={16} />,
    unit: ' mg/L',
    max: 400,
    explain: 'Bicarbonate is a naturally occurring ion in water that comes from dissolved carbon dioxide and minerals. It acts as a buffer, helping keep the pH of water stable. Higher bicarbonate often means the water comes from a limestone aquifer.',
  },
  {
    key: 'chloride' as keyof Brand,
    label: 'Chloride',
    icon: <Waves size={16} />,
    unit: ' mg/L',
    max: 30,
    explain: 'Chloride is a naturally occurring ion in water. Small amounts are normal. Higher levels can come from seawater intrusion, road salt, or geological formations. High chloride can affect taste but does not by itself indicate water is unsafe.',
  },
  {
    key: 'sulfate' as keyof Brand,
    label: 'Sulfate',
    icon: <Shield size={16} />,
    unit: ' mg/L',
    max: 60,
    explain: 'Sulfate is a mineral that dissolves into water from rocks and soil. It is present in most natural water sources. At very high levels it can have a laxative effect, but typical drinking water levels are well below this.',
  },
];

const FLOW_STEPS = ['Source', 'Composition', 'Understand', 'Use', 'Responsible Management'];

const PAIRS: [number, number][] = [
  [0, 1],
  [2, 3],
  [4, 5],
];

export function BrandsPage() {
  const [pairIdx, setPairIdx] = useState(0);
  const [flipping, setFlipping] = useState(false);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; text: string; label: string; icon: React.ReactNode } | null>(null);

  const handleFlip = useCallback((dir: 'next' | 'prev') => {
    setFlipping(true);
    setTimeout(() => {
      setPairIdx((prev) => {
        if (dir === 'next') return (prev + 1) % PAIRS.length;
        return (prev - 1 + PAIRS.length) % PAIRS.length;
      });
      setFlipping(false);
    }, 300);
  }, []);

  const showTooltip = (e: React.MouseEvent, param: typeof PARAM_INFO[number]) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    setTooltip({
      x: rect.left + rect.width / 2,
      y: rect.bottom + 8,
      text: param.explain,
      label: param.label,
      icon: param.icon,
    });
  };

  const hideTooltip = () => setTooltip(null);

  const [idxA, idxB] = PAIRS[pairIdx];
  const brandA = BRANDS[idxA];
  const brandB = BRANDS[idxB];

  return (
    <div className="min-h-screen pt-16 bg-gradient-mist">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-aqua-50 rounded-full px-4 py-1.5 mb-4">
            <BookOpen size={14} className="text-aqua-600" />
            <span className="text-sm text-aqua-700 font-medium">Educational Water Awareness</span>
          </div>
          <h1 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-3">
            What's in the Water You Drink?
          </h1>
          <p className="text-slatey/60 max-w-2xl mx-auto text-sm sm:text-base">
            Water may look completely clear, but it contains dissolved minerals and substances you cannot see.
            Understanding water composition helps us become more aware of what we consume and how water quality is described.
          </p>
        </div>

        {/* Awareness flow diagram */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-sm text-slatey mb-4 text-center">
            From Source to Responsible Management
          </h2>
          <div className="flex items-center justify-center gap-1 sm:gap-3 flex-wrap">
            {FLOW_STEPS.map((step, i) => (
              <div key={step} className="flex items-center gap-1 sm:gap-3">
                <div className="flex flex-col items-center gap-2">
                  <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center ${i === 0 ? 'bg-ocean-100 text-ocean-600' : i === 1 ? 'bg-aqua-100 text-aqua-600' : i === 2 ? 'bg-teal-100 text-teal-600' : i === 3 ? 'bg-amber-100 text-amber-600' : 'bg-coral-100 text-coral-600'}`}>
                    {i === 0 && <MapPin size={20} />}
                    {i === 1 && <Beaker size={20} />}
                    {i === 2 && <BookOpen size={20} />}
                    {i === 3 && <Droplets size={20} />}
                    {i === 4 && <Shield size={20} />}
                  </div>
                  <span className="text-xs text-slatey/70 font-medium text-center">{step}</span>
                </div>
                {i < FLOW_STEPS.length - 1 && <ArrowRight size={16} className="text-slatey/30 hidden sm:block" />}
              </div>
            ))}
          </div>
          <p className="text-xs text-slatey/50 text-center mt-4 max-w-xl mx-auto">
            Knowing the composition of water is the first step toward understanding water as a resource —
            not just something we consume and discard, but part of a circular system.
          </p>
        </div>

        {/* Educational disclaimer */}
        <div className="flex items-start gap-3 bg-amber-50 rounded-xl p-4 mb-6 border border-amber-200">
          <Info size={18} className="text-amber-600 flex-shrink-0 mt-0.5" />
          <p className="text-xs sm:text-sm text-amber-800 leading-relaxed">
            <strong>Educational and water-awareness purposes only.</strong> This section is not intended to provide medical advice,
            diagnose health conditions, or declare one water brand universally better than another.
            Information is presented from available published water-composition data. Values may vary by batch, season, and source.
          </p>
        </div>

        {/* Brand comparison — flip card style */}
        <div className="mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-2">Compare Water Composition</h2>
          <p className="text-sm text-slatey/60 mb-4">Two brands shown at a time. Hover any parameter to see what it means. Use the arrows to flip between brand pairs.</p>

          {/* Flip controls */}
          <div className="flex items-center justify-center gap-4 mb-5">
            <button
              onClick={() => handleFlip('prev')}
              className="w-10 h-10 rounded-full bg-white shadow-soft flex items-center justify-center text-ocean-600 hover:bg-aqua-50 hover:shadow-float transition-all"
              aria-label="Previous pair"
            >
              <ChevronLeft size={20} />
            </button>
            <div className="flex gap-2">
              {PAIRS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { setFlipping(true); setTimeout(() => { setPairIdx(i); setFlipping(false); }, 300); }}
                  className={`h-2.5 rounded-full transition-all ${pairIdx === i ? 'w-8 bg-aqua-500' : 'w-2.5 bg-softgrey hover:bg-aqua-300'}`}
                  aria-label={`Go to pair ${i + 1}`}
                />
              ))}
            </div>
            <button
              onClick={() => handleFlip('next')}
              className="w-10 h-10 rounded-full bg-white shadow-soft flex items-center justify-center text-ocean-600 hover:bg-aqua-50 hover:shadow-float transition-all"
              aria-label="Next pair"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Comparison cards with flip animation */}
          <div
            className="grid sm:grid-cols-2 gap-5"
            style={{
              perspective: '1200px',
              transformStyle: 'preserve-3d',
            }}
          >
            <div
              className="transition-all duration-300"
              style={{
                transform: flipping ? 'rotateY(90deg)' : 'rotateY(0deg)',
                opacity: flipping ? 0 : 1,
              }}
            >
              <BrandComparisonCard brand={brandA} onHoverParam={showTooltip} onLeaveParam={hideTooltip} accent="aqua" />
            </div>
            <div
              className="transition-all duration-300"
              style={{
                transform: flipping ? 'rotateY(-90deg)' : 'rotateY(0deg)',
                opacity: flipping ? 0 : 1,
              }}
            >
              <BrandComparisonCard brand={brandB} onHoverParam={showTooltip} onLeaveParam={hideTooltip} accent="teal" />
            </div>
          </div>

          <p className="text-xs text-slatey/40 mt-4 text-center">
            Hover any parameter name to see what it means. Bars show relative values within each parameter's typical range.
          </p>
        </div>

        {/* Why does this matter? */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-sm text-slatey mb-3">Why Does This Matter?</h2>
          <p className="text-sm text-slatey/70 leading-relaxed">
            Water may look completely clear, but it can contain dissolved minerals and other substances that cannot be seen.
            Understanding water composition helps us become more aware of what we consume and how water quality is described.
            ReWater wants users to move beyond simply seeing water as something we consume and discard, and instead understand its
            source, composition, treatment, and eventual place within a circular water system.
          </p>
        </div>

        {/* TDS clarification */}
        <div className="card p-6 mb-6">
          <div className="flex items-start gap-3">
            <Info size={18} className="text-aqua-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-display font-semibold text-sm text-slatey mb-2">A Note on TDS and Safety</h3>
              <p className="text-sm text-slatey/70 leading-relaxed">
                TDS (Total Dissolved Solids) tells you how much is dissolved in the water — mainly minerals.
                A low TDS does not mean water is "purer" or better for you. A high TDS does not mean water is unsafe.
                TDS is a descriptive measure. Water safety depends on what specific substances are present,
                their concentrations, and whether they exceed health-based limits set by regulators.
              </p>
            </div>
          </div>
        </div>

        {/* Connection to ReWater */}
        <div className="card p-6 bg-gradient-to-br from-aqua-50 to-white">
          <div className="flex items-center gap-2 mb-3">
            <Droplets size={18} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-sm text-slatey">How This Connects to ReWater</h2>
          </div>
          <p className="text-sm text-slatey/70 leading-relaxed">
            Knowing what we drink matters. Awareness is the first step toward using our water resources more responsibly.
            When we understand water composition, we can make better decisions about water treatment, reuse, and conservation.
            ReWater's mission is to move beyond seeing water as something we consume and discard — toward understanding it as
            a resource that flows through a circular system of source, treatment, reuse, and recovery.
          </p>
        </div>

        {/* Data source note */}
        <div className="flex items-start gap-2 mt-6">
          <Info size={14} className="text-slatey/30 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-slatey/40">
            Composition data shown here is from publicly available published information (brand websites, water quality reports, and published studies).
            Actual values may vary by batch, production location, and season. This page is for education and awareness, not for comparing or ranking brands.
          </p>
        </div>
      </div>

      {/* Fixed tooltip — always renders as topmost layer */}
      {tooltip && (
        <div
          className="fixed z-[9999] w-72 p-4 bg-ocean-900 text-white text-xs rounded-xl shadow-float pointer-events-none"
          style={{
            left: Math.min(tooltip.x - 144, window.innerWidth - 290),
            top: tooltip.y,
          }}
        >
          <p className="font-bold text-aqua-300 mb-1.5 flex items-center gap-1.5">
            {tooltip.icon} {tooltip.label}
          </p>
          <p className="leading-relaxed text-white/95">{tooltip.text}</p>
        </div>
      )}
    </div>
  );
}

function BrandComparisonCard({
  brand,
  onHoverParam,
  onLeaveParam,
  accent,
}: {
  brand: Brand;
  onHoverParam: (e: React.MouseEvent, param: typeof PARAM_INFO[number]) => void;
  onLeaveParam: () => void;
  accent: 'aqua' | 'teal';
}) {
  const accentBg = accent === 'aqua' ? 'from-aqua-50 to-white' : 'from-teal-50 to-white';
  const accentText = accent === 'aqua' ? 'text-aqua-600' : 'text-teal-600';
  const accentBar = accent === 'aqua' ? 'from-aqua-400 to-aqua-500' : 'from-teal-400 to-teal-500';

  return (
    <div className={`card p-5 bg-gradient-to-br ${accentBg}`}>
      {/* Brand header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-display font-bold text-lg text-slatey">{brand.name}</h3>
          <p className="text-xs text-slatey/50 mt-0.5 flex items-center gap-1">
            <MapPin size={10} /> {brand.origin}
          </p>
          <p className={`text-xs ${accentText} mt-0.5`}>{brand.source}</p>
        </div>
        <Droplets size={28} className={`${accentText} opacity-40`} />
      </div>

      {/* Parameters */}
      <div className="space-y-2.5">
        {PARAM_INFO.map((param) => {
          const value = brand[param.key] as number | null;
          const pct = value !== null ? Math.min((value / param.max) * 100, 100) : 0;
          return (
            <div key={param.key} className="flex items-center gap-2">
              <span
                className="w-24 flex-shrink-0 flex items-center gap-1.5 cursor-help text-xs font-medium text-slatey/70 hover:text-aqua-700 transition-colors"
                onMouseEnter={(e) => onHoverParam(e, param)}
                onMouseLeave={onLeaveParam}
              >
                <span className={`${accentText} flex-shrink-0`}>{param.icon}</span>
                <span className="underline decoration-dotted decoration-slatey/30 underline-offset-2 hover:decoration-aqua-500 whitespace-nowrap">
                  {param.label}
                </span>
              </span>
              <div className="flex-1 h-2 bg-softgrey/50 rounded-full overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${accentBar} rounded-full transition-all duration-500`}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className="text-xs font-display font-bold text-slatey w-16 text-right flex-shrink-0">
                {value !== null ? `${value}${param.unit}` : '—'}
              </span>
            </div>
          );
        })}
      </div>

      <p className="text-xs text-slatey/40 mt-3 flex items-center gap-1">
        <RotateCcw size={10} /> Hover parameter names for explanations
      </p>
    </div>
  );
}
