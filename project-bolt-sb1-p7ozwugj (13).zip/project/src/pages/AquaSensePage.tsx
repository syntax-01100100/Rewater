import { useEffect, useLayoutEffect, useRef } from 'react';
import * as THREE from 'three';
import { useLenis } from 'lenis/react';
import { ArrowLeft } from 'lucide-react';
import type { PageId } from '@/components/Navigation';

/**
 * AquaSense — scroll-driven 3D prototype story.
 * Drop into src/pages/AquaSensePage.tsx. Uses the `three` package already in the project.
 * The canvas is `position: sticky` inside this page, so the site footer still scrolls into view normally.
 */

const CHAPTERS = 9;

const CSS = `
.aq { --o950:#020F1A; --o900:#031726; --o800:#042235; --o700:#052E47; --o600:#063B5C; --o500:#0F5C85; --o400:#2E77A0; --o300:#5E9BBF; --o200:#97C2D9; --o100:#C9E0EC; --o50:#EAF4F9; --a600:#136F87; --a500:#178BA8; --a400:#1FA7C8; --a300:#4DD2E3; --a200:#8AE0EC; --a100:#C2EDF5; --a50:#E6F7FB; --t400:#48B7A5; --t500:#2E9D8C; --t600:#1F7A6C; --amber:#F2B84B; --mist:#F4FAFC;
  --soft: rgba(244,250,252,.9); --line: rgba(138,224,236,.22);
  position: relative; background: linear-gradient(180deg, #020F1A 0%, #031726 40%, #042235 100%); color: var(--mist); font-family: Inter, system-ui, sans-serif; font-size: 14px; line-height: 1.6; overflow-x: clip; }
.aq *, .aq *::before, .aq *::after { box-sizing: border-box; }
.aq-stage { position: sticky; top: 0; height: 100vh; height: 100svh; margin-bottom: -100vh; margin-bottom: -100svh; z-index: 0; pointer-events: none; }
.aq-stage canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }
.aq-glow { position: absolute; inset: 0; z-index: 1; pointer-events: none;
  background: radial-gradient(60% 50% at 88% 8%, rgba(31,167,200,.22), transparent 70%), radial-gradient(55% 45% at 6% 92%, rgba(72,183,165,.2), transparent 70%), radial-gradient(40% 35% at 50% 50%, rgba(15,92,133,.12), transparent 70%); }
.aq-fallback { position: absolute; inset: 0; display: none; place-items: center; text-align: center; padding: 24px; color: var(--soft); }

.aq-back { position: fixed; top: 72px; left: 16px; z-index: 25; display: inline-flex; align-items: center; gap: 6px; padding: 7px 12px; border-radius: 999px; border: 1px solid rgba(138,224,236,.3); background: rgba(3,23,38,.82); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); color: var(--mist); font-size: 12px; font-weight: 500; cursor: pointer; transition: .2s; }
.aq-back:hover { background: rgba(6,59,92,.92); border-color: var(--a300); color: var(--a200); }

.aq-rail { position: fixed; right: clamp(10px,2vw,26px); top: 50%; transform: translateY(-50%); z-index: 20; display: flex; flex-direction: column; gap: 14px; }
.aq-rail button { width: 10px; height: 10px; padding: 0; border-radius: 50%; border: 1.5px solid var(--o300); background: transparent; cursor: pointer; transition: .25s; }
.aq-rail button.on { background: var(--a300); border-color: var(--a300); transform: scale(1.35); }
.aq :focus-visible { outline: 3px solid var(--a300); outline-offset: 3px; }

.aq-ch { position: relative; z-index: 5; min-height: 100vh; min-height: 100svh; display: flex; align-items: center; padding: 110px clamp(20px,7vw,110px); }
.aq-ch.r { justify-content: flex-end; }
.aq-ch.c { justify-content: center; text-align: center; }
.aq-copy { max-width: 480px; background: linear-gradient(135deg, rgba(3,23,38,.92), rgba(6,59,92,.85)); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); border: 1px solid var(--line); border-radius: 26px; padding: clamp(24px,3vw,38px); box-shadow: 0 20px 60px rgba(0,0,0,.45); }
.aq-ch.c .aq-copy { max-width: 760px; }
.aq h1, .aq h2 { font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-weight: 800; letter-spacing: -0.035em; line-height: 1.05; margin: 0 0 16px; color: #fff; text-shadow: 0 2px 22px rgba(2,15,26,.9); }
.aq h1 { font-size: clamp(32px,5vw,64px); }
.aq h2 { font-size: clamp(24px,3.4vw,42px); }
.aq p { margin: 0 0 14px; color: var(--soft); max-width: 42ch; }
.aq-ch.c p { margin-left: auto; margin-right: auto; }
.aq p.lead { color: #fff; font-size: 1.06em; }
.aq-status { display: inline-flex; align-items: center; gap: 8px; font-size: 12px; color: var(--amber); background: rgba(242,184,75,.1); border: 1px solid rgba(242,184,75,.35); padding: 5px 12px; border-radius: 999px; margin-bottom: 20px; }
.aq-status i { width: 8px; height: 8px; border-radius: 50%; background: var(--amber); }
.aq-hint { margin-top: 24px; display: flex; align-items: center; gap: 10px; font-size: 12px; color: var(--soft); }
.aq-hint i { display: block; width: 1.5px; height: 38px; background: linear-gradient(var(--a300), transparent); transform-origin: top; animation: aqdrip 1.9s ease-in-out infinite; }
@keyframes aqdrip { 0% { transform: scaleY(0); } 60% { transform: scaleY(1); } 100% { transform: scaleY(1); opacity: 0; } }
.aq-facts { list-style: none; padding: 0; margin: 22px 0 0; border-top: 1px solid var(--line); }
.aq-facts li { display: flex; justify-content: space-between; gap: 18px; padding: 10px 0; border-bottom: 1px solid var(--line); font-size: 13px; }
.aq-facts li span:first-child { color: #fff; font-weight: 500; }
.aq-facts li span:last-child { color: var(--soft); text-align: right; }

.aq-glass { background: linear-gradient(135deg, rgba(3,23,38,.9), rgba(4,34,53,.85)); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); border: 1px solid var(--line); border-radius: 24px; padding: clamp(22px,3vw,40px); width: min(920px,100%); text-align: left; }
.aq-glass h2 { margin-bottom: 8px; }
.aq-glass > p { margin-bottom: 22px; }
.aq-tablewrap { overflow-x: auto; }
.aq table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 520px; }
.aq th, .aq td { text-align: left; padding: 10px 8px; border-bottom: 1px solid var(--line); vertical-align: top; }
.aq th { font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-weight: 600; color: var(--a200); font-size: 12px; }
.aq td:first-child { color: var(--a300); font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-weight: 600; white-space: nowrap; }
.aq td:nth-child(2) { color: #fff; font-weight: 500; }
.aq td:nth-child(3) { color: var(--soft); }
.aq-btns { display: flex; gap: 12px; flex-wrap: wrap; justify-content: center; margin-top: 18px; }
.aq-btn { font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-weight: 600; font-size: 14px; padding: 12px 24px; border-radius: 14px; border: 0; cursor: pointer; background: var(--a400); color: #fff; box-shadow: 0 0 24px rgba(31,167,200,.4); }
.aq-btn:hover { background: var(--a300); color: var(--o950); }
.aq-fine { font-size: 11.5px; color: var(--a200); margin-top: 22px; max-width: 60ch; margin-left: auto; margin-right: auto; }

.aq-tag { position: fixed; left: 0; top: 0; z-index: 8; pointer-events: none; opacity: 0; will-change: transform, opacity; padding: 8px 12px 9px; border-radius: 12px; background: rgba(3,23,38,.88); border: 1px solid var(--a400); box-shadow: 0 0 18px rgba(31,167,200,.35); white-space: nowrap; }
.aq-tag b { display: block; font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: 15px; line-height: 1.1; color: var(--a200); letter-spacing: -0.01em; }
.aq-tag span { font-size: 11px; color: var(--soft); }

@media (max-width: 820px) {
  .aq { font-size: 13.5px; }
  .aq-ch, .aq-ch.r { align-items: flex-end; justify-content: flex-start; padding-bottom: 44px; padding-top: 90px; }
  .aq-ch.c { justify-content: center; align-items: center; }
  .aq-ch:not(.c) .aq-copy { max-width: 100%; margin: 0 -6px; padding: 22px 18px 20px; background: linear-gradient(to top, rgba(3,23,38,.97) 70%, rgba(3,23,38,.82)); }
  .aq-rail { display: none; }
  .aq-tag b { font-size: 13px; }
  .aq-back { top: 68px; left: 12px; font-size: 12px; padding: 6px 10px; }
}
@media (prefers-reduced-motion: reduce) { .aq-hint i { animation: none; transform: none; } }
`;

type Key = { cam: [number, number, number]; look: [number, number, number]; sx: number };
const KEYS: Key[] = [
  { cam: [0.6, 13, 10.5], look: [0.6, 0, 0.4], sx: -0.19 },
  { cam: [2.8, 3.9, 3.3], look: [0.75, 0.3, 0], sx: 0.19 },
  { cam: [6.8, 4.4, 7.4], look: [3.0, 0.3, 3.5], sx: -0.19 },
  { cam: [-9.2, 8.5, 0.8], look: [-3.3, 0.2, 0.6], sx: 0.19 },
  { cam: [-1.2, 3.1, 1.3], look: [-1.2, 0.5, -1.0], sx: -0.19 },
  { cam: [0, 4.6, 14.5], look: [0.2, 3.3, -1], sx: 0.19 },
  { cam: [8.8, 4.6, 6.2], look: [4.8, 0.4, 0.8], sx: -0.19 },
  { cam: [0, 14, 9], look: [0, 0, 0.5], sx: 0 },
  { cam: [0, 9, 13], look: [0, 1.5, 0], sx: 0 },
];

const PARTS: [string, string, string][] = [
  ['1×', 'ESP32 DevKit', 'ESP32 DevKit V1 or ESP32-WROOM-32'],
  ['1×', 'pH sensor kit', 'pH probe with a matching interface module'],
  ['1×', 'Turbidity sensor', 'Analog turbidity sensor module'],
  ['1×', 'TDS/EC sensor', 'TDS sensor kit or module that works with ESP32'],
  ['1×', 'Waterproof temperature probe', 'DS18B20, waterproof'],
  ['1×', '0.96" OLED', 'I²C SSD1306, 128×64'],
  ['1×', 'Breadboard', 'Full-size or half-size'],
  ['1 pack', 'Jumper wires', 'Male-to-male and male-to-female'],
  ['1×', 'USB data cable', "Matches your ESP32's port"],
  ['1×', '5 V power bank', 'Any small USB power bank'],
];

const sm = (t: number) => t * t * (3 - 2 * t);
const lp = (a: number, b: number, t: number) => a + (b - a) * t;

export function AquaSensePage({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fallbackRef = useRef<HTMLDivElement>(null);

  const lenis = useLenis();
  useLayoutEffect(() => {
    lenis?.scrollTo(0, { immediate: true, force: true });
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  }, [lenis]);

  const goTo = (i: number) =>
    document.getElementById(`aq-c${i}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  useEffect(() => {
    const root = rootRef.current;
    const canvas = canvasRef.current;
    if (!root || !canvas) return;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    } catch {
      if (fallbackRef.current) fallbackRef.current.style.display = 'grid';
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;

    const BG = 0x031726;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(BG);
    scene.fog = new THREE.Fog(0x042235, 22, 48);
    const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);

    // Lights (x PI because three r155+ uses physical light units)
    scene.add(new THREE.HemisphereLight(0xc9e0ec, 0x052e47, 0.85 * Math.PI));
    const key = new THREE.DirectionalLight(0xeaf4f9, 1.25 * Math.PI);
    key.position.set(6, 14, 8);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -11, right: 11, top: 11, bottom: -11, near: 1, far: 40 });
    key.shadow.bias = -0.0004;
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x4dd2e3, 0.8 * Math.PI);
    rim.position.set(-8, 5, -8);
    scene.add(rim);

    // Ground
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(90, 90),
      new THREE.MeshStandardMaterial({ color: 0x052e47, roughness: 0.92, metalness: 0.05 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);
    const grid = new THREE.GridHelper(60, 60, 0x1fa7c8, 0x0f5c85);
    grid.position.y = 0.004;
    const gm = grid.material as THREE.LineBasicMaterial;
    gm.transparent = true;
    gm.opacity = 0.22;
    scene.add(grid);

    // Floating particles
    const PN = 260;
    const ppos = new Float32Array(PN * 3);
    const pspd: number[] = [];
    for (let i = 0; i < PN; i++) {
      ppos[i * 3] = (Math.random() - 0.5) * 30;
      ppos[i * 3 + 1] = Math.random() * 10;
      ppos[i * 3 + 2] = -14 + Math.random() * 26;
      pspd.push(0.15 + Math.random() * 0.5);
    }
    const pgeo = new THREE.BufferGeometry();
    pgeo.setAttribute('position', new THREE.BufferAttribute(ppos, 3));
    scene.add(new THREE.Points(pgeo, new THREE.PointsMaterial({ color: 0x8ae0ec, size: 0.09, transparent: true, opacity: 0.6, depthWrite: false, blending: THREE.AdditiveBlending })));
    const ppos2 = new Float32Array(40 * 3);
    for (let i = 0; i < 40; i++) {
      ppos2[i * 3] = (Math.random() - 0.5) * 26;
      ppos2[i * 3 + 1] = Math.random() * 8;
      ppos2[i * 3 + 2] = -12 + Math.random() * 22;
    }
    const pgeo2 = new THREE.BufferGeometry();
    pgeo2.setAttribute('position', new THREE.BufferAttribute(ppos2, 3));
    scene.add(new THREE.Points(pgeo2, new THREE.PointsMaterial({ color: 0x4dd2e3, size: 0.45, transparent: true, opacity: 0.12, depthWrite: false, blending: THREE.AdditiveBlending })));

    // Materials
    const M = (color: number, rough = 0.6, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    const mat = {
      pcb: M(0x1f7a6c, 0.55, 0.1), black: M(0x052e47, 0.55, 0.2), white: M(0xf4fafc, 0.55),
      steel: M(0xc9e0ec, 0.28, 0.9), gold: M(0xf2b84b, 0.35, 0.9), blueBoard: M(0x063b5c, 0.5, 0.1),
      whitePlastic: M(0xeaf4f9, 0.4), blueProbe: M(0x0f5c85, 0.35, 0.3),
      clear: new THREE.MeshStandardMaterial({ color: 0xc2edf5, roughness: 0.1, transparent: true, opacity: 0.35 }),
      ledOn: new THREE.MeshStandardMaterial({ color: 0x4dd2e3, emissive: 0x4dd2e3, emissiveIntensity: 1.6 }),
    };

    const station = new THREE.Group();
    scene.add(station);
    const add = (geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, parent?: THREE.Object3D | null) => {
      const mesh = new THREE.Mesh(geo, m);
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      (parent || station).add(mesh);
      return mesh;
    };
    const box = (w: number, h: number, d: number, m: THREE.Material, x: number, y: number, z: number, parent?: THREE.Object3D | null) =>
      add(new THREE.BoxGeometry(w, h, d), m, x, y, z, parent);
    const cyl = (rt: number, rb: number, h: number, m: THREE.Material, x: number, y: number, z: number, parent?: THREE.Object3D | null, seg = 24) =>
      add(new THREE.CylinderGeometry(rt, rb, h, seg), m, x, y, z, parent);
    const canvasTex = (c: HTMLCanvasElement) => {
      const t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 4;
      return t;
    };

    type V3 = [number, number, number];
    const tube = (pts: V3[], color: number, radius: number, rough = 0.5) => {
      const curve = new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(p[0], p[1], p[2])));
      const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 48, radius, 8, false), M(color, rough, 0.05));
      mesh.castShadow = true;
      station.add(mesh);
    };
    const WIRE = [0xc94545, 0xf2b84b, 0x8ad8cc, 0x2e9d8c, 0x0f5c85, 0x1f7a6c, 0x052e47, 0x97c2d9];
    const wire = (a: V3, b: V3, ci: number, lift = 0.7) => {
      const mid: V3 = [(a[0] + b[0]) / 2, Math.max(a[1], b[1]) + lift, (a[2] + b[2]) / 2];
      tube([a, [a[0], a[1] + 0.25, a[2]], mid, [b[0], b[1] + 0.25, b[2]], b], WIRE[ci % WIRE.length], 0.035, 0.55);
    };

    // Breadboard
    box(3.8, 0.3, 5.8, mat.white, 0, 0.15, 0);
    {
      const c = document.createElement('canvas');
      c.width = 380; c.height = 580;
      const g = c.getContext('2d')!;
      g.fillStyle = '#f4fafc'; g.fillRect(0, 0, 380, 580);
      g.fillStyle = '#c9e0ec';
      for (let y = 24; y < 560; y += 18) {
        for (let x = 66; x < 314; x += 18) { if (x > 178 && x < 202) continue; g.fillRect(x, y, 5, 5); }
        for (let rx = 0; rx < 2; rx++) { g.fillRect(rx ? 338 : 30, y, 5, 5); g.fillRect(rx ? 352 : 16, y, 5, 5); }
      }
      g.fillStyle = '#5e9bbf'; g.fillRect(186, 0, 8, 580);
      g.fillStyle = '#c94545'; g.fillRect(12, 0, 3, 580); g.fillRect(348, 0, 3, 580);
      g.fillStyle = '#0f5c85'; g.fillRect(44, 0, 3, 580); g.fillRect(332, 0, 3, 580);
      const t = canvasTex(c); t.anisotropy = 8;
      const p = new THREE.Mesh(new THREE.PlaneGeometry(3.8, 5.8), new THREE.MeshStandardMaterial({ map: t, roughness: 0.6 }));
      p.rotation.x = -Math.PI / 2; p.position.y = 0.302; p.receiveShadow = true;
      station.add(p);
    }

    // ESP32
    const ex = 0.75;
    box(1.3, 0.1, 2.7, mat.black, ex, 0.36, 0);
    box(0.07, 0.07, 2.5, mat.gold, ex - 0.55, 0.43, 0);
    box(0.07, 0.07, 2.5, mat.gold, ex + 0.55, 0.43, 0);
    box(0.75, 0.09, 0.95, mat.steel, ex, 0.45, -0.85);
    box(0.42, 0.05, 0.42, M(0x1a1d22, 0.4, 0.3), ex, 0.43, 0.15);
    box(0.4, 0.2, 0.34, mat.steel, ex, 0.46, 1.42);
    {
      const c = document.createElement('canvas'); c.width = 440; c.height = 112;
      const g = c.getContext('2d')!;
      g.fillStyle = '#c9e0ec'; g.font = '600 54px Inter, Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText('ESP32 DevKit V1', 220, 56);
      const l = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.28), new THREE.MeshBasicMaterial({ map: canvasTex(c), transparent: true }));
      l.rotation.x = -Math.PI / 2; l.position.set(ex, 0.415, 0.75);
      station.add(l);
    }

    // OLED
    const OC = { x: -1.15, y: 0.5, z: -1.0 };
    box(1.9, 0.12, 1.2, mat.blueBoard, OC.x, OC.y, OC.z);
    box(1.62, 0.03, 0.9, M(0x031726, 0.3), OC.x, OC.y + 0.075, OC.z);
    for (let i = 0; i < 4; i++) box(0.09, 0.2, 0.09, mat.black, OC.x - 0.6 + i * 0.4, 0.4, OC.z + 0.52);
    const oledCanvas = document.createElement('canvas');
    oledCanvas.width = 512; oledCanvas.height = 256;
    const oledTex = canvasTex(oledCanvas);
    const oledScreen = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.75), new THREE.MeshBasicMaterial({ map: oledTex }));
    oledScreen.rotation.x = -Math.PI / 2;
    oledScreen.position.set(OC.x, OC.y + 0.095, OC.z);
    station.add(oledScreen);

    // Turbidity module
    const tb = new THREE.Group(); tb.position.set(-3.3, 0.06, -3.3); tb.rotation.y = 0.35; station.add(tb);
    box(1.9, 0.1, 1.5, mat.pcb, 0, 0, 0, tb);
    box(0.9, 0.45, 0.8, mat.whitePlastic, -0.25, 0.28, -0.1, tb);
    box(0.5, 0.2, 0.36, M(0xc9e0ec, 0.5), -0.25, 0.4, -0.1, tb);
    for (let i = 0; i < 5; i++) box(0.08, 0.2, 0.08, mat.black, -0.4 + i * 0.2, 0.1, 0.68, tb);
    tube([[-3.7, 0.3, -4.1], [-4.6, 0.3, -4.8], [-5.8, 0.25, -5.2], [-7, 0.2, -4.4]], 0x052e47, 0.07, 0.6);

    // pH interface board + BNC + probe
    const pb = new THREE.Group(); pb.position.set(2.6, 0.06, -3.1); station.add(pb);
    box(1.6, 0.1, 1.0, mat.pcb, 0, 0, 0, pb);
    cyl(0.2, 0.2, 0.75, mat.steel, 1.05, 0.28, 0, pb, 28).rotation.z = Math.PI / 2;
    cyl(0.13, 0.13, 0.2, mat.steel, 1.5, 0.28, 0, pb, 24).rotation.z = Math.PI / 2;
    for (let i = 0; i < 4; i++) box(0.08, 0.2, 0.08, mat.black, -0.55 + i * 0.25, 0.1, 0.4, pb);
    tube([[3.75, 0.34, -3.1], [4.0, 0.3, -2.4], [3.3, 0.3, -1.2], [3.0, 0.3, 0.6], [3.3, 0.3, 2.2], [3.35, 0.3, 3.0]], 0x0f5c85, 0.075, 0.45);
    const probe = new THREE.Group(); probe.position.set(3.0, 0.36, 4.0); probe.rotation.y = -0.45; station.add(probe);
    cyl(0.17, 0.17, 2.0, mat.clear, 0, 0, 0, probe, 24).rotation.x = Math.PI / 2;
    cyl(0.09, 0.09, 1.7, mat.blueProbe, 0, 0, 0.05, probe, 20).rotation.x = Math.PI / 2;
    const phTip = new THREE.Vector3(3.0 + Math.sin(-0.45), 0.1, 4.0 + Math.cos(-0.45));

    // TDS module + DS18B20
    const tdsG = new THREE.Group(); tdsG.position.set(-3.3, 0.06, 2.5); tdsG.rotation.y = 0.5; station.add(tdsG);
    box(1.9, 0.1, 1.1, mat.pcb, 0, 0, 0, tdsG);
    cyl(0.2, 0.2, 0.22, mat.steel, -0.6, 0.15, 0, tdsG, 20);
    for (let i = 0; i < 6; i++) box(0.08, 0.2, 0.08, mat.black, -0.2 + i * 0.17, 0.1, -0.48, tdsG);
    tube([[-2.35, 0.25, 3.25], [-2.2, 0.15, 4.0], [-2.7, 0.14, 4.7], [-3.4, 0.14, 4.8]], 0x052e47, 0.065, 0.6);
    cyl(0.14, 0.14, 2.1, mat.steel, -4.5, 0.16, 4.8, null, 24).rotation.z = Math.PI / 2;
    cyl(0.1, 0.1, 0.4, mat.black, -3.35, 0.16, 4.8, null, 16).rotation.z = Math.PI / 2;

    // Power bank + USB cable
    const pwr = new THREE.Group(); pwr.position.set(5.0, 0.38, 0.6); station.add(pwr);
    box(2.0, 0.76, 3.2, M(0x042235, 0.5, 0.15), 0, 0, 0, pwr);
    box(0.06, 0.18, 0.5, mat.steel, -1.0, 0.0, -0.8, pwr);
    for (let i = 0; i < 3; i++) add(new THREE.SphereGeometry(0.05, 12, 12), mat.ledOn, -0.45 + i * 0.22, 0.4, 1.2, pwr);
    tube([[0.75, 0.46, 1.6], [0.75, 0.4, 2.3], [1.4, 0.3, 3.3], [2.6, 0.3, 3.3], [3.4, 0.45, 2.6], [3.5, 0.5, 1.2], [3.95, 0.55, -0.2]], 0x97c2d9, 0.09, 0.35);

    // Jumper wires
    wire([-3.0, 0.25, -2.7], [-1.6, 0.34, -0.1], 0, 0.9);
    wire([-2.9, 0.25, -2.7], [-1.7, 0.34, 0.4], 1, 1.0);
    wire([-2.8, 0.25, -2.7], [-1.5, 0.34, 1.1], 2, 0.8);
    wire([2.2, 0.2, -2.6], [1.7, 0.34, -1.4], 3, 0.8);
    wire([2.45, 0.2, -2.6], [1.65, 0.34, -0.9], 4, 0.9);
    wire([2.7, 0.2, -2.6], [1.6, 0.34, -0.3], 5, 1.0);
    wire([-2.9, 0.2, 1.8], [-1.3, 0.34, 1.6], 6, 0.7);
    wire([-2.7, 0.2, 1.9], [-1.4, 0.34, 2.1], 0, 0.8);
    wire([-2.5, 0.2, 2.0], [-1.5, 0.34, 2.5], 7, 0.7);
    wire([-1.5, 0.4, -0.45], [-0.2, 0.34, -0.5], 3, 0.7);
    wire([-1.1, 0.4, -0.45], [-0.15, 0.34, 0.1], 2, 0.9);
    wire([-0.7, 0.4, -0.45], [-0.1, 0.34, 0.7], 1, 1.0);

    // Sensing ripples
    const ripple = (x: number, z: number, color: number) => {
      const m = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
      const r = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.0, 64), m);
      r.rotation.x = -Math.PI / 2; r.position.set(x, 0.02, z);
      scene.add(r);
      return r;
    };
    const rip = [ripple(phTip.x, phTip.z, 0x4dd2e3), ripple(-4.8, 4.8, 0xf2b84b), ripple(-3.3, 2.5, 0x48b7a5), ripple(-3.3, -3.3, 0x8ae0ec)];

    // ReWater panel + data flow
    const panelCanvas = document.createElement('canvas');
    panelCanvas.width = 768; panelCanvas.height = 460;
    const panelTex = canvasTex(panelCanvas);
    const panelMat = new THREE.MeshBasicMaterial({ map: panelTex, transparent: true, opacity: 0 });
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 3.83), panelMat);
    panel.position.set(0.4, 6.4, -1.2);
    scene.add(panel);

    const FLOW = 90;
    const fpos = new Float32Array(FLOW * 3);
    const fseed: number[][] = [];
    for (let i = 0; i < FLOW; i++) fseed.push([Math.random(), Math.random() * Math.PI * 2, 0.25 + Math.random() * 0.5]);
    const fgeo = new THREE.BufferGeometry();
    fgeo.setAttribute('position', new THREE.BufferAttribute(fpos, 3));
    const fmat = new THREE.PointsMaterial({ color: 0x8ae0ec, size: 0.1, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending });
    scene.add(new THREE.Points(fgeo, fmat));
    const waves: THREE.Mesh[] = [];
    for (let i = 0; i < 3; i++) {
      const wm = new THREE.MeshBasicMaterial({ color: 0x4dd2e3, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
      const w = new THREE.Mesh(new THREE.TorusGeometry(1, 0.012, 8, 64), wm);
      w.rotation.x = Math.PI / 2;
      scene.add(w);
      waves.push(w);
    }

    // Live values -> OLED + ReWater panel + labels
    const vals = { turb: 12.4, tds: 256, ph: 7.23, temp: 24.6 };
    const base = { ...vals };
    const rr = (g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) => {
      g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
    };
    const drawOled = () => {
      const g = oledCanvas.getContext('2d')!;
      g.fillStyle = '#031726'; g.fillRect(0, 0, 512, 256);
      g.fillStyle = '#c2edf5'; g.font = '600 38px "Courier New", monospace'; g.textBaseline = 'middle';
      const lines = [`Turbidity: ${vals.turb.toFixed(1)} NTU`, `TDS: ${Math.round(vals.tds)} ppm`, `pH: ${vals.ph.toFixed(2)}`, `Temp: ${vals.temp.toFixed(1)} C`];
      lines.forEach((t, k) => g.fillText(t, 28, 40 + k * 58));
      oledTex.needsUpdate = true;
    };
    const drawPanel = () => {
      const g = panelCanvas.getContext('2d')!;
      const W = panelCanvas.width, H = panelCanvas.height;
      g.clearRect(0, 0, W, H);
      g.fillStyle = 'rgba(6,59,92,0.96)'; rr(g, 0, 0, W, H, 28); g.fill();
      g.strokeStyle = 'rgba(77,210,227,0.6)'; g.lineWidth = 3; rr(g, 2, 2, W - 4, H - 4, 28); g.stroke();
      g.fillStyle = '#f4fafc'; g.font = '800 38px "Plus Jakarta Sans", Arial, sans-serif'; g.textBaseline = 'alphabetic';
      g.fillText('ReWater · Water Passport', 36, 66);
      g.fillStyle = '#48b7a5'; g.beginPath(); g.arc(W - 150, 50, 7, 0, 7); g.fill();
      g.fillStyle = '#8ae0ec'; g.font = '500 24px Inter, Arial, sans-serif'; g.fillText('Live from AquaSense', W - 135, 58);
      const cards = [['pH', vals.ph.toFixed(2), ''], ['TDS', String(Math.round(vals.tds)), 'ppm'], ['Turbidity', vals.turb.toFixed(1), 'NTU'], ['Temperature', vals.temp.toFixed(1), '°C']];
      cards.forEach((cd, k) => {
        const x = 36 + (k % 2) * 358, y = 108 + Math.floor(k / 2) * 160;
        g.fillStyle = 'rgba(255,255,255,0.07)'; rr(g, x, y, 338, 140, 20); g.fill();
        g.fillStyle = '#8ae0ec'; g.font = '500 24px Inter, Arial, sans-serif'; g.fillText(cd[0], x + 22, y + 40);
        g.fillStyle = '#f4fafc'; g.font = '800 56px "Plus Jakarta Sans", Arial, sans-serif'; g.fillText(cd[1], x + 22, y + 104);
        const tw = g.measureText(cd[1]).width;
        g.fillStyle = '#5e9bbf'; g.font = '500 24px Inter, Arial, sans-serif'; g.fillText(cd[2], x + 32 + tw, y + 104);
      });
      g.fillStyle = '#5e9bbf'; g.font = '500 20px Inter, Arial, sans-serif'; g.fillText('Same reading as the device screen · example values', 36, H - 22);
      panelTex.needsUpdate = true;
    };
    const tagVals = root.querySelectorAll<HTMLElement>('[data-k]');
    const pushVals = () => {
      const fmt: Record<string, string> = { ph: `pH ${vals.ph.toFixed(2)}`, turb: `${vals.turb.toFixed(1)} NTU`, tds: `${Math.round(vals.tds)} ppm`, temp: `${vals.temp.toFixed(1)} °C` };
      tagVals.forEach((el) => { el.textContent = fmt[el.dataset.k || '']; });
      drawOled(); drawPanel();
    };
    const jitter = () => {
      vals.turb = base.turb + (Math.random() - 0.5) * 0.6;
      vals.tds = base.tds + (Math.random() - 0.5) * 6;
      vals.ph = base.ph + (Math.random() - 0.5) * 0.06;
      vals.temp = base.temp + (Math.random() - 0.5) * 0.2;
      pushVals();
    };
    pushVals();
    const jitterId = reduce ? 0 : window.setInterval(jitter, 1600);
    document.fonts?.ready.then(pushVals);

    // Tags
    const tagDefs = [
      { id: 'esp', ch: 1, pos: new THREE.Vector3(0.75, 1.0, -1.15) },
      { id: 'ph', ch: 2, pos: new THREE.Vector3(3.0, 1.1, 4.0) },
      { id: 'turb', ch: 3, pos: new THREE.Vector3(-3.3, 1.5, -3.3) },
      { id: 'tds', ch: 3, pos: new THREE.Vector3(-3.3, 0.9, 2.5) },
      { id: 'temp', ch: 3, pos: new THREE.Vector3(-4.5, 0.8, 4.8) },
    ].map((t) => ({ ...t, el: root.querySelector<HTMLElement>(`#aq-tag-${t.id}`)! }));

    // Layout / scroll
    let W = 1, H = 1, mobile = false;
    let centers: number[] = [];
    const secs: HTMLElement[] = [];
    for (let i = 0; i < CHAPTERS; i++) { const el = document.getElementById(`aq-c${i}`); if (el) secs.push(el); }
    const measure = () => {
      centers = secs.map((el) => { const r = el.getBoundingClientRect(); return r.top + window.scrollY + r.height / 2; });
    };
    const resize = () => {
      W = window.innerWidth; H = window.innerHeight; mobile = W < 820;
      renderer.setSize(W, H, false);
      camera.aspect = W / H; camera.updateProjectionMatrix();
      measure();
    };
    window.addEventListener('resize', resize);
    window.addEventListener('load', measure);
    const ro = new ResizeObserver(measure);
    ro.observe(root);
    resize();

    const chapterFloat = () => {
      const m = window.scrollY + H / 2;
      if (m <= centers[0]) return 0;
      for (let i = 0; i < centers.length - 1; i++) {
        if (m < centers[i + 1]) return i + (m - centers[i]) / (centers[i + 1] - centers[i]);
      }
      return centers.length - 1;
    };

    const railBtns = root.querySelectorAll<HTMLElement>('.aq-rail button');
    const rail = root.querySelector<HTMLElement>('.aq-rail');
    const weight = (f: number, ch: number, width = 0.45) => Math.max(0, 1 - Math.abs(f - ch) / width);

    let fSm = -1, raf = 0;
    const t0 = performance.now();
    const tmp = new THREE.Vector3();

    const frame = (now: number) => {
      const time = (now - t0) / 1000;
      const target = chapterFloat();
      if (fSm < 0) fSm = target;
      fSm += (target - fSm) * (reduce ? 1 : 0.09);
      const f = fSm;
      const i = Math.min(Math.floor(f), KEYS.length - 2);
      const t = sm(Math.min(1, f - i));
      const A = KEYS[i], B = KEYS[i + 1];

      const dist = mobile ? 1.35 : 1;
      const lx = lp(A.look[0], B.look[0], t), ly = lp(A.look[1], B.look[1], t), lz = lp(A.look[2], B.look[2], t);
      const cx = lx + (lp(A.cam[0], B.cam[0], t) - lx) * dist;
      const cy = ly + (lp(A.cam[1], B.cam[1], t) - ly) * dist;
      const cz = lz + (lp(A.cam[2], B.cam[2], t) - lz) * dist;
      camera.position.set(cx + (reduce ? 0 : Math.sin(time * 0.35) * 0.35), cy + (reduce ? 0 : Math.sin(time * 0.27) * 0.12), cz);
      camera.lookAt(lx, ly, lz);

      const sx = mobile ? 0 : lp(A.sx, B.sx, t);
      let sy = mobile ? 0.17 : 0;
      if (mobile && f > 6.6) sy = lp(0.17, 0, Math.min(1, (f - 6.6) / 0.8));
      camera.setViewOffset(W, H, -sx * W, -sy * H, W, H);

      // ripples
      const wPh = weight(f, 2, 0.6), w3 = weight(f, 3, 0.6);
      const rw = [wPh, w3, w3, w3];
      rip.forEach((r, k) => {
        const ph = (time * 0.7 + k * 0.33) % 1;
        r.scale.setScalar(0.5 + ph * 1.1);
        (r.material as THREE.MeshBasicMaterial).opacity = rw[k] * (1 - ph) * 0.65;
      });

      // data flow, wifi rings, panel
      const w5 = weight(f, 5, 0.8);
      panelMat.opacity = Math.min(1, w5 * 1.6);
      panel.position.y = 6.2 + Math.sin(time * 0.8) * 0.06;
      fmat.opacity = w5;
      for (let k = 0; k < FLOW; k++) {
        const p = (fseed[k][0] + time * 0.12 * (0.6 + fseed[k][2])) % 1;
        fpos[k * 3] = lp(0.75, 0.4, p) + Math.sin(p * 9 + fseed[k][1]) * 0.22 * fseed[k][2];
        fpos[k * 3 + 1] = lp(0.6, 4.5, p);
        fpos[k * 3 + 2] = lp(-0.6, -1.2, p) + Math.cos(p * 9 + fseed[k][1]) * 0.2 * fseed[k][2];
      }
      fgeo.attributes.position.needsUpdate = true;
      waves.forEach((w, q) => {
        const pq = (time * 0.45 + q / 3) % 1;
        w.position.set(0.75, 1.0 + pq * 1.4, -0.6);
        w.scale.setScalar(0.25 + pq * 1.1);
        (w.material as THREE.MeshBasicMaterial).opacity = w5 * (1 - pq) * 0.7;
      });

      if (!reduce) {
        for (let j = 0; j < PN; j++) { ppos[j * 3 + 1] += pspd[j] * 0.012; if (ppos[j * 3 + 1] > 10) ppos[j * 3 + 1] = 0.2; }
        pgeo.attributes.position.needsUpdate = true;
      }

      mat.ledOn.emissiveIntensity = 1.2 + (reduce ? 0.4 : Math.sin(time * 2.2) * 0.4) + weight(f, 6, 0.7) * 1.2;

      // tags
      tagDefs.forEach((tg) => {
        const a = weight(f, tg.ch, 0.55);
        if (a <= 0.01) { tg.el.style.opacity = '0'; return; }
        tmp.copy(tg.pos).project(camera);
        const px = (tmp.x * 0.5 + 0.5) * W, py = (-tmp.y * 0.5 + 0.5) * H;
        tg.el.style.opacity = tmp.z > 1 ? '0' : String(a);
        tg.el.style.transform = `translate3d(${px - 20}px,${py - 72}px,0)`;
      });

      // rail: active dot, hidden once the page has scrolled out
      const active = Math.round(f);
      railBtns.forEach((b, k) => b.classList.toggle('on', k === active));
      if (rail) rail.style.display = root.getBoundingClientRect().bottom < H * 0.6 ? 'none' : '';

      renderer.render(scene, camera);
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      if (jitterId) window.clearInterval(jitterId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('load', measure);
      ro.disconnect();
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        const mm = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mm)) mm.forEach((x) => x.dispose()); else mm?.dispose();
      });
      oledTex.dispose(); panelTex.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div className="aq" ref={rootRef}>
      <style>{CSS}</style>

      {onNavigate && (
        <button className="aq-back" onClick={() => onNavigate('future')}>
          <ArrowLeft size={16} /> Back to Future Lab
        </button>
      )}

      <div className="aq-stage">
        <canvas ref={canvasRef} role="img" aria-label="Interactive 3D model of the AquaSense water-quality prototype, which changes view as you scroll" />
        <div className="aq-glow" aria-hidden="true" />
        <div className="aq-fallback" ref={fallbackRef}><p>Your browser can't show the 3D prototype. The story below still works.</p></div>
      </div>

      <nav className="aq-rail" aria-label="Story chapters">
        {['Introduction', 'The ESP32 brain', 'pH sensor', 'TDS, turbidity and temperature', 'OLED screen', 'Sending to ReWater', 'Power', 'Parts list', 'Closing'].map((label, i) => (
          <button key={label} aria-label={label} onClick={() => goTo(i)} />
        ))}
      </nav>

      <div className="aq-tag" id="aq-tag-esp"><b>ESP32 DevKit V1</b><span>Reads sensors, sends over Wi-Fi</span></div>
      <div className="aq-tag" id="aq-tag-ph"><b data-k="ph">pH 7.23</b><span>pH probe</span></div>
      <div className="aq-tag" id="aq-tag-turb"><b data-k="turb">12.4 NTU</b><span>Turbidity sensor</span></div>
      <div className="aq-tag" id="aq-tag-tds"><b data-k="tds">256 ppm</b><span>TDS / EC module</span></div>
      <div className="aq-tag" id="aq-tag-temp"><b data-k="temp">24.6 °C</b><span>DS18B20 temperature probe</span></div>

      <section className="aq-ch" id="aq-c0">
        <div className="aq-copy">
          <div className="aq-status"><i /> Concept prototype</div>
          <h1>Every drop has a story.</h1>
          <p className="lead">AquaSense is a small ESP32 station that measures pH, TDS, turbidity and temperature, then sends the same reading to your ReWater Water Passport.</p>
          <div className="aq-hint"><i /> Scroll to look around the prototype</div>
        </div>
      </section>

      <section className="aq-ch r" id="aq-c1">
        <div className="aq-copy">
          <h2>One small brain.</h2>
          <p className="lead">An ESP32 DevKit collects every sensor reading in one place.</p>
          <p>It formats the numbers, shows them on the screen and sends them over Wi-Fi. Wi-Fi is built into the chip, so no extra radio is needed.</p>
        </div>
      </section>

      <section className="aq-ch" id="aq-c2">
        <div className="aq-copy">
          <h2>pH, straight from the water.</h2>
          <p className="lead">The probe makes a tiny voltage. A matching interface board makes it readable for the ESP32.</p>
          <ul className="aq-facts">
            <li><span>Measures</span><span>Acidity and alkalinity</span></li>
            <li><span>Range</span><span>0 to 14</span></li>
            <li><span>Target accuracy</span><span>±0.1</span></li>
          </ul>
        </div>
      </section>

      <section className="aq-ch r" id="aq-c3">
        <div className="aq-copy">
          <h2>Three more senses.</h2>
          <p className="lead">Dissolved solids, cloudiness and heat, measured at the same moment.</p>
          <ul className="aq-facts">
            <li><span>TDS / EC</span><span>0–2000 ppm · ±2%</span></li>
            <li><span>Turbidity</span><span>0–1000 NTU · ±5%</span></li>
            <li><span>Temperature</span><span>0–80 °C · ±0.5 °C</span></li>
          </ul>
          <p style={{ marginTop: 16 }}>The waterproof DS18B20 probe also lets the device correct other readings for temperature.</p>
        </div>
      </section>

      <section className="aq-ch" id="aq-c4">
        <div className="aq-copy">
          <h2>The result shows on the device first.</h2>
          <p className="lead">A 0.96-inch OLED screen prints all four readings the moment they are measured.</p>
          <p>You can check a sample in the field without a phone or a signal.</p>
        </div>
      </section>

      <section className="aq-ch r" id="aq-c5">
        <div className="aq-copy">
          <h2>Then the same numbers reach ReWater.</h2>
          <p className="lead">Each reading is sent over Wi-Fi and stored with a time and a device ID.</p>
          <p>The screen and the website show one measurement, not two separate values.</p>
        </div>
      </section>

      <section className="aq-ch" id="aq-c6">
        <div className="aq-copy">
          <h2>Runs from a power bank.</h2>
          <p className="lead">Plug in any small 5 V USB power bank and carry it to a tank, a well or an outflow.</p>
          <p>The ESP32 and its USB cable are all the power connection it needs.</p>
        </div>
      </section>

      <section className="aq-ch c" id="aq-c7">
        <div className="aq-glass">
          <h2>What you need to build it.</h2>
          <p>One of each, plus jumper wires. Everything plugs together on a breadboard, with no soldering.</p>
          <div className="aq-tablewrap">
            <table>
              <thead><tr><th scope="col">Qty</th><th scope="col">Part</th><th scope="col">Look for</th></tr></thead>
              <tbody>
                {PARTS.map(([q, p, l]) => (
                  <tr key={p}><td>{q}</td><td>{p}</td><td>{l}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="aq-ch c" id="aq-c8">
        <div className="aq-copy">
          <h2>Give your water a live reading.</h2>
          <p className="lead">See where AquaSense readings end up: the ReWater Water Passport.</p>
          <div className="aq-btns">
            <button className="aq-btn" onClick={() => goTo(7)}>Review the parts list</button>
          </div>
          <p className="aq-fine">AquaSense is a concept prototype. Until the device is built, readings inside ReWater are simulated demo values, and the numbers on this page are examples.</p>
        </div>
      </section>
    </div>
  );
}

export default AquaSensePage;
