import { useEffect, useState, lazy, Suspense } from 'react';
import { Beaker, MapPin, RefreshCw, ArrowRight, Droplets, TrendingUp, AlertTriangle, Bell, Sparkles, Recycle, TestTube, Shield, LogIn, UserPlus, FlaskConical, Cpu, Database, Target, HandHeart } from 'lucide-react';
import { AlertList } from '@/components/AlertList';
import { CircularityAnimation } from '@/components/animations/CircularityAnimation';
import VaporizeTextCycle, { Tag } from '@/components/ui/vapour-text-effect';
import { CardStack, type CardStackItem } from '@/components/ui/card-stack';
import { supabase, type WaterSample, type Alert as AlertType, type ImpactRecord } from '@/lib/supabase';
import { formatRelative, formatNumber } from '@/lib/utils';
import { useAuth } from '@/lib/auth';
import type { PageId } from '@/components/Navigation';

const AquaSensePreview = lazy(() => import('@/components/AquaSensePreview'));

interface HomePageProps {
  onNavigate: (page: PageId) => void;
  onShowAuth?: (mode: 'signin' | 'signup') => void;
}

export function HomePage({ onNavigate, onShowAuth }: HomePageProps) {
  const { user } = useAuth();
  const [recentSamples, setRecentSamples] = useState<WaterSample[]>([]);
  const [alerts, setAlerts] = useState<AlertType[]>([]);
  const [impact, setImpact] = useState<ImpactRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    (async () => {
      const [samplesRes, alertsRes, impactRes] = await Promise.all([
        supabase.from('water_samples').select('*').order('created_at', { ascending: false }).limit(4),
        supabase.from('alerts').select('*').order('created_at', { ascending: false }).limit(5),
        supabase.from('impact_records').select('*').order('created_at', { ascending: false }).limit(1).maybeSingle(),
      ]);
      setRecentSamples(samplesRes.data || []);
      setAlerts(alertsRes.data || []);
      setImpact(impactRes.data);
      setLoading(false);
    })();
  }, [user]);

  if (!user) {
    return <PreLoginHome onNavigate={onNavigate} onShowAuth={onShowAuth} />;
  }

  const hasTestedWater = recentSamples.length > 0;

  return (
    <div className="min-h-screen pt-16">
      {/* Hero — compact for signed-in users */}
      <section className="relative min-h-[320px] flex items-center justify-center overflow-hidden bg-gradient-hero">
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center py-16">
          <h1 className="font-display font-bold text-3xl sm:text-4xl text-white mb-3 animate-fade-slide">
            Welcome back
          </h1>
          <p className="text-base text-white/80 mb-6 max-w-xl mx-auto animate-fade-slide" style={{ animationDelay: '0.1s' }}>
            What are you checking today?
          </p>
          <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 animate-rise" style={{ animationDelay: '0.2s' }}>
            <button
              onClick={() => onNavigate('check')}
              className="group inline-flex items-center gap-3 bg-white text-ocean-600 rounded-2xl px-7 py-3.5 text-base font-semibold shadow-float transition-all duration-300 hover:shadow-glow hover:scale-105 active:scale-100"
            >
              <Beaker size={22} className="text-aqua-400 group-hover:rotate-12 transition-transform" />
              Check a water sample
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => onNavigate('passport')}
              className="group inline-flex items-center gap-3 bg-aqua-400/30 backdrop-blur-md text-white rounded-2xl px-6 py-3.5 text-base font-semibold border border-aqua-300/30 transition-all duration-300 hover:bg-aqua-400/50 hover:scale-105"
            >
              <Droplets size={22} className="text-aqua-200" />
              Create Water Passport
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Quick stats */}
      {impact && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 -mt-8 relative z-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'What We Could Recover', value: formatNumber(impact.water_recovered), unit: 'L', icon: <Droplets size={20} />, color: 'aqua' },
              { label: 'Freshwater Avoided', value: formatNumber(impact.freshwater_avoided), unit: 'L', icon: <TrendingUp size={20} />, color: 'teal' },
              { label: 'Samples Monitored', value: formatNumber(impact.samples_monitored), unit: '', icon: <Beaker size={20} />, color: 'ocean' },
              { label: 'Active Alerts', value: formatNumber(alerts.filter(a => !a.acknowledged).length), unit: '', icon: <AlertTriangle size={20} />, color: 'amber' },
            ].map((stat, i) => (
              <div key={stat.label} className="card p-4 animate-rise" style={{ animationDelay: `${0.4 + i * 0.1}s` }}>
                <div className={`inline-flex p-2 rounded-lg bg-${stat.color}-50 text-${stat.color}-600 mb-2`}>
                  {stat.icon}
                </div>
                <div className="font-display font-bold text-2xl text-slatey">
                  {stat.value}<span className="text-sm text-slatey/50 ml-0.5">{stat.unit}</span>
                </div>
                <div className="text-xs text-slatey/60">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Recent samples + alerts */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Recent samples */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-bold text-xl text-slatey">Recent Samples</h2>
              <button onClick={() => onNavigate('check')} className="text-sm text-aqua-600 hover:text-aqua-700 font-medium flex items-center gap-1">
                View all <ArrowRight size={14} />
              </button>
            </div>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="card p-4 animate-pulse">
                    <div className="h-4 bg-softgrey rounded w-1/3 mb-2" />
                    <div className="h-3 bg-softgrey rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : hasTestedWater ? (
              <div className="space-y-3">
                {recentSamples.map((sample, i) => (
                  <button
                    key={sample.id}
                    onClick={() => onNavigate('check')}
                    className="card p-4 w-full text-left hover:shadow-float transition-all duration-200 animate-fade-slide"
                    style={{ animationDelay: `${i * 0.05}s` }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-slatey">{sample.source_name}</h3>
                        <p className="text-xs text-slatey/50 mt-0.5">{formatRelative(sample.created_at)}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        {sample.ph !== null && (
                          <div className="text-center">
                            <div className="text-xs text-slatey/40">pH</div>
                            <div className="font-display font-bold text-lg text-ocean-600">{sample.ph}</div>
                          </div>
                        )}
                        {sample.tds !== null && (
                          <div className="text-center">
                            <div className="text-xs text-slatey/40">TDS</div>
                            <div className="font-display font-bold text-lg text-aqua-600">{sample.tds}</div>
                          </div>
                        )}
                        {sample.turbidity !== null && (
                          <div className="text-center">
                            <div className="text-xs text-slatey/40">NTU</div>
                            <div className="font-display font-bold text-lg text-teal-600">{sample.turbidity}</div>
                          </div>
                        )}
                        <ArrowRight size={16} className="text-slatey/30" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="card p-8 text-center">
                <Beaker className="mx-auto mb-3 text-aqua-300" size={32} />
                <p className="text-slatey/60 text-sm mb-4">You haven't tested any water yet. Check your first sample to get started.</p>
                <button onClick={() => onNavigate('check')} className="btn-aqua inline-flex items-center gap-2">
                  <Beaker size={18} /> Start checking
                </button>
              </div>
            )}
          </div>

          {/* Alerts — only show if user has tested water */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-bold text-xl text-slatey flex items-center gap-2">
                <Bell size={18} className="text-amber-400" /> Alerts
              </h2>
              {hasTestedWater && <span className="badge-amber">{alerts.filter(a => !a.acknowledged).length} active</span>}
            </div>
            {hasTestedWater ? (
              <AlertList alerts={alerts} />
            ) : (
              <div className="card p-6 text-center">
                <Shield className="mx-auto mb-3 text-teal-300" size={28} />
                <p className="text-sm text-slatey/60 mb-2">Alerts appear after you test water</p>
                <p className="text-xs text-slatey/40">Once you run a water check, we'll monitor your results and alert you to anything that needs attention.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* AquaSense 3D preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <Suspense fallback={<div className="rounded-3xl bg-ocean-950 border border-white/10" style={{ minHeight: 320 }} />}>
          <AquaSensePreview onOpen={() => onNavigate('aquasense')} />
        </Suspense>
      </section>

      {/* Journey banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="card p-8 bg-gradient-to-r from-ocean-50 via-mist to-teal-50 border-softgrey">
          <h2 className="font-display font-bold text-2xl text-ocean-600 mb-2 text-center">Your Water Journey</h2>
          <p className="text-center text-slatey/60 text-sm mb-6">Every water source tells a story. Follow it through.</p>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4">
            {[
              { label: 'Find', icon: <MapPin size={18} />, page: 'map' as PageId },
              { label: 'Check', icon: <Beaker size={18} />, page: 'check' as PageId },
              { label: 'Passport', icon: <Droplets size={18} />, page: 'passport' as PageId },
              { label: 'Act', icon: <RefreshCw size={18} />, page: 'circular' as PageId },
              { label: 'Retest', icon: <Beaker size={18} />, page: 'check' as PageId },
              { label: 'Impact', icon: <TrendingUp size={18} />, page: 'impact' as PageId },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-2 sm:gap-4">
                <button onClick={() => onNavigate(step.page)} className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 rounded-full bg-white shadow-soft flex items-center justify-center text-ocean-600 group-hover:bg-aqua-400 group-hover:text-white transition-all duration-300 group-hover:scale-110">
                    {step.icon}
                  </div>
                  <span className="text-xs font-medium text-slatey/70">{step.label}</span>
                </button>
                {i < 5 && <div className="h-0.5 w-4 sm:w-8 bg-gradient-to-r from-aqua-300 to-teal-300 hidden sm:block" />}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── Pre-login landing page ──────────────────────────────────────────────────

const stageItems: CardStackItem[] = [
  { id: 1, title: 'COLLECT', description: 'Source, quantity, quality, temperature and field observations', imageSrc: 'https://images.pexels.com/photos/38070651/pexels-photo-38070651.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { id: 2, title: 'IDENTIFY', description: 'Create a unique Water ID and passport for every source', imageSrc: 'https://images.pexels.com/photos/7298554/pexels-photo-7298554.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { id: 3, title: 'UNDERSTAND', description: 'Combine measurements, observations and full sample history', imageSrc: 'https://images.pexels.com/photos/3862140/pexels-photo-3862140.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { id: 4, title: 'DECIDE', description: 'Identify treatment, recovery and reuse pathways', imageSrc: 'https://images.pexels.com/photos/5712211/pexels-photo-5712211.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { id: 5, title: 'CIRCULATE', description: 'Treat, recover and reuse water where appropriate', imageSrc: 'https://images.pexels.com/photos/17765487/pexels-photo-17765487.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { id: 6, title: 'UPDATE', description: 'Retest the water and update its living digital history', imageSrc: 'https://images.pexels.com/photos/30174277/pexels-photo-30174277.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
];

function PreLoginHome({ onNavigate, onShowAuth }: { onNavigate: (page: PageId) => void; onShowAuth?: (mode: 'signin' | 'signup') => void }) {
  return (
    <div className="min-h-screen pt-16">
      {/* Hero — ocean sea background with vapour text effect */}
      <section className="relative min-h-[640px] flex items-center justify-center overflow-hidden bg-ocean-950">
        <img
          src="https://images.pexels.com/photos/38485579/pexels-photo-38485579.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-ocean-950/45 pointer-events-none" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center py-20">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-md rounded-full px-4 py-1.5 mb-8 animate-fade-in">
            <Droplets size={14} className="text-aqua-300" />
            <span className="text-sm text-white/90 font-medium">Water Intelligence for a Circular Future</span>
          </div>
          <div className="h-[100px] sm:h-[140px] lg:h-[160px] mb-4 animate-fade-slide [filter:invert(1)]">
            <VaporizeTextCycle
              texts={["ReWater"]}
              font={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                fontSize: "80px",
                fontWeight: 800
              }}
              color="#ffffff"
              spread={5}
              density={5}
              animation={{
                vaporizeDuration: 3,
                fadeInDuration: 1.5,
                waitDuration: 2
              }}
              direction="left-to-right"
              alignment="center"
              tag={Tag.H1}
            />
          </div>
          <p className="text-lg sm:text-xl text-white/80 mb-8 max-w-2xl mx-auto animate-fade-slide" style={{ animationDelay: '0.1s' }}>
            ReWater gives water a digital identity. It collects information about a water source, builds a continuously updated Water Profile, analyzes its condition and history, and identifies pathways for treatment, resource recovery and reuse.
          </p>

          <div className="flex flex-wrap justify-center gap-3 animate-rise" style={{ animationDelay: '0.2s' }}>
            <button
              onClick={() => onNavigate('circular')}
              className="group inline-flex items-center gap-2 bg-aqua-400 text-white rounded-2xl px-7 py-3.5 text-base font-semibold shadow-float transition-all duration-300 hover:bg-aqua-500 hover:shadow-glow hover:scale-105 active:scale-100"
            >
              <RefreshCw size={20} className="group-hover:rotate-180 transition-transform duration-500" />
              Explore
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Water Intelligence Loop visual — Card Stack */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
        <div className="text-center mb-8">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-2">How ReWater Thinks About Water</h2>
          <p className="text-sm text-slatey/60 max-w-xl mx-auto">Six connected stages that turn water data into circular action. Click or drag to explore.</p>
        </div>
        <CardStack
          items={stageItems}
          initialIndex={0}
          autoAdvance
          intervalMs={3000}
          pauseOnHover
          showDots
          cardWidth={480}
          cardHeight={300}
          overlap={0.45}
          spreadDeg={40}
        />
      </section>

      {/* Circularity animation */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="text-center mb-6">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-2">The Water Circularity Cycle</h2>
          <p className="text-sm text-slatey/60 max-w-xl mx-auto">Water doesn't just disappear after use. Follow it through the full circular journey.</p>
        </div>
        <div className="card p-6">
          <CircularityAnimation />
        </div>
      </section>

      {/* Give every drop a journey */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-teal-50 rounded-full px-4 py-1.5 mb-4">
            <Droplets size={14} className="text-teal-600" />
            <span className="text-sm text-teal-700 font-medium">Water Passport</span>
          </div>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-3">Give every drop a journey.</h2>
          <p className="text-slatey/60 max-w-2xl mx-auto text-sm sm:text-base">
            ReWater turns tested water into traceable digital records, helping identify what water is,
            what it can become, and where its next useful destination could be.
          </p>
        </div>

        <div className="card p-8">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {[
              { label: 'Test', icon: <Beaker size={18} />, desc: 'Analyze a water sample' },
              { label: 'Understand', icon: <Cpu size={18} />, desc: 'See what the results mean' },
              { label: 'Reuse', icon: <Recycle size={18} />, desc: 'Find a suitable reuse pathway' },
              { label: 'Recover', icon: <Droplets size={18} />, desc: 'Identify recoverable resources' },
              { label: 'Track', icon: <TrendingUp size={18} />, desc: 'Follow the full journey' },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-2 sm:gap-3">
                <div className="flex flex-col items-center gap-2 group">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-aqua-50 to-teal-50 flex items-center justify-center text-ocean-600 group-hover:bg-aqua-400 group-hover:text-white transition-all duration-300 group-hover:scale-110 shadow-soft">
                    {step.icon}
                  </div>
                  <span className="text-xs font-bold text-slatey/80">{step.label}</span>
                  <span className="text-xs text-slatey/40 text-center max-w-[80px]">{step.desc}</span>
                </div>
                {i < 4 && <ArrowRight size={16} className="text-slatey/30 hidden sm:block" />}
              </div>
            ))}
          </div>
        </div>

      </section>

      {/* Our Mission */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="card p-8 bg-gradient-to-br from-ocean-50 via-mist to-aqua-50">
          <div className="text-center mb-4">
            <div className="inline-flex items-center gap-2 bg-aqua-100 rounded-full px-4 py-1.5 mb-3">
              <Target size={14} className="text-aqua-600" />
              <span className="text-sm text-aqua-700 font-medium">Our Mission</span>
            </div>
          </div>
          <p className="text-sm sm:text-base text-slatey/70 leading-relaxed text-center">
            ReWater helps make every drop count. We track water from its source through testing, reuse, treatment, and resource recovery, helping find where suitable water can go next. With AquaSense, Water Passports, Water Journey, smart mapping, and Water Credits, we turn water data into practical action. Water Credits digitally record verified water that has been recovered, reused, or conserved, helping measure impact and identify where water-related needs are greatest through predictive mapping. When you choose to understand, support, reuse, or recover water, you can be part of that impact too. Together, every rescued drop can have a purpose, a journey, and a future.
          </p>
        </div>
      </section>

      {/* Water Credits top bar */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 pb-4">
        <div className="card p-5 bg-gradient-to-r from-aqua-50 to-teal-50 border-aqua-100">
          <div className="flex items-start gap-3">
            <Sparkles size={20} className="text-aqua-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-slatey mb-1">Water Credits — Turn recovered water into measurable impact.</p>
              <p className="text-xs text-slatey/60 leading-relaxed">
                When suitable water is recovered, ReWater can record the verified contribution as Water Credits. These credits can support eligible water-access and hydration initiatives, helping connect water recovery with environmental and human impact.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* From Recovery to Impact */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
        <div className="text-center mb-6">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-2">From Recovery to Impact</h2>
          <p className="text-sm text-slatey/60 max-w-2xl mx-auto">
            ReWater helps turn verified water recovery into measurable impact. Water Credits record eligible recovered, reused, or conserved water and connect those contributions to participating water-access, hydration, or environmental initiatives.
          </p>
        </div>
        <div className="card p-8">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {[
              { label: 'Recover', icon: <Recycle size={18} /> },
              { label: 'Credit', icon: <Sparkles size={18} /> },
              { label: 'Support', icon: <HandHeart size={18} /> },
              { label: 'Impact', icon: <TrendingUp size={18} /> },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-2 sm:gap-3">
                <div className="flex flex-col items-center gap-2 group">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-aqua-50 to-teal-50 flex items-center justify-center text-ocean-600 group-hover:bg-aqua-400 group-hover:text-white transition-all duration-300 group-hover:scale-110 shadow-soft">
                    {step.icon}
                  </div>
                  <span className="text-xs font-bold text-slatey/80">{step.label}</span>
                </div>
                {i < 3 && <ArrowRight size={16} className="text-slatey/30 hidden sm:block" />}
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-aqua-600 font-medium mt-6">
            Your recovered water can be part of something bigger.
          </p>
        </div>
      </section>

      {/* Feature cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="font-display font-bold text-3xl text-ocean-600 text-center mb-2">What ReWater does</h2>
        <p className="text-slatey/60 text-center mb-10 max-w-2xl mx-auto">From collecting water data to understanding its condition and identifying what could happen next.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { icon: <MapPin size={24} />, title: 'Water Map', desc: 'See water sources across the UAE and connect them to Water Passports.', page: 'map' as PageId, color: 'ocean' },
            { icon: <Beaker size={24} />, title: 'Check Water', desc: 'Create a Water Passport using AquaSense, AquaCard, camera, or manual observations.', page: 'check' as PageId, color: 'aqua' },
            { icon: <Droplets size={24} />, title: 'Water Passport', desc: 'Every sample gets a unique Water ID with a persistent digital history.', page: 'passport' as PageId, color: 'teal' },
            { icon: <RefreshCw size={24} />, title: 'Circularity Engine', desc: 'Identifies treatment, resource recovery, and reuse pathways from the water profile.', page: 'circular' as PageId, color: 'teal' },
            { icon: <TrendingUp size={24} />, title: 'Impact', desc: 'See what could happen if water recovery were implemented at scale.', page: 'impact' as PageId, color: 'ocean' },
            { icon: <Sparkles size={24} />, title: 'Future Lab', desc: 'Explore emerging technologies that could transform water management.', page: 'future' as PageId, color: 'aqua' },
          ].map((feat, i) => (
            <button
              key={feat.title}
              onClick={() => onNavigate(feat.page)}
              className="card p-6 text-left hover:shadow-float transition-all duration-300 hover:-translate-y-1 group animate-fade-slide"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div className={`inline-flex p-3 rounded-xl bg-${feat.color}-50 text-${feat.color}-600 mb-4 group-hover:scale-110 transition-transform`}>
                {feat.icon}
              </div>
              <h3 className="font-display font-semibold text-lg text-slatey mb-1.5">{feat.title}</h3>
              <p className="text-sm text-slatey/60 leading-relaxed">{feat.desc}</p>
              <div className="flex items-center gap-1 mt-3 text-sm text-aqua-600 font-medium">
                Explore <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* AquaSense 3D preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <Suspense fallback={<div className="rounded-3xl bg-ocean-950 border border-white/10" style={{ minHeight: 320 }} />}>
          <AquaSensePreview onOpen={() => onNavigate('aquasense')} />
        </Suspense>
      </section>

      {/* How it works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="card p-8 bg-gradient-to-r from-ocean-50 via-mist to-teal-50 border-softgrey">
          <h2 className="font-display font-bold text-2xl text-ocean-600 mb-2 text-center">How it works</h2>
          <p className="text-center text-slatey/60 text-sm mb-8">Five steps from finding water to understanding its potential.</p>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4">
            {[
              { label: 'Find', icon: <MapPin size={18} />, page: 'map' as PageId },
              { label: 'Check', icon: <Beaker size={18} />, page: 'check' as PageId },
              { label: 'Understand', icon: <Droplets size={18} />, page: 'check' as PageId },
              { label: 'Act', icon: <RefreshCw size={18} />, page: 'circular' as PageId },
              { label: 'Impact', icon: <TrendingUp size={18} />, page: 'impact' as PageId },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-2 sm:gap-4">
                <button onClick={() => onNavigate(step.page)} className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 rounded-full bg-white shadow-soft flex items-center justify-center text-ocean-600 group-hover:bg-aqua-400 group-hover:text-white transition-all duration-300 group-hover:scale-110">
                    {step.icon}
                  </div>
                  <span className="text-xs font-medium text-slatey/70">{step.label}</span>
                </button>
                {i < 4 && <div className="h-0.5 w-4 sm:w-8 bg-gradient-to-r from-aqua-300 to-teal-300 hidden sm:block" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How this connects to ReWater */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="text-center mb-6">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-ocean-600 mb-2">How This Connects to ReWater</h2>
          <p className="text-sm text-slatey/60 max-w-xl mx-auto">Every feature in ReWater is part of one connected system — from finding water to understanding what's in it and what could happen next.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { icon: <MapPin size={20} />, label: 'Find Water', desc: 'Where did we find this water?', page: 'map' as PageId, color: 'ocean' },
            { icon: <Beaker size={20} />, label: 'AquaSense', desc: 'What did we measure electronically?', page: 'check' as PageId, color: 'aqua' },
            { icon: <FlaskConical size={20} />, label: 'AquaCard', desc: 'What did the test card indicate?', page: 'check' as PageId, color: 'teal' },
            { icon: <Droplets size={20} />, label: 'AI Analysis', desc: 'What problems might require investigation?', page: 'check' as PageId, color: 'ocean' },
            { icon: <RefreshCw size={20} />, label: 'Water Journey', desc: 'What treatment and reuse pathways could apply?', page: 'circular' as PageId, color: 'teal' },
            { icon: <TrendingUp size={20} />, label: 'Impact', desc: 'What could happen if this pathway were implemented at scale?', page: 'impact' as PageId, color: 'ocean' },
            { icon: <Sparkles size={20} />, label: 'Future Lab', desc: 'What emerging technologies could improve these pathways?', page: 'future' as PageId, color: 'aqua' },
            { icon: <Recycle size={20} />, label: 'Water Awareness', desc: 'What is in the water we drink and why does it matter?', page: 'brands' as PageId, color: 'teal' },
            { icon: <Shield size={20} />, label: 'Responsible Management', desc: 'How do we keep water in circulation for as long as practical?', page: 'circular' as PageId, color: 'ocean' },
          ].map((item, i) => (
            <button
              key={i}
              onClick={() => onNavigate(item.page)}
              className="card p-5 text-left hover:shadow-float transition-all duration-300 hover:-translate-y-1 group"
            >
              <div className="flex items-center gap-3 mb-2">
                <span className={`w-10 h-10 rounded-xl bg-${item.color}-50 text-${item.color}-600 flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  {item.icon}
                </span>
                <span className="text-sm font-semibold text-slatey">{item.label}</span>
              </div>
              <p className="text-xs text-slatey/60 leading-relaxed">{item.desc}</p>
            </button>
          ))}
        </div>
      </section>

      {/* Sign-in prompt */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 pb-16">
        <div className="card p-8 text-center bg-gradient-to-b from-aqua-50 to-mist border-softgrey">
          <Recycle size={32} className="text-aqua-500 mx-auto mb-3" />
          <h2 className="font-display font-bold text-xl text-ocean-600 mb-2">Sign in to save your results</h2>
          <p className="text-sm text-slatey/60 mb-5 max-w-md mx-auto">
            Create a free account to save your Water Passports, track water history, and see your impact over time.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {onShowAuth && (
              <button onClick={() => onShowAuth('signin')} className="btn-aqua inline-flex items-center gap-2">
                <LogIn size={18} /> Sign In
              </button>
            )}
            {onShowAuth && (
              <button onClick={() => onShowAuth('signup')} className="btn-primary inline-flex items-center gap-2">
                <UserPlus size={18} /> Create Account
              </button>
            )}
            <button onClick={() => onNavigate('check')} className="btn-secondary inline-flex items-center gap-2">
              <TestTube size={18} /> Try without an account
            </button>
          </div>
          <p className="text-xs text-slatey/40 mt-4">
            You can check water and explore everything without signing in. Sign in when you want to save your data.
          </p>
        </div>
      </section>
    </div>
  );
}
