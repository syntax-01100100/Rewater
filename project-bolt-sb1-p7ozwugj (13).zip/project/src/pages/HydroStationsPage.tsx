import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  Droplet, ArrowLeft, Plus, ShieldCheck, MapPin,
  Droplets, Users, Sparkles, Info, Building2, CheckCircle,
  X, AlertCircle, Crosshair, Search, Loader2,
  Coins, HandHeart,
} from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { supabase, type HydroStation } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { donateCreditsToStation, fetchCreditBalance, type CreditBalance } from '@/lib/waterCredits';
import { type PageId } from '@/components/Navigation';

interface HydroStationsPageProps {
  onNavigate: (page: PageId) => void;
}

const WATER_STATUS_COLORS: Record<string, string> = {
  available: 'bg-teal-100 text-teal-700',
  limited: 'bg-amber-100 text-amber-700',
  offline: 'bg-coral-100 text-coral-700',
};

const MINIMUM_BALANCE = 20;

interface DemoStation {
  stationId: string;
  name: string;
  area: string;
  emirate: string;
  lat: number;
  lng: number;
  sponsor: string;
  initiative: string;
  waterStatus: string;
  credits: number;
  safeWaterSupply: string;
}

const DEMO_STATIONS: DemoStation[] = [
  { stationId: 'HS-AD-01', name: 'Mussafah Demo Station', area: 'Mussafah Industrial Area', emirate: 'Abu Dhabi', lat: 24.3744, lng: 54.4896, sponsor: 'Example Company', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 120, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-AD-02', name: 'ICAD Industrial Station', area: 'ICAD', emirate: 'Abu Dhabi', lat: 24.4054, lng: 54.4919, sponsor: 'Gulf Manufacturing', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 85, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-AD-03', name: 'KEZAD Station', area: 'KEZAD', emirate: 'Abu Dhabi', lat: 24.8200, lng: 54.8400, sponsor: 'KEZAD Authority', initiative: 'Worker Hydration Program', waterStatus: 'limited', credits: 15, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-AD-04', name: 'Al Ain Industrial Station', area: 'Al Ain Industrial City', emirate: 'Abu Dhabi', lat: 24.2075, lng: 55.6500, sponsor: 'Al Ain Industries', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 60, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-AD-05', name: 'Rahayel Station', area: 'Rahayel', emirate: 'Abu Dhabi', lat: 24.4100, lng: 54.5200, sponsor: 'Rahayel Group', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 45, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-AD-06', name: 'Ruwais Industrial Station', area: 'Ruwais Industrial Area', emirate: 'Abu Dhabi', lat: 24.1200, lng: 52.7300, sponsor: 'Ruwais Energy', initiative: 'Worker Hydration Program', waterStatus: 'offline', credits: 0, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-DX-01', name: 'Al Quoz Industrial Station', area: 'Al Quoz Industrial Area', emirate: 'Dubai', lat: 25.1438, lng: 55.2273, sponsor: 'Al Quoz Trading', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 100, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-DX-02', name: 'Jebel Ali Industrial Station', area: 'Jebel Ali Industrial Area', emirate: 'Dubai', lat: 25.0100, lng: 55.1700, sponsor: 'Jebel Ali Port Co.', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 70, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-DX-03', name: 'JAFZA Station', area: 'Jebel Ali Free Zone', emirate: 'Dubai', lat: 25.0150, lng: 55.1850, sponsor: 'JAFZA Authority', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 55, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-DX-04', name: 'Ras Al Khor Station', area: 'Ras Al Khor Industrial Area', emirate: 'Dubai', lat: 25.1900, lng: 55.3400, sponsor: 'Ras Al Khor Mfg', initiative: 'Worker Hydration Program', waterStatus: 'limited', credits: 12, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-DX-05', name: 'Al Qusais Station', area: 'Al Qusais Industrial Area', emirate: 'Dubai', lat: 25.2700, lng: 55.3800, sponsor: 'Al Qusais Group', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 50, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-SH-01', name: 'Industrial Area 1 Station', area: 'Industrial Area 1', emirate: 'Sharjah', lat: 25.2900, lng: 55.4300, sponsor: 'Sharjah Industrial', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 48, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-SH-05', name: 'Hamriyah Free Zone Station', area: 'Hamriyah Free Zone', emirate: 'Sharjah', lat: 25.4700, lng: 55.5000, sponsor: 'Hamriyah FZ', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 55, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-AJ-01', name: 'Al Jurf Industrial Station', area: 'Al Jurf Industrial Area', emirate: 'Ajman', lat: 25.4000, lng: 55.5000, sponsor: 'Ajman Industrial', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 40, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-RK-01', name: 'RAKEZ Station', area: 'RAKEZ', emirate: 'Ras Al Khaimah', lat: 25.7800, lng: 55.9400, sponsor: 'RAKEZ Authority', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 50, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-FJ-01', name: 'Fujairah Free Zone Station', area: 'Fujairah Free Zone', emirate: 'Fujairah', lat: 25.1700, lng: 56.3500, sponsor: 'Fujairah FZ', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 45, safeWaterSupply: 'Municipal verified supply' },
  { stationId: 'HS-UQ-01', name: 'UAQ Industrial Station', area: 'UAQ Industrial Area', emirate: 'Umm Al Quwain', lat: 25.5600, lng: 55.5400, sponsor: 'UAQ Industrial', initiative: 'Worker Hydration Program', waterStatus: 'available', credits: 30, safeWaterSupply: 'Municipal verified supply' },
];

function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function createDemoIcon(status: string): L.DivIcon {
  const color = status === 'available' ? '#0d9488' : status === 'limited' ? '#f59e0b' : '#ef4444';
  return L.divIcon({
    className: 'demo-hydro-marker',
    html: `<div style="position:relative;width:36px;height:36px;">
      <div style="width:28px;height:28px;border-radius:50% 50% 50% 0;background:${color};transform:rotate(-45deg);border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
        <span style="transform:rotate(45deg);color:white;font-size:14px;font-weight:bold;">D</span>
      </div>
    </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 32],
  });
}

// Unified station option for donation (works for both real and demo stations)
interface DonateOption {
  id: string;
  name: string;
  stationId: string;
  credits: number;
  isDemo: boolean;
}

// ── Donate Modal ──────────────────────────────────────────────────
function DonateModal({ options, userBalance, userId, onClose, onSuccess }: {
  options: DonateOption[];
  userBalance: number;
  userId: string;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [amount, setAmount] = useState(5);
  const [customAmount, setCustomAmount] = useState('');
  const [selectedOptionId, setSelectedOptionId] = useState('');
  const [donating, setDonating] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (options.length > 0) setSelectedOptionId(options[0].id);
  }, [options]);

  const handleDonate = async () => {
    const option = options.find(o => o.id === selectedOptionId);
    if (!option || amount <= 0) return;
    if (amount > userBalance) { setError('Insufficient balance.'); return; }
    setDonating(true);
    setError(null);
    const ok = await donateCreditsToStation({
      userId,
      stationId: option.id,
      stationName: option.name,
      amount,
    });
    setDonating(false);
    if (!ok) { setError('Donation failed. Please try again.'); return; }
    setDone(true);
    setTimeout(() => { onSuccess(); onClose(); }, 1500);
  };

  const canDonate = amount > 0 && amount <= userBalance && !!selectedOptionId;

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ocean-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card max-w-md w-full p-6 animate-fade-slide">
        <button onClick={onClose} className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-mist">
          <X size={18} className="text-slatey/50" />
        </button>
        <h2 className="font-display font-bold text-xl text-slatey mb-1 flex items-center gap-2">
          <HandHeart size={20} className="text-aqua-600" /> Donate Credits
        </h2>
        <p className="text-xs text-slatey/50 mb-4">Transfer credits from your balance to a HydroStation.</p>

        {done ? (
          <div className="text-center py-6 bg-teal-50 rounded-xl">
            <CheckCircle size={36} className="text-teal-500 mx-auto mb-2" />
            <p className="text-sm font-medium text-teal-700">Donation Complete!</p>
            <p className="text-xs text-teal-600/70 mt-1">{amount} credits donated to {options.find(o => o.id === selectedOptionId)?.name}</p>
          </div>
        ) : (
          <>
            <div className="bg-mist rounded-xl p-3 mb-4 flex items-center justify-between">
              <span className="text-xs text-slatey/50">Your balance</span>
              <span className="font-display font-bold text-aqua-700">{userBalance.toFixed(2)} Credits</span>
            </div>

            <p className="text-sm font-medium text-slatey/70 mb-2">Select HydroStation</p>
            <select value={selectedOptionId} onChange={e => setSelectedOptionId(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey mb-4 focus:outline-none focus:ring-2 focus:ring-aqua-400">
              {options.map(o => (
                <option key={o.id} value={o.id}>{o.name} ({o.stationId})</option>
              ))}
            </select>

            <p className="text-sm font-medium text-slatey/70 mb-2">Choose amount</p>
            <div className="flex gap-2 flex-wrap mb-3">
              {[5, 10, 25].map(amt => (
                <button key={amt} onClick={() => { setAmount(amt); setCustomAmount(''); }}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${amount === amt && !customAmount ? 'bg-aqua-600 text-white' : 'bg-mist text-slatey/60 hover:bg-aqua-50'}`}>
                  {amt} Credits
                </button>
              ))}
            </div>
            <div className="mb-4">
              <label className="text-xs text-slatey/50 block mb-1">Custom amount</label>
              <input type="number" min="1" value={customAmount} placeholder="Enter amount"
                onChange={e => { setCustomAmount(e.target.value); const v = parseFloat(e.target.value); if (v > 0) setAmount(v); }}
                className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
            </div>

            {error && (
              <p className="text-xs text-coral-600 text-center mb-3">{error}</p>
            )}
            <button onClick={handleDonate} disabled={donating || !canDonate}
              className="btn-aqua w-full disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2">
              {donating ? 'Donating...' : <><HandHeart size={16} /> Donate {amount} Credits</>}
            </button>
            <p className="text-xs text-slatey/40 text-center mt-2">
              Credits are transferred from your balance to the station's credit balance.
            </p>
          </>
        )}
      </div>
    </div>
  );
}

// ── Demo Station Card ──────────────────────────────────────────────
function DemoStationCard({ station, distance, onDonate }: {
  station: DemoStation;
  distance: number | null;
  onDonate: () => void;
}) {
  const isLowBalance = station.credits < MINIMUM_BALANCE;
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-aqua-100 to-teal-100 flex items-center justify-center text-aqua-600 flex-shrink-0 relative">
            <Droplet size={24} />
            <span className="absolute -top-1 -right-1 text-[8px] font-bold text-amber-600 bg-amber-100 px-1 rounded">DEMO</span>
          </div>
          <div>
            <p className="font-semibold text-slatey">{station.name}</p>
            <p className="text-xs text-slatey/50 flex items-center gap-1">
              <MapPin size={10} /> {station.area}, {station.emirate}
              {distance !== null && <span className="ml-2 text-aqua-600 font-medium">{distance < 1 ? '<1' : distance.toFixed(1)} km away</span>}
            </p>
          </div>
        </div>
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${WATER_STATUS_COLORS[station.waterStatus]}`}>
          {station.waterStatus}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
        <div className="bg-mist rounded-lg p-3 text-center">
          <Sparkles size={16} className="mx-auto text-aqua-500 mb-1" />
          <p className="font-display font-bold text-base text-slatey">{station.credits.toFixed(2)}</p>
          <p className="text-xs text-slatey/50">Available Credits</p>
        </div>
        <div className="bg-teal-50 rounded-lg p-3 text-center">
          <Building2 size={16} className="mx-auto text-teal-500 mb-1" />
          <p className="font-display font-bold text-xs text-teal-700 truncate">{station.sponsor}</p>
          <p className="text-xs text-teal-600/70">Sponsor</p>
        </div>
        <div className="bg-ocean-50 rounded-lg p-3 text-center">
          <Users size={16} className="mx-auto text-ocean-500 mb-1" />
          <p className="font-display font-bold text-xs text-ocean-700">{station.initiative}</p>
          <p className="text-xs text-ocean-600/70">Initiative</p>
        </div>
        <div className="bg-amber-50 rounded-lg p-3 text-center">
          <ShieldCheck size={16} className="mx-auto text-amber-500 mb-1" />
          <p className="font-display font-bold text-xs text-amber-700 capitalize">{station.waterStatus}</p>
          <p className="text-xs text-amber-600/70">Water Status</p>
        </div>
      </div>

      {isLowBalance && (
        <div className="flex items-start gap-2 bg-amber-50 rounded-lg p-2.5 mb-3">
          <AlertCircle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">This station needs sponsorship. Balance is below the minimum operating threshold.</p>
        </div>
      )}

      <button onClick={onDonate}
        className="w-full inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors justify-center">
        <HandHeart size={16} /> Donate Credits
      </button>
    </div>
  );
}

export function HydroStationsPage({ onNavigate }: HydroStationsPageProps) {
  const { user } = useAuth();
  const [userStations, setUserStations] = useState<HydroStation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [creditBalance, setCreditBalance] = useState<CreditBalance | null>(null);
  const [activeTab, setActiveTab] = useState<'nearby' | 'map' | 'list'>('nearby');

  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationStatus, setLocationStatus] = useState<'idle' | 'requesting' | 'granted' | 'denied'>('idle');
  const [areaFilter, setAreaFilter] = useState<string>('all');

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const [mapSelectedStation, setMapSelectedStation] = useState<DemoStation | null>(null);

  const [formName, setFormName] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formSponsor, setFormSponsor] = useState('');
  const [formInitiative, setFormInitiative] = useState('Worker Hydration Program');
  const [formSupply, setFormSupply] = useState('Municipal verified supply');
  const [showDonate, setShowDonate] = useState(false);
  const [donateTargetDemo, setDonateTargetDemo] = useState<DemoStation | null>(null);
  const [donateTargetStation, setDonateTargetStation] = useState<HydroStation | null>(null);

  const loadData = useCallback(async () => {
    if (!user) return;
    const [{ data: stationData }, bal] = await Promise.all([
      supabase.from('hydro_stations').select('*').order('created_at', { ascending: false }),
      fetchCreditBalance(user.id),
    ]);
    setUserStations(stationData || []);
    setCreditBalance(bal);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  const sortedDemoStations = useMemo(() => {
    if (!userLocation) return DEMO_STATIONS;
    return [...DEMO_STATIONS].sort((a, b) =>
      distanceKm(userLocation.lat, userLocation.lng, a.lat, a.lng) -
      distanceKm(userLocation.lat, userLocation.lng, b.lat, b.lng)
    );
  }, [userLocation]);

  const filteredStations = useMemo(() => {
    if (areaFilter === 'all') return sortedDemoStations;
    return sortedDemoStations.filter(s => s.emirate === areaFilter);
  }, [sortedDemoStations, areaFilter]);

  const emirates = useMemo(() => {
    const set = new Set(DEMO_STATIONS.map(s => s.emirate));
    return ['all', ...Array.from(set)];
  }, []);

  // Build unified donate options list
  const allDonateOptions: DonateOption[] = useMemo(() => [
    ...userStations.map<DonateOption>(s => ({
      id: s.id,
      name: s.name,
      stationId: s.station_id,
      credits: s.credit_balance as number,
      isDemo: false,
    })),
    ...DEMO_STATIONS.map<DonateOption>(s => ({
      id: s.stationId,
      name: s.name,
      stationId: s.stationId,
      credits: s.credits,
      isDemo: true,
    })),
  ], [userStations]);

  const handleFindNearby = () => {
    setLocationStatus('requesting');
    if (!navigator.geolocation) { setLocationStatus('denied'); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => { setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setLocationStatus('granted'); },
      () => { setLocationStatus('denied'); },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
    );
  };

  useEffect(() => {
    if (activeTab !== 'map' || !mapContainerRef.current || mapRef.current) return;
    const map = L.map(mapContainerRef.current, { center: [25.20, 55.40], zoom: 9, scrollWheelZoom: true });
    mapRef.current = map;
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors', maxZoom: 18 }).addTo(map);
    return () => { map.remove(); mapRef.current = null; markersRef.current = []; };
  }, [activeTab]);

  useEffect(() => {
    if (activeTab !== 'map' || !mapRef.current) return;
    const map = mapRef.current;
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];
    DEMO_STATIONS.forEach((station) => {
      const icon = createDemoIcon(station.waterStatus);
      const marker = L.marker([station.lat, station.lng], { icon }).addTo(map);
      marker.bindPopup(`<div style="min-width:200px;"><div style="font-weight:bold;font-size:14px;color:#0f766e;margin-bottom:4px;">DEMO — ${station.name}</div><div style="font-size:12px;color:#666;margin-bottom:6px;">${station.area}, ${station.emirate}</div><div style="font-size:11px;line-height:1.6;"><div><strong>Sponsor:</strong> ${station.sponsor}</div><div><strong>Credits:</strong> ${station.credits}</div></div></div>`);
      marker.on('click', () => setMapSelectedStation(station));
      markersRef.current.push(marker);
    });
    if (userLocation) {
      const userIcon = L.divIcon({ className: 'user-location-marker', html: '<div style="width:20px;height:20px;border-radius:50%;background:#3b82f6;border:3px solid white;box-shadow:0 0 8px rgba(59,130,246,0.5);"></div>', iconSize: [20, 20], iconAnchor: [10, 10] });
      const userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userIcon }).addTo(map);
      userMarker.bindPopup('<div style="font-size:12px;font-weight:600;color:#3b82f6;">Your Location</div>');
      markersRef.current.push(userMarker);
      map.setView([userLocation.lat, userLocation.lng], 10);
    }
  }, [activeTab, userLocation]);

  const handleCreateStation = async () => {
    if (!user || !formName || !formLocation) return;
    const stationCount = userStations.length;
    const stationId = `HS-${String(stationCount + 1).padStart(3, '0')}`;
    const { data, error } = await supabase.from('hydro_stations').insert({
      station_id: stationId, name: formName, location: formLocation,
      sponsor_company: formSponsor || (user.isDemo ? 'Demo Company' : user.email),
      supported_initiative: formInitiative, safe_water_supply: formSupply,
      credit_balance: 0, water_status: 'available',
    }).select('*').single();
    if (!error && data) {
      setUserStations(prev => [data, ...prev]);
      setShowCreate(false); setFormName(''); setFormLocation(''); setFormSponsor('');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slatey/60 mb-4">Please sign in to view HydroStations.</p>
          <button onClick={() => onNavigate('home')} className="btn-primary">Back to Home</button>
        </div>
      </div>
    );
  }

  if (loading) {
    return <div className="min-h-screen pt-16 flex items-center justify-center"><div className="text-slatey/40">Loading HydroStations...</div></div>;
  }

  const currentBalance = creditBalance?.current ?? 0;

  // Build options for a specific donate target
  const getDonateOptions = (targetDemo: DemoStation | null, targetStation: HydroStation | null): DonateOption[] => {
    if (targetDemo) {
      // Include the targeted demo station first, then all others
      const target: DonateOption = {
        id: targetDemo.stationId, name: targetDemo.name, stationId: targetDemo.stationId,
        credits: targetDemo.credits, isDemo: true,
      };
      const rest = allDonateOptions.filter(o => o.id !== targetDemo.stationId);
      return [target, ...rest];
    }
    if (targetStation) {
      return allDonateOptions;
    }
    return allDonateOptions;
  };

  const activeDonateTarget = donateTargetDemo ?? donateTargetStation;
  const activeDonateOptions = getDonateOptions(donateTargetDemo, donateTargetStation);
  const showDonateModal = showDonate || !!activeDonateTarget;

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-b from-aqua-50 via-mist to-mist">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <button onClick={() => onNavigate('water-credits')}
          className="flex items-center gap-2 text-sm text-slatey/50 hover:text-ocean-600 transition-colors mb-6">
          <ArrowLeft size={16} /> Back to Water Credits
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-aqua-500 to-teal-400 flex items-center justify-center text-white mx-auto mb-4 shadow-float">
            <Droplet size={36} />
          </div>
          <h1 className="font-display font-bold text-3xl text-ocean-600">HydroStations</h1>
          <p className="text-sm text-slatey/60 mt-2 max-w-lg mx-auto">
            Drinking-water stations that provide separately verified safe drinking water, sponsored by Water Credits.
          </p>
          <span className="inline-block mt-2 text-xs font-bold text-amber-600 bg-amber-100 px-3 py-1 rounded-full">PROTOTYPE / DEMO</span>
        </div>

        {/* Credit balance + station count */}
        <div className="card p-5 mb-6 bg-gradient-to-br from-aqua-600 to-ocean-600 text-white">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="font-display font-bold text-2xl">{currentBalance.toFixed(2)}</p>
              <p className="text-xs text-white/70 mt-1">Your Credit Balance</p>
            </div>
            <div>
              <p className="font-display font-bold text-2xl">{DEMO_STATIONS.length}</p>
              <p className="text-xs text-white/70 mt-1">Demo Stations</p>
            </div>
            <div>
              <p className="font-display font-bold text-2xl">{userStations.length}</p>
              <p className="text-xs text-white/70 mt-1">Your Stations</p>
            </div>
          </div>
          {currentBalance > 0 && (
            <button onClick={() => { setShowDonate(true); setDonateTargetDemo(null); setDonateTargetStation(null); }}
              className="w-full mt-4 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-sm font-medium transition-colors">
              <HandHeart size={16} /> Donate Credits to a Station
            </button>
          )}
        </div>

        {/* How it works */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-4">How HydroStations Work</h2>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-4">
            {[
              { label: 'Water Recovery', icon: <Droplets size={18} /> },
              { label: 'Business Contributes', icon: <Coins size={18} /> },
              { label: 'Credits Assigned', icon: <Sparkles size={18} /> },
              { label: 'Donate Credits', icon: <HandHeart size={18} /> },
              { label: 'Station Funded', icon: <ShieldCheck size={18} /> },
              { label: 'Impact Tracked', icon: <Users size={18} /> },
            ].map((step, i) => (
              <div key={step.label} className="flex items-center gap-2 sm:gap-3">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-aqua-50 to-teal-50 flex items-center justify-center text-aqua-600 shadow-soft">
                    {step.icon}
                  </div>
                  <span className="text-xs font-bold text-slatey/80 text-center max-w-[80px]">{step.label}</span>
                </div>
                {i < 5 && <div className="text-slatey/30 text-xl hidden sm:block">&rarr;</div>}
              </div>
            ))}
          </div>
          <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3">
            <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 leading-relaxed">
              HydroStations dispense from their own approved safe drinking-water supply — not from recovered water.
              Donate Water Credits to sponsor stations and keep water flowing for workers.
            </p>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
          {[
            { id: 'nearby', label: 'Find Nearby', icon: <Crosshair size={14} /> },
            { id: 'map', label: 'Demo Map', icon: <MapPin size={14} /> },
            { id: 'list', label: 'All Stations', icon: <Building2 size={14} /> },
          ].map((t) => (
            <button key={t.id} onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${activeTab === t.id ? 'bg-aqua-600 text-white' : 'bg-white text-slatey/60 border border-softgrey hover:bg-mist'}`}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Nearby tab */}
        {activeTab === 'nearby' && (
          <div className="space-y-4 mb-6">
            {locationStatus === 'idle' && (
              <div className="card p-6 text-center">
                <Crosshair size={32} className="mx-auto text-aqua-500 mb-3" />
                <h3 className="font-display font-semibold text-slatey mb-2">Find Nearby HydroStations</h3>
                <p className="text-xs text-slatey/50 mb-4 max-w-md mx-auto">
                  Allow location access to find the nearest demo HydroStations.
                </p>
                <button onClick={handleFindNearby} className="btn-aqua inline-flex items-center gap-2">
                  <Crosshair size={16} /> Find Nearby Stations
                </button>
              </div>
            )}
            {locationStatus === 'requesting' && (
              <div className="card p-6 text-center">
                <Loader2 size={24} className="animate-spin text-aqua-500 mx-auto mb-3" />
                <p className="text-sm text-slatey/60">Requesting location...</p>
              </div>
            )}
            {locationStatus === 'denied' && (
              <div className="card p-6 text-center">
                <AlertCircle size={32} className="mx-auto text-amber-500 mb-3" />
                <h3 className="font-display font-semibold text-slatey mb-2">Location Permission Denied</h3>
                <p className="text-xs text-slatey/50 mb-4">You can still browse demo stations manually.</p>
                <div className="flex items-center gap-2 justify-center flex-wrap">
                  <button onClick={handleFindNearby} className="btn-secondary text-sm flex items-center gap-2"><Crosshair size={14} /> Try Again</button>
                  <button onClick={() => setActiveTab('list')} className="btn-aqua text-sm flex items-center gap-2"><Building2 size={14} /> Browse by Area</button>
                </div>
              </div>
            )}
            {locationStatus === 'granted' && userLocation && (
              <>
                <div className="flex items-center gap-2 bg-teal-50 rounded-xl p-3">
                  <CheckCircle size={16} className="text-teal-600 flex-shrink-0" />
                  <p className="text-xs text-teal-700">Location detected. Showing nearest demo HydroStations first.</p>
                </div>
                {filteredStations.slice(0, 10).map((station) => {
                  const dist = distanceKm(userLocation.lat, userLocation.lng, station.lat, station.lng);
                  return (
                    <DemoStationCard key={station.stationId} station={station} distance={dist}
                      onDonate={() => { setDonateTargetDemo(station); setDonateTargetStation(null); setShowDonate(false); }}
                    />
                  );
                })}
              </>
            )}
          </div>
        )}

        {/* Map tab */}
        {activeTab === 'map' && (
          <div className="space-y-4 mb-6">
            <div className="card p-2">
              <div ref={mapContainerRef} style={{ height: '500px', width: '100%', borderRadius: '12px', zIndex: 0 }} />
            </div>
            <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3">
              <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-amber-700 leading-relaxed">
                All markers are <span className="font-medium">DEMO HydroStations</span> — fictional prototype locations. Click a marker for details.
              </p>
            </div>
            {mapSelectedStation && (
              <div className="card p-5">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-aqua-100 to-teal-100 flex items-center justify-center text-aqua-600 flex-shrink-0">
                      <Droplet size={24} />
                    </div>
                    <div>
                      <p className="font-semibold text-slatey">DEMO — {mapSelectedStation.name}</p>
                      <p className="text-xs text-slatey/50">{mapSelectedStation.stationId} &middot; <MapPin size={10} className="inline" /> {mapSelectedStation.area}, {mapSelectedStation.emirate}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${WATER_STATUS_COLORS[mapSelectedStation.waterStatus]}`}>{mapSelectedStation.waterStatus}</span>
                </div>
                <div className="bg-mist rounded-xl p-3 space-y-1.5 mb-3">
                  <div className="flex items-center justify-between text-xs"><span className="text-slatey/50">Sponsor</span><span className="font-medium text-slatey">{mapSelectedStation.sponsor}</span></div>
                  <div className="flex items-center justify-between text-xs"><span className="text-slatey/50">Available Credits</span><span className="font-medium text-aqua-700">{mapSelectedStation.credits.toFixed(2)}</span></div>
                </div>
                <button onClick={() => { setDonateTargetDemo(mapSelectedStation); setDonateTargetStation(null); setShowDonate(false); }}
                  className="w-full inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors justify-center">
                  <HandHeart size={16} /> Donate Credits
                </button>
              </div>
            )}
          </div>
        )}

        {/* List tab */}
        {activeTab === 'list' && (
          <div className="space-y-4 mb-6">
            <div className="flex items-center gap-2 flex-wrap">
              <Search size={14} className="text-slatey/40" />
              {emirates.map((em) => (
                <button key={em} onClick={() => setAreaFilter(em)}
                  className={`text-xs px-3 py-1.5 rounded-full font-medium transition-colors ${areaFilter === em ? 'bg-aqua-600 text-white' : 'bg-white text-slatey/60 border border-softgrey hover:bg-mist'}`}>
                  {em === 'all' ? 'All Emirates' : em}
                </button>
              ))}
            </div>
            {filteredStations.map((station) => (
              <DemoStationCard key={station.stationId} station={station}
                distance={userLocation ? distanceKm(userLocation.lat, userLocation.lng, station.lat, station.lng) : null}
                onDonate={() => { setDonateTargetDemo(station); setDonateTargetStation(null); setShowDonate(false); }}
              />
            ))}
          </div>
        )}

        {/* User-created stations */}
        {userStations.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-semibold text-lg text-slatey">Your Created Stations</h2>
              <button onClick={() => setShowCreate(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors">
                <Plus size={16} /> New Station
              </button>
            </div>
            <div className="space-y-4">
              {userStations.map((station) => {
                const isLow = (station.credit_balance as number) < (station.minimum_balance || MINIMUM_BALANCE);
                return (
                  <div key={station.id} className="card p-5">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-aqua-100 to-teal-100 flex items-center justify-center text-aqua-600 flex-shrink-0">
                          <Droplet size={24} />
                        </div>
                        <div>
                          <p className="font-semibold text-slatey">{station.name}</p>
                          <p className="text-xs text-slatey/50">{station.station_id} &middot; <MapPin size={10} className="inline" /> {station.location}</p>
                        </div>
                      </div>
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${WATER_STATUS_COLORS[station.water_status]}`}>{station.water_status}</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
                      <div className="bg-mist rounded-lg p-3 text-center">
                        <Sparkles size={16} className="mx-auto text-aqua-500 mb-1" />
                        <p className="font-display font-bold text-base text-slatey">{(station.credit_balance as number).toFixed(2)}</p>
                        <p className="text-xs text-slatey/50">Credit Balance</p>
                      </div>
                      <div className="bg-teal-50 rounded-lg p-3 text-center">
                        <Droplets size={16} className="mx-auto text-teal-500 mb-1" />
                        <p className="font-display font-bold text-base text-teal-700">{station.total_litres_dispensed.toLocaleString()} L</p>
                        <p className="text-xs text-teal-600/70">Dispensed</p>
                      </div>
                      <div className="bg-ocean-50 rounded-lg p-3 text-center">
                        <Users size={16} className="mx-auto text-ocean-500 mb-1" />
                        <p className="font-display font-bold text-base text-ocean-700">{station.total_worker_visits}</p>
                        <p className="text-xs text-ocean-600/70">Worker Visits</p>
                      </div>
                      <div className="bg-amber-50 rounded-lg p-3 text-center">
                        <ShieldCheck size={16} className="mx-auto text-amber-500 mb-1" />
                        <p className="font-display font-bold text-base text-amber-700">{station.supported_initiative}</p>
                        <p className="text-xs text-amber-600/70">Initiative</p>
                      </div>
                    </div>
                    {isLow && (
                      <div className="flex items-start gap-2 bg-amber-50 rounded-lg p-2.5 mb-3">
                        <AlertCircle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-amber-700">This station needs sponsorship. Balance is below the minimum ({station.minimum_balance || MINIMUM_BALANCE} credits). Donate credits to keep water flowing.</p>
                      </div>
                    )}
                    <button onClick={() => { setDonateTargetStation(station); setDonateTargetDemo(null); setShowDonate(false); }}
                      className="w-full inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors justify-center">
                      <HandHeart size={16} /> Donate Credits
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Disclaimer */}
        <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-4 mt-4">
          <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700 leading-relaxed">
            All HydroStations are <span className="font-medium">fictional demo locations</span> for prototype demonstration.
            Drinking water at each station comes from a separately verified safe supply, not from recovered water.
          </p>
        </div>
      </div>

      {/* Create station modal */}
      {showCreate && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-ocean-900/40 backdrop-blur-sm" onClick={() => setShowCreate(false)} />
          <div className="relative card max-w-md w-full p-6 animate-fade-slide max-h-[80vh] overflow-y-auto">
            <button onClick={() => setShowCreate(false)} className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-mist"><X size={18} className="text-slatey/50" /></button>
            <h2 className="font-display font-bold text-xl text-slatey mb-4 flex items-center gap-2"><Droplet size={20} className="text-aqua-600" /> New HydroStation</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Station Name</label>
                <input type="text" value={formName} onChange={e => setFormName(e.target.value)} placeholder="e.g. Jebel Ali Station 1"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Location</label>
                <input type="text" value={formLocation} onChange={e => setFormLocation(e.target.value)} placeholder="e.g. Jebel Ali Industrial Zone"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Sponsor Company</label>
                <input type="text" value={formSponsor} onChange={e => setFormSponsor(e.target.value)} placeholder="Company name"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Supported Initiative</label>
                <input type="text" value={formInitiative} onChange={e => setFormInitiative(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Safe Water Supply</label>
                <input type="text" value={formSupply} onChange={e => setFormSupply(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
              </div>
            </div>
            <button onClick={handleCreateStation} disabled={!formName || !formLocation}
              className="btn-aqua w-full mt-5 disabled:opacity-50 disabled:cursor-not-allowed">Create Station</button>
          </div>
        </div>
      )}

      {/* Donate modal */}
      {showDonateModal && user && (
        <DonateModal
          options={activeDonateOptions}
          userBalance={currentBalance}
          userId={user.id}
          onClose={() => { setShowDonate(false); setDonateTargetDemo(null); setDonateTargetStation(null); }}
          onSuccess={loadData}
        />
      )}

    </div>
  );
}
