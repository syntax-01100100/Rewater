import { useState, useEffect } from 'react';
import {
  Droplets, MapPin, Beaker, Cpu, FlaskConical, RefreshCw,
  CheckCircle, AlertCircle, Recycle, ArrowRight,
  Shield, Trash2, TestTube, Thermometer, Waves, Zap,
  Calendar, Info, AlertTriangle, Sparkles, Users, Wifi
} from 'lucide-react';
import { fetchLatestReadingForPassport, fetchReadingHistoryForPassport, type SensorReading } from '@/lib/sensorData';
import { useWaterPassport, type WaterPassport, type PassportStage, type PassportMeasurement } from '@/lib/waterPassport';
import { useAuth } from '@/lib/auth';
import { useAuthGuard } from '@/lib/authGuard';
import type { PageId } from '@/components/Navigation';
import { PassportTimeline, PassportCard } from '@/components/PassportTimeline';
import { stageLabel, stageOrder, statusLabel } from '@/lib/waterPassport';
import { CREDIT_CONFIG, calculateCreditEligible, calculateCredits } from '@/lib/waterCredits';

const STAGES: { id: PassportStage; label: string; icon: React.ReactNode }[] = [
  { id: 'collected', label: 'Source', icon: <Droplets size={16} /> },
  { id: 'identified', label: 'Test', icon: <Beaker size={16} /> },
  { id: 'profiled', label: 'Understand', icon: <Cpu size={16} /> },
  { id: 'analyzed', label: 'Analyzed', icon: <ArrowRight size={16} /> },
  { id: 'pathway_identified', label: 'Treat', icon: <FlaskConical size={16} /> },
  { id: 'treated', label: 'Treated', icon: <CheckCircle size={16} /> },
  { id: 'reuse_pathway', label: 'Reuse', icon: <Recycle size={16} /> },
  { id: 'retest_required', label: 'Retest', icon: <RefreshCw size={16} /> },
  { id: 'verified', label: 'Verified', icon: <Shield size={16} /> },
];

function measurementIcon(name: string): React.ReactNode {
  const n = name.toLowerCase();
  if (n.includes('ph')) return <Droplets size={14} />;
  if (n.includes('temp')) return <Thermometer size={14} />;
  if (n.includes('turb')) return <Beaker size={14} />;
  if (n.includes('tds')) return <Zap size={14} />;
  if (n.includes('nitrate') || n.includes('nitrite')) return <TestTube size={14} />;
  if (n.includes('hard')) return <Waves size={14} />;
  if (n.includes('chlor')) return <Shield size={14} />;
  return <Beaker size={14} />;
}

export function WaterPassportPage({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  const { passports, passport, selectPassport, selectedId, deletePassport, addEvent, setStage, addRetest } = useWaterPassport();
  const { user } = useAuth();
  const { requireAuth } = useAuthGuard();
  const [showRetest, setShowRetest] = useState(false);

  const activePassport = selectedId ? passports.find(p => p.waterId === selectedId) : passport;

  if (!user) {
    return (
      <div className="min-h-screen pt-16 bg-gradient-mist">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
          <PassportPreview />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 bg-gradient-mist">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="font-display font-bold text-2xl text-slatey mb-1">Water Passport</h1>
              <p className="text-sm text-slatey/60">Every water sample gets a digital identity and history.</p>
            </div>
            <button
              onClick={() => onNavigate ? onNavigate('check') : undefined}
              className="btn-primary flex items-center gap-2"
            >
              <Beaker size={16} /> Test Water
            </button>
          </div>
        </div>

        {/* Demo banner */}
        {activePassport?.isDemo && (
          <div className="flex items-center gap-2 bg-amber-50 rounded-xl px-4 py-2.5 mb-5 border border-amber-200">
            <Sparkles size={16} className="text-amber-500 flex-shrink-0" />
            <p className="text-xs text-amber-700">
              <span className="font-semibold">DEMO ACCOUNT</span> — This passport contains demonstration data for exploration.
            </p>
          </div>
        )}

        {passports.length === 0 ? (
          <EmptyState onNavigate={onNavigate} />
        ) : (
          <div className="grid lg:grid-cols-[300px_1fr] gap-6">
            {/* Passport list */}
            <div>
              <h2 className="font-display font-semibold text-sm text-slatey/70 mb-3">Your Passports</h2>
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                {passports.map((p) => (
                  <div key={p.waterId} className="relative group">
                    <PassportCard
                      passport={p}
                      compact
                      onClick={() => selectPassport(p.waterId)}
                    />
                    {p.waterId === activePassport?.waterId && (
                      <div className="absolute -left-1 top-1/2 -translate-y-1/2 w-1 h-8 bg-aqua-400 rounded-full" />
                    )}
                    <button
                      onClick={(e) => { e.stopPropagation(); deletePassport(p.waterId); }}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-slatey/30 hover:text-coral-500 transition-all p-1"
                      aria-label="Delete passport"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Active passport detail */}
            {activePassport ? (
              <PassportDetail
                passport={activePassport}
                onMarkTreated={() => {
                  addEvent(activePassport.waterId, 'treated', 'Treatment applied', 'Filtration and disinfection completed');
                }}
                onActivateReuse={() => {
                  setStage(activePassport.waterId, 'reuse_pathway');
                  addEvent(activePassport.waterId, 'reuse_pathway', 'Reuse pathway activated', 'Water routed for reuse');
                }}
                onRequestRetest={() => setShowRetest(true)}
              />
            ) : (
              <EmptyState onNavigate={onNavigate} />
            )}
          </div>
        )}

        {/* Retest modal */}
        {showRetest && activePassport && (
          <RetestModal
            passport={activePassport}
            onClose={() => setShowRetest(false)}
            onRetest={(treatment, verified) => {
              addRetest(activePassport.waterId, {
                timestamp: new Date().toISOString(),
                before: activePassport.measurements,
                after: activePassport.measurements,
                treatmentApplied: treatment,
                verified,
              });
              setShowRetest(false);
            }}
          />
        )}
      </div>
    </div>
  );
}

function PassportPreview() {
  return (
    <div>
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-aqua-50 rounded-full px-4 py-1.5 mb-4">
          <Droplets size={14} className="text-aqua-600" />
          <span className="text-sm text-aqua-700 font-medium">Water Passport</span>
        </div>
        <h1 className="font-display font-bold text-2xl sm:text-3xl text-slatey mb-3">
          Every Water Sample Has a Story
        </h1>
        <p className="text-slatey/60 max-w-2xl mx-auto text-sm sm:text-base">
          The Water Passport gives each water sample a digital identity — tracking its journey from source to treatment to reuse and recovery.
        </p>
      </div>

      {/* Journey preview */}
      <div className="card p-6 mb-6">
        <h2 className="font-display font-semibold text-sm text-slatey mb-5 text-center">The Circular Journey</h2>
        <div className="flex items-center justify-center gap-1 sm:gap-2 flex-wrap">
          {STAGES.map((s, i) => (
            <div key={s.id} className="flex items-center gap-1 sm:gap-2">
              <div className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-2xl bg-aqua-50 text-aqua-600 flex items-center justify-center">
                  {s.icon}
                </div>
                <span className="text-xs text-slatey/60 font-medium text-center">{s.label}</span>
              </div>
              {i < STAGES.length - 1 && <ArrowRight size={14} className="text-aqua-300" />}
            </div>
          ))}
        </div>
      </div>

      <div className="card p-8 text-center bg-gradient-to-br from-aqua-50 to-white">
        <Droplets size={40} className="mx-auto text-aqua-300 mb-4" />
        <h3 className="font-display font-semibold text-lg text-slatey mb-2">Sign in to start your passport</h3>
        <p className="text-sm text-slatey/60 max-w-md mx-auto mb-6">
          Create water passports by testing water samples, track treatment journeys, explore reuse pathways, and build a circular water record.
        </p>
        <p className="text-xs text-slatey/40">
          A Water Passport is created only after water testing is completed — not when you sign in.
        </p>
      </div>
    </div>
  );
}

function EmptyState({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  return (
    <div className="card p-12 text-center">
      <Droplets size={48} className="mx-auto text-aqua-200 mb-4" />
      <h3 className="font-display font-semibold text-lg text-slatey mb-2">No Water Passports yet</h3>
      <p className="text-sm text-slatey/60 mb-6 max-w-md mx-auto">
        Complete water testing before creating a Water Passport.
        A Water Passport is only created after a water sample has been tested and analyzed — not when you create an account.
      </p>
      {onNavigate && (
        <button onClick={() => onNavigate('check')} className="btn-primary inline-flex items-center gap-2">
          <Beaker size={16} /> Test Water
        </button>
      )}
    </div>
  );
}

function PassportDetail({
  passport,
  onMarkTreated,
  onActivateReuse,
  onRequestRetest,
}: {
  passport: WaterPassport;
  onMarkTreated: () => void;
  onActivateReuse: () => void;
  onRequestRetest: () => void;
}) {
  const [activeTab, setActiveTab] = useState<'overview' | 'journey' | 'reuse' | 'history'>('overview');
  const stageNum = stageOrder(passport.currentStage);
  const profile = passport.profile;
  const [liveReading, setLiveReading] = useState<SensorReading | null>(null);
  const [liveHistory, setLiveHistory] = useState<SensorReading[]>([]);
  const [liveLoading, setLiveLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLiveLoading(true);
    Promise.all([
      fetchLatestReadingForPassport(passport.waterId),
      fetchReadingHistoryForPassport(passport.waterId, 5),
    ]).then(([latest, history]) => {
      if (cancelled) return;
      setLiveReading(latest);
      setLiveHistory(history);
      setLiveLoading(false);
    });
    return () => { cancelled = true; };
  }, [passport.waterId]);

  return (
    <div className="space-y-5">
      {/* Passport header card */}
      <div className="card p-6 bg-gradient-to-br from-white to-aqua-50/30">
        <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-aqua-100 to-teal-100 flex items-center justify-center">
              <Droplets size={28} className="text-aqua-600" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-slatey">{passport.waterId}</h2>
              <p className="text-sm text-slatey/60">{passport.source}</p>
              <p className="text-xs text-slatey/40 flex items-center gap-1 mt-0.5">
                <MapPin size={10} /> {passport.sourceType} · <Calendar size={10} /> {new Date(passport.collectionDate).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${stageNum >= 6 ? 'bg-teal-100 text-teal-700' : 'bg-aqua-100 text-aqua-700'}`}>
              {stageLabel(passport.currentStage)}
            </div>
            {passport.isDemo && (
              <span className="block text-xs text-amber-600 font-medium mt-1">DEMO</span>
            )}
          </div>
        </div>

        {/* Circular journey progress */}
        <div className="mt-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slatey/60">Circularity Journey</span>
            <span className="text-xs text-slatey/40">Stage {stageNum + 1} of {STAGES.length}</span>
          </div>
          <div className="flex items-center gap-1">
            {STAGES.map((s, i) => {
              const completed = i <= stageNum;
              const current = i === stageNum;
              return (
                <div key={s.id} className="flex items-center flex-1 last:flex-none">
                  <div
                    className={`flex flex-col items-center gap-1 transition-all ${current ? 'scale-110' : ''}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                      completed
                        ? current
                          ? 'bg-aqua-500 text-white shadow-float'
                          : 'bg-aqua-400 text-white'
                        : 'bg-softgrey text-slatey/40'
                    }`}>
                      {s.icon}
                    </div>
                    <span className={`text-[10px] ${completed ? 'text-slatey/70 font-medium' : 'text-slatey/30'} hidden sm:block`}>{s.label}</span>
                  </div>
                  {i < STAGES.length - 1 && (
                    <div className={`flex-1 h-0.5 mx-1 ${i < stageNum ? 'bg-aqua-400' : 'bg-softgrey'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {[
          { id: 'overview', label: 'Overview', icon: <Beaker size={14} /> },
          { id: 'journey', label: 'Journey Timeline', icon: <ArrowRight size={14} /> },
          { id: 'reuse', label: 'Reuse & Recovery', icon: <Recycle size={14} /> },
          { id: 'history', label: 'Water-Use History', icon: <RefreshCw size={14} /> },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
              activeTab === t.id ? 'bg-ocean-600 text-white' : 'bg-white text-slatey/60 border border-softgrey hover:bg-mist'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* Overview tab */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {/* AquaSense live readings */}
          <AquaSenseLiveCard
            reading={liveReading}
            history={liveHistory}
            loading={liveLoading}
            passportId={passport.waterId}
          />

          {/* Quality indicators */}
          <div className="card p-5">
            <h3 className="font-display font-semibold text-sm text-slatey mb-4 flex items-center gap-2">
              <Beaker size={14} className="text-aqua-600" /> Quality Indicators
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {passport.measurements.map((m, i) => (
                <MeasurementCard key={i} m={m} />
              ))}
            </div>
          </div>

          {/* Water Credit Calculation */}
          <WaterCreditCalcCard passport={passport} />

          {/* Status & treatment */}
          {profile && (
            <>
              <div className="card p-5">
                <h3 className="font-display font-semibold text-sm text-slatey mb-3 flex items-center gap-2">
                  <FlaskConical size={14} className="text-teal-600" /> Recommended Treatment
                </h3>
                <div className="space-y-2">
                  {profile.treatmentPathway.map((stage, i) => (
                    <div key={i} className="flex items-start gap-3 bg-mist rounded-xl p-3">
                      <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center text-xs font-bold flex-shrink-0">{i + 1}</span>
                      <div>
                        <p className="text-sm font-medium text-slatey">{stage.name}</p>
                        <p className="text-xs text-slatey/60 mt-0.5">{stage.addresses}</p>
                      </div>
                    </div>
                  ))}
                  {profile.treatmentPathway.length === 0 && (
                    <p className="text-sm text-slatey/50">No treatment stages needed.</p>
                  )}
                </div>
              </div>

              {/* Verification disclaimer */}
              <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-4 border border-amber-200">
                <AlertTriangle size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-800">
                  <strong>Educational estimates only.</strong> ReWater is a screening prototype, not a certified laboratory.
                  These results help you understand water quality — they do not replace professional testing or certify water as safe for drinking.
                </p>
              </div>
            </>
          )}

          {/* Action buttons */}
          <div className="card p-5">
            <div className="flex gap-3 flex-wrap">
              {stageOrder(passport.currentStage) < stageOrder('treated') && (
                <button onClick={onMarkTreated} className="btn-primary text-sm flex items-center gap-2">
                  <CheckCircle size={14} /> Mark as Treated
                </button>
              )}
              {stageOrder(passport.currentStage) >= stageOrder('treated') && stageOrder(passport.currentStage) < stageOrder('reuse_pathway') && (
                <button onClick={onActivateReuse} className="btn-primary text-sm flex items-center gap-2">
                  <Recycle size={14} /> Activate Reuse Pathway
                </button>
              )}
              <button onClick={onRequestRetest} className="btn-secondary text-sm flex items-center gap-2">
                <RefreshCw size={14} /> Retest
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Journey tab */}
      {activeTab === 'journey' && (
        <div className="card p-6">
          <h3 className="font-display font-semibold text-sm text-slatey mb-4">Circularity Timeline</h3>
          <PassportTimeline events={passport.events} />
        </div>
      )}

      {/* Reuse tab */}
      {activeTab === 'reuse' && (
        <div className="space-y-4">
          {profile ? (
            <>
              <div className="card p-5">
                <h3 className="font-display font-semibold text-sm text-slatey mb-3 flex items-center gap-2">
                  <Recycle size={14} className="text-teal-600" /> Possible Reuse Options
                </h3>
                <div className="space-y-2">
                  {profile.reusePathways.map((p, i) => (
                    <div key={i} className="bg-mist rounded-xl p-3">
                      <p className="text-sm font-medium text-slatey">{p.category}</p>
                      <p className="text-xs text-slatey/60 mt-1"><span className="font-medium">Treatment required:</span> {p.treatmentRequired}</p>
                      <p className="text-xs text-slatey/60"><span className="font-medium">Verification needed:</span> {p.verificationNeeded}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card p-5">
                <h3 className="font-display font-semibold text-sm text-slatey mb-3 flex items-center gap-2">
                  <Zap size={14} className="text-amber-600" /> Resources That Could Be Recovered
                </h3>
                <div className="space-y-2">
                  {profile.resourceRecovery.map((r, i) => (
                    <div key={i} className="flex items-center gap-3 bg-mist rounded-xl p-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${r.status === 'confirmed' ? 'bg-teal-100 text-teal-600' : 'bg-amber-100 text-amber-600'}`}>
                        {r.status === 'confirmed' ? <CheckCircle size={16} /> : <Info size={16} />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slatey">{r.resource}</p>
                        <p className="text-xs text-slatey/60">{r.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="card p-6 text-center">
              <p className="text-sm text-slatey/50">No reuse data available yet.</p>
            </div>
          )}
        </div>
      )}

      {/* History tab */}
      {activeTab === 'history' && (
        <div className="card p-6">
          <h3 className="font-display font-semibold text-sm text-slatey mb-4">Water-Use History</h3>
          {passport.previousUses.length === 0 && passport.reuseHistory.length === 0 ? (
            <p className="text-sm text-slatey/50 text-center py-4">No use history recorded yet.</p>
          ) : (
            <div className="space-y-3">
              {[...passport.reuseHistory, ...passport.previousUses].map((use, i) => (
                <div key={i} className="flex items-center gap-3 bg-mist rounded-xl p-3">
                  <RefreshCw size={14} className="text-aqua-600" />
                  <span className="text-sm text-slatey">{use}</span>
                </div>
              ))}
            </div>
          )}

          {/* Retest records */}
          {passport.retests.length > 0 && (
            <div className="mt-6">
              <h4 className="font-display font-semibold text-sm text-slatey mb-3">Retest Records</h4>
              <div className="space-y-3">
                {passport.retests.map((r, i) => (
                  <div key={i} className="bg-mist rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      {r.verified ? <CheckCircle size={14} className="text-teal-500" /> : <AlertCircle size={14} className="text-amber-500" />}
                      <span className="text-sm font-medium text-slatey">{r.verified ? 'Verified' : 'Not Verified'}</span>
                      <span className="text-xs text-slatey/40 ml-auto">{new Date(r.timestamp).toLocaleDateString()}</span>
                    </div>
                    <p className="text-xs text-slatey/60">Treatment: {r.treatmentApplied}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MeasurementCard({ m }: { m: PassportMeasurement }) {
  return (
    <div className="bg-mist rounded-xl p-3">
      <div className="flex items-center gap-2 mb-1.5">
        <span className="text-aqua-600">{measurementIcon(m.name)}</span>
        <span className="text-xs text-slatey/60">{m.name}</span>
      </div>
      <div className="font-display font-bold text-lg text-slatey">
        {m.value}<span className="text-xs text-slatey/40 ml-1">{m.unit}</span>
      </div>
      <div className="text-[10px] text-slatey/40 mt-0.5">{statusLabel(m.status)}</div>
    </div>
  );
}

function WaterCreditCalcCard({ passport }: { passport: WaterPassport }) {
  const litresMeasured = (() => {
    if (!passport.quantity || passport.quantity <= 0) return 0;
    if (passport.unit === 'mL') return passport.quantity / 1000;
    if (passport.unit === 'm³' || passport.unit === 'm3') return passport.quantity * 1000;
    return passport.quantity;
  })();

  const isEligible =
    passport.reuseHistory.length > 0 ||
    passport.recoveryHistory.length > 0 ||
    passport.currentStage === 'treated' ||
    passport.currentStage === 'verified' ||
    passport.currentStage === 'reuse_pathway';

  const recoveredLitres = passport.recoveredWaterLitres ?? (isEligible ? litresMeasured : 0);
  const inputLitres = passport.inputWaterLitres ?? litresMeasured;
  const lossLitres = passport.treatmentLossLitres ?? (inputLitres > 0 && recoveredLitres > 0 ? inputLitres - recoveredLitres : 0);
  const recoveryRate = passport.recoveryRate ?? (inputLitres > 0 ? (recoveredLitres / inputLitres) * 100 : 0);
  const creditEligible = isEligible ? calculateCreditEligible(recoveredLitres) : 0;
  const waterCredits = isEligible ? calculateCredits(recoveredLitres).creditsGenerated : 0;

  return (
    <div className="card p-5">
      <h3 className="font-display font-semibold text-sm text-slatey mb-4 flex items-center gap-2">
        <Sparkles size={14} className="text-aqua-600" /> Water Credit Calculation
      </h3>

      {/* Flow: Input → Recovered → Loss → Rate → Credit-Eligible → Credits */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {[
          { label: 'Input', value: inputLitres > 0 ? `${inputLitres.toLocaleString()} L` : '—', icon: <Droplets size={14} />, color: 'ocean' },
          { label: 'Recovered', value: recoveredLitres > 0 ? `${recoveredLitres.toLocaleString()} L` : '—', icon: <Recycle size={14} />, color: 'teal' },
          { label: 'Loss', value: lossLitres > 0 ? `${lossLitres.toLocaleString()} L` : '—', icon: <Droplets size={14} />, color: 'coral' },
          { label: 'Recovery Rate', value: recoveryRate > 0 ? `${recoveryRate.toFixed(1)}%` : '—', icon: <Beaker size={14} />, color: 'aqua' },
          { label: 'Credit-Eligible', value: creditEligible > 0 ? `${creditEligible.toFixed(1)} L` : '—', icon: <Sparkles size={14} />, color: 'teal' },
          { label: 'Water Credits', value: waterCredits > 0 ? waterCredits.toFixed(2) : '0', icon: <Sparkles size={14} />, color: 'aqua' },
        ].map((step, i) => (
          <div key={step.label} className="flex items-center gap-2">
            <div className={`bg-${step.color}-50 rounded-lg p-2.5 text-center min-w-[90px]`}>
              <span className={`text-${step.color}-600 flex justify-center mb-1`}>{step.icon}</span>
              <p className="font-display font-bold text-sm text-slatey">{step.value}</p>
              <p className="text-[10px] text-slatey/50">{step.label}</p>
            </div>
            {i < 5 && <ArrowRight size={12} className="text-slatey/30" />}
          </div>
        ))}
      </div>

      {/* Calculation formula */}
      {litresMeasured > 0 && (
        <div className="bg-mist rounded-xl p-3 mb-3">
          <p className="text-xs text-slatey/60 leading-relaxed">
            <span className="font-medium text-slatey">Formula:</span> Credit-Eligible Water = Recovered Water × {Math.round(CREDIT_CONFIG.partnershipShare * 100)}% partnership share. Water Credits = Credit-Eligible ÷ {CREDIT_CONFIG.creditUnitSizeLitres} L
          </p>
          {recoveredLitres > 0 && (
            <p className="text-xs text-slatey/70 mt-1 font-mono">
              {recoveredLitres.toLocaleString()} L × {Math.round(CREDIT_CONFIG.partnershipShare * 100)}% = {creditEligible.toFixed(1)} L → {creditEligible.toFixed(1)} ÷ {CREDIT_CONFIG.creditUnitSizeLitres} = <span className="font-bold text-aqua-700">{waterCredits.toFixed(2)} credits</span>
            </p>
          )}
        </div>
      )}

      {/* Eligibility note */}
      {!isEligible && litresMeasured > 0 && (
        <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3">
          <AlertTriangle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700 leading-relaxed">
            Water Credits are <span className="font-medium">not generated from quantity alone</span>. Complete an
            eligible recovery, treatment, or reuse pathway to generate Water Credits. Current credits: 0.
          </p>
        </div>
      )}

      {/* Credit breakdown */}
      {waterCredits > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-ocean-50 rounded-lg p-3 text-center">
            <p className="font-display font-bold text-base text-ocean-700">{inputLitres.toLocaleString()} L</p>
            <p className="text-xs text-ocean-600/70">Wastewater Input</p>
          </div>
          <div className="bg-teal-50 rounded-lg p-3 text-center">
            <p className="font-display font-bold text-base text-teal-700">{recoveredLitres.toLocaleString()} L</p>
            <p className="text-xs text-teal-600/70">Water Recovered</p>
          </div>
          <div className="bg-aqua-50 rounded-lg p-3 text-center">
            <p className="font-display font-bold text-base text-aqua-700">{creditEligible.toFixed(1)} L</p>
            <p className="text-xs text-aqua-600/70">Credit-Eligible Water</p>
          </div>
          <div className="bg-amber-50 rounded-lg p-3 text-center">
            <p className="font-display font-bold text-base text-amber-700">{waterCredits.toFixed(2)}</p>
            <p className="text-xs text-amber-600/70">Water Credits Earned</p>
          </div>
        </div>
      )}

      {litresMeasured === 0 && (
        <div className="flex items-start gap-2 bg-mist rounded-xl p-3">
          <Info size={14} className="text-slatey/40 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-slatey/50">
            No water quantity was entered for this passport. Add a quantity when testing a new water sample to
            calculate Water Credits.
          </p>
        </div>
      )}
    </div>
  );
}

function AquaSenseLiveCard({
  reading,
  history,
  loading,
  passportId,
}: {
  reading: SensorReading | null;
  history: SensorReading[];
  loading: boolean;
  passportId: string;
}) {
  if (loading) {
    return (
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Wifi size={14} className="text-aqua-600" />
          <h3 className="font-display font-semibold text-sm text-slatey">AquaSense Live Readings</h3>
        </div>
        <div className="animate-pulse space-y-2">
          <div className="h-4 bg-softgrey rounded w-1/3" />
          <div className="h-16 bg-softgrey rounded" />
        </div>
      </div>
    );
  }

  if (!reading) {
    return (
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Wifi size={14} className="text-slatey/40" />
          <h3 className="font-display font-semibold text-sm text-slatey">AquaSense Live Readings</h3>
        </div>
        <div className="flex items-start gap-2 bg-mist rounded-xl p-3">
          <Info size={14} className="text-slatey/40 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-xs text-slatey/60">
              No real AquaSense readings yet for <span className="font-medium">{passportId}</span>.
              Send a reading from an ESP32 device with this passport ID to see live measurements here.
            </p>
            <p className="text-[10px] text-slatey/40 mt-1">
              Until then, measurements shown above are from the water test form and may be simulated or estimated.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const metrics = [
    { label: 'pH', value: reading.ph, unit: '', icon: <Droplets size={14} /> },
    { label: 'TDS', value: reading.tds, unit: 'ppm', icon: <Zap size={14} /> },
    { label: 'Turbidity', value: reading.turbidity, unit: 'NTU', icon: <Beaker size={14} /> },
    { label: 'Temperature', value: reading.temperature, unit: '\u00b0C', icon: <Thermometer size={14} /> },
  ];

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500" />
          </span>
          <h3 className="font-display font-semibold text-sm text-slatey">AquaSense Live Readings</h3>
        </div>
        <span className="text-[10px] text-slatey/40 font-mono">{reading.device_id}</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
        {metrics.map((m) => (
          <div key={m.label} className="bg-mist rounded-xl p-3">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="text-teal-600">{m.icon}</span>
              <span className="text-[10px] text-slatey/50">{m.label}</span>
            </div>
            <div className="font-display font-bold text-base text-slatey">
              {m.value != null ? m.value.toFixed(m.label === 'pH' ? 2 : 1) : '\u2014'}
              {m.unit && <span className="text-[10px] text-slatey/40 ml-1">{m.unit}</span>}
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between text-[10px] text-slatey/40 mb-3">
        <span>Source: {reading.source || 'unknown'}</span>
        <span>{new Date(reading.timestamp).toLocaleString()}</span>
      </div>

      {history.length > 1 && (
        <details className="text-xs">
          <summary className="cursor-pointer text-slatey/50 hover:text-slatey/70">
            Recent reading history ({history.length})
          </summary>
          <div className="mt-2 space-y-1.5">
            {history.slice(0, 5).map((h) => (
              <div key={h.id} className="flex items-center gap-3 bg-mist rounded-lg px-3 py-1.5">
                <span className="text-[10px] text-slatey/40 font-mono">{new Date(h.timestamp).toLocaleTimeString()}</span>
                <span className="text-slatey/60">pH {h.ph?.toFixed(2) ?? '\u2014'}</span>
                <span className="text-slatey/60">TDS {h.tds != null ? Math.round(h.tds) : '\u2014'}</span>
                <span className="text-slatey/60">NTU {h.turbidity?.toFixed(1) ?? '\u2014'}</span>
                <span className="text-slatey/60">{h.temperature?.toFixed(1) ?? '\u2014'}\u00b0C</span>
              </div>
            ))}
          </div>
        </details>
      )}

      <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3 mt-3 border border-amber-200">
        <AlertTriangle size={12} className="text-amber-500 flex-shrink-0 mt-0.5" />
        <p className="text-[10px] text-amber-800 leading-relaxed">
          These are raw sensor measurements from the AquaSense prototype, not certified laboratory results.
          They help understand water quality but do not certify water as safe for drinking.
          Appropriate treatment and professional testing are required before determining safe use.
        </p>
      </div>
    </div>
  );
}

function RetestModal({ passport, onClose, onRetest }: {
  passport: WaterPassport;
  onClose: () => void;
  onRetest: (treatment: string, verified: boolean) => void;
}) {
  const [treatment, setTreatment] = useState('');
  const [verified, setVerified] = useState(true);

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ocean-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md animate-fade-slide">
        <div className="card p-6">
          <h2 className="font-display font-bold text-lg text-slatey mb-4 flex items-center gap-2">
            <RefreshCw size={18} className="text-aqua-600" /> Retest Water Sample
          </h2>
          <p className="text-xs text-slatey/50 mb-4">Record a retest for {passport.waterId} — {passport.source}</p>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-medium text-slatey/60 block mb-1.5">Treatment Applied</label>
              <input
                type="text"
                value={treatment}
                onChange={(e) => setTreatment(e.target.value)}
                placeholder="e.g. Filtration + UV"
                className="w-full px-3 py-2 rounded-lg border border-softgrey bg-white text-sm text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slatey/60 block mb-2">Retest Result</label>
              <div className="flex gap-2">
                <button
                  onClick={() => setVerified(true)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${verified ? 'bg-teal-100 text-teal-700 border-2 border-teal-300' : 'bg-mist text-slatey/50 border border-softgrey'}`}
                >
                  <CheckCircle size={14} className="inline mr-1" /> Verified
                </button>
                <button
                  onClick={() => setVerified(false)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${!verified ? 'bg-amber-100 text-amber-700 border-2 border-amber-300' : 'bg-mist text-slatey/50 border border-softgrey'}`}
                >
                  <AlertCircle size={14} className="inline mr-1" /> Not Verified
                </button>
              </div>
            </div>
          </div>

          <div className="flex gap-3 mt-5">
            <button onClick={onClose} className="btn-secondary text-sm flex-1">Cancel</button>
            <button
              onClick={() => onRetest(treatment || 'Not specified', verified)}
              className="btn-primary text-sm flex-1 flex items-center justify-center gap-2"
            >
              <RefreshCw size={14} /> Record Retest
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
