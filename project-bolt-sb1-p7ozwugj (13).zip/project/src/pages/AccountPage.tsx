import { useState } from 'react';
import {
  UserCircle, Mail, Lock, Shield, Bell, Globe, Clock, Palette,
  Save, Check, ArrowLeft, Camera, MapPin, Phone, Sparkles,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { type PageId } from '@/components/Navigation';

interface AccountPageProps {
  onNavigate: (page: PageId) => void;
}

export function AccountPage({ onNavigate }: AccountPageProps) {
  const { user, signOut } = useAuth();

  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [phone, setPhone] = useState('');
  const [language, setLanguage] = useState('English');
  const [timezone, setTimezone] = useState('GMT+4 (UAE)');
  const [dateFormat, setDateFormat] = useState('DD/MM/YYYY');
  const [theme, setTheme] = useState('light');
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifPush, setNotifPush] = useState(false);
  const [notifInApp, setNotifInApp] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  if (!user) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slatey/60 mb-4">Please sign in to view your account.</p>
          <button onClick={() => onNavigate('home')} className="btn-primary">Back to Home</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-b from-ocean-50 via-mist to-mist">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-sm text-slatey/50 hover:text-ocean-600 transition-colors"
          >
            <ArrowLeft size={16} /> Back to Home
          </button>
        </div>

        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-ocean-500 to-aqua-400 flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4 shadow-float">
            {user.email.slice(0, 2).toUpperCase()}
          </div>
          <h1 className="font-display font-bold text-2xl text-ocean-600">Account Settings</h1>
          <p className="text-sm text-slatey/60 mt-1">{user.email}</p>
          {user.isDemo && (
            <span className="inline-block mt-2 text-xs font-bold text-amber-600 bg-amber-100 px-3 py-1 rounded-full">DEMO ACCOUNT</span>
          )}
        </div>

        {/* Core Personal Information */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <UserCircle size={20} className="text-ocean-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Core Personal Information</h2>
          </div>

          <div className="space-y-4">
            {/* Avatar */}
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-ocean-500 to-aqua-400 flex items-center justify-center text-white text-xl font-bold shadow-soft">
                {user.email.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <button className="text-sm text-aqua-600 hover:text-aqua-700 font-medium flex items-center gap-2">
                  <Camera size={14} /> Change avatar
                </button>
                <p className="text-xs text-slatey/40 mt-1">Optional — your initials are used by default</p>
              </div>
            </div>

            {/* Name */}
            <div>
              <label className="text-sm font-medium text-slatey/70 block mb-1.5">Name or Username</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your display name"
                className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
              />
            </div>

            {/* Bio */}
            <div>
              <label className="text-sm font-medium text-slatey/70 block mb-1.5">Bio or Description</label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="A short summary about you (optional)"
                rows={3}
                className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all resize-none"
              />
            </div>

            {/* Contact info */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5">
                  <Mail size={14} /> Email
                </label>
                <input
                  type="email"
                  value={user.email}
                  disabled
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-mist text-slatey/60 cursor-not-allowed"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5">
                  <Phone size={14} /> Phone
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+971 50 000 0000 (optional)"
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Login & Security */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Lock size={20} className="text-ocean-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Login & Security</h2>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 bg-mist rounded-xl">
              <div className="flex items-center gap-3">
                <Mail size={18} className="text-slatey/50" />
                <div>
                  <p className="text-sm font-medium text-slatey">Email / Username</p>
                  <p className="text-xs text-slatey/50">{user.email}</p>
                </div>
              </div>
              <button className="text-sm text-aqua-600 hover:text-aqua-700 font-medium">Manage</button>
            </div>

            <div className="flex items-center justify-between p-4 bg-mist rounded-xl">
              <div className="flex items-center gap-3">
                <Lock size={18} className="text-slatey/50" />
                <div>
                  <p className="text-sm font-medium text-slatey">Password</p>
                  <p className="text-xs text-slatey/50">Change your password</p>
                </div>
              </div>
              <button className="text-sm text-aqua-600 hover:text-aqua-700 font-medium">Change</button>
            </div>

            <div className="flex items-center justify-between p-4 bg-mist rounded-xl">
              <div className="flex items-center gap-3">
                <Shield size={18} className="text-slatey/50" />
                <div>
                  <p className="text-sm font-medium text-slatey">Two-Factor Authentication (2FA)</p>
                  <p className="text-xs text-slatey/50">Extra security for your account</p>
                </div>
              </div>
              <span className="text-xs font-medium text-amber-600 bg-amber-100 px-2.5 py-1 rounded-full">Coming Soon</span>
            </div>
          </div>
        </section>

        {/* Preferences & Regional Settings */}
        <section className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Globe size={20} className="text-ocean-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Preferences & Regional Settings</h2>
          </div>

          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5">
                  <Globe size={14} /> Language
                </label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
                >
                  <option>English</option>
                  <option>Arabic</option>
                  <option>Hindi</option>
                  <option>Urdu</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5">
                  <Clock size={14} /> Time Zone
                </label>
                <select
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
                >
                  <option>GMT+4 (UAE)</option>
                  <option>GMT+3 (KSA)</option>
                  <option>GMT+5:30 (India)</option>
                  <option>GMT+0 (UTC)</option>
                </select>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5">Date Format</label>
                <select
                  value={dateFormat}
                  onChange={(e) => setDateFormat(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400 transition-all"
                >
                  <option>DD/MM/YYYY</option>
                  <option>MM/DD/YYYY</option>
                  <option>YYYY-MM-DD</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1.5">
                  <Palette size={14} /> Theme / Appearance
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setTheme('light')}
                    className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${theme === 'light' ? 'bg-ocean-600 text-white' : 'bg-mist text-slatey/60'}`}
                  >
                    Light
                  </button>
                  <button
                    onClick={() => setTheme('dark')}
                    className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${theme === 'dark' ? 'bg-ocean-600 text-white' : 'bg-mist text-slatey/60'}`}
                  >
                    Dark
                  </button>
                </div>
              </div>
            </div>

            {/* Notifications */}
            <div>
              <label className="text-sm font-medium text-slatey/70 block mb-2 flex items-center gap-1.5">
                <Bell size={14} /> Notification Preferences
              </label>
              <div className="space-y-2">
                <ToggleRow label="Email notifications" checked={notifEmail} onChange={setNotifEmail} />
                <ToggleRow label="Push notifications" checked={notifPush} onChange={setNotifPush} />
                <ToggleRow label="In-app alerts" checked={notifInApp} onChange={setNotifInApp} />
              </div>
            </div>
          </div>
        </section>

        {/* Save button */}
        <div className="flex items-center justify-between gap-3 mb-6">
          <button
            onClick={() => signOut()}
            className="flex items-center gap-2 text-sm text-coral-500 hover:text-coral-600 font-medium"
          >
            <ArrowLeft size={16} className="rotate-90" /> Sign Out
          </button>
          <button
            onClick={handleSave}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium transition-all ${saved ? 'bg-teal-400 text-white' : 'btn-primary'}`}
          >
            {saved ? <><Check size={16} /> Saved</> : <><Save size={16} /> Save Changes</>}
          </button>
        </div>

        {/* Demo data note */}
        {user.isDemo && (
          <div className="card p-5 bg-amber-50 border-amber-200">
            <div className="flex items-start gap-3">
              <Sparkles size={18} className="text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-800">Demo Account</p>
                <p className="text-xs text-amber-700 mt-1">
                  You are using a demo account. Changes to profile settings are not permanently saved.
                  Demo Water Passports and water testing data are labeled as DEMO DATA throughout the platform.
                </p>
              </div>
            </div>
          </div>
        )}

        <p className="text-xs text-slatey/40 text-center mt-6">
          ReWater is a screening prototype. Profile settings are stored locally in this demo.
        </p>
      </div>
    </div>
  );
}

function ToggleRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between p-3 bg-mist rounded-xl">
      <span className="text-sm text-slatey/70">{label}</span>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-all ${checked ? 'bg-aqua-400' : 'bg-softgrey'}`}
        aria-label={`Toggle ${label}`}
      >
        <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-soft transition-all ${checked ? 'left-5.5' : 'left-0.5'}`} style={{ left: checked ? '22px' : '2px' }} />
      </button>
    </div>
  );
}
