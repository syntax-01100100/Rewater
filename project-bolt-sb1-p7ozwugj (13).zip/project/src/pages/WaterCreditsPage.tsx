import { useState, useEffect, useCallback } from 'react';
import {
  Sparkles, Droplets, Recycle, HandHeart, Users, ArrowLeft,
  Info, ArrowRight, Beaker, ChevronDown, ChevronUp,
  Droplet, ShieldCheck, Building2, Plus, Wallet, History,
  TrendingUp, Coins, FlaskConical, BadgeCheck, Target, AlertCircle,
} from 'lucide-react';
import { useWaterPassport, type WaterPassport, passportStatusLabel, type PassportStatus } from '@/lib/waterPassport';
import { useAuth } from '@/lib/auth';
import { type PageId } from '@/components/Navigation';
import { supabase, type HydroStation, type WaterCreditTransaction } from '@/lib/supabase';
import {
  fetchCreditTransactions, recordCreditTransaction, CREDIT_LABEL, CREDIT_CONFIG,
  calculateCredits, calculateRecoveryRate, calculateCreditEligible,
  generateCreditsFromPassport,
  type CreditBalance, fetchCreditBalance,
} from '@/lib/waterCredits';

interface WaterCreditsPageProps {
  onNavigate: (page: PageId) => void;
}

function getLitres(passport: WaterPassport): number {
  if (passport.inputWaterLitres != null) return passport.inputWaterLitres;
  if (!passport.quantity || passport.quantity <= 0) return 0;
  if (passport.unit === 'mL') return passport.quantity / 1000;
  if (passport.unit === 'm³' || passport.unit === 'm3') return passport.quantity * 1000;
  return passport.quantity;
}

function getRecoveredLitres(passport: WaterPassport): number {
  if (passport.recoveredWaterLitres != null) return passport.recoveredWaterLitres;
  return 0;
}

function isPassportActive(p: WaterPassport): boolean {
  return p.reuseHistory.length > 0 || p.recoveryHistory.length > 0 ||
    p.currentStage === 'treated' || p.currentStage === 'verified' || p.currentStage === 'reuse_pathway';
}

function getPassportStatus(p: WaterPassport): PassportStatus {
  if (p.currentStage === 'verified' || p.currentStage === 'reuse_pathway') return 'completed';
  if (p.currentStage === 'retest_required') return 'awaiting_retest';
  if (p.currentStage === 'not_verified') return 'treatment_required';
  return 'ongoing';
}

function isPassportVerified(p: WaterPassport): boolean {
  return p.currentStage === 'verified' || p.currentStage === 'reuse_pathway';
}

function PassportRecoveryCard({ passport }: { passport: WaterPassport }) {
  const inputL = getLitres(passport);
  const recoveredL = getRecoveredLitres(passport);
  const lossL = passport.treatmentLossLitres ?? (inputL > 0 && recoveredL > 0 ? inputL - recoveredL : 0);
  const rate = passport.recoveryRate ?? (inputL > 0 ? calculateRecoveryRate(inputL, recoveredL) : 0);
  const isActive = isPassportActive(passport);
  const status = getPassportStatus(passport);

  return (
    <div className="card p-5 mb-4">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-aqua-50 flex items-center justify-center text-aqua-600 flex-shrink-0">
            <Droplets size={20} />
          </div>
          <div>
            <p className="font-semibold text-slatey">{passport.source}</p>
            <p className="text-xs text-slatey/50 font-mono">{passport.waterId} &middot; {passport.sourceType}</p>
          </div>
        </div>
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${status === 'completed' ? 'bg-teal-100 text-teal-700' : status === 'treatment_required' ? 'bg-coral-100 text-coral-700' : status === 'awaiting_retest' ? 'bg-amber-100 text-amber-700' : 'bg-aqua-100 text-aqua-700'}`}>
          {passportStatusLabel(status)}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-ocean-50 rounded-xl p-3 text-center">
          <p className="font-display font-bold text-base text-ocean-700">{inputL > 0 ? `${inputL.toLocaleString()} L` : '—'}</p>
          <p className="text-xs text-ocean-600/70">Wastewater Input</p>
        </div>
        <div className="bg-teal-50 rounded-xl p-3 text-center">
          <p className="font-display font-bold text-base text-teal-700">{recoveredL > 0 ? `${recoveredL.toLocaleString()} L` : '—'}</p>
          <p className="text-xs text-teal-600/70">Water Recovered</p>
        </div>
        <div className="bg-coral-50 rounded-xl p-3 text-center">
          <p className="font-display font-bold text-base text-coral-700">{lossL > 0 ? `${lossL.toLocaleString()} L` : '—'}</p>
          <p className="text-xs text-coral-600/70">Treatment Loss</p>
        </div>
        <div className="bg-aqua-50 rounded-xl p-3 text-center">
          <p className="font-display font-bold text-base text-aqua-700">{rate > 0 ? `${rate.toFixed(1)}%` : '—'}</p>
          <p className="text-xs text-aqua-600/70">Recovery Rate</p>
        </div>
      </div>

      {passport.treatmentPartner && (
        <div className="flex items-center gap-2 mt-3 text-xs">
          <FlaskConical size={12} className="text-slatey/40" />
          <span className="text-slatey/50">Treatment: <span className="font-medium text-slatey/70">{passport.treatmentPartner}</span></span>
          {passport.verificationPartner && (
            <>
              <BadgeCheck size={12} className="text-slatey/40 ml-2" />
              <span className="text-slatey/50">Verification: <span className="font-medium text-slatey/70">{passport.verificationPartner}</span></span>
            </>
          )}
        </div>
      )}

      {passport.creditsGenerated != null && passport.creditsGenerated > 0 && (
        <div className="flex items-center gap-2 mt-3 bg-teal-50 rounded-lg px-3 py-2">
          <Coins size={14} className="text-teal-600" />
          <span className="text-xs text-teal-700 font-medium">{passport.creditsGenerated} Credits generated from this passport</span>
          {passport.creditEligibleLitres != null && (
            <span className="text-xs text-teal-600/70 ml-1">({passport.creditEligibleLitres.toFixed(1)} L credit-eligible)</span>
          )}
        </div>
      )}

      <div className="flex items-start gap-2 bg-amber-50 rounded-lg p-3 mt-3">
        <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-700 leading-relaxed">
          <span className="font-medium">Recovered water ≠ drinking water.</span> The {recoveredL.toLocaleString()} L recovered is recorded as an environmental metric only.
          Drinking water at a HydroStation comes from a separately verified safe supply.
        </p>
      </div>
    </div>
  );
}

function CreditHistoryItem({ tx }: { tx: WaterCreditTransaction }) {
  const isPositive = tx.transaction_type === 'earned' || tx.transaction_type === 'donated';
  const icon = tx.transaction_type === 'earned' ? <Coins size={16} /> :
    tx.transaction_type === 'donated' ? <HandHeart size={16} /> :
    tx.transaction_type === 'assigned' ? <Building2 size={16} /> :
    <Droplet size={16} />;
  const label = tx.transaction_type === 'earned' ? 'Credits Generated' :
    tx.transaction_type === 'donated' ? 'Credit Donation' :
    tx.transaction_type === 'assigned' ? 'Station Sponsorship' :
    'HydroStation Dispensing';

  return (
    <div className="p-3 bg-mist rounded-xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${isPositive ? 'bg-teal-50 text-teal-600' : 'bg-aqua-50 text-aqua-600'}`}>
            {icon}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-slatey truncate">{label}</p>
            <p className="text-xs text-slatey/50 truncate">{tx.description}</p>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <p className={`text-sm font-bold ${isPositive ? 'text-teal-600' : 'text-aqua-600'}`}>
            {isPositive ? '+' : '-'}{tx.amount} Credits
          </p>
          <p className="text-xs text-slatey/40">Bal: {tx.balance_after}</p>
        </div>
      </div>
      <div className="flex flex-wrap gap-2 mt-2 ml-12">
        {tx.sponsor && (
          <span className="text-xs bg-ocean-50 text-ocean-700 px-2 py-0.5 rounded-full flex items-center gap-1">
            <Building2 size={10} /> {tx.sponsor}
          </span>
        )}
        {tx.treatment_partner && (
          <span className="text-xs bg-aqua-50 text-aqua-700 px-2 py-0.5 rounded-full flex items-center gap-1">
            <FlaskConical size={10} /> {tx.treatment_partner}
          </span>
        )}
        {tx.verification_partner && (
          <span className="text-xs bg-teal-50 text-teal-700 px-2 py-0.5 rounded-full flex items-center gap-1">
            <BadgeCheck size={10} /> {tx.verification_partner}
          </span>
        )}
        {tx.station_name && (
          <span className="text-xs bg-mist text-slatey/60 px-2 py-0.5 rounded-full flex items-center gap-1">
            <Droplet size={10} /> {tx.station_name}
          </span>
        )}
        {tx.net_benefit_aed != null && (
          <span className="text-xs bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">
            Net: AED {tx.net_benefit_aed}
          </span>
        )}
        {tx.purpose && (
          <span className="text-xs text-slatey/40 px-2 py-0.5">{tx.purpose}</span>
        )}
      </div>
    </div>
  );
}

function CreditGenerationModal({ passport, stations, user, onClose, onComplete, updatePassport, onNavigate }: {
  passport: WaterPassport;
  stations: HydroStation[];
  user: { id: string; email: string; isDemo: boolean };
  onClose: () => void;
  onComplete: () => void;
  updatePassport: (id: string, updates: Partial<WaterPassport>) => void;
  onNavigate: (page: PageId) => void;
}) {
  const inputL = getLitres(passport);
  const [recoveredL, setRecoveredL] = useState(Math.round(inputL * 0.85));
  const [treatmentPartner, setTreatmentPartner] = useState('ReWater Treatment Partner');
  const [verificationPartner, setVerificationPartner] = useState('ReWater Verification Lab');
  const [selectedStationId, setSelectedStationId] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<{ credits: number; stationName: string | null } | null>(null);

  useEffect(() => {
    if (stations.length > 0) setSelectedStationId(stations[0].id);
  }, [stations]);

  const lossL = inputL - recoveredL;
  const rate = calculateRecoveryRate(inputL, recoveredL);
  const creditEligible = calculateCreditEligible(recoveredL);
  const credits = calculateCredits(recoveredL).creditsGenerated;

  const handleSubmit = async () => {
    if (inputL <= 0 || recoveredL <= 0 || !treatmentPartner || !verificationPartner) return;
    setSubmitting(true);
    setError(null);
    const station = stations.find(s => s.id === selectedStationId);
    const result = await generateCreditsFromPassport({
      userId: user.id,
      passportId: passport.waterId,
      inputLitres: inputL,
      recoveredLitres: recoveredL,
      sponsor: user.isDemo ? 'Demo Company' : user.email,
      treatmentPartner,
      verificationPartner,
      stationId: selectedStationId || null,
      stationName: station?.name || null,
      initiative: station?.supported_initiative || null,
    });
    if (!result) {
      setError('Failed to generate credits. Please try again — check the console for details.');
      setSubmitting(false);
      return;
    }
    updatePassport(passport.waterId, {
      inputWaterLitres: inputL,
      recoveredWaterLitres: recoveredL,
      treatmentLossLitres: inputL - recoveredL,
      recoveryRate: result.recoveryRate,
      treatmentPartner,
      verificationPartner,
      creditEligibleLitres: result.creditEligibleLitres,
      creditsGenerated: result.creditsGenerated,
    });
    setSubmitting(false);
    onComplete();
    setSuccess({ credits: result.creditsGenerated, stationName: station?.name || null });
  };

  if (success) {
    return (
      <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-ocean-900/40 backdrop-blur-sm" onClick={onClose} />
        <div className="relative card max-w-lg w-full p-6 animate-fade-slide text-center">
          <div className="w-16 h-16 rounded-2xl bg-teal-50 flex items-center justify-center text-teal-500 mx-auto mb-4">
            <BadgeCheck size={32} />
          </div>
          <h2 className="font-display font-bold text-xl text-slatey mb-2">Credits Generated!</h2>
          <p className="text-sm text-slatey/60 mb-1">
            <span className="font-display font-bold text-teal-700">{success.credits.toFixed(2)}</span> Water Credits have been added to your balance.
          </p>
          {success.stationName && (
            <p className="text-xs text-slatey/50 mb-4">
              Credits assigned to <span className="font-medium text-slatey/70">{success.stationName}</span>
            </p>
          )}
          <div className="space-y-2 mt-6">
            <button onClick={() => { onClose(); onNavigate('hydro-stations'); }}
              className="btn-aqua w-full inline-flex items-center justify-center gap-2">
              <Droplet size={16} /> Go to HydroStations
            </button>
            <button onClick={onClose}
              className="w-full text-sm text-slatey/50 hover:text-slatey transition-colors py-2">
              Stay on Water Credits
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ocean-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card max-w-lg w-full p-6 animate-fade-slide max-h-[85vh] overflow-y-auto">
        <h2 className="font-display font-bold text-xl text-slatey mb-1 flex items-center gap-2">
          <Sparkles size={20} className="text-aqua-600" /> Generate Water Credits
        </h2>
        <p className="text-xs text-slatey/50 mb-4">
          Passport <span className="font-mono">{passport.waterId}</span> — {inputL.toLocaleString()} L wastewater input verified.
        </p>

        {/* Water flow */}
        <div className="bg-ocean-50 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between text-xs font-medium">
            <div className="text-center">
              <p className="text-ocean-700 font-bold">{inputL.toLocaleString()} L</p>
              <p className="text-ocean-600/70">Input</p>
            </div>
            <ArrowRight size={14} className="text-slatey/30" />
            <div className="text-center">
              <p className="text-aqua-700 font-bold">{recoveredL.toLocaleString()} L</p>
              <p className="text-aqua-600/70">Recovered</p>
            </div>
            <ArrowRight size={14} className="text-slatey/30" />
            <div className="text-center">
              <p className="text-coral-700 font-bold">{lossL.toLocaleString()} L</p>
              <p className="text-coral-600/70">Loss</p>
            </div>
            <ArrowRight size={14} className="text-slatey/30" />
            <div className="text-center">
              <p className="text-teal-700 font-bold">{rate.toFixed(1)}%</p>
              <p className="text-teal-600/70">Rate</p>
            </div>
          </div>
        </div>

        {/* Recovered water input */}
        <div className="mb-4">
          <label className="text-sm font-medium text-slatey/70 block mb-1.5">Recovered Water (Litres)</label>
          <input type="number" min="0" max={inputL} value={recoveredL}
            onChange={e => setRecoveredL(Math.min(inputL, Math.max(0, parseFloat(e.target.value) || 0)))}
            className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400" />
          <p className="text-xs text-slatey/50 mt-1">Treatment loss: {lossL.toLocaleString()} L ({(100 - rate).toFixed(1)}%)</p>
        </div>

        {/* Partners */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1"><FlaskConical size={12} /> Treatment Partner</label>
            <input type="text" value={treatmentPartner} onChange={e => setTreatmentPartner(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-softgrey bg-white text-slatey text-sm focus:outline-none focus:ring-2 focus:ring-aqua-400" />
          </div>
          <div>
            <label className="text-sm font-medium text-slatey/70 block mb-1.5 flex items-center gap-1"><BadgeCheck size={12} /> Verification Partner</label>
            <input type="text" value={verificationPartner} onChange={e => setVerificationPartner(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-softgrey bg-white text-slatey text-sm focus:outline-none focus:ring-2 focus:ring-aqua-400" />
          </div>
        </div>

        {/* Credit-eligible + credits */}
        <div className="bg-gradient-to-br from-aqua-50 to-teal-50 rounded-xl p-4 mb-4">
          <p className="text-xs font-semibold text-slatey mb-3">Credit Calculation (Prototype Partnership Model)</p>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slatey/60">Recovered Water</span>
              <span className="font-bold text-slatey">{recoveredL.toLocaleString()} L</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slatey/60">Partnership Share ({Math.round(CREDIT_CONFIG.partnershipShare * 100)}%)</span>
              <span className="font-bold text-teal-700">{creditEligible.toFixed(1)} L credit-eligible</span>
            </div>
            <div className="border-t border-aqua-100 pt-2 flex justify-between">
              <span className="text-sm font-semibold text-slatey">Water Credits Generated</span>
              <span className="font-display font-bold text-lg text-teal-700">{credits.toFixed(2)}</span>
            </div>
            <p className="text-xs text-slatey/50 pt-1">{creditEligible.toFixed(1)} L ÷ {CREDIT_CONFIG.creditUnitSizeLitres} L = {credits.toFixed(2)} credits</p>
          </div>
        </div>

        {/* Station assignment */}
        <div className="mb-4">
          <label className="text-sm font-medium text-slatey/70 block mb-1.5">Assign to HydroStation</label>
          {stations.length === 0 ? (
            <p className="text-xs text-slatey/40 bg-mist rounded-lg p-3">No HydroStations yet. Create one first on the HydroStations page.</p>
          ) : (
            <select value={selectedStationId} onChange={e => setSelectedStationId(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-softgrey bg-white text-slatey focus:outline-none focus:ring-2 focus:ring-aqua-400">
              {stations.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.station_id})</option>
              ))}
            </select>
          )}
        </div>

        {error && (
          <div className="flex items-start gap-2 bg-coral-50 rounded-xl p-3 mb-4">
            <AlertCircle size={14} className="text-coral-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-coral-700">{error}</p>
          </div>
        )}

        <button onClick={handleSubmit} disabled={submitting || inputL <= 0 || recoveredL <= 0 || !treatmentPartner || !verificationPartner}
          className="btn-aqua w-full disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2">
          {submitting ? 'Processing...' : <><Plus size={16} /> Generate {credits.toFixed(2)} Credits</>}
        </button>
      </div>
    </div>
  );
}

export function WaterCreditsPage({ onNavigate }: WaterCreditsPageProps) {
  const { user } = useAuth();
  const { passports, loading: passportsLoading, updatePassport } = useWaterPassport();
  const [transactions, setTransactions] = useState<WaterCreditTransaction[]>([]);
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [stations, setStations] = useState<HydroStation[]>([]);
  const [showGeneration, setShowGeneration] = useState<WaterPassport | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    const [txns, bal, { data: stationData }] = await Promise.all([
      fetchCreditTransactions(user.id),
      fetchCreditBalance(user.id),
      supabase.from('hydro_stations').select('*').order('created_at', { ascending: false }),
    ]);
    setTransactions(txns);
    setBalance(bal);
    setStations(stationData || []);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const totalWaterInput = passports.reduce((sum, p) => sum + (isPassportActive(p) ? getLitres(p) : 0), 0);
  const totalWaterRecovered = passports.reduce((sum, p) => sum + (isPassportActive(p) ? getRecoveredLitres(p) : 0), 0);
  const totalWaterLoss = passports.reduce((sum, p) => {
    const inputL = getLitres(p);
    const recoveredL = getRecoveredLitres(p);
    return sum + (inputL > 0 && recoveredL > 0 ? inputL - recoveredL : 0);
  }, 0);
  const overallRate = totalWaterInput > 0 ? (totalWaterRecovered / totalWaterInput) * 100 : 0;

  const totalLitresDispensed = stations.reduce((s, st) => s + st.total_litres_dispensed, 0);

  if (!user) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slatey/60 mb-4">Please sign in to view your Water Credits.</p>
          <button onClick={() => onNavigate('home')} className="btn-primary">Back to Home</button>
        </div>
      </div>
    );
  }

  if (passportsLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-slatey/40">Loading...</div>
      </div>
    );
  }

  const currentBalance = balance?.current ?? 0;

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-b from-aqua-50 via-mist to-mist">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <button onClick={() => onNavigate('passport')}
          className="flex items-center gap-2 text-sm text-slatey/50 hover:text-ocean-600 transition-colors mb-6">
          <ArrowLeft size={16} /> Back to Water Passport
        </button>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-aqua-500 to-teal-400 flex items-center justify-center text-white mx-auto mb-4 shadow-float">
            <Sparkles size={36} />
          </div>
          <h1 className="font-display font-bold text-3xl text-ocean-600">Water Credits</h1>
          <p className="text-sm text-slatey/60 mt-2 max-w-lg mx-auto">
            Water Credits represent sponsor-funded contributions to HydroStation hydration initiatives.
            Water recovered and Water Credits are tracked independently.
          </p>
          <span className="inline-block mt-3 text-xs font-bold text-amber-600 bg-amber-100 px-3 py-1 rounded-full">
            PROTOTYPE ACCOUNTING MODEL
          </span>
        </div>

        {/* Complete flow visualization */}
        <div className="card p-5 mb-6">
          <p className="text-sm font-semibold text-slatey mb-3">The Complete Water Credit Flow</p>
          <div className="flex flex-wrap items-center gap-1.5 mb-4">
            {[
              { label: 'Wastewater', icon: <Droplets size={14} />, color: 'ocean' },
              { label: 'Treat', icon: <FlaskConical size={14} />, color: 'aqua' },
              { label: 'Recover', icon: <Recycle size={14} />, color: 'teal' },
              { label: 'Verified', icon: <ShieldCheck size={14} />, color: 'teal' },
              { label: 'Net Benefit', icon: <TrendingUp size={14} />, color: 'amber' },
              { label: 'Company', icon: <Building2 size={14} />, color: 'ocean' },
              { label: 'HydroStation', icon: <Droplet size={14} />, color: 'aqua' },
              { label: 'ReWater', icon: <Sparkles size={14} />, color: 'teal' },
              { label: 'Credits', icon: <Coins size={14} />, color: 'aqua' },
              { label: 'Impact', icon: <Target size={14} />, color: 'teal' },
            ].map((s, i) => (
              <div key={s.label} className="flex items-center gap-1.5">
                <div className={`flex items-center gap-1 bg-${s.color}-50 rounded-lg px-2.5 py-1.5`}>
                  <span className={`text-${s.color}-600`}>{s.icon}</span>
                  <span className="text-xs font-medium text-slatey">{s.label}</span>
                </div>
                {i < 9 && <ArrowRight size={10} className="text-slatey/30" />}
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-3">
            <div className="flex items-center gap-2 bg-aqua-50 rounded-lg px-3 py-2">
              <Sparkles size={14} className="text-aqua-500" />
              <span className="text-xs text-aqua-700">1 Credit = {CREDIT_CONFIG.creditUnitSizeLitres} L credit-eligible water</span>
            </div>
            <div className="flex items-center gap-2 bg-teal-50 rounded-lg px-3 py-2">
              <Droplets size={14} className="text-teal-500" />
              <span className="text-xs text-teal-700">Litres recovered tracked separately</span>
            </div>
            <div className="flex items-center gap-2 bg-amber-50 rounded-lg px-3 py-2">
              <Info size={14} className="text-amber-500" />
              <span className="text-xs text-amber-700">Recovered water ≠ drinking water</span>
            </div>
          </div>
        </div>

        {/* Two independent metrics — side by side */}
        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          {/* Environmental metric */}
          <div className="card p-5 bg-gradient-to-br from-ocean-600 to-aqua-600 text-white">
            <div className="flex items-center gap-2 mb-3">
              <Droplets size={20} />
              <h2 className="font-display font-semibold text-sm">Water Recovery (Environmental)</h2>
            </div>
            <p className="font-display font-bold text-3xl">{totalWaterRecovered > 0 ? `${totalWaterRecovered.toLocaleString()} L` : '0 L'}</p>
            <p className="text-xs text-white/70 mt-1">Total Water Recovered</p>
            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-white/20">
              <div>
                <p className="font-display font-bold text-sm">{totalWaterInput > 0 ? `${totalWaterInput.toLocaleString()} L` : '0 L'}</p>
                <p className="text-xs text-white/70">Input</p>
              </div>
              <div>
                <p className="font-display font-bold text-sm">{totalWaterLoss > 0 ? `${totalWaterLoss.toLocaleString()} L` : '0 L'}</p>
                <p className="text-xs text-white/70">Loss</p>
              </div>
              <div>
                <p className="font-display font-bold text-sm">{overallRate > 0 ? `${overallRate.toFixed(1)}%` : '—'}</p>
                <p className="text-xs text-white/70">Rate</p>
              </div>
            </div>
          </div>

          {/* Sponsorship metric */}
          <div className="card p-5 bg-gradient-to-br from-teal-500 to-aqua-500 text-white">
            <div className="flex items-center gap-2 mb-3">
              <Wallet size={20} />
              <h2 className="font-display font-semibold text-sm">Water Credits (Sponsorship)</h2>
            </div>
            <p className="font-display font-bold text-3xl">{currentBalance.toFixed(2)}</p>
            <p className="text-xs text-white/70 mt-1">Current Balance</p>
            <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-white/20">
              <div>
                <p className="font-display font-bold text-lg">{(balance?.earned ?? 0).toFixed(0)}</p>
                <p className="text-xs text-white/70">Credits Earned</p>
              </div>
              <div>
                <p className="font-display font-bold text-lg">{(balance?.used ?? 0).toFixed(2)}</p>
                <p className="text-xs text-white/70">Credits Used</p>
              </div>
            </div>
          </div>
        </div>

        {/* Prototype accounting label */}
        <div className="card p-4 mb-6 bg-amber-50 border-amber-100">
          <div className="flex items-start gap-3">
            <Info size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-amber-800 mb-1">Prototype Partnership Model</p>
              <p className="text-xs text-amber-700 leading-relaxed">
                {CREDIT_LABEL}. Credits are only generated after water has completed an eligible treatment, recovery, or reuse pathway — not from quantity alone.
                The partnership share ({Math.round(CREDIT_CONFIG.partnershipShare * 100)}%) and credit unit size ({CREDIT_CONFIG.creditUnitSizeLitres} L) are configurable prototype assumptions.
              </p>
            </div>
          </div>
        </div>

        {/* Credit History */}
        <div className="card p-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <History size={20} className="text-aqua-600" />
              <h2 className="font-display font-semibold text-lg text-slatey">Credit History</h2>
            </div>
            <button onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-1 text-xs text-aqua-600 font-medium">
              {showHistory ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              {showHistory ? 'Hide' : 'Show'}
            </button>
          </div>

          {transactions.length === 0 ? (
            <div className="text-center py-6">
              <Wallet size={28} className="mx-auto text-slatey/30 mb-2" />
              <p className="text-xs text-slatey/50">No credit transactions yet. Generate credits from a verified Water Passport.</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                <div className="bg-teal-50 rounded-xl p-3 text-center">
                  <TrendingUp size={16} className="mx-auto text-teal-500 mb-1" />
                  <p className="font-display font-bold text-sm text-teal-700">+{(balance?.earned ?? 0).toFixed(0)}</p>
                  <p className="text-xs text-teal-600/70">Earned</p>
                </div>
                <div className="bg-aqua-50 rounded-xl p-3 text-center">
                  <Building2 size={16} className="mx-auto text-aqua-500 mb-1" />
                  <p className="font-display font-bold text-sm text-aqua-700">-{(balance?.assigned ?? 0).toFixed(0)}</p>
                  <p className="text-xs text-aqua-600/70">Assigned</p>
                </div>
                <div className="bg-ocean-50 rounded-xl p-3 text-center">
                  <Droplet size={16} className="mx-auto text-ocean-500 mb-1" />
                  <p className="font-display font-bold text-sm text-ocean-700">-{(balance?.used ?? 0).toFixed(2)}</p>
                  <p className="text-xs text-ocean-600/70">Dispensed</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-aqua-50 rounded-xl mb-4">
                <span className="text-sm font-medium text-slatey">Current Balance</span>
                <span className="font-display font-bold text-xl text-aqua-700">{currentBalance.toFixed(2)} Credits</span>
              </div>
              {showHistory && (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {transactions.map(tx => <CreditHistoryItem key={tx.id} tx={tx} />)}
                </div>
              )}
            </>
          )}
        </div>

        {/* HydroStation summary */}
        <div className="card p-5 mb-6 bg-gradient-to-br from-aqua-50 to-teal-50">
          <div className="flex items-center gap-2 mb-3">
            <Droplet size={20} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">HydroStation Impact</h2>
          </div>
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-white rounded-xl p-3 text-center">
              <p className="font-display font-bold text-lg text-slatey">{stations.length}</p>
              <p className="text-xs text-slatey/50">Stations Supported</p>
            </div>
            <div className="bg-white rounded-xl p-3 text-center">
              <p className="font-display font-bold text-lg text-teal-700">{totalLitresDispensed > 0 ? `${totalLitresDispensed.toLocaleString()} L` : '0 L'}</p>
              <p className="text-xs text-slatey/50">Drinking Water Dispensed</p>
            </div>
            <div className="bg-white rounded-xl p-3 text-center">
              <p className="font-display font-bold text-lg text-ocean-700">{stations.reduce((s, st) => s + st.total_worker_visits, 0)}</p>
              <p className="text-xs text-slatey/50">Worker Visits</p>
            </div>
          </div>
          <button onClick={() => onNavigate('hydro-stations')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors">
            <Droplet size={14} /> View HydroStations
          </button>
        </div>

        {/* Per-passport recovery breakdown */}
        <div className="mb-2">
          <h2 className="font-display font-semibold text-lg text-slatey mb-4">Water Recovery Records</h2>
          {passports.length === 0 ? (
            <div className="card p-8 text-center">
              <div className="w-16 h-16 rounded-2xl bg-aqua-50 flex items-center justify-center text-aqua-400 mx-auto mb-4">
                <Droplets size={30} />
              </div>
              <h3 className="font-display font-bold text-lg text-ocean-600 mb-2">No Water Passports Yet</h3>
              <p className="text-sm text-slatey/60 mb-5">
                Complete a water test to create your first passport. Water recovery is recorded separately from Water Credits.
              </p>
              <button onClick={() => onNavigate('check')} className="btn-aqua inline-flex items-center gap-2">
                <Beaker size={16} /> Check Water
              </button>
            </div>
          ) : (
            passports.map(p => (
              <div key={p.waterId}>
                <PassportRecoveryCard passport={p} />
                {isPassportVerified(p) && p.creditsGenerated == null && (
                  <button
                    onClick={() => setShowGeneration(p)}
                    className="btn-aqua w-full mb-4 inline-flex items-center justify-center gap-2"
                  >
                    <Plus size={16} /> Generate Credits for {p.waterId}
                  </button>
                )}
                {p.creditsGenerated != null && (
                  <div className="flex items-center justify-center gap-2 mb-4 text-xs text-teal-600 font-medium">
                    <BadgeCheck size={14} /> {p.creditsGenerated} credits already generated
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Disclaimer */}
        <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-4 mt-4">
          <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700 leading-relaxed">
            Water Credits are a prototype record-keeping concept representing sponsored HydroStation funding.
            They do not constitute legally recognized environmental credits or carbon offsets.
            Your environmental contribution (litres recovered) and your hydration funding (Water Credits) are tracked separately.
          </p>
        </div>
      </div>

      {/* Credit generation modal */}
      {showGeneration && user && (
        <CreditGenerationModal
          passport={showGeneration}
          stations={stations}
          user={user}
          onClose={() => setShowGeneration(null)}
          onComplete={loadData}
          updatePassport={updatePassport}
          onNavigate={onNavigate}
        />
      )}
    </div>
  );
}
