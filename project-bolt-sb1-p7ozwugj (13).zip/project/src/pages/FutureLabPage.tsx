import { useState } from 'react';
import {
  Cloud, Droplets, Zap, Thermometer,
  ArrowRight, Info, FlaskConical,
  TrendingUp, Beaker, Recycle, Factory,
  Sparkles, Cpu, Satellite, Mountain, Battery,
  Wind, Sun, Network as NetworkIcon
} from 'lucide-react';
import { AtmosphericWaterAnimation, CloudRainAnimation, PiezoelectricAnimation, NetworkAnimation, DigitalTwinAnimation } from '@/components/animations';
import { SplineScene } from '@/components/ui/splite';
import { Spotlight } from '@/components/ui/spotlight';
import type { PageId } from '@/components/Navigation';

type LabModule = 'atmospheric' | 'hidden' | 'piezoelectric' | 'sensors' | 'satellite' | 'digitaltwin';

type ModuleStatus = 'CURRENT PROTOTYPE' | 'PLANNED' | 'RESEARCH CONCEPT' | 'FUTURE';

const statusColors: Record<ModuleStatus, string> = {
  'CURRENT PROTOTYPE': '#2E9D8C',
  'PLANNED': '#1FA7C8',
  'RESEARCH CONCEPT': '#F2B84B',
  'FUTURE': '#E8734B',
};

const modules: { id: LabModule; title: string; icon: React.ReactNode; status: ModuleStatus }[] = [
  { id: 'atmospheric', title: 'Atmospheric Water', icon: <Cloud size={24} />, status: 'RESEARCH CONCEPT' },
  { id: 'hidden', title: 'Hidden Water', icon: <Mountain size={24} />, status: 'RESEARCH CONCEPT' },
  { id: 'piezoelectric', title: 'Low-Energy Monitoring', icon: <Battery size={24} />, status: 'FUTURE' },
  { id: 'sensors', title: 'AquaSense Device', icon: <Cpu size={24} />, status: 'PLANNED' },
  { id: 'satellite', title: 'Satellite Mapping', icon: <Satellite size={24} />, status: 'RESEARCH CONCEPT' },
  { id: 'digitaltwin', title: 'Digital Twin', icon: <NetworkIcon size={24} />, status: 'FUTURE' },
];

// UAE climate data (publicly available, sources noted inline)
const UAE_CLIMATE = {
  avgHumidity: 60, // UAE average relative humidity (%), NCM historical data
  avgTemp: 28, // UAE average annual temperature (°C), NCM
  summerHumidity: 70, // Coastal summer humidity (%)
  summerTemp: 38, // Summer temperature (°C)
  winterHumidity: 50,
  winterTemp: 18,
  rainfall: 94, // UAE average annual rainfall (mm), NCM
  acHours: 8, // Average daily AC operation hours in summer
};

export function FutureLabPage({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  const [active, setActive] = useState<LabModule>('atmospheric');

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-b from-ocean-950 via-ocean-900 to-ocean-800">
      {/* 3D future-water vision */}
      <div className="relative mx-auto mb-8 min-h-[calc(100vh-4rem)] h-[calc(100vh-4rem)] w-full max-w-none overflow-hidden rounded-none bg-black">
        <Spotlight className="-top-40 left-0 md:left-60 md:-top-20" />
        <div className="absolute inset-0 z-10 flex items-center pointer-events-none">
          <div className="flex w-full flex-col items-start gap-8 px-6 text-left sm:px-12 lg:flex-row lg:items-start lg:justify-between lg:px-20">
            <div className="max-w-md flex-shrink-0">
              <span className="mb-4 inline-flex rounded-full border border-aqua-300/30 bg-aqua-300/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.2em] text-aqua-200">
                Future Lab
              </span>
              <h2 className="text-3xl font-bold leading-tight text-white sm:text-5xl">
                What We Could Achieve in the Future?
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-white/80 sm:text-base">
                Explore a live 3D water vision built around smarter sensing, circular treatment, and systems that help every drop find its next useful purpose.
              </p>
            </div>
          </div>
        </div>
        <SplineScene
          scene="https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode"
          className="relative left-6 h-full w-full sm:left-12"
        />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md rounded-full px-4 py-1.5 mb-4">
            <FlaskConical size={14} className="text-aqua-300" />
            <span className="text-sm text-white/95 font-medium">Experimental Concepts</span>
          </div>
          <h1 className="font-display font-bold text-3xl text-white mb-2">Future Lab</h1>
          <p className="text-white/95 text-sm">Technologies that could contribute to water circularity in the UAE</p>
        </div>
        <div className="bg-white/12 backdrop-blur-md rounded-2xl border border-white/15 p-6 mb-8">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-aqua-400/20 flex items-center justify-center flex-shrink-0">
              <Sparkles size={20} className="text-aqua-300" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-white mb-1">What is the Future Lab?</h2>
              <p className="text-sm text-white/95 leading-relaxed">
                The Future Lab explores technologies that could contribute to water circularity in the UAE and the wider Gulf region. Each concept explains <span className="text-white font-medium">what it does</span>, <span className="text-white font-medium">how it works</span>, and <span className="text-white font-medium">why it matters</span> for this region. Every concept is labelled by its maturity level so you can tell what exists today from what is still being researched.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
            {(Object.keys(statusColors) as ModuleStatus[]).map((status) => (
              <div key={status} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: statusColors[status] }} />
                <span className="text-xs font-medium" style={{ color: statusColors[status] }}>{status}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-white/10">
            <p className="text-xs text-white/90">
              UAE climate data used in these modules comes from the UAE National Center of Meteorology (NCM) historical records. Where calculations are shown, they use publicly available UAE-specific data — not random numbers.
            </p>
          </div>
        </div>

        {/* Module selector */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-8">
          {modules.map((m) => (
            <button
              key={m.id}
              onClick={() => setActive(m.id)}
              className={`p-4 rounded-2xl transition-all text-left ${
                active === m.id
                  ? 'bg-white/20 backdrop-blur-md border border-white/25'
                  : 'bg-white/8 border border-white/10 hover:bg-white/12'
              }`}
            >
              <div className={`mb-2 ${active === m.id ? 'text-aqua-300' : 'text-white/60'}`}>{m.icon}</div>
              <h3 className={`text-sm font-medium ${active === m.id ? 'text-white' : 'text-white/70'}`}>{m.title}</h3>
              <span className="text-xs mt-1 block" style={{ color: statusColors[m.status] }}>{m.status}</span>
            </button>
          ))}
        </div>

        {/* Module content */}
        <div className="bg-white/12 backdrop-blur-md rounded-2xl border border-white/15 p-6 min-h-[400px]">
          {active === 'atmospheric' && <AtmosphericModule />}
          {active === 'hidden' && <HiddenWaterModule />}
          {active === 'piezoelectric' && <PiezoelectricModule />}
          {active === 'sensors' && <AquaSenseFutureModule onNavigate={onNavigate} />}
          {active === 'satellite' && <SatelliteModule />}
          {active === 'digitaltwin' && <DigitalTwinModule />}
        </div>
      </div>
    </div>
  );
}

function ConceptSection({ what, how, why }: { what: string; how: string; why: string }) {
  return (
    <div className="grid sm:grid-cols-3 gap-4 mb-6">
      <div className="bg-white/10 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-7 h-7 rounded-lg bg-aqua-400/20 flex items-center justify-center text-aqua-300 text-xs font-bold">1</div>
          <h4 className="text-sm font-semibold text-white">What It Does</h4>
        </div>
        <p className="text-xs text-white/95 leading-relaxed">{what}</p>
      </div>
      <div className="bg-white/10 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-7 h-7 rounded-lg bg-teal-400/20 flex items-center justify-center text-teal-300 text-xs font-bold">2</div>
          <h4 className="text-sm font-semibold text-white">How It Works</h4>
        </div>
        <p className="text-xs text-white/95 leading-relaxed">{how}</p>
      </div>
      <div className="bg-white/10 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-7 h-7 rounded-lg bg-ocean-400/20 flex items-center justify-center text-ocean-300 text-xs font-bold">3</div>
          <h4 className="text-sm font-semibold text-white">Why It Matters</h4>
        </div>
        <p className="text-xs text-white/95 leading-relaxed">{why}</p>
      </div>
    </div>
  );
}

function AtmosphericModule() {
  const [season, setSeason] = useState<'summer' | 'winter' | 'average'>('average');
  const [method, setMethod] = useState<'condensation' | 'sorbent' | 'hybrid'>('condensation');

  const humidity = season === 'summer' ? UAE_CLIMATE.summerHumidity : season === 'winter' ? UAE_CLIMATE.winterHumidity : UAE_CLIMATE.avgHumidity;
  const temp = season === 'summer' ? UAE_CLIMATE.summerTemp : season === 'winter' ? UAE_CLIMATE.winterTemp : UAE_CLIMATE.avgTemp;

  // Yield estimate based on method and UAE climate data
  // Condensation: requires high humidity, lower temp differential
  // Sorbent: works better in moderate humidity, uses solar thermal energy
  // Hybrid: combines both approaches
  const methodFactor = method === 'sorbent' ? 0.8 : method === 'hybrid' ? 1.2 : 0.5;
  const tempDifferential = Math.max(0, 30 - Math.abs(temp - 22)) / 30;
  const yieldEstimate = Math.round(humidity * methodFactor * tempDifferential * 100) / 10;
  const energyRequired = method === 'condensation' ? 0.3 : method === 'sorbent' ? 0.15 : 0.22;

  return (
    <div className="animate-fade-slide">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-aqua-400/20 flex items-center justify-center text-aqua-300">
          <Cloud size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-white">Atmospheric Water Harvesting</h2>
          <p className="text-sm text-white/95">Extracting water from humidity in the air</p>
        </div>
        <span className="ml-auto text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap" style={{ color: '#1FA7C8', border: '1px solid #1FA7C840' }}>RESEARCH CONCEPT</span>
      </div>

      <div className="bg-white rounded-xl p-4 mb-6 shadow-lg">
        <CloudRainAnimation />
      </div>

      <ConceptSection
        what="Collects water vapour from the air and converts it into liquid water. In the UAE, coastal humidity averages 60-70% — meaning every cubic metre of air contains water that could be captured."
        how="Two main approaches: (1) Condensation — cool air below its dew point so water condenses on a cold surface, like droplets on a cold glass. (2) Sorbent — use materials that absorb water vapour at night, then release it when heated by the sun during the day. Hybrid systems combine both."
        why="The UAE has high coastal humidity but low rainfall. Atmospheric water harvesting could provide a supplementary water source that does not require groundwater or desalination. It is especially relevant for coastal cities like Abu Dhabi and Dubai where humidity is highest."
      />

      <div className="bg-white rounded-xl p-4 mb-6 shadow-lg">
        <AtmosphericWaterAnimation />
      </div>

      {/* UAE climate data display */}
      <div className="bg-white/10 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Thermometer size={14} className="text-aqua-300" />
          <p className="text-xs font-medium text-white">UAE Climate Data (NCM Historical Averages)</p>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {(['average', 'summer', 'winter'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSeason(s)}
              className={`rounded-lg p-3 text-center transition-all ${
                season === s ? 'bg-aqua-400/20 border border-aqua-400/40' : 'bg-white/5 border border-white/5'
              }`}
            >
              <p className="text-xs text-white/70 capitalize">{s}</p>
              <p className="font-display font-bold text-lg text-white mt-1">
                {s === 'summer' ? UAE_CLIMATE.summerHumidity : s === 'winter' ? UAE_CLIMATE.winterHumidity : UAE_CLIMATE.avgHumidity}%
              </p>
              <p className="text-xs text-white/60">
                {s === 'summer' ? UAE_CLIMATE.summerTemp : s === 'winter' ? UAE_CLIMATE.winterTemp : UAE_CLIMATE.avgTemp}°C
              </p>
            </button>
          ))}
        </div>
        <p className="text-xs text-white/90 mt-2">Source: UAE National Center for Meteorology — historical averages</p>
      </div>

      {/* Method selector */}
      <div className="mb-4">
        <label className="text-sm text-white/90 mb-2 block">Harvesting Method</label>
        <div className="grid grid-cols-3 gap-2">
          {(['condensation', 'sorbent', 'hybrid'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMethod(m)}
              className={`px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                method === m ? 'bg-aqua-400 text-white' : 'bg-white/15 text-white/70'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="bg-white/10 rounded-xl p-4 space-y-3">
        <div className="text-center pb-3 border-b border-white/15">
          <p className="text-white/95 text-sm">Estimated yield at {humidity}% humidity, {temp}°C</p>
          <p className="font-display font-bold text-3xl text-aqua-300 mt-1">
            {yieldEstimate}<span className="text-lg text-white/60 ml-1">L/day per m²</span>
          </p>
          <p className="text-white/60 text-xs mt-1">Range: {(yieldEstimate * 0.5).toFixed(1)} – {(yieldEstimate * 1.5).toFixed(1)} L/day</p>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-white/95 flex items-center gap-2"><Zap size={14} className="text-amber-400" /> Energy Required</span>
          <span className="font-display font-bold text-white">{energyRequired} kWh/L</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-white/95 flex items-center gap-2"><Sun size={14} className="text-aqua-300" /> Solar Compatibility</span>
          <span className="font-display font-bold text-white">{method === 'sorbent' ? 'High' : method === 'hybrid' ? 'Medium' : 'Low'}</span>
        </div>
      </div>

      <div className="mt-4 flex items-start gap-2 bg-amber-400/15 rounded-xl p-3">
        <Info size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-white/95">
          Estimates use UAE NCM climate data and published research on atmospheric water harvesting efficiency. These are theoretical estimates — actual yield depends on device design, airflow, and surface area. A future prototype could validate these numbers.
        </p>
      </div>
    </div>
  );
}

function HiddenWaterModule() {
  const sources = [
    {
      name: 'AC / HVAC Condensate',
      what: 'Water that condenses on air conditioning coils when humid air hits cold surfaces.',
      how: 'In the UAE, AC units run 8+ hours daily in summer. Each unit can produce 5-20 litres of condensate per day. The water is relatively clean — it is essentially distilled water from humidity.',
      why: 'The UAE has one of the highest AC usage rates in the world. This water is currently drained as waste but could be collected for irrigation, cooling tower make-up, or toilet flushing.',
      quantity: '5-20 L/day per AC unit',
      difficulty: 'Low — existing infrastructure',
      feasibility: 90,
      icon: <Factory size={20} />,
    },
    {
      name: 'Rainwater',
      what: 'Water collected from rooftops and surfaces during rainfall events.',
      how: 'UAE averages 94mm of rain per year (NCM). A 200m² roof could capture ~15,000 litres annually (94mm × 200m² × 0.8 efficiency). Rainwater is relatively clean but needs filtration and disinfection.',
      why: 'Rainfall is low but not zero. Every litre captured reduces desalination demand. Rainwater harvesting is simple, proven, and works alongside other sources.',
      quantity: '~15,000 L/year per 200m² roof',
      difficulty: 'Low — proven technology',
      feasibility: 85,
      icon: <Cloud size={20} />,
    },
    {
      name: 'Greywater',
      what: 'Wastewater from showers, sinks, and washing machines — not toilets.',
      how: 'Greywater makes up 50-80% of household wastewater. It can be treated with basic filtration and disinfection for non-potable reuse like irrigation and toilet flushing.',
      why: 'In a country where most water is desalinated at high energy cost, reusing water once before discarding it significantly reduces demand on freshwater infrastructure.',
      quantity: 'High — 50-80% of household water',
      difficulty: 'Medium — needs treatment system',
      feasibility: 75,
      icon: <Droplets size={20} />,
    },
    {
      name: 'Stormwater',
      what: 'Rainwater that runs off streets, parking lots, and other surfaces during storms.',
      how: 'UAE flash floods produce large volumes of stormwater in short periods. Capture basins and permeable surfaces can collect this water for groundwater recharge or treatment.',
      why: 'Stormwater is currently managed as a flood risk, not a resource. Capturing it reduces both flood damage and desalination demand.',
      quantity: 'High during storms',
      difficulty: 'Medium — needs capture infrastructure',
      feasibility: 70,
      icon: <Beaker size={20} />,
    },
    {
      name: 'Treated Wastewater (TSE)',
      what: 'Wastewater that has been treated to a standard safe for restricted reuse.',
      how: 'UAE treatment plants already produce TSE (Treated Sewage Effluent) used for landscaping. Expanding TSE use to industrial cooling and toilet flushing reduces freshwater demand.',
      why: 'The UAE already treats wastewater — the opportunity is to use more of it instead of discharging it. This is existing infrastructure that could be better utilized.',
      quantity: 'Very High — existing plants',
      difficulty: 'High — distribution network needed',
      feasibility: 60,
      icon: <Recycle size={20} />,
    },
  ];

  return (
    <div className="animate-fade-slide">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-aqua-400/20 flex items-center justify-center text-aqua-300">
          <Mountain size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-white">Hidden Water Discovery</h2>
          <p className="text-sm text-white/95">Water sources currently overlooked or treated as waste</p>
        </div>
        <span className="ml-auto text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap" style={{ color: '#F2B84B', border: '1px solid #F2B84B40' }}>RESEARCH CONCEPT</span>
      </div>

      <ConceptSection
        what="Identifies water sources that already exist in the UAE but are not being used — AC condensate, rainwater, greywater, stormwater, and treated wastewater."
        how="Each source is assessed for water quantity, treatment difficulty, energy requirements, and feasibility. The UAE already has infrastructure for some of these (AC units, treatment plants) — the gap is in collection and reuse systems."
        why="Every litre of hidden water reused is a litre of desalinated freshwater saved — plus the energy and cost of producing it. The UAE has one of the highest per-capita water consumption rates in the world, making this especially impactful."
      />

      <div className="space-y-3">
        {sources.sort((a, b) => b.feasibility - a.feasibility).map((s, i) => (
          <div key={s.name} className="bg-white/10 rounded-xl p-4 animate-fade-slide" style={{ animationDelay: `${i * 0.1}s` }}>
            <div className="flex items-center justify-between gap-4 mb-3">
              <div className="flex items-center gap-3 flex-1">
                <div className="w-10 h-10 rounded-lg bg-aqua-400/20 flex items-center justify-center text-aqua-300 flex-shrink-0">
                  {s.icon}
                </div>
                <div>
                  <h3 className="text-sm font-medium text-white">{s.name}</h3>
                  <p className="text-xs text-white/90 mt-0.5">{s.quantity}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="font-display font-bold text-2xl text-aqua-300">{s.feasibility}</div>
                <div className="text-xs text-white/90">feasibility</div>
              </div>
            </div>
            <p className="text-xs text-white/95 mb-1"><span className="text-white/70 font-medium">What:</span> {s.what}</p>
            <p className="text-xs text-white/95 mb-1"><span className="text-white/70 font-medium">How:</span> {s.how}</p>
            <p className="text-xs text-white/95"><span className="text-white/70 font-medium">Why:</span> {s.why}</p>
            <div className="h-1.5 bg-white/15 rounded-full overflow-hidden mt-3">
              <div className="h-full bg-gradient-to-r from-aqua-400 to-teal-400 rounded-full transition-all duration-1000" style={{ width: `${s.feasibility}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PiezoelectricModule() {
  return (
    <div className="animate-fade-slide">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-amber-400/20 flex items-center justify-center text-amber-300">
          <Battery size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-white">Piezoelectric Energy Harvesting</h2>
          <p className="text-sm text-white/95">Generating electricity from footsteps to power water sensors</p>
        </div>
        <span className="ml-auto text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap" style={{ color: '#E8734B', border: '1px solid #E8734B40' }}>FUTURE</span>
      </div>

      <ConceptSection
        what="Piezoelectric materials generate small amounts of electricity when physically pressed or deformed. Installing these materials in floors or walkways could harvest energy from footsteps to power low-energy water quality sensors."
        how="Certain crystals and ceramics (like PZT — lead zirconate titanate) produce an electrical charge when mechanically stressed. When embedded in floor tiles, each footstep compresses the material and generates a small voltage. This energy is stored in a battery or capacitor and used to power sensors that monitor water quality — such as pH, turbidity, or temperature sensors in a building's water system."
        why="Water quality monitoring requires sensors, and sensors require power. In remote or distributed monitoring points, replacing batteries is expensive and impractical. Piezoelectric harvesting could make self-powered monitoring nodes possible — no batteries, no wiring, no maintenance. This is especially relevant for monitoring hidden water sources like AC condensate or greywater systems across a building."
      />

      <div className="bg-white rounded-xl p-4 mb-6 shadow-lg">
        <PiezoelectricAnimation />
      </div>

      {/* How it works — step by step */}
      <div className="bg-white/10 rounded-xl p-6 mb-6">
        <h3 className="text-sm font-medium text-white mb-4">How It Works — Step by Step</h3>
        <div className="space-y-4">
          {[
            { step: 1, title: 'Footstep applies pressure', desc: 'A person walks on a floor tile containing piezoelectric material. Their weight (60-80 kg) compresses the material.', icon: <Zap size={16} /> },
            { step: 2, title: 'Material generates electricity', desc: 'The piezoelectric crystal produces a small electrical charge — typically 0.3-0.7 milliwatts per step, depending on the material and pressure.', icon: <Battery size={16} /> },
            { step: 3, title: 'Energy is stored', desc: 'The charge is collected by a circuit and stored in a capacitor or small battery. Multiple steps accumulate energy over time.', icon: <TrendingUp size={16} /> },
            { step: 4, title: 'Sensor runs on stored energy', desc: 'A low-power water quality sensor (like a pH probe) draws from the stored energy to take periodic readings — no external power needed.', icon: <Cpu size={16} /> },
          ].map((s) => (
            <div key={s.step} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-400/20 flex items-center justify-center text-amber-300 flex-shrink-0">
                {s.icon}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{s.step}. {s.title}</p>
                <p className="text-xs text-white/95 mt-0.5">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Key facts */}
      <div className="grid sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white/10 rounded-xl p-4 text-center">
          <Zap size={20} className="text-amber-300 mx-auto mb-2" />
          <p className="font-display font-bold text-lg text-white">~0.5 mW</p>
          <p className="text-xs text-white/90">Per step (typical)</p>
        </div>
        <div className="bg-white/10 rounded-xl p-4 text-center">
          <Battery size={20} className="text-aqua-300 mx-auto mb-2" />
          <p className="font-display font-bold text-lg text-white">Low power</p>
          <p className="text-xs text-white/90">Sensors need ~10 mW</p>
        </div>
        <div className="bg-white/10 rounded-xl p-4 text-center">
          <Factory size={20} className="text-teal-300 mx-auto mb-2" />
          <p className="font-display font-bold text-lg text-white">Building use</p>
          <p className="text-xs text-white/90">High-traffic areas</p>
        </div>
      </div>

      <div className="flex items-start gap-2 bg-amber-400/15 rounded-xl p-3">
        <Info size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-white/95">
          This concept does not create water — it explores a way to power water monitoring sensors without batteries. Piezoelectric energy harvesting is a real technology used in some flooring systems, but applying it to water sensors is a future concept that would require prototyping and validation.
        </p>
      </div>
    </div>
  );
}

function AquaSenseFutureModule({ onNavigate }: { onNavigate?: (page: PageId) => void }) {
  return (
    <div className="animate-fade-slide">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-ocean-400/20 flex items-center justify-center text-ocean-300">
          <Cpu size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-white">Future AquaSense Device</h2>
          <p className="text-sm text-white/95">ESP32-connected sensors for live water quality monitoring</p>
        </div>
        <span className="ml-auto text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap" style={{ color: '#1FA7C8', border: '1px solid #1FA7C840' }}>PLANNED</span>
      </div>

      <ConceptSection
        what="AquaSense is a future hardware device that will measure water quality parameters electronically and send readings to the ReWater website in real time — no manual data entry needed."
        how="The device uses an ESP32 microcontroller connected to sensors for pH, TDS, EC, turbidity, and temperature. It reads the sensors, sends data via Wi-Fi to the ReWater database, and displays the same reading on its built-in OLED screen. The website receives the identical measurement — not a separate generated value."
        why="Currently, water testing on ReWater requires manual data entry or simulated demo data. AquaSense would automate this — place the sensor in water, and real readings appear on the website instantly. This makes continuous monitoring possible, which is essential for detecting trends and catching contamination early."
      />

      <div className="bg-white rounded-xl p-4 mb-6 shadow-lg">
        <NetworkAnimation />
      </div>

      <button
        onClick={() => onNavigate?.('aquasense')}
        className="btn-secondary mb-6 inline-flex items-center gap-2"
      >
        Check out the AquaSense model <ArrowRight size={18} />
      </button>

      {/* Architecture diagram */}
      <div className="bg-ocean-950/40 rounded-2xl p-6 mb-6">
        <p className="text-xs text-white/90 mb-4">Planned data flow — when the device is built</p>
        <div className="space-y-3">
          {[
            { label: 'AquaSense Sensors', icon: <Cpu size={20} />, desc: 'pH, TDS, EC, Turbidity, Temperature probes in water' },
            { label: 'ESP32 Microcontroller', icon: <Cpu size={20} />, desc: 'Reads sensor values, formats data, sends via Wi-Fi' },
            { label: 'Wi-Fi / Data Connection', icon: <Wind size={20} />, desc: 'Transmits readings to the ReWater API' },
            { label: 'ReWater Database', icon: <Beaker size={20} />, desc: 'Stores readings with timestamp, device ID, and calibration info' },
            { label: 'ReWater Website', icon: <FlaskConical size={20} />, desc: 'Displays live readings — same values as the OLED screen' },
          ].map((step, i) => (
            <div key={i}>
              <div className="flex items-center gap-3 bg-white/10 rounded-xl p-3">
                <div className="w-10 h-10 rounded-lg bg-aqua-400/20 flex items-center justify-center text-aqua-300 flex-shrink-0">
                  {step.icon}
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{step.label}</p>
                  <p className="text-xs text-white/95">{step.desc}</p>
                </div>
              </div>
              {i < 4 && <div className="flex justify-center py-1"><ArrowRight size={14} className="text-white/30 rotate-90" /></div>}
            </div>
          ))}
        </div>
      </div>

      {/* Same measurement note */}
      <div className="bg-aqua-400/15 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Droplets size={16} className="text-aqua-300" />
          <p className="text-sm font-medium text-white">Same Measurement, Two Displays</p>
        </div>
        <p className="text-xs text-white/95">
          When AquaSense takes a reading, the same values appear on both the device's OLED screen and the ReWater website. For example: pH 7.2, TDS 340 ppm, Turbidity 12 NTU, Temperature 26.4°C — one measurement, not two separately generated values.
        </p>
      </div>

      {/* Sensor list */}
      <div className="bg-white/10 rounded-xl p-4 mb-6">
        <p className="text-sm font-medium text-white mb-3">What AquaSense Will Measure</p>
        <div className="space-y-2">
          {[
            { param: 'pH', icon: <Droplets size={18} />, range: '0-14', accuracy: '±0.1' },
            { param: 'TDS', icon: <Zap size={18} />, range: '0-2000 ppm', accuracy: '±2%' },
            { param: 'EC', icon: <Beaker size={18} />, range: '0-4000 µS/cm', accuracy: '±1%' },
            { param: 'Turbidity', icon: <FlaskConical size={18} />, range: '0-1000 NTU', accuracy: '±5%' },
            { param: 'Temperature', icon: <Thermometer size={18} />, range: '0-80°C', accuracy: '±0.5°C' },
          ].map((s) => (
            <div key={s.param} className="flex items-center justify-between bg-white/8 rounded-lg p-3">
              <div className="flex items-center gap-2">
                <span className="text-aqua-300">{s.icon}</span>
                <span className="text-sm text-white">{s.param}</span>
              </div>
              <div className="text-right">
                <span className="text-xs text-white/95">{s.range}</span>
                <span className="text-xs text-white/85 ml-2">· {s.accuracy}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-start gap-2 bg-amber-400/15 rounded-xl p-3">
        <Info size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-white/95">
          AquaSense is a future development concept — not a currently deployed device. The ReWater website is already structured to receive real sensor data when the device exists. No website rebuild will be needed. The current platform works fully without any physical hardware.
        </p>
      </div>
    </div>
  );
}

function SatelliteModule() {
  return (
    <div className="animate-fade-slide">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-teal-400/20 flex items-center justify-center text-teal-300">
          <Satellite size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-white">Satellite Water Mapping</h2>
          <p className="text-sm text-white/95">Remote sensing for water resource discovery across the Gulf</p>
        </div>
        <span className="ml-auto text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap" style={{ color: '#1FA7C8', border: '1px solid #1FA7C840' }}>RESEARCH CONCEPT</span>
      </div>

      <ConceptSection
        what="Uses publicly available satellite data (Landsat, Sentinel, GRACE) to detect surface water, monitor groundwater changes, and identify potential water harvesting sites across the UAE and Gulf region."
        how="Satellites measure different wavelengths of light reflected from Earth's surface. Water absorbs certain wavelengths and reflects others — this spectral signature lets satellites identify water bodies, estimate water quality (like turbidity from reflectance), and track changes over time. GRACE satellites measure gravity changes caused by groundwater depletion."
        why="The Gulf region faces water scarcity across all GCC countries. Satellite monitoring could help track water resources across borders, identify where groundwater is being depleted fastest, and pinpoint locations where rainwater harvesting or other water recovery would have the most impact."
      />

      {/* What it could do */}
      <div className="bg-white/10 rounded-xl p-4 mb-6">
        <h3 className="text-sm font-medium text-white mb-3">What Satellite Data Could Show</h3>
        <div className="space-y-3">
          {[
            { label: 'Surface water detection', desc: 'Identify and track lakes, reservoirs, and wadi flows across the UAE using Landsat/Sentinel imagery.', icon: <Droplets size={16} /> },
            { label: 'Groundwater monitoring', desc: 'Track groundwater depletion across the Arabian Peninsula using GRACE gravity data (available publicly).', icon: <Mountain size={16} /> },
            { label: 'Water quality indicators', desc: 'Estimate turbidity and algal blooms in water bodies from spectral reflectance data.', icon: <Beaker size={16} /> },
            { label: 'Rainwater harvesting sites', desc: 'Identify rooftops and surfaces suitable for rainwater capture from high-resolution satellite imagery.', icon: <Cloud size={16} /> },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-teal-400/20 flex items-center justify-center text-teal-300 flex-shrink-0">
                {item.icon}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{item.label}</p>
                <p className="text-xs text-white/95 mt-0.5">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Data sources */}
      <div className="bg-white/10 rounded-xl p-4 mb-6">
        <h3 className="text-sm font-medium text-white mb-3">Public Data Sources</h3>
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            { name: 'Landsat', desc: 'USGS — 30m resolution, since 1972', icon: <Satellite size={16} /> },
            { name: 'Sentinel-2', desc: 'ESA — 10m resolution, since 2015', icon: <Satellite size={16} /> },
            { name: 'GRACE', desc: 'NASA — groundwater gravity data', icon: <Mountain size={16} /> },
          ].map((s) => (
            <div key={s.name} className="bg-white/8 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-teal-300">{s.icon}</span>
                <span className="text-sm font-medium text-white">{s.name}</span>
              </div>
              <p className="text-xs text-white/95">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-start gap-2 bg-amber-400/15 rounded-xl p-3">
        <Info size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-white/95">
          This is a research concept. Satellite data sources are publicly available, but integrating them into ReWater would require significant development — processing pipelines, data storage, and analysis tools. No live satellite data is shown here.
        </p>
      </div>
    </div>
  );
}

function DigitalTwinModule() {
  const [activePath, setActivePath] = useState<'municipal' | 'wastewater' | 'condensate' | 'reuse'>('municipal');

  return (
    <div className="animate-fade-slide">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-teal-400/20 flex items-center justify-center text-teal-300">
          <NetworkIcon size={24} />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-white">Digital Twin</h2>
          <p className="text-sm text-white/95">Site-level water system simulation from many Water Passports</p>
        </div>
        <span className="ml-auto text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap" style={{ color: '#E8734B', border: '1px solid #E8734B40' }}>FUTURE</span>
      </div>

      <ConceptSection
        what="A Digital Twin is a virtual model of a building or site's entire water system. It combines many individual Water Passports into a single live model that shows how water flows through a building — from municipal input to wastewater, treatment, storage, and reuse."
        how="Each water source gets a Water Passport with its measurements, treatment history, and reuse status. As passports accumulate, they form a site-level picture. The Digital Twin visualises this data as an interactive model — pipes, flows, treatment units, and storage — so you can see where water enters, where it's used, and where it could be recovered."
        why="A single Water Passport tells you about one sample. A Digital Twin tells you about an entire building or campus. This makes it possible to identify site-level opportunities — like recovering AC condensate for cooling tower make-up, or routing treated greywater to irrigation — that you cannot see from individual samples alone."
      />

      <div className="bg-white rounded-xl p-4 mb-6 shadow-lg">
        <DigitalTwinAnimation activePath={activePath} />
      </div>

      {/* Progression visual */}
      <div className="bg-white/10 rounded-xl p-6 mb-6">
        <h3 className="text-sm font-medium text-white mb-4">From One Passport to a Digital Twin</h3>
        <div className="space-y-3">
          {[
            { label: 'Individual Water Passport', desc: 'One water sample with its ID, measurements, and history', icon: <Droplets size={18} /> },
            { label: 'Many Water Passports', desc: 'Multiple samples from different sources across a site', icon: <Beaker size={18} /> },
            { label: 'Site-Level Water System', desc: 'All passports combined show the full water picture of a building', icon: <Factory size={18} /> },
            { label: 'Digital Twin', desc: 'A live virtual model that mirrors the real water system', icon: <NetworkIcon size={18} /> },
            { label: 'System-Level Optimization', desc: 'Identify recovery and reuse opportunities across the whole site', icon: <TrendingUp size={18} /> },
          ].map((step, i) => (
            <div key={i}>
              <div className="flex items-center gap-3 bg-white/10 rounded-xl p-3">
                <div className="w-10 h-10 rounded-lg bg-aqua-400/20 flex items-center justify-center text-aqua-300 flex-shrink-0">
                  {step.icon}
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{step.label}</p>
                  <p className="text-xs text-white/95">{step.desc}</p>
                </div>
              </div>
              {i < 4 && <div className="flex justify-center py-1"><ArrowRight size={14} className="text-white/40 rotate-90" /></div>}
            </div>
          ))}
        </div>
      </div>

      {/* Path selector */}
      <div className="mb-4">
        <label className="text-sm text-white/95 mb-2 block">Explore Water Pathways</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {(['municipal', 'wastewater', 'condensate', 'reuse'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setActivePath(p)}
              className={`px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                activePath === p ? 'bg-aqua-400 text-white' : 'bg-white/15 text-white/90'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-start gap-2 bg-amber-400/15 rounded-xl p-3">
        <Info size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-white/95">
          The Digital Twin is a future concept. The animation above is a conceptual visualisation — it does not connect to live building data. Building a real Digital Twin would require sensors, data integration, and a 3D model of the site's water infrastructure.
        </p>
      </div>
    </div>
  );
}
