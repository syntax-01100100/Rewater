import { useState, useEffect } from 'react';
import {
  Droplets, TrendingDown, Recycle, Beaker, AlertTriangle,
  Factory, Zap, Cloud, ChevronRight,
  Target, Users, Lightbulb, Shield, Building2, Sprout,
  Info, Sparkles, BarChart3,
  HandHeart, MapPin, TrendingUp, Sun, FileBarChart, ArrowDown, CheckCircle, ArrowRight,
} from 'lucide-react';
import { supabase, type WaterSample } from '@/lib/supabase';
import { formatDate } from '@/lib/utils';
import { ResourceRecoveryAnimation, NetworkAnimation, PiezoelectricAnimation } from '@/components/animations';
import { useWaterPassport } from '@/lib/waterPassport';
import { useAuth } from '@/lib/auth';
import { loadLocalSamples } from '@/lib/localPersistence';
import { PassportCard } from '@/components/PassportTimeline';

export function ImpactPage({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const [samples, setSamples] = useState<WaterSample[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCalc, setShowCalc] = useState(false);

  const { user } = useAuth();
  const { passport, passports } = useWaterPassport();

  useEffect(() => {
    if (user) {
      (async () => {
        const { data, error } = await supabase.from('water_samples').select('*').order('created_at', { ascending: false }).limit(20);
        if (!error) setSamples(data || []);
        setLoading(false);
      })();
    } else {
      setSamples(loadLocalSamples());
      setLoading(false);
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-slatey/40">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 bg-gradient-mist">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Mission header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-aqua-50 rounded-full px-4 py-1.5 mb-4">
            <Target size={14} className="text-aqua-600" />
            <span className="text-sm text-aqua-700 font-medium">Our Mission</span>
          </div>
          <h1 className="font-display font-bold text-3xl text-ocean-600 mb-3">Potential Impact</h1>
          <p className="text-slatey/60 max-w-2xl mx-auto">
            What ReWater could achieve in the UAE — not what we have already done. These are projections based on UAE climate and water infrastructure data, clearly labelled as estimates.
          </p>
        </div>

        {/* Mission, Goal, Who, Why */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="card p-6">
            <div className="w-10 h-10 rounded-xl bg-aqua-50 text-aqua-600 flex items-center justify-center mb-3">
              <Target size={20} />
            </div>
            <h3 className="font-display font-semibold text-sm text-slatey mb-2">Our Goal</h3>
            <p className="text-xs text-slatey/60 leading-relaxed">
              Reduce freshwater waste in the UAE and Gulf region by making water circularity practical and understandable.
            </p>
          </div>
          <div className="card p-6">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center mb-3">
              <Users size={20} />
            </div>
            <h3 className="font-display font-semibold text-sm text-slatey mb-2">Who This Is For</h3>
            <p className="text-xs text-slatey/60 leading-relaxed">
              Students, researchers, environmental professionals, and anyone in the Gulf who wants to understand and reduce water waste.
            </p>
          </div>
          <div className="card p-6">
            <div className="w-10 h-10 rounded-xl bg-ocean-50 text-ocean-600 flex items-center justify-center mb-3">
              <Lightbulb size={20} />
            </div>
            <h3 className="font-display font-semibold text-sm text-slatey mb-2">Why We Built This</h3>
            <p className="text-xs text-slatey/60 leading-relaxed">
              The UAE has one of the highest per-capita water consumption rates in the world, with most water coming from energy-intensive desalination.
            </p>
          </div>
          <div className="card p-6">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
              <Shield size={20} />
            </div>
            <h3 className="font-display font-semibold text-sm text-slatey mb-2">What We Do</h3>
            <p className="text-xs text-slatey/60 leading-relaxed">
              Help people test water quality, find hidden water sources, understand treatment options, and explore circular reuse — all in one platform.
            </p>
          </div>
        </div>

        {/* Potential impact numbers — clearly labelled as projections */}
        <div className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles size={18} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Potential Impact Projections</h2>
            <span className="ml-auto text-xs px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">ESTIMATES</span>
          </div>
          <p className="text-xs text-slatey/50 mb-6">
            Based on UAE water consumption data and published recovery rates. These are what ReWater could help achieve — not what has been achieved.
          </p>

          <div className="grid sm:grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-aqua-50 to-white rounded-xl p-6 text-center">
              <Droplets className="mx-auto text-aqua-400 mb-3" size={28} />
              <p className="font-display font-bold text-3xl text-slatey">15,000+</p>
              <p className="text-xs text-slatey/60 mt-1">Litres/year recoverable per building from AC condensate, rainwater, and greywater</p>
            </div>
            <div className="bg-gradient-to-br from-teal-50 to-white rounded-xl p-6 text-center">
              <TrendingDown className="mx-auto text-teal-400 mb-3" size={28} />
              <p className="font-display font-bold text-3xl text-slatey">~30%</p>
              <p className="text-xs text-slatey/60 mt-1">Potential reduction in freshwater demand for a typical UAE household</p>
            </div>
            <div className="bg-gradient-to-br from-ocean-50 to-white rounded-xl p-6 text-center">
              <Zap className="mx-auto text-ocean-400 mb-3" size={28} />
              <p className="font-display font-bold text-3xl text-slatey">~12 kWh</p>
              <p className="text-xs text-slatey/60 mt-1">Energy saved per 1,000 litres of water reused instead of desalinated</p>
            </div>
          </div>

          <button onClick={() => setShowCalc(!showCalc)} className="text-sm text-aqua-600 hover:text-aqua-700 font-medium mt-4 flex items-center gap-1">
            {showCalc ? 'Hide' : 'Show'} calculation basis <ChevronRight size={14} className={`transition-transform ${showCalc ? 'rotate-90' : ''}`} />
          </button>
          {showCalc && (
            <div className="mt-4 p-4 bg-mist rounded-xl text-sm text-slatey/70 space-y-2 animate-fade-in">
              <p><span className="font-medium text-slatey">AC Condensate:</span> UAE AC units produce 5-20 L/day per unit × 8+ hours operation. A building with 10 AC units could recover 50-200 L/day.</p>
              <p><span className="font-medium text-slatey">Rainwater:</span> UAE average rainfall 94mm/year (NCM) × 200m² roof × 0.8 efficiency = ~15,000 L/year.</p>
              <p><span className="font-medium text-slatey">Greywater:</span> 50-80% of household water is greywater. With basic treatment, 30-50% could be reused for toilet flushing and irrigation.</p>
              <p><span className="font-medium text-slatey">Energy saving:</span> UAE desalination uses ~12 kWh per 1,000 L. Every litre reused avoids this energy cost.</p>
              <p className="text-xs text-slatey/40 pt-2 border-t border-softgrey">Sources: UAE NCM rainfall data, UAE Water Conservation Strategy, published desalination energy figures.</p>
            </div>
          )}
        </div>

        {/* Recovery breakdown — what could be recovered */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-4">Where Recovery Could Come From</h2>
          <div className="space-y-4">
            {[
              {
                label: 'AC Condensate Recovery',
                icon: <Factory size={18} />,
                color: 'teal',
                detail: 'UAE buildings run AC 8+ months/year. Each unit produces 5-20 L/day of relatively clean condensate.',
                potential: 'High — existing infrastructure',
              },
              {
                label: 'Rainwater Capture',
                icon: <Cloud size={18} />,
                color: 'aqua',
                detail: '94mm annual rainfall (NCM). Simple rooftop collection can capture 70-80% of this.',
                potential: 'Medium — seasonal but proven',
              },
              {
                label: 'Greywater Reuse',
                icon: <Droplets size={18} />,
                color: 'ocean',
                detail: 'Showers, sinks, and washing machines produce 50-80% of household wastewater. Basic treatment enables toilet flushing and irrigation.',
                potential: 'High — significant volume',
              },
            ].map((r) => (
              <div key={r.label}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-slatey/70 flex items-center gap-2">
                    <span className={`text-${r.color}-400`}>{r.icon}</span>
                    {r.label}
                  </span>
                  <span className="text-xs text-slatey/50">{r.potential}</span>
                </div>
                <p className="text-xs text-slatey/50 pl-6 mb-2">{r.detail}</p>
                <div className="h-2 bg-softgrey rounded-full overflow-hidden ml-6">
                  <div
                    className={`h-full bg-gradient-to-r from-${r.color}-300 to-${r.color}-500 rounded-full transition-all duration-1000`}
                    style={{ width: r.potential.includes('High') ? '85%' : '60%' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Resource recovery animation */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-2">One Stream, Multiple Potential Outputs</h2>
          <p className="text-sm text-slatey/60 mb-4">A water stream can produce recovered water and potentially recoverable materials.</p>
          <ResourceRecoveryAnimation />
        </div>

        {/* Energy-water animation */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-2">Energy + Water: Piezoelectric Concept</h2>
          <p className="text-sm text-slatey/60 mb-4">Footsteps generating electricity to power water quality sensors.</p>
          <PiezoelectricAnimation />
        </div>

        {/* Treatment pathway explanation */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-4 flex items-center gap-2">
            <Beaker size={18} className="text-aqua-600" /> How Treatment Works
          </h2>
          <p className="text-sm text-slatey/60 mb-4">
            When ReWater analyzes a water sample, it generates a treatment pathway — a step-by-step plan for making that water safe for a specific reuse purpose. Here is how that works:
          </p>
          <div className="space-y-3">
            {[
              { step: 1, title: 'Pre-screening', desc: 'Large particles and debris are removed through screens or settling. This protects downstream equipment.', icon: <Factory size={16} /> },
              { step: 2, title: 'Sedimentation', desc: 'Water sits in a tank so heavier particles settle by gravity. This reduces turbidity before filtration.', icon: <Droplets size={16} /> },
              { step: 3, title: 'Filtration', desc: 'Fine particles are removed through sand, membrane, or cartridge filters. Target: turbidity below 1 NTU for drinking.', icon: <Beaker size={16} /> },
              { step: 4, title: 'Adsorption (if needed)', desc: 'Activated carbon removes colour, odour, and organic compounds that filtration cannot catch.', icon: <Recycle size={16} /> },
              { step: 5, title: 'Nutrient removal (if needed)', desc: 'If nitrate or nitrite are elevated, biological denitrification converts them to harmless nitrogen gas.', icon: <Sprout size={16} /> },
              { step: 6, title: 'Salinity reduction (if needed)', desc: 'If TDS is high, reverse osmosis or other desalination removes dissolved salts.', icon: <Zap size={16} /> },
              { step: 7, title: 'Disinfection', desc: 'UV, chlorination, or ozonation kills remaining pathogens. Required before any reuse involving human contact.', icon: <Shield size={16} /> },
              { step: 8, title: 'Final quality testing', desc: 'All relevant parameters are retested to confirm the water meets the standard for its intended use.', icon: <BarChart3 size={16} /> },
            ].map((s) => (
              <div key={s.step} className="flex items-start gap-3 bg-mist rounded-xl p-3">
                <div className="w-8 h-8 rounded-lg bg-ocean-100 text-ocean-600 flex items-center justify-center text-sm font-bold flex-shrink-0">
                  {s.step}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slatey">{s.title}</p>
                  <p className="text-xs text-slatey/60 mt-0.5">{s.desc}</p>
                </div>
                <span className="text-slatey/30 flex-shrink-0">{s.icon}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-start gap-2 bg-aqua-50 rounded-xl p-3">
            <Info size={16} className="text-aqua-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-slatey/70">
              Not every water sample needs all 8 steps. ReWater generates a custom pathway based on what was detected — for example, clear tap water may only need disinfection, while turbid greywater needs the full sequence.
            </p>
          </div>
        </div>

        {/* What ReWater could achieve */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-4">What ReWater Could Enable</h2>
          <div className="mb-4">
            <NetworkAnimation />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              { icon: <Building2 size={20} />, title: 'Building-level water recovery', desc: 'A UAE building could recover 15,000+ litres per year from AC condensate and rainwater alone — enough for toilet flushing and landscape irrigation.' },
              { icon: <Beaker size={20} />, title: 'Informed water testing', desc: 'Students and researchers can test water quality, understand what the results mean, and get a clear treatment plan — without needing a chemistry degree.' },
              { icon: <Recycle size={20} />, title: 'Circular water reuse', desc: 'Instead of using desalinated water once and discarding it, buildings could reuse it for non-potable purposes before it leaves the system.' },
              { icon: <AlertTriangle size={20} />, title: 'Early contamination detection', desc: 'Regular testing with AquaSense (when available) could catch water quality changes before they become health risks.' },
            ].map((item, i) => (
              <div key={i} className="bg-mist rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-aqua-600">{item.icon}</span>
                  <h3 className="text-sm font-medium text-slatey">{item.title}</h3>
                </div>
                <p className="text-xs text-slatey/60 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Current Water Passport — only visible when signed in */}
        {user && passport && (
          <div className="card p-6 mb-6">
            <h2 className="font-display font-semibold text-lg text-slatey mb-2 flex items-center gap-2">
              <Droplets size={18} className="text-aqua-600" /> Current Water Passport
            </h2>
            <p className="text-xs text-slatey/50 mb-4">The passport you created on the Check Water page is available here for scenario analysis.</p>
            <PassportCard passport={passport} />
          </div>
        )}

        {/* All passports — only visible when signed in */}
        {user && passports.length > 1 && (
          <div className="card p-6 mb-6">
            <h2 className="font-display font-semibold text-sm text-slatey mb-3">All Water Passports ({passports.length})</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {passports.slice(0, 6).map((p) => (
                <PassportCard key={p.waterId} passport={p} compact />
              ))}
            </div>
          </div>
        )}

        {/* Sample timeline */}
        {samples.length > 0 && (
          <div className="card p-6">
            <h2 className="font-display font-semibold text-lg text-slatey mb-4">Water Samples Tested So Far</h2>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {samples.map((s) => (
                <div key={s.id} className="flex items-center justify-between p-3 bg-mist rounded-xl">
                  <div>
                    <span className="text-sm font-medium text-slatey">{s.source_name}</span>
                    <span className="text-xs text-slatey/40 ml-2">{formatDate(s.created_at)}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    {s.ph && <span className="text-ocean-600 font-medium">pH {s.ph}</span>}
                    {s.tds && <span className="text-aqua-600 font-medium">TDS {s.tds}</span>}
                    {s.turbidity !== null && <span className="text-teal-600 font-medium">NTU {s.turbidity}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ─── Water Circularity Tracking ─────────────────────────────── */}
        <div className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Droplets size={20} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Tracking Every Drop of Rescued Water</h2>
          </div>
          <p className="text-sm text-slatey/60 mb-4">
            ReWater can create a digital record of recovered water and track where its environmental or human value
            could be maximized. The platform could potentially record:
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {[
              { label: 'Litres recovered', icon: <Droplets size={16} /> },
              { label: 'Source & date', icon: <MapPin size={16} /> },
              { label: 'Treatment status', icon: <Shield size={16} /> },
              { label: 'Intended reuse', icon: <Recycle size={16} /> },
              { label: 'Location', icon: <MapPin size={16} /> },
              { label: 'Organization', icon: <Building2 size={16} /> },
              { label: 'Destination / use', icon: <TrendingUp size={16} /> },
              { label: 'Associated impact', icon: <BarChart3 size={16} /> },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-2 bg-mist rounded-xl p-3">
                <span className="text-aqua-600">{item.icon}</span>
                <span className="text-xs text-slatey/70">{item.label}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-slatey/50">
            The system can help identify suitable destinations for recovered water based on verified quality,
            permitted uses, location, demand, and other relevant constraints.
          </p>
        </div>

        {/* ─── Impact Flow Visualization ─────────────────────────────── */}
        <div className="card p-6 mb-6">
          <h2 className="font-display font-semibold text-lg text-slatey mb-2">From Water Source to Recorded Impact</h2>
          <p className="text-sm text-slatey/60 mb-6">ReWater is not simply a water-quality checker — it is a data and decision-support layer for water circularity.</p>
          <div className="flex flex-col items-center gap-2">
            {[
              { label: 'Water Source', icon: <Droplets size={20} />, color: 'aqua' },
              { label: 'Test & Verify', icon: <Beaker size={20} />, color: 'ocean' },
              { label: 'Recovered Water', icon: <Recycle size={20} />, color: 'teal' },
              { label: 'ReWater Digital Record', icon: <FileBarChart size={20} />, color: 'ocean' },
              { label: 'Water Credit / Contribution', icon: <Sparkles size={20} />, color: 'aqua' },
              { label: 'Match With Eligible Need', icon: <Target size={20} />, color: 'teal' },
              { label: 'Environmental or Human Impact', icon: <HandHeart size={20} />, color: 'aqua' },
              { label: 'Impact Data Recorded', icon: <BarChart3 size={20} />, color: 'ocean' },
            ].map((step, i) => (
              <div key={step.label} className="flex flex-col items-center">
                <div className={`flex items-center gap-3 px-5 py-3 rounded-2xl bg-${step.color}-50 text-${step.color}-700 shadow-soft`}>
                  {step.icon}
                  <span className="text-sm font-medium">{step.label}</span>
                </div>
                {i < 7 && <ArrowDown size={18} className="text-slatey/30 my-0.5" />}
              </div>
            ))}
          </div>
        </div>

        {/* ─── Water Credits (brief) ──────────────────────────────────── */}
        <div className="card p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles size={20} className="text-aqua-600" />
            <h2 className="font-display font-semibold text-lg text-slatey">Water Credits</h2>
            <span className="ml-auto text-xs px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">CONCEPT</span>
          </div>
          <p className="text-sm text-slatey/60 mb-4">
            Organizations generating verified excess or recovered water can record that contribution digitally
            instead of treating every contribution as a physical bottle transfer.
          </p>
          <div className="bg-mist rounded-xl p-4 mb-4">
            <p className="text-xs text-slatey/70 leading-relaxed">
              <span className="font-medium text-slatey">Example:</span> A company building generates 1,000 L of verified
              recoverable water through ReWater. The system creates a corresponding digital water contribution.
              That contribution could support an appropriate water-access initiative, such as funding safe drinking-water
              delivery to nearby hydration stations — subject to real-world verification, safety requirements, and
              participating organizations.
            </p>
          </div>
          <div className="flex items-start gap-2 bg-aqua-50 rounded-xl p-3 mt-3">
            <Info size={14} className="text-aqua-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-slatey/70">
              When suitable water is recovered and verified, ReWater records the contribution as Water Credits.
              These credits can support eligible hydration, water-access, and environmental initiatives.
            </p>
          </div>
          {onNavigate && (
            <button
              onClick={() => onNavigate('water-credits')}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-aqua-600 text-white text-sm font-medium hover:bg-aqua-700 transition-colors"
            >
              <Sparkles size={14} /> View Water Credits
            </button>
          )}
        </div>

        {/* Disclaimer */}
        <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-4 mt-6">
          <Info size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            All impact figures are projections based on publicly available UAE data (NCM, water authority reports). ReWater is a screening and education platform — it does not replace certified laboratory testing or professional water treatment design.
          </p>
        </div>
      </div>
    </div>
  );
}
