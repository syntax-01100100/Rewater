// Water Analysis Engine — Structured scientific decision system

export type DataSource = 'measured' | 'estimated' | 'observed' | 'simulated' | 'ai-inferred';
export type Severity = 'normal' | 'watch' | 'elevated' | 'high' | 'critical';

export interface ParameterResult {
  name: string;
  value: number;
  unit: string;
  source: DataSource;
  refRange: string;
  status: string;
  severity: Severity;
  confidence: 'High' | 'Medium' | 'Low' | 'N/A';
}

export interface Finding {
  title: string;
  detail: string;
  confidence: string;
  level: 'good' | 'warning' | 'info' | 'alert';
  parameters: string[];
}

export interface TreatmentStage {
  name: string;
  addresses: string;
  whyNeeded: string;
  canRemove: string;
  cannotRemove: string;
  mustTestAfter: string;
}

export type Recoverability = 'high' | 'moderate' | 'low' | 'not-recommended';

export interface ReusePathway {
  category: string;
  treatmentRequired: string;
  verificationNeeded: string;
}

export interface ResourceRecovery {
  resource: string;
  status: 'potential' | 'confirmed';
  detail: string;
}

export interface PreventionPlan {
  problemDetected: string;
  possibleSource: string;
  monitorWhat: string;
  monitoringFrequency: string;
  earlyWarningTrigger: string;
  preventionAction: string;
}

export interface WaterProfile {
  parameters: ParameterResult[];
  findings: Finding[];
  treatmentPathway: TreatmentStage[];
  recoverability: Recoverability;
  recoverabilityReasoning: string;
  reusePathways: ReusePathway[];
  resourceRecovery: ResourceRecovery[];
  preventionPlan: PreventionPlan;
  needsVerification: string[];
  uncertainty: string;
}

export interface AquaSenseData {
  ph: number;
  temperature: number;
  turbidity: number;
  tds: number;
  ec: number;
}

export interface AquaCardData {
  nitrate: number;
  nitrite: number;
  hardness: number;
  chlorine: number;
}

export interface CameraData {
  colour: string;
  cloudiness: string;
  visibleParticles: boolean;
  sediment: boolean;
  foam: boolean;
  oilAppearance: boolean;
  surfaceAppearance: string;
  confidence: 'High' | 'Medium' | 'Low';
}

export interface AnalysisContext {
  sourceName: string;
  sourceType: string;
  intendedUse: string;
}

const severityColor: Record<Severity, string> = {
  normal: 'teal',
  watch: 'aqua',
  elevated: 'amber',
  high: 'amber',
  critical: 'coral',
};

export function getSeverityColor(s: Severity): string {
  return severityColor[s];
}

export function getSeverityLabel(s: Severity): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function phParameter(ph: number, use: string): ParameterResult {
  const drinkingMin = 6.5, drinkingMax = 8.5;
  let severity: Severity = 'normal';
  let status = 'Within neutral range';
  if (ph < 5.5) { severity = 'critical'; status = 'Strongly acidic'; }
  else if (ph < 6.5) { severity = 'elevated'; status = 'Below typical range'; }
  else if (ph > 9.5) { severity = 'critical'; status = 'Strongly alkaline'; }
  else if (ph > 8.5) { severity = 'elevated'; status = 'Above typical range'; }
  if (use === 'irrigation' && ph >= 6.0 && ph <= 8.5) { severity = 'normal'; status = 'Suitable for irrigation'; }
  return {
    name: 'pH',
    value: ph,
    unit: '',
    source: 'measured',
    refRange: `${drinkingMin}–${drinkingMax} (drinking)`,
    status,
    severity,
    confidence: 'High',
  };
}

function tempParameter(temp: number): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Normal temperature';
  if (temp > 35) { severity = 'elevated'; status = 'Above typical — possible thermal input'; }
  else if (temp < 5) { severity = 'watch'; status = 'Below typical'; }
  return {
    name: 'Temperature',
    value: temp,
    unit: '°C',
    source: 'measured',
    refRange: '10–30 (ambient water)',
    status,
    severity,
    confidence: 'High',
  };
}

function turbidityParameter(turb: number, use: string): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Clear';
  const drinkingLimit = 1;
  const irrigationLimit = 5;
  const limit = use === 'drinking' ? drinkingLimit : irrigationLimit;
  if (turb > 20) { severity = 'critical'; status = 'Very high — significant suspended material'; }
  else if (turb > 10) { severity = 'high'; status = 'High — cloudy'; }
  else if (turb > limit) { severity = 'elevated'; status = 'Above limit for intended use'; }
  else if (turb > 1) { severity = 'watch'; status = 'Slight turbidity'; }
  return {
    name: 'Turbidity',
    value: turb,
    unit: 'NTU',
    source: 'measured',
    refRange: `≤${limit} NTU (${use})`,
    status,
    severity,
    confidence: 'High',
  };
}

function tdsParameter(tds: number, use: string): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Within typical range';
  const drinkingLimit = 500;
  const irrigationLimit = 1000;
  const limit = use === 'drinking' ? drinkingLimit : irrigationLimit;
  if (tds > 5000) { severity = 'critical'; status = 'Very high — saline/brackish'; }
  else if (tds > 2000) { severity = 'high'; status = 'High dissolved solids'; }
  else if (tds > limit) { severity = 'elevated'; status = `Above limit for ${use}`; }
  else if (tds < 50) { severity = 'watch'; status = 'Very low mineral content'; }
  return {
    name: 'TDS',
    value: tds,
    unit: 'mg/L',
    source: 'measured',
    refRange: `≤${limit} mg/L (${use})`,
    status,
    severity,
    confidence: 'Medium',
  };
}

function nitrateParameter(n: number): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Within range';
  if (n > 50) { severity = 'critical'; status = 'Above drinking limit'; }
  else if (n > 10) { severity = 'elevated'; status = 'Elevated — investigate source'; }
  else if (n > 3) { severity = 'watch'; status = 'Detectable'; }
  return {
    name: 'Nitrate (NO₃)',
    value: n,
    unit: 'mg/L',
    source: 'estimated',
    refRange: '≤10 (drinking, preventive) / ≤50 (WHO)',
    status,
    severity,
    confidence: 'Medium',
  };
}

function nitriteParameter(n: number): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Within range';
  if (n > 3) { severity = 'critical'; status = 'Above drinking limit'; }
  else if (n > 1) { severity = 'elevated'; status = 'Elevated'; }
  else if (n > 0.1) { severity = 'watch'; status = 'Detectable'; }
  return {
    name: 'Nitrite (NO₂)',
    value: n,
    unit: 'mg/L',
    source: 'estimated',
    refRange: '≤1 (drinking)',
    status,
    severity,
    confidence: 'Medium',
  };
}

function hardnessParameter(h: number): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Moderate hardness';
  if (h > 300) { severity = 'elevated'; status = 'Very hard water'; }
  else if (h > 150) { severity = 'watch'; status = 'Hard water'; }
  else if (h < 60) { severity = 'watch'; status = 'Soft water'; }
  return {
    name: 'Hardness',
    value: h,
    unit: 'mg/L CaCO₃',
    source: 'estimated',
    refRange: '60–200 (moderate)',
    status,
    severity,
    confidence: 'Medium',
  };
}

function chlorineParameter(c: number): ParameterResult {
  let severity: Severity = 'normal';
  let status = 'Within range';
  if (c > 4) { severity = 'high'; status = 'High — above typical disinfection'; }
  else if (c > 2) { severity = 'elevated'; status = 'Elevated residual chlorine'; }
  else if (c < 0.2 && c > 0) { severity = 'watch'; status = 'Low residual'; }
  return {
    name: 'Chlorine (Free)',
    value: c,
    unit: 'mg/L',
    source: 'estimated',
    refRange: '0.2–4 (disinfected supply)',
    status,
    severity,
    confidence: 'Medium',
  };
}

function cameraParameters(cam: CameraData): ParameterResult[] {
  const params: ParameterResult[] = [];
  params.push({
    name: 'Apparent Colour',
    value: 0,
    unit: cam.colour,
    source: 'observed',
    refRange: 'Clear/colourless',
    status: cam.colour === 'Clear' ? 'Normal' : 'Observed colour',
    severity: cam.colour === 'Clear' ? 'normal' : 'watch',
    confidence: cam.confidence,
  });
  params.push({
    name: 'Cloudiness',
    value: 0,
    unit: cam.cloudiness,
    source: 'observed',
    refRange: 'Clear',
    status: cam.cloudiness,
    severity: cam.cloudiness === 'Clear' ? 'normal' : cam.cloudiness === 'Elevated' ? 'elevated' : 'high',
    confidence: cam.confidence,
  });
  if (cam.visibleParticles) {
    params.push({
      name: 'Visible Particles',
      value: 0,
      unit: 'detected',
      source: 'observed',
      refRange: 'None visible',
      status: 'Visible suspended material detected',
      severity: 'elevated',
      confidence: cam.confidence,
    });
  }
  if (cam.foam) {
    params.push({
      name: 'Foam',
      value: 0,
      unit: 'observed',
      source: 'observed',
      refRange: 'None',
      status: 'Foam observed on surface',
      severity: 'watch',
      confidence: cam.confidence,
    });
  }
  if (cam.oilAppearance) {
    params.push({
      name: 'Oil-like Appearance',
      value: 0,
      unit: 'observed',
      source: 'observed',
      refRange: 'None',
      status: 'Possible oil-like surface appearance',
      severity: 'high',
      confidence: 'Low',
    });
  }
  return params;
}

function identifyFindings(params: ParameterResult[], cam: CameraData | null, ctx: AnalysisContext): Finding[] {
  const findings: Finding[] = [];

  for (const p of params) {
    if (p.severity === 'elevated' || p.severity === 'high' || p.severity === 'critical') {
      const f: Finding = {
        title: `${p.name} is ${p.status.toLowerCase()}`,
        detail: getFindingDetail(p, ctx),
        confidence: p.confidence,
        level: p.severity === 'critical' ? 'alert' : p.severity === 'high' ? 'warning' : 'warning',
        parameters: [p.name],
      };
      findings.push(f);
    } else if (p.severity === 'watch') {
      findings.push({
        title: `${p.name}: ${p.status}`,
        detail: getFindingDetail(p, ctx),
        confidence: p.confidence,
        level: 'info',
        parameters: [p.name],
      });
    } else if (p.severity === 'normal' && p.source === 'measured') {
      findings.push({
        title: `${p.name} is within normal range`,
        detail: `${p.name} of ${p.value}${p.unit} is within the reference range (${p.refRange}). This is consistent with expected water quality for this parameter.`,
        confidence: p.confidence,
        level: 'good',
        parameters: [p.name],
      });
    }
  }

  // Multi-parameter patterns
  const elevatedParams = params.filter(p => p.severity === 'elevated' || p.severity === 'high' || p.severity === 'critical');
  if (elevatedParams.length >= 3) {
    findings.push({
      title: 'Multiple parameters outside expected ranges',
      detail: `${elevatedParams.length} parameters show elevated or high values: ${elevatedParams.map(p => p.name).join(', ')}. This pattern may be consistent with a broader water-quality issue. Additional testing is recommended to identify the source and confirm the cause.`,
      confidence: 'Medium',
      level: 'alert',
      parameters: elevatedParams.map(p => p.name),
    });
  }

  // Nitrate + nitrite pattern
  const hasNitrate = params.find(p => p.name === 'Nitrate (NO₃)');
  const hasNitrite = params.find(p => p.name === 'Nitrite (NO₂)');
  if (hasNitrate && hasNitrate.severity !== 'normal' && hasNitrite && hasNitrite.severity !== 'normal') {
    findings.push({
      title: 'Nitrogen compounds detected together',
      detail: 'Both nitrate and nitrite are elevated. This could indicate agricultural runoff, fertilizer leaching, or sewage contamination. This pattern warrants investigation of upstream sources and additional biological testing.',
      confidence: 'Medium',
      level: 'warning',
      parameters: ['Nitrate (NO₃)', 'Nitrite (NO₂)'],
    });
  }

  if (cam?.oilAppearance) {
    findings.push({
      title: 'Possible oil-like visual appearance',
      detail: 'A surface appearance consistent with oil was observed by camera. This is a visual observation only and cannot confirm the presence or type of hydrocarbon. Laboratory testing is required. Do not use this water until the source is identified.',
      confidence: 'Low',
      level: 'alert',
      parameters: ['Oil-like Appearance'],
    });
  }

  return findings;
}

function getFindingDetail(p: ParameterResult, ctx: AnalysisContext): string {
  const sourceType = ctx.sourceType;
  switch (p.name) {
    case 'pH':
      if (p.value < 6.5) return `pH of ${p.value} suggests acidic conditions. This could be consistent with acid rain influence, certain geological conditions, or industrial discharge. For ${sourceType}, this may affect infrastructure corrosion or biological activity.`;
      if (p.value > 8.5) return `pH of ${p.value} suggests alkaline conditions. Common in mineral-rich groundwater or areas with limestone geology. This may contribute to scaling in pipes.`;
      return `pH of ${p.value} is within the typical neutral range.`;
    case 'Turbidity':
      return `Turbidity of ${p.value} NTU indicates ${p.value > 10 ? 'significant' : 'measurable'} suspended particles. This could suggest sediment disturbance, surface runoff, biological activity, or industrial input. High turbidity can shield microorganisms from disinfection.`;
    case 'TDS':
      return `TDS of ${p.value} mg/L indicates ${p.value > 2000 ? 'high' : 'elevated'} dissolved solids. TDS is estimated from conductivity. For ${sourceType}, this may indicate brackish water, mineral-rich groundwater, or contamination input.`;
    case 'Nitrate (NO₃)':
      return `Nitrate of ${p.value} mg/L may indicate agricultural runoff, fertilizer leaching, or sewage contamination. Elevated nitrate in drinking water is a health concern, particularly for infants.`;
    case 'Hardness':
      return `Hardness of ${p.value} mg/L as CaCO₃ indicates ${p.value > 300 ? 'very hard' : 'hard'} water. This is common in mineral-rich groundwater and affects scaling, soap efficiency, and appliance lifespan.`;
    default:
      return `${p.name}: ${p.status}. Reference range: ${p.refRange}.`;
  }
}

function buildTreatmentPathway(params: ParameterResult[], cam: CameraData | null): TreatmentStage[] {
  const stages: TreatmentStage[] = [];

  const hasIssue = (name: string, minSeverity: Severity = 'elevated') => {
    const p = params.find(p => p.name === name);
    if (!p) return false;
    const order: Severity[] = ['normal', 'watch', 'elevated', 'high', 'critical'];
    return order.indexOf(p.severity) >= order.indexOf(minSeverity);
  };

  // Pre-screening
  if (hasIssue('Turbidity', 'elevated') || cam?.visibleParticles || cam?.sediment) {
    stages.push({
      name: 'Pre-screening',
      addresses: 'Large particles, debris, sediment',
      whyNeeded: 'Removes large suspended material before finer treatment stages to protect equipment and improve efficiency.',
      canRemove: 'Large particles, debris, coarse sediment',
      cannotRemove: 'Dissolved substances, fine particles, microorganisms',
      mustTestAfter: 'Turbidity (should be reduced but not eliminated)',
    });
    stages.push({
      name: 'Solids Removal / Sedimentation',
      addresses: 'Suspended solids, fine particles',
      whyNeeded: 'Allows heavier particles to settle by gravity, reducing load on downstream filtration.',
      canRemove: 'Settleable solids, sand, silt',
      cannotRemove: 'Dissolved solids, colloidal particles, bacteria',
      mustTestAfter: 'Turbidity, total suspended solids',
    });
  }

  // Turbidity reduction / filtration
  if (hasIssue('Turbidity', 'elevated')) {
    stages.push({
      name: 'Filtration (Turbidity Reduction)',
      addresses: 'Fine suspended particles causing turbidity',
      whyNeeded: 'Reduces turbidity to acceptable levels by removing particles too fine for sedimentation.',
      canRemove: 'Fine particles, some colloids, some larger microorganisms',
      cannotRemove: 'Dissolved chemicals, viruses, most bacteria',
      mustTestAfter: 'Turbidity (target ≤1 NTU for drinking)',
    });
  }

  // Adsorption for odour/colour/organic
  if (cam && (cam.colour !== 'Clear' || cam.foam)) {
    stages.push({
      name: 'Adsorption (Activated Carbon)',
      addresses: 'Colour, odour, some organic compounds',
      whyNeeded: 'Activated carbon adsorbs organic compounds that cause colour, odour, or taste issues.',
      canRemove: 'Some organic compounds, chlorine, taste/odour compounds',
      cannotRemove: 'Minerals, salinity, most bacteria, heavy metals',
      mustTestAfter: 'Colour, odour, total organic carbon if available',
    });
  }

  // Biological treatment for nutrient contamination
  if (hasIssue('Nitrate (NO₃)', 'elevated') || hasIssue('Nitrite (NO₂)', 'elevated')) {
    stages.push({
      name: 'Biological Treatment (Nutrient Removal)',
      addresses: 'Nitrate, nitrite, organic nitrogen',
      whyNeeded: 'Biological denitrification converts nitrate to nitrogen gas. This is the primary method for reducing nitrogen in wastewater.',
      canRemove: 'Nitrate, nitrite, organic nitrogen (with proper process design)',
      cannotRemove: 'Salinity, heavy metals, most other dissolved chemicals',
      mustTestAfter: 'Nitrate, nitrite, total nitrogen',
    });
  }

  // Desalination for high TDS
  if (hasIssue('TDS', 'elevated') || hasIssue('TDS', 'high')) {
    stages.push({
      name: 'Salinity Reduction / Desalination',
      addresses: 'High TDS, dissolved salts, brackish/saline water',
      whyNeeded: 'Reverse osmosis or other desalination removes dissolved salts that cannot be removed by filtration or biological treatment.',
      canRemove: 'Dissolved salts, most minerals, most contaminants',
      cannotRemove: 'Some gases, very small organic molecules (depending on membrane)',
      mustTestAfter: 'TDS, EC, specific ions of concern',
    });
  }

  // Disinfection — always needed for reuse
  stages.push({
    name: 'Disinfection',
    addresses: 'Pathogens, bacteria, viruses',
    whyNeeded: 'Final barrier against microorganisms. Required before any reuse involving human contact. UV, chlorination, or ozonation are common methods.',
    canRemove: 'Most bacteria, viruses, some protozoa (method-dependent)',
    cannotRemove: 'Chemical contaminants, dissolved solids, heavy metals',
    mustTestAfter: 'Residual disinfectant, coliform bacteria (laboratory)',
  });

  // Final quality testing
  stages.push({
    name: 'Final Quality Testing',
    addresses: 'Verification of treatment effectiveness',
    whyNeeded: 'Confirms that treatment has achieved the required water quality for the intended use.',
    canRemove: 'N/A — this is a verification step',
    cannotRemove: 'N/A',
    mustTestAfter: 'All relevant parameters for intended use standard',
  });

  return stages;
}

function assessRecoverability(params: ParameterResult[]): { level: Recoverability; reasoning: string } {
  const critical = params.filter(p => p.severity === 'critical');
  const high = params.filter(p => p.severity === 'high');
  const elevated = params.filter(p => p.severity === 'elevated');
  const tds = params.find(p => p.name === 'TDS');
  const hasOil = params.find(p => p.name === 'Oil-like Appearance');

  if (hasOil || (critical.length > 0 && critical.some(p => p.name !== 'TDS'))) {
    return {
      level: 'not-recommended',
      reasoning: 'Available information indicates potential contamination that requires professional/laboratory assessment before recovery can be considered. The detected pattern may include unknown hazardous substances. Do not proceed with recovery until the contamination source is identified and appropriate treatment is validated.',
    };
  }

  if (tds && tds.value > 5000) {
    return {
      level: 'low',
      reasoning: 'Very high salinity (TDS >5000 mg/L) makes recovery technically difficult and energy-intensive. Desalination would be required, with significant energy demand and brine management needs. Recovery may be feasible with appropriate technology but is not practical for small-scale or low-energy applications.',
    };
  }

  if (critical.length > 0) {
    return {
      level: 'low',
      reasoning: `${critical.length} parameter(s) at critical levels. Recovery may be technically possible but requires advanced treatment, professional assessment, and significant resources. The complexity and cost may exceed the value of the recovered water for the intended use.`,
    };
  }

  if (high.length > 0 || elevated.length > 2) {
    return {
      level: 'moderate',
      reasoning: 'Recovery may be possible, but additional testing or more advanced treatment is required. The detected parameters indicate that a multi-stage treatment pathway would be needed. Professional validation of treatment effectiveness is recommended before reuse.',
    };
  }

  return {
    level: 'high',
    reasoning: 'The water appears potentially treatable with appropriate treatment and verification. No parameters indicate severe contamination or technically prohibitive conditions. Standard treatment stages (as outlined in the pathway) should be sufficient for the intended reuse, subject to final quality testing.',
  };
}

function assessReuse(recoverability: Recoverability, params: ParameterResult[]): ReusePathway[] {
  if (recoverability === 'not-recommended') {
    return [{
      category: 'No reuse recommended until verified',
      treatmentRequired: 'Full laboratory assessment and source identification first',
      verificationNeeded: 'Contaminant identification and professional treatment design',
    }];
  }

  const pathways: ReusePathway[] = [];
  const tds = params.find(p => p.name === 'TDS');
  const turb = params.find(p => p.name === 'Turbidity');

  pathways.push({
    category: 'Irrigation / Landscaping',
    treatmentRequired: turb && turb.severity !== 'normal' ? 'Filtration + disinfection' : 'Disinfection',
    verificationNeeded: 'TDS within irrigation limits, no phytotoxic compounds, pathogen testing',
  });

  pathways.push({
    category: 'Toilet Flushing',
    treatmentRequired: 'Filtration + disinfection',
    verificationNeeded: 'Turbidity ≤5 NTU, disinfection residual maintained',
  });

  pathways.push({
    category: 'Cleaning / Wash-down',
    treatmentRequired: 'Filtration + disinfection',
    verificationNeeded: 'Turbidity acceptable, no staining compounds',
  });

  if (tds && tds.value < 1000) {
    pathways.push({
      category: 'Industrial Processes (cooling, washing)',
      treatmentRequired: 'Treatment to meet specific industrial water quality standards',
      verificationNeeded: 'TDS, hardness, chloride, and pH within industrial specifications',
    });
  }

  if (recoverability === 'high' && (!tds || tds.value < 300)) {
    pathways.push({
      category: 'Potable reuse (requires advanced treatment + authority approval)',
      treatmentRequired: 'Multi-barrier treatment: filtration, adsorption, desalination if needed, disinfection, advanced oxidation',
      verificationNeeded: 'Full laboratory testing to drinking water standards, regulatory approval, continuous monitoring',
    });
  }

  return pathways;
}

function assessResources(params: ParameterResult[], ctx: AnalysisContext): ResourceRecovery[] {
  const resources: ResourceRecovery[] = [];
  const nitrate = params.find(p => p.name === 'Nitrate (NO₃)');
  const tds = params.find(p => p.name === 'TDS');
  const temp = params.find(p => p.name === 'Temperature');

  if (nitrate && (nitrate.severity === 'elevated' || nitrate.severity === 'high')) {
    resources.push({
      resource: 'Nitrogen / Phosphorus Recovery',
      status: 'potential',
      detail: 'Nutrient-rich water may contain recoverable nitrogen and phosphorus for fertilizer use. This is a potential resource — not confirmed recoverable without process and feasibility data. Struvite precipitation or ion exchange could be investigated.',
    });
  }

  if (tds && tds.value > 2000) {
    resources.push({
      resource: 'Salt / Mineral Recovery',
      status: 'potential',
      detail: 'High-salinity water may contain recoverable salts or minerals. Desalination concentrate (brine) could be processed for salt recovery. This is a potential resource — commercial recoverability requires feasibility study and purification validation.',
    });
  }

  if (ctx.sourceType === 'wastewater' || ctx.sourceType === 'greywater') {
    resources.push({
      resource: 'Biogas / Energy from Organics',
      status: 'potential',
      detail: 'Organic-rich wastewater may support anaerobic digestion for biogas production. This is a potential energy pathway — technically appropriate only with sufficient organic load and process design.',
    });
  }

  if (temp && temp.value > 30) {
    resources.push({
      resource: 'Heat Recovery',
      status: 'potential',
      detail: 'Warm water (>30°C) may contain recoverable thermal energy via heat exchangers. This is a potential resource — feasibility depends on temperature differential and volume.',
    });
  }

  if (resources.length === 0) {
    resources.push({
      resource: 'No significant resource recovery identified',
      status: 'potential',
      detail: 'Based on available measurements, no valuable resources were identified at levels suggesting recovery potential. Additional testing may reveal resources not detectable by current sensors.',
    });
  }

  return resources;
}

function buildPrevention(findings: Finding[]): PreventionPlan {
  const elevatedFindings = findings.filter(f => f.level === 'warning' || f.level === 'alert');
  const topIssue = elevatedFindings[0];

  return {
    problemDetected: topIssue ? topIssue.title : 'No significant issues detected',
    possibleSource: topIssue ? inferSource(topIssue.parameters) : 'N/A',
    monitorWhat: elevatedFindings.map(f => f.parameters.join(', ')).join('; ') || 'Continue routine monitoring of all parameters',
    monitoringFrequency: elevatedFindings.length > 2 ? 'Weekly until stable, then monthly' : 'Monthly, with quarterly review',
    earlyWarningTrigger: elevatedFindings.length > 0
      ? `${elevatedFindings[0].parameters[0]} trending upward over 2+ consecutive measurements`
      : 'Any parameter moving from NORMAL to WATCH status',
    preventionAction: elevatedFindings.length > 0
      ? `Investigate upstream sources, verify treatment is functioning, increase monitoring frequency, and conduct laboratory confirmation testing. Compare future readings with this baseline to track improvement or deterioration.`
      : 'Maintain current monitoring schedule. Compare future readings with this baseline to detect any trend early.',
  };
}

function inferSource(params: string[]): string {
  if (params.includes('Nitrate (NO₃)') || params.includes('Nitrite (NO₂)')) {
    return 'Possible agricultural runoff, fertilizer leaching, or sewage/septic system input upstream';
  }
  if (params.includes('Turbidity')) {
    return 'Possible sediment disturbance, construction activity, surface runoff, or infrastructure issue upstream';
  }
  if (params.includes('TDS')) {
    return 'Possible saline intrusion, geological mineral input, or industrial discharge upstream';
  }
  if (params.includes('pH')) {
    return 'Possible industrial discharge, geological conditions, or acid rain influence';
  }
  return 'Source unknown — upstream investigation recommended';
}

function buildVerification(params: ParameterResult[], cam: CameraData | null): string[] {
  const v: string[] = [];
  v.push('Laboratory coliform / E. coli testing (bacteria cannot be detected by AquaSense, AquaCard, or camera)');
  v.push('Heavy metals analysis (lead, arsenic, cadmium — not detectable by current screening methods)');
  v.push('Full mineral panel and specific ion analysis at a certified laboratory');
  if (cam?.oilAppearance) {
    v.push('Hydrocarbon / oil contamination testing (visual observation is not confirmatory)');
  }
  v.push('Treatment effectiveness verification: retest all parameters after treatment');
  v.push('Regulatory compliance check against applicable standards for intended reuse');
  v.push('Site-specific validation by a qualified water treatment professional');
  return v;
}

export function generateWaterProfile(
  sense: AquaSenseData | null,
  card: AquaCardData | null,
  camera: CameraData | null,
  ctx: AnalysisContext
): WaterProfile {
  const params: ParameterResult[] = [];
  const use = ctx.intendedUse || 'general';

  if (sense) {
    params.push(phParameter(sense.ph, use));
    params.push(tempParameter(sense.temperature));
    params.push(turbidityParameter(sense.turbidity, use));
    params.push(tdsParameter(sense.tds, use));
    params.push({
      name: 'Electrical Conductivity',
      value: sense.ec,
      unit: 'µS/cm',
      source: 'measured',
      refRange: 'Derived → TDS estimated',
      status: 'Direct sensor reading',
      severity: 'normal',
      confidence: 'Medium',
    });
  }

  if (card) {
    params.push(nitrateParameter(card.nitrate));
    params.push(nitriteParameter(card.nitrite));
    params.push(hardnessParameter(card.hardness));
    params.push(chlorineParameter(card.chlorine));
  }

  if (camera) {
    params.push(...cameraParameters(camera));
  }

  const findings = identifyFindings(params, camera, ctx);
  const treatmentPathway = buildTreatmentPathway(params, camera);
  const recoverability = assessRecoverability(params);
  const reusePathways = assessReuse(recoverability.level, params);
  const resourceRecovery = assessResources(params, ctx);
  const preventionPlan = buildPrevention(findings);
  const needsVerification = buildVerification(params, camera);

  const paramCount = params.length;

  const uncertainty = paramCount === 0
    ? 'Very High — no measurements available'
    : camera && !sense && !card
    ? 'High — only visible characteristics assessed; no chemical or physical measurements'
    : sense && !card && !camera
    ? 'Moderate — electronic sensor data only; no chemical screening or visual assessment'
    : sense && card && !camera
    ? 'Low-Moderate — sensor + chemical data; no visual assessment'
    : sense && card && camera
    ? 'Low — comprehensive screening across all methods'
    : 'Moderate — limited screening data available';

  return {
    parameters: params,
    findings,
    treatmentPathway,
    recoverability: recoverability.level,
    recoverabilityReasoning: recoverability.reasoning,
    reusePathways,
    resourceRecovery,
    preventionPlan,
    needsVerification,
    uncertainty,
  };
}

export const recoverabilityMeta: Record<Recoverability, { label: string; color: string; description: string }> = {
  high: { label: 'High Recoverability', color: 'teal', description: 'Potentially treatable with appropriate treatment and verification' },
  moderate: { label: 'Moderate Recoverability', color: 'aqua', description: 'Recovery possible but requires additional testing or advanced treatment' },
  low: { label: 'Low Recoverability', color: 'amber', description: 'Technically difficult, energy-intensive, or uncertain' },
  'not-recommended': { label: 'Not Currently Recommended', color: 'coral', description: 'Insufficient information or indicates professional assessment required' },
};
