import { supabase, type WaterCreditTransaction, type BusinessSubscription, type ReWaterRevenue } from './supabase';

const DEMO_USER_ID = 'demo-user-local';
const DEMO_TX_KEY = 'rewater_demo_credit_transactions';

function isDemoUser(userId: string): boolean {
  return userId === DEMO_USER_ID;
}

function loadDemoTxns(): WaterCreditTransaction[] {
  try {
    const raw = localStorage.getItem(DEMO_TX_KEY);
    return raw ? (JSON.parse(raw) as WaterCreditTransaction[]) : [];
  } catch {
    return [];
  }
}

function saveDemoTxns(txns: WaterCreditTransaction[]): void {
  try {
    localStorage.setItem(DEMO_TX_KEY, JSON.stringify(txns));
  } catch { /* ignore */ }
}

// ── Configurable prototype partnership model ────────────────────
export const CREDIT_CONFIG = {
  partnershipShare: 0.20,
  creditUnitSizeLitres: 100,
  companySharePct: 70,
  hydrostationFundPct: 20,
  rewaterSharePct: 10,
} as const;

export const CREDIT_LABEL = `1 Water Credit = ${CREDIT_CONFIG.creditUnitSizeLitres} L of credit-eligible water (recovered water × ${Math.round(CREDIT_CONFIG.partnershipShare * 100)}% partnership share)`;

export interface CreditBalance {
  earned: number;
  donated: number;
  used: number;
  assigned: number;
  current: number;
}

export interface CreditCalculationResult {
  recoveryRate: number;
  creditEligibleLitres: number;
  creditsGenerated: number;
}

export function calculateRecoveryRate(inputLitres: number, recoveredLitres: number): number {
  if (inputLitres <= 0) return 0;
  return (recoveredLitres / inputLitres) * 100;
}

export function calculateCreditEligible(recoveredLitres: number, config: typeof CREDIT_CONFIG = CREDIT_CONFIG): number {
  return recoveredLitres * config.partnershipShare;
}

export function calculateCredits(recoveredLitres: number, config: typeof CREDIT_CONFIG = CREDIT_CONFIG): CreditCalculationResult {
  if (recoveredLitres <= 0) return { recoveryRate: 0, creditEligibleLitres: 0, creditsGenerated: 0 };
  const creditEligible = calculateCreditEligible(recoveredLitres, config);
  const credits = creditEligible / config.creditUnitSizeLitres;
  return {
    recoveryRate: 0,
    creditEligibleLitres: creditEligible,
    creditsGenerated: Math.round(credits * 100) / 100,
  };
}

export function calculateCreditsFromPassport(inputLitres: number, recoveredLitres: number, config: typeof CREDIT_CONFIG = CREDIT_CONFIG): CreditCalculationResult {
  const rate = calculateRecoveryRate(inputLitres, recoveredLitres);
  const result = calculateCredits(recoveredLitres, config);
  return { ...result, recoveryRate: rate };
}

// ── Transaction helpers ──────────────────────────────────────────
export async function fetchCreditTransactions(userId: string): Promise<WaterCreditTransaction[]> {
  if (isDemoUser(userId)) return loadDemoTxns();
  const { data, error } = await supabase
    .from('water_credit_transactions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) return [];
  return (data || []) as WaterCreditTransaction[];
}

export async function fetchCreditBalance(userId: string): Promise<CreditBalance> {
  const txns = await fetchCreditTransactions(userId);
  const earned = txns.filter(t => t.transaction_type === 'earned').reduce((s, t) => s + t.amount, 0);
  const donated = txns.filter(t => t.transaction_type === 'donated').reduce((s, t) => s + t.amount, 0);
  const used = txns.filter(t => t.transaction_type === 'used').reduce((s, t) => s + t.amount, 0);
  const assigned = txns.filter(t => t.transaction_type === 'assigned').reduce((s, t) => s + t.amount, 0);
  const current = earned - donated - used - assigned;
  return { earned, donated, used, assigned, current };
}

export async function recordCreditTransaction(params: {
  userId: string;
  type: WaterCreditTransaction['transaction_type'];
  amount: number;
  stationId?: string | null;
  stationName?: string | null;
  passportId?: string | null;
  sponsor?: string | null;
  initiative?: string | null;
  treatmentPartner?: string | null;
  verificationPartner?: string | null;
  netBenefitAed?: number | null;
  purpose?: string | null;
  description: string;
}): Promise<WaterCreditTransaction | null> {
  const { userId, type, amount } = params;
  const balance = await fetchCreditBalance(userId);
  const balanceAfter =
    type === 'earned' ? balance.current + amount :
    balance.current - amount;
  const creditsRemaining = type === 'earned' ? balanceAfter : Math.max(0, balanceAfter);

  const baseFields = {
    user_id: userId,
    transaction_type: type,
    amount,
    balance_after: balanceAfter,
    credits_remaining: creditsRemaining,
    station_id: params.stationId ?? null,
    station_name: params.stationName ?? null,
    passport_id: params.passportId ?? null,
    sponsor: params.sponsor ?? null,
    initiative: params.initiative ?? null,
    treatment_partner: params.treatmentPartner ?? null,
    verification_partner: params.verificationPartner ?? null,
    net_benefit_aed: params.netBenefitAed ?? null,
    purpose: params.purpose ?? null,
    description: params.description,
  };

  if (isDemoUser(userId)) {
    const tx: WaterCreditTransaction = {
      id: `demo-tx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      created_at: new Date().toISOString(),
      company_share_pct: CREDIT_CONFIG.companySharePct,
      hydrostation_fund_pct: CREDIT_CONFIG.hydrostationFundPct,
      rewater_share_pct: CREDIT_CONFIG.rewaterSharePct,
      ...baseFields,
    } as WaterCreditTransaction;
    const txns = loadDemoTxns();
    saveDemoTxns([tx, ...txns]);
    return tx;
  }

  const { data, error } = await supabase
    .from('water_credit_transactions')
    .insert(baseFields)
    .select('*')
    .single();
  if (error) {
    console.error('[recordCreditTransaction] insert failed:', error.message, error.details, error.hint);
    return null;
  }
  return data as WaterCreditTransaction;
}

// ── Full credit generation from a verified passport ──────────────
export async function generateCreditsFromPassport(params: {
  userId: string;
  passportId: string;
  inputLitres: number;
  recoveredLitres: number;
  sponsor: string;
  treatmentPartner: string;
  verificationPartner: string;
  stationId?: string | null;
  stationName?: string | null;
  initiative?: string | null;
}): Promise<CreditCalculationResult | null> {
  const calc = calculateCreditsFromPassport(params.inputLitres, params.recoveredLitres);
  const creditEligible = calc.creditEligibleLitres;

  const tx = await recordCreditTransaction({
    userId: params.userId,
    type: 'earned',
    amount: calc.creditsGenerated,
    passportId: params.passportId,
    sponsor: params.sponsor,
    treatmentPartner: params.treatmentPartner,
    verificationPartner: params.verificationPartner,
    purpose: `Credit-eligible: ${creditEligible.toFixed(1)} L (${params.recoveredLitres} L × ${Math.round(CREDIT_CONFIG.partnershipShare * 100)}%)`,
    description: `${calc.creditsGenerated} credits from ${params.passportId}: ${params.inputLitres} L input → ${params.recoveredLitres} L recovered (${calc.recoveryRate.toFixed(1)}%), ${creditEligible.toFixed(1)} L credit-eligible`,
  });
  if (!tx) return null;

  if (params.stationId && !isDemoUser(params.userId)) {
    const { data: station, error: stErr } = await supabase
      .from('hydro_stations')
      .select('credit_balance')
      .eq('id', params.stationId)
      .single();
    if (stErr) {
      console.error('[generateCredits] station fetch failed:', stErr.message);
    } else if (station) {
      const { error: updErr } = await supabase
        .from('hydro_stations')
        .update({ credit_balance: (station.credit_balance as number) + calc.creditsGenerated })
        .eq('id', params.stationId);
      if (updErr) console.error('[generateCredits] station update failed:', updErr.message);
    }
  }

  if (!isDemoUser(params.userId)) {
    const { error: ppErr } = await supabase.from('water_passports').update({
      input_water_litres: params.inputLitres,
      recovered_water_litres: params.recoveredLitres,
      treatment_loss_litres: params.inputLitres - params.recoveredLitres,
      recovery_rate: calc.recoveryRate,
      treatment_partner: params.treatmentPartner,
      verification_partner: params.verificationPartner,
      credit_eligible_litres: creditEligible,
      credits_generated: calc.creditsGenerated,
    }).eq('passport_id', params.passportId).eq('user_id', params.userId);
    if (ppErr) console.error('[generateCredits] passport update failed:', ppErr.message);
  }

  return calc;
}

export async function assignCreditsToStation(params: {
  userId: string;
  stationId: string;
  stationName: string;
  amount: number;
  sponsor?: string;
  initiative?: string;
  treatmentPartner?: string;
  verificationPartner?: string;
  netBenefitAed?: number | null;
}): Promise<boolean> {
  const tx = await recordCreditTransaction({
    userId: params.userId,
    type: 'assigned',
    amount: params.amount,
    stationId: params.stationId,
    stationName: params.stationName,
    sponsor: params.sponsor,
    initiative: params.initiative,
    treatmentPartner: params.treatmentPartner,
    verificationPartner: params.verificationPartner,
    netBenefitAed: params.netBenefitAed ?? null,
    purpose: `Assigned to ${params.stationName}`,
    description: `Credits assigned to ${params.stationName}`,
  });
  if (!tx) return false;
  if (isDemoUser(params.userId)) return true;

  const { data: station } = await supabase
    .from('hydro_stations')
    .select('credit_balance')
    .eq('id', params.stationId)
    .single();
  if (station) {
    await supabase
      .from('hydro_stations')
      .update({ credit_balance: (station.credit_balance as number) + params.amount })
      .eq('id', params.stationId);
  }
  return true;
}

export async function donateCreditsToStation(params: {
  userId: string;
  stationId: string;
  stationName: string;
  amount: number;
}): Promise<boolean> {
  const tx = await recordCreditTransaction({
    userId: params.userId,
    type: 'donated',
    amount: params.amount,
    stationId: params.stationId,
    stationName: params.stationName,
    description: `Donated credits to ${params.stationName}`,
  });
  if (!tx) return false;
  if (isDemoUser(params.userId)) return true;

  const { data: station } = await supabase
    .from('hydro_stations')
    .select('credit_balance')
    .eq('id', params.stationId)
    .single();
  if (station) {
    await supabase
      .from('hydro_stations')
      .update({ credit_balance: (station.credit_balance as number) + params.amount })
      .eq('id', params.stationId);
  }
  return true;
}

export async function dispenseWater(params: {
  userId: string;
  stationId: string;
  stationName: string;
  amountMl: number;
  creditsUsed: number;
  sponsor: string;
  initiative: string;
  treatmentPartner?: string;
  verificationPartner?: string;
}): Promise<boolean> {
  const { userId, stationId, amountMl, creditsUsed } = params;

  const tx = await recordCreditTransaction({
    userId,
    type: 'used',
    amount: creditsUsed,
    stationId,
    stationName: params.stationName,
    sponsor: params.sponsor,
    initiative: params.initiative,
    treatmentPartner: params.treatmentPartner,
    verificationPartner: params.verificationPartner,
    description: `${amountMl} mL dispensed at ${params.stationName}`,
  });
  if (!tx) return false;
  if (isDemoUser(userId)) return true;

  const { data: station } = await supabase
    .from('hydro_stations')
    .select('credit_balance, total_litres_dispensed, total_worker_visits')
    .eq('id', stationId)
    .single();
  if (station) {
    await supabase
      .from('hydro_stations')
      .update({
        credit_balance: Math.max(0, (station.credit_balance as number) - creditsUsed),
        total_litres_dispensed: (station.total_litres_dispensed || 0) + amountMl / 1000,
        total_worker_visits: (station.total_worker_visits || 0) + 1,
      })
      .eq('id', stationId);
  }

  await supabase.from('hydro_station_dispensing').insert({
    user_id: userId,
    station_id: stationId,
    station_name: params.stationName,
    amount_ml: amountMl,
    credits_used: creditsUsed,
    sponsor: params.sponsor,
    initiative: params.initiative,
    treatment_partner: params.treatmentPartner ?? null,
    verification_partner: params.verificationPartner ?? null,
  });

  return true;
}

// ── Business Subscriptions ───────────────────────────────────────
export const SUBSCRIPTION_PLANS = {
  free: {
    name: 'Free',
    price: 0,
    features: ['water_passports', 'water_journey'],
  },
  essential: {
    name: 'Essential',
    price: 299,
    features: ['water_passports', 'water_journey', 'water_credits', 'impact_reporting'],
  },
  professional: {
    name: 'Professional',
    price: 799,
    features: ['water_passports', 'water_journey', 'water_credits', 'impact_reporting', 'analytics', 'predictive_mapping', 'esg_export'],
  },
  enterprise: {
    name: 'Enterprise',
    price: 1999,
    features: ['water_passports', 'water_journey', 'water_credits', 'impact_reporting', 'analytics', 'predictive_mapping', 'esg_export', 'priority_support', 'custom_integrations'],
  },
} as const;

export type SubscriptionPlan = keyof typeof SUBSCRIPTION_PLANS;

export async function fetchSubscription(userId: string): Promise<BusinessSubscription | null> {
  const { data, error } = await supabase
    .from('business_subscriptions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .maybeSingle();
  if (error || !data) return null;
  return data as BusinessSubscription;
}

export async function updateSubscription(userId: string, plan: SubscriptionPlan): Promise<boolean> {
  const features = SUBSCRIPTION_PLANS[plan].features;
  const now = new Date();
  const trialEndsAt = plan !== 'free' ? new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString() : null;
  const { error } = await supabase
    .from('business_subscriptions')
    .upsert({
      user_id: userId,
      plan,
      status: 'active',
      features,
      started_at: now.toISOString(),
      trial_ends_at: trialEndsAt,
      cancelled_at: null,
      updated_at: now.toISOString(),
    }, { onConflict: 'user_id' });
  if (error) return false;

  if (plan !== 'free') {
    await recordReWaterRevenue({
      userId,
      source: 'subscription',
      amountAed: SUBSCRIPTION_PLANS[plan].price,
      description: `${SUBSCRIPTION_PLANS[plan].name} subscription (7-day free trial)`,
    });
  }
  return true;
}

export async function cancelSubscription(userId: string): Promise<boolean> {
  const { error } = await supabase
    .from('business_subscriptions')
    .update({
      status: 'cancelled',
      cancelled_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('user_id', userId);
  if (error) return false;
  return true;
}

export function isSubscriptionInTrial(sub: BusinessSubscription | null): boolean {
  if (!sub || sub.status !== 'active' || !sub.trial_ends_at) return false;
  return new Date(sub.trial_ends_at) > new Date();
}

export function trialDaysRemaining(sub: BusinessSubscription | null): number {
  if (!isSubscriptionInTrial(sub)) return 0;
  const ms = new Date(sub!.trial_ends_at!).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / (24 * 60 * 60 * 1000)));
}

export function hasFeatureAccess(sub: BusinessSubscription | null, feature: string): boolean {
  if (!sub || sub.status !== 'active') return feature === 'water_passports' || feature === 'water_journey';
  return sub.features.includes(feature);
}

// ── ReWater Revenue ──────────────────────────────────────────────
export async function recordReWaterRevenue(params: {
  userId: string;
  source: 'service_fee' | 'subscription' | 'transaction_fee';
  amountAed: number;
  passportId?: string | null;
  description: string;
}): Promise<void> {
  await supabase.from('rewater_revenue').insert({
    user_id: params.userId,
    source: params.source,
    amount_aed: params.amountAed,
    description: params.description,
    passport_id: params.passportId ?? null,
  });
}

export async function fetchReWaterRevenue(userId: string): Promise<ReWaterRevenue[]> {
  const { data, error } = await supabase
    .from('rewater_revenue')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) return [];
  return (data || []) as ReWaterRevenue[];
}
