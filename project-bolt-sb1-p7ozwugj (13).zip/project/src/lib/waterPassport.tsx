import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { WaterProfile, AnalysisContext } from './waterAnalysis';
import { supabase } from './supabase';
import { useAuth } from './auth';

export type MeasurementStatus = 'MEASURED' | 'ESTIMATED' | 'OBSERVED' | 'SIMULATED' | 'LAB_VERIFIED';

export type PassportStage =
  | 'collected'
  | 'identified'
  | 'profiled'
  | 'analyzed'
  | 'pathway_identified'
  | 'treated'
  | 'retest_required'
  | 'verified'
  | 'not_verified'
  | 'reuse_pathway';

export type PassportStatus = 'completed' | 'ongoing' | 'awaiting_retest' | 'treatment_required';

export type DataOrigin = 'aquasense' | 'aquacard' | 'camera' | 'manual' | 'lab' | 'simulated';

export interface PassportMeasurement {
  name: string;
  value: number;
  unit: string;
  status: MeasurementStatus;
  origin: DataOrigin;
}

export interface PassportEvent {
  timestamp: string;
  stage: PassportStage;
  label: string;
  detail: string;
}

export interface RetestRecord {
  timestamp: string;
  before: PassportMeasurement[];
  after: PassportMeasurement[];
  treatmentApplied: string;
  verified: boolean;
}

export interface WaterPassport {
  waterId: string;
  source: string;
  sourceType: string;
  collectionDate: string;
  quantity: number | null;
  unit: string;
  intendedUse: string;
  measurements: PassportMeasurement[];
  observations: string[];
  previousUses: string[];
  treatmentHistory: string[];
  recoveryHistory: string[];
  reuseHistory: string[];
  currentStage: PassportStage;
  recommendedPathway: string[];
  profile: WaterProfile | null;
  events: PassportEvent[];
  retests: RetestRecord[];
  lastUpdated: string;
  isDemo: boolean;
  dbId?: string;
  inputWaterLitres: number | null;
  recoveredWaterLitres: number | null;
  treatmentLossLitres: number | null;
  recoveryRate: number | null;
  treatmentPartner: string | null;
  verificationPartner: string | null;
  netBenefitAed: number | null;
  companyShareAed: number | null;
  hydrostationFundAed: number | null;
  rewaterShareAed: number | null;
  creditsGenerated: number | null;
  creditEligibleLitres: number | null;
}

export interface WaterPassportContextValue {
  passport: WaterPassport | null;
  passports: WaterPassport[];
  selectedId: string | null;
  loading: boolean;
  selectPassport: (id: string | null) => void;
  getPassport: (id: string) => WaterPassport | undefined;
  createPassport: (params: {
    source: string;
    sourceType: string;
    intendedUse: string;
    measurements: PassportMeasurement[];
    observations: string[];
    profile: WaterProfile | null;
    quantity?: number | null;
    unit?: string;
    isDemo?: boolean;
    inputWaterLitres?: number | null;
    recoveredWaterLitres?: number | null;
    treatmentPartner?: string | null;
    verificationPartner?: string | null;
  }) => WaterPassport;
  updatePassport: (id: string, updates: Partial<WaterPassport>) => void;
  addEvent: (id: string, stage: PassportStage, label: string, detail: string) => void;
  addRetest: (id: string, retest: RetestRecord) => void;
  setStage: (id: string, stage: PassportStage) => void;
  deletePassport: (id: string) => void;
  clearAll: () => void;
}

const STORAGE_KEY = 'rewater_passports';
const SEQ_KEY = 'rewater_passport_seq';

const WaterPassportContext = createContext<WaterPassportContextValue | undefined>(undefined);

function getNextSequence(): number {
  const stored = parseInt(localStorage.getItem(SEQ_KEY) || '0', 10);
  const next = stored + 1;
  localStorage.setItem(SEQ_KEY, String(next));
  return next;
}

export function generateWaterId(): string {
  const seq = getNextSequence();
  return `RW-WP-2026-${String(seq).padStart(5, '0')}`;
}

function deriveStatus(stage: PassportStage): PassportStatus {
  if (stage === 'verified' || stage === 'reuse_pathway') return 'completed';
  if (stage === 'retest_required') return 'awaiting_retest';
  if (stage === 'treated') return 'ongoing';
  if (stage === 'not_verified') return 'treatment_required';
  return 'ongoing';
}

function loadFromStorage(): WaterPassport[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as WaterPassport[];
  } catch {
    return [];
  }
}

function saveToStorage(passports: WaterPassport[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(passports));
  } catch {
    // localStorage may be unavailable
  }
}

const stageLabels: Record<PassportStage, string> = {
  collected: 'Water Collected',
  identified: 'Source Identified',
  profiled: 'Profile Created',
  analyzed: 'Analyzed',
  pathway_identified: 'Pathway Identified',
  treated: 'Treated',
  retest_required: 'Retest Required',
  verified: 'Verified',
  not_verified: 'Not Verified',
  reuse_pathway: 'Reuse Pathway',
};

export function stageLabel(stage: PassportStage): string {
  return stageLabels[stage] ?? stage;
}

export function stageOrder(stage: PassportStage): number {
  const order: PassportStage[] = [
    'collected', 'identified', 'profiled', 'analyzed',
    'pathway_identified', 'treated', 'retest_required',
    'verified', 'not_verified', 'reuse_pathway',
  ];
  return order.indexOf(stage);
}

export function passportStatusLabel(status: PassportStatus): string {
  switch (status) {
    case 'completed': return 'Completed';
    case 'ongoing': return 'Ongoing';
    case 'awaiting_retest': return 'Awaiting Retest';
    case 'treatment_required': return 'Treatment Required';
  }
}

export function passportStatusColor(status: PassportStatus): string {
  switch (status) {
    case 'completed': return 'bg-teal-100 text-teal-700';
    case 'ongoing': return 'bg-aqua-100 text-aqua-700';
    case 'awaiting_retest': return 'bg-amber-100 text-amber-700';
    case 'treatment_required': return 'bg-coral-100 text-coral-700';
  }
}

async function savePassportToDb(passport: WaterPassport, userId: string): Promise<string | null> {
  const status = deriveStatus(passport.currentStage);
  const payload = {
    user_id: userId,
    passport_id: passport.waterId,
    source: passport.source,
    source_type: passport.sourceType,
    collection_date: passport.collectionDate,
    quantity: passport.quantity,
    unit: passport.unit,
    intended_use: passport.intendedUse,
    status,
    current_stage: passport.currentStage,
    measurements: JSON.parse(JSON.stringify(passport.measurements)),
    profile: passport.profile ? JSON.parse(JSON.stringify(passport.profile)) : null,
    events: JSON.parse(JSON.stringify(passport.events)),
    recovery_history: passport.recoveryHistory,
    reuse_history: passport.reuseHistory,
    treatment_history: passport.treatmentHistory,
    is_demo: passport.isDemo,
    last_updated: new Date().toISOString(),
    input_water_litres: passport.inputWaterLitres,
    recovered_water_litres: passport.recoveredWaterLitres,
    treatment_loss_litres: passport.treatmentLossLitres,
    recovery_rate: passport.recoveryRate,
    treatment_partner: passport.treatmentPartner,
    verification_partner: passport.verificationPartner,
    net_benefit_aed: passport.netBenefitAed,
    company_share_aed: passport.companyShareAed,
    hydrostation_fund_aed: passport.hydrostationFundAed,
    rewater_share_aed: passport.rewaterShareAed,
    credits_generated: passport.creditsGenerated,
    credit_eligible_litres: passport.creditEligibleLitres,
  };

  if (passport.dbId) {
    const { data, error } = await supabase
      .from('water_passports')
      .update(payload)
      .eq('id', passport.dbId)
      .select('id')
      .single();
    if (!error && data) return data.id;
  }

  const { data, error } = await supabase
    .from('water_passports')
    .upsert(payload, { onConflict: 'passport_id' })
    .select('id')
    .single();
  if (!error && data) return data.id;
  return null;
}

async function loadPassportsFromDb(userId: string): Promise<WaterPassport[]> {
  const { data, error } = await supabase
    .from('water_passports')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error || !data) return [];
  return (data as Record<string, unknown>[]).map(row => dbRowToPassport(row));
}

function dbRowToPassport(row: Record<string, unknown>): WaterPassport {
  return {
    waterId: row.passport_id as string,
    source: row.source as string,
    sourceType: row.source_type as string,
    collectionDate: row.collection_date as string,
    quantity: (row.quantity as number) ?? null,
    unit: (row.unit as string) ?? 'L',
    intendedUse: (row.intended_use as string) ?? '',
    measurements: (row.measurements as PassportMeasurement[]) ?? [],
    observations: [],
    previousUses: [],
    treatmentHistory: (row.treatment_history as string[]) ?? [],
    recoveryHistory: (row.recovery_history as string[]) ?? [],
    reuseHistory: (row.reuse_history as string[]) ?? [],
    currentStage: (row.current_stage as PassportStage) ?? 'collected',
    recommendedPathway: [],
    profile: (row.profile as WaterProfile | null) ?? null,
    events: (row.events as PassportEvent[]) ?? [],
    retests: [],
    lastUpdated: (row.last_updated as string) ?? new Date().toISOString(),
    isDemo: (row.is_demo as boolean) ?? false,
    dbId: row.id as string,
    inputWaterLitres: (row.input_water_litres as number) ?? null,
    recoveredWaterLitres: (row.recovered_water_litres as number) ?? null,
    treatmentLossLitres: (row.treatment_loss_litres as number) ?? null,
    recoveryRate: (row.recovery_rate as number) ?? null,
    treatmentPartner: (row.treatment_partner as string) ?? null,
    verificationPartner: (row.verification_partner as string) ?? null,
    netBenefitAed: (row.net_benefit_aed as number) ?? null,
    companyShareAed: (row.company_share_aed as number) ?? null,
    hydrostationFundAed: (row.hydrostation_fund_aed as number) ?? null,
    rewaterShareAed: (row.rewater_share_aed as number) ?? null,
    creditsGenerated: (row.credits_generated as number) ?? null,
    creditEligibleLitres: (row.credit_eligible_litres as number) ?? null,
  };
}

export function WaterPassportProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [passports, setPassports] = useState<WaterPassport[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setPassports([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    loadPassportsFromDb(user.id).then(dbPassports => {
      if (dbPassports.length > 0) {
        setPassports(dbPassports);
        const maxSeq = dbPassports.reduce((max, p) => {
          const m = p.waterId.match(/(\d+)$/);
          return m ? Math.max(max, parseInt(m[1], 10)) : max;
        }, 0);
        if (maxSeq > 0) localStorage.setItem(SEQ_KEY, String(maxSeq));
      } else {
        const local = loadFromStorage();
        setPassports(local);
      }
      setLoading(false);
    });
  }, [user]);

  const createPassport = useCallback((params: {
    source: string;
    sourceType: string;
    intendedUse: string;
    measurements: PassportMeasurement[];
    observations: string[];
    profile: WaterProfile | null;
    quantity?: number | null;
    unit?: string;
    isDemo?: boolean;
    inputWaterLitres?: number | null;
    recoveredWaterLitres?: number | null;
    treatmentPartner?: string | null;
    verificationPartner?: string | null;
  }): WaterPassport => {
    const now = new Date().toISOString();
    const id = generateWaterId();
    const recommendedPathway = params.profile?.treatmentPathway.map(s => s.name) ?? [];
    const inputLitres = params.inputWaterLitres ?? params.quantity ?? null;
    const recoveredLitres = params.recoveredWaterLitres ?? null;
    const lossLitres = inputLitres != null && recoveredLitres != null ? inputLitres - recoveredLitres : null;
    const rate = inputLitres != null && recoveredLitres != null && inputLitres > 0 ? (recoveredLitres / inputLitres) * 100 : null;
    const passport: WaterPassport = {
      waterId: id,
      source: params.source,
      sourceType: params.sourceType,
      collectionDate: now,
      quantity: params.quantity ?? null,
      unit: params.unit ?? 'L',
      intendedUse: params.intendedUse,
      measurements: params.measurements,
      observations: params.observations,
      previousUses: [],
      treatmentHistory: [],
      recoveryHistory: [],
      reuseHistory: [],
      currentStage: 'collected',
      recommendedPathway,
      profile: params.profile,
      events: [
        { timestamp: now, stage: 'collected', label: 'Water collected', detail: `Source: ${params.source}` },
        { timestamp: now, stage: 'identified', label: 'Source identified', detail: `Type: ${params.sourceType}` },
      ],
      retests: [],
      lastUpdated: now,
      isDemo: params.isDemo ?? true,
      inputWaterLitres: inputLitres,
      recoveredWaterLitres: recoveredLitres,
      treatmentLossLitres: lossLitres,
      recoveryRate: rate,
      treatmentPartner: params.treatmentPartner ?? null,
      verificationPartner: params.verificationPartner ?? null,
      netBenefitAed: null,
      companyShareAed: null,
      hydrostationFundAed: null,
      rewaterShareAed: null,
      creditsGenerated: null,
      creditEligibleLitres: null,
    };
    setPassports(prev => [passport, ...prev]);
    saveToStorage([passport, ...passports]);
    if (user) savePassportToDb(passport, user.id);
    return passport;
  }, [user]);

  const updatePassport = useCallback((id: string, updates: Partial<WaterPassport>) => {
    setPassports(prev => {
      const next = prev.map(p =>
        p.waterId === id ? { ...p, ...updates, lastUpdated: new Date().toISOString() } : p
      );
      saveToStorage(next);
      const updated = next.find(p => p.waterId === id);
      if (updated && user) savePassportToDb(updated, user.id);
      return next;
    });
  }, [user]);

  const addEvent = useCallback((id: string, stage: PassportStage, label: string, detail: string) => {
    const event: PassportEvent = {
      timestamp: new Date().toISOString(),
      stage,
      label,
      detail,
    };
    setPassports(prev => {
      const next = prev.map(p =>
        p.waterId === id
          ? { ...p, events: [...p.events, event], currentStage: stage, lastUpdated: new Date().toISOString() }
          : p
      );
      saveToStorage(next);
      const updated = next.find(p => p.waterId === id);
      if (updated && user) savePassportToDb(updated, user.id);
      return next;
    });
  }, [user]);

  const addRetest = useCallback((id: string, retest: RetestRecord) => {
    setPassports(prev => {
      const next = prev.map(p =>
        p.waterId === id
          ? {
              ...p,
              retests: [...p.retests, retest],
              currentStage: (retest.verified ? 'verified' : 'not_verified') as PassportStage,
              lastUpdated: new Date().toISOString(),
              events: [...p.events, {
                timestamp: retest.timestamp,
                stage: (retest.verified ? 'verified' : 'not_verified') as PassportStage,
                label: retest.verified ? 'Retest verified' : 'Retest recorded',
                detail: `Treatment: ${retest.treatmentApplied}`,
              }],
            }
          : p
      );
      saveToStorage(next);
      const updated = next.find(p => p.waterId === id);
      if (updated && user) savePassportToDb(updated, user.id);
      return next;
    });
  }, [user]);

  const setStage = useCallback((id: string, stage: PassportStage) => {
    setPassports(prev => {
      const next = prev.map(p =>
        p.waterId === id ? { ...p, currentStage: stage, lastUpdated: new Date().toISOString() } : p
      );
      saveToStorage(next);
      const updated = next.find(p => p.waterId === id);
      if (updated && user) savePassportToDb(updated, user.id);
      return next;
    });
  }, [user]);

  const deletePassport = useCallback((id: string) => {
    setPassports(prev => {
      const next = prev.filter(p => p.waterId !== id);
      saveToStorage(next);
      return next;
    });
    setSelectedId(prev => prev === id ? null : prev);
    if (user) {
      supabase.from('water_passports').delete().eq('passport_id', id).eq('user_id', user.id);
    }
  }, [user]);

  const clearAll = useCallback(() => {
    setPassports([]);
    setSelectedId(null);
    saveToStorage([]);
  }, []);

  const selectPassport = useCallback((id: string | null) => {
    setSelectedId(id);
  }, []);

  const getPassport = useCallback((id: string): WaterPassport | undefined => {
    return passports.find(p => p.waterId === id);
  }, [passports]);

  const latest = passports[0] ?? null;
  const passport = selectedId ? getPassport(selectedId) ?? latest : latest;

  return (
    <WaterPassportContext.Provider value={{
      passport,
      passports,
      selectedId,
      loading,
      selectPassport,
      getPassport,
      createPassport,
      updatePassport,
      addEvent,
      addRetest,
      setStage,
      deletePassport,
      clearAll,
    }}>
      {children}
    </WaterPassportContext.Provider>
  );
}

export function useWaterPassport(): WaterPassportContextValue {
  const ctx = useContext(WaterPassportContext);
  if (!ctx) throw new Error('useWaterPassport must be used within WaterPassportProvider');
  return ctx;
}

export function statusLabel(status: MeasurementStatus): string {
  return status.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

export function statusColor(status: MeasurementStatus): string {
  switch (status) {
    case 'MEASURED': return 'teal';
    case 'LAB_VERIFIED': return 'teal';
    case 'ESTIMATED': return 'aqua';
    case 'OBSERVED': return 'aqua';
    case 'SIMULATED': return 'amber';
    default: return 'slatey';
  }
}

export function getAnalysisContext(passport: Pick<WaterPassport, 'source' | 'sourceType' | 'intendedUse'>): AnalysisContext {
  return {
    sourceName: passport.source,
    sourceType: passport.sourceType,
    intendedUse: passport.intendedUse,
  };
}
