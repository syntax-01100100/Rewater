import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { supabase } from './supabase';

export interface AuthUser {
  id: string;
  email: string;
  isDemo: boolean;
}

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  signInDemo: () => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const DEMO_USER: AuthUser = {
  id: 'demo-user-local',
  email: 'demo@rewater.ae',
  isDemo: true,
};

const DEMO_STORAGE_KEY = 'rewater_demo_session';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for local demo session first
    const demoSession = localStorage.getItem(DEMO_STORAGE_KEY);
    if (demoSession === 'true') {
      setUser(DEMO_USER);
      setLoading(false);
      return;
    }

    // Then check Supabase session
    supabase.auth.getSession().then(({ data }) => {
      if (data.session?.user) {
        setUser({ id: data.session.user.id, email: data.session.user.email || '', isDemo: false });
      }
      setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      // Don't override demo session
      if (localStorage.getItem(DEMO_STORAGE_KEY) === 'true') return;

      if (session?.user) {
        setUser({ id: session.user.id, email: session.user.email || '', isDemo: false });
      } else {
        setUser(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    return { error: null };
  };

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };
    return { error: null };
  };

  const signOut = async () => {
    // Clear demo session
    localStorage.removeItem(DEMO_STORAGE_KEY);
    // Also sign out of Supabase in case there's a session
    await supabase.auth.signOut();
    setUser(null);
  };

  const signInDemo = async () => {
    // Pure local demo — no Supabase involved
    localStorage.setItem(DEMO_STORAGE_KEY, 'true');
    setUser(DEMO_USER);
    return { error: null };
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, signInDemo }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
