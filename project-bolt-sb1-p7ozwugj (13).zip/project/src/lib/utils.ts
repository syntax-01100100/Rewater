export const sourceTypeLabels: Record<string, string> = {
  groundwater: 'Groundwater',
  surface: 'Surface Water',
  rainwater: 'Rainwater',
  wastewater: 'Wastewater',
  greywater: 'Greywater',
  condensate: 'AC Condensate',
  stormwater: 'Stormwater',
  seawater: 'Seawater',
  atmospheric: 'Atmospheric',
};

export const sourceTypeColors: Record<string, string> = {
  groundwater: '#48B7A5',
  surface: '#1FA7C8',
  rainwater: '#5E9BBF',
  wastewater: '#F2B84B',
  greywater: '#97C2D9',
  condensate: '#C2EAE3',
  stormwater: '#2E77A0',
  seawater: '#063B5C',
  atmospheric: '#E6F7FB',
};

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function formatRelative(dateStr: string): string {
  const d = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffHrs / 24);
  if (diffHrs < 1) return 'Just now';
  if (diffHrs < 24) return `${diffHrs}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(dateStr);
}

export function phLabel(ph: number): { label: string; color: string } {
  if (ph < 6.5) return { label: 'Acidic', color: 'coral' };
  if (ph > 8.5) return { label: 'Alkaline', color: 'amber' };
  return { label: 'Neutral', color: 'teal' };
}

export function turbidityLabel(t: number): { label: string; color: string } {
  if (t < 1) return { label: 'Clear', color: 'teal' };
  if (t < 5) return { label: 'Slight', color: 'aqua' };
  if (t < 10) return { label: 'Cloudy', color: 'amber' };
  return { label: 'Very Cloudy', color: 'coral' };
}

export function tdsLabel(tds: number): { label: string; color: string } {
  if (tds < 50) return { label: 'Very Low', color: 'aqua' };
  if (tds < 300) return { label: 'Low', color: 'teal' };
  if (tds < 600) return { label: 'Moderate', color: 'aqua' };
  if (tds < 1000) return { label: 'High', color: 'amber' };
  return { label: 'Very High', color: 'coral' };
}

export function generateAIInterpretation(sample: {
  ph: number | null;
  temperature: number | null;
  turbidity: number | null;
  tds: number | null;
  nitrate: number | null;
  hardness: number | null;
  chlorine: number | null;
}): {
  findings: { title: string; detail: string; confidence: string; level: string }[];
  recommendations: string[];
  reusePotential: string;
  treatmentPathway: string[];
  uncertainty: string;
} {
  const findings: { title: string; detail: string; confidence: string; level: string }[] = [];
  const recommendations: string[] = [];
  const treatmentPathway: string[] = [];
  let reusePotential = 'Requires further assessment';
  let uncertainty = 'Moderate — based on screening parameters only';

  if (sample.ph !== null) {
    if (sample.ph < 6.5) {
      findings.push({
        title: 'pH is below neutral range',
        detail: `Measured pH of ${sample.ph} suggests acidic conditions. This could be consistent with acid rain influence, certain geological conditions, or industrial discharge nearby.`,
        confidence: 'Medium',
        level: 'warning',
      });
      recommendations.push('Investigate source of acidity — check upstream industrial or natural factors');
      treatmentPathway.push('pH neutralization (dosing with alkaline agent)');
    } else if (sample.ph > 8.5) {
      findings.push({
        title: 'pH is above neutral range',
        detail: `Measured pH of ${sample.ph} suggests alkaline conditions. Common in mineral-rich groundwater or areas with limestone geology.`,
        confidence: 'Medium',
        level: 'warning',
      });
      recommendations.push('Check if mineral content is within acceptable range for intended use');
      treatmentPathway.push('Acid dosing or blending with lower-pH source');
    } else {
      findings.push({
        title: 'pH is within normal range',
        detail: `Measured pH of ${sample.ph} is within the typical neutral range (6.5–8.5) for most natural waters.`,
        confidence: 'High',
        level: 'good',
      });
    }
  }

  if (sample.turbidity !== null) {
    if (sample.turbidity > 5) {
      findings.push({
        title: 'Turbidity is elevated',
        detail: `Turbidity of ${sample.turbidity} NTU indicates significant suspended particles. This could suggest sediment disturbance, surface runoff, or biological activity.`,
        confidence: 'Medium',
        level: 'warning',
      });
      recommendations.push('Investigate possible upstream sediment or contamination sources');
      treatmentPathway.push('Particle removal (sedimentation + filtration)');
    } else {
      findings.push({
        title: 'Turbidity is low',
        detail: `Turbidity of ${sample.turbidity} NTU indicates relatively clear water with minimal suspended particles.`,
        confidence: 'High',
        level: 'good',
      });
    }
  }

  if (sample.tds !== null) {
    if (sample.tds > 1000) {
      findings.push({
        title: 'TDS is high',
        detail: `TDS of ${sample.tds} mg/L indicates high dissolved solids. This may be brackish water or mineral-rich groundwater. TDS is estimated from conductivity and should be labelled as such.`,
        confidence: 'Medium',
        level: 'warning',
      });
      recommendations.push('Consider reverse osmosis or desalination if intended for drinking');
      treatmentPathway.push('Desalination (reverse osmosis or distillation)');
      treatmentPathway.push('Mineral/recovery from concentrate stream');
    } else if (sample.tds < 100) {
      findings.push({
        title: 'TDS is very low',
        detail: `TDS of ${sample.tds} mg/L indicates very low mineral content. This is typical of rainwater, condensate, or highly purified water.`,
        confidence: 'High',
        level: 'info',
      });
      reusePotential = 'Good — suitable for non-potable reuse with minimal treatment';
    } else {
      findings.push({
        title: 'TDS is within moderate range',
        detail: `TDS of ${sample.tds} mg/L is within a moderate range typical of many natural freshwater sources.`,
        confidence: 'High',
        level: 'good',
      });
      reusePotential = 'Good — suitable for irrigation or industrial reuse with basic treatment';
    }
  }

  if (sample.nitrate !== null && sample.nitrate > 10) {
    findings.push({
      title: 'Nitrate is elevated',
      detail: `Nitrate of ${sample.nitrate} mg/L may indicate agricultural runoff, fertilizer leaching, or sewage contamination.`,
      confidence: 'Medium',
      level: 'warning',
    });
    recommendations.push('Test for nitrite and other nitrogen compounds');
    recommendations.push('Investigate upstream agricultural or sewage sources');
    treatmentPathway.push('Biological treatment (denitrification)');
  }

  if (sample.hardness !== null && sample.hardness > 200) {
    findings.push({
      title: 'Hardness is high',
      detail: `Hardness of ${sample.hardness} mg/L indicates high calcium and magnesium content. This is common in mineral-rich groundwater.`,
      confidence: 'High',
      level: 'info',
    });
    treatmentPathway.push('Softening (ion exchange or lime softening)');
  }

  if (findings.length === 0) {
    findings.push({
      title: 'Insufficient data for assessment',
      detail: 'No measurements were recorded. Use AquaSense or AquaCard to collect water quality data.',
      confidence: 'N/A',
      level: 'info',
    });
    uncertainty = 'High — no measurements available';
  }

  if (treatmentPathway.length === 0) {
    treatmentPathway.push('Basic screening and monitoring');
    reusePotential = 'Potentially suitable for direct non-potable reuse';
  }

  recommendations.push('This screening does not certify water as safe to drink');
  recommendations.push('For drinking water assessment, validated laboratory testing is required');

  return {
    findings,
    recommendations,
    reusePotential,
    treatmentPathway,
    uncertainty,
  };
}

export function calculateCircularityScore(inputs: {
  waterDemand: number;
  rainfall: number;
  catchmentArea: number;
  acCondensate: number;
  wastewater: number;
  greywater: number;
  renewableEnergy: number;
}): {
  recoveredWater: number;
  freshwaterAvoided: number;
  byProductReduction: number;
  energyNeeds: number;
  circularityScore: number;
  sdg: Record<string, number>;
} {
  const rainwaterCaptured = inputs.rainfall * inputs.catchmentArea * 0.8;
  const greywaterReused = inputs.greywater * 0.7;
  const wastewaterReused = inputs.wastewater * 0.6;
  const acCollected = inputs.acCondensate;

  const recoveredWater = rainwaterCaptured + greywaterReused + wastewaterReused + acCollected;
  const freshwaterAvoided = Math.min(recoveredWater, inputs.waterDemand);
  const byProductReduction = (greywaterReused + wastewaterReused) * 0.3;
  const energyNeeds = recoveredWater * 0.5 - inputs.renewableEnergy;
  const circularityScore = inputs.waterDemand > 0
    ? Math.min(100, Math.round((recoveredWater / inputs.waterDemand) * 100))
    : 0;

  const sdg = {
    sdg6: Math.min(100, circularityScore + 10),
    sdg9: Math.min(100, Math.round((inputs.renewableEnergy / Math.max(1, energyNeeds)) * 60)),
    sdg11: Math.min(100, circularityScore),
    sdg12: Math.min(100, Math.round((byProductReduction / Math.max(1, inputs.wastewater + inputs.greywater)) * 100)),
    sdg13: Math.min(100, Math.round((recoveredWater / Math.max(1, inputs.waterDemand)) * 70)),
    sdg14: Math.min(100, Math.round((wastewaterReused / Math.max(1, inputs.wastewater)) * 80)),
    sdg15: Math.min(100, circularityScore - 5),
  };

  return {
    recoveredWater: Math.round(recoveredWater),
    freshwaterAvoided: Math.round(freshwaterAvoided),
    byProductReduction: Math.round(byProductReduction),
    energyNeeds: Math.round(Math.max(0, energyNeeds)),
    circularityScore,
    sdg,
  };
}

export function formatNumber(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return n.toLocaleString();
}

export const sdgInfo: Record<string, { title: string; color: string; description: string }> = {
  sdg6: { title: 'Clean Water & Sanitation', color: '#26BDE2', description: 'Water quality, reuse and resource recovery' },
  sdg9: { title: 'Industry, Innovation & Infrastructure', color: '#FD6925', description: 'Sensors, AI and circular infrastructure' },
  sdg11: { title: 'Sustainable Cities & Communities', color: '#FD9D24', description: 'Urban water circularity' },
  sdg12: { title: 'Responsible Consumption & Production', color: '#BF8B2E', description: 'Recover resources instead of waste' },
  sdg13: { title: 'Climate Action', color: '#3F7E44', description: 'Efficiency and lower resource waste' },
  sdg14: { title: 'Life Below Water', color: '#0A97D9', description: 'Reduce harmful discharges and marine impacts' },
  sdg15: { title: 'Life on Land', color: '#56C02B', description: 'Reduce water-related environmental pressure' },
};
