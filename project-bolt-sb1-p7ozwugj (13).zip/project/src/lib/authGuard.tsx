import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { useAuth } from './auth';

interface AuthGuardContextValue {
  requireAuth: (feature: string, onAuthed: () => void) => void;
  pendingFeature: string | null;
  authedCallback: (() => void) | null;
  dismiss: () => void;
  triggerAuth: (mode: 'signin' | 'signup') => void;
  showGuard: boolean;
  requestedMode: 'signin' | 'signup';
}

const AuthGuardContext = createContext<AuthGuardContextValue | undefined>(undefined);

export function AuthGuardProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [pendingFeature, setPendingFeature] = useState<string | null>(null);
  const [authedCallback, setAuthedCallback] = useState<(() => void) | null>(null);
  const [showGuard, setShowGuard] = useState(false);
  const [requestedMode, setRequestedMode] = useState<'signin' | 'signup'>('signin');

  const requireAuth = useCallback((feature: string, onAuthed: () => void) => {
    if (user) {
      onAuthed();
      return;
    }
    setPendingFeature(feature);
    setAuthedCallback(() => onAuthed);
    setShowGuard(true);
  }, [user]);

  const dismiss = useCallback(() => {
    setShowGuard(false);
    setPendingFeature(null);
    setAuthedCallback(null);
  }, []);

  const triggerAuth = useCallback((mode: 'signin' | 'signup') => {
    setShowGuard(false);
    setPendingFeature(null);
    setRequestedMode(mode);
  }, []);

  return (
    <AuthGuardContext.Provider value={{
      requireAuth,
      pendingFeature,
      authedCallback,
      dismiss,
      triggerAuth,
      showGuard,
      requestedMode,
    }}>
      {children}
    </AuthGuardContext.Provider>
  );
}

export function useAuthGuard(): AuthGuardContextValue {
  const ctx = useContext(AuthGuardContext);
  if (!ctx) throw new Error('useAuthGuard must be used within AuthGuardProvider');
  return ctx;
}
