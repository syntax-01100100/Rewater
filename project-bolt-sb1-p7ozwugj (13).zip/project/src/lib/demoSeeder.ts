import { useEffect, useRef } from 'react';
import { useAuth } from './auth';

const DEMO_SEED_KEY = 'rewater_demo_seeded';

export function useDemoSeeder() {
  const { user } = useAuth();
  const hasSeeded = useRef(false);

  useEffect(() => {
    if (!user || hasSeeded.current) return;
    if (!user.isDemo) return;

    // Only mark that we've seen this demo session. No auto-creating passports.
    const alreadySeeded = localStorage.getItem(DEMO_SEED_KEY);
    if (alreadySeeded) {
      hasSeeded.current = true;
      return;
    }

    localStorage.setItem(DEMO_SEED_KEY, 'true');
    hasSeeded.current = true;
  }, [user]);
}

export function clearDemoSeed() {
  localStorage.removeItem(DEMO_SEED_KEY);
}
