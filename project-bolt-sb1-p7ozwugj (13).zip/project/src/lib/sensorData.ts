// Sensor Data Abstraction Layer
// Decouples sensor data from UI components so the future AquaSense
// hardware can be connected without rebuilding the frontend.

import { supabase } from './supabase';

export interface SensorReading {
  id: string;
  device_id: string;
  sample_id: string | null;
  passport_id: string | null;
  timestamp: string;
  ph: number | null;
  tds: number | null;
  ec: number | null;
  turbidity: number | null;
  temperature: number | null;
  source: string | null;
  status: string;
  calibration_info: Record<string, unknown> | null;
  is_simulated: boolean;
  created_at: string;
}

export type DeviceStatus = 'connected' | 'disconnected' | 'error' | 'future';

export interface DeviceState {
  status: DeviceStatus;
  deviceId: string | null;
  lastReading: SensorReading | null;
  isLoading: boolean;
  error: string | null;
}

export const FUTURE_DEVICE_STATE: DeviceState = {
  status: 'future',
  deviceId: null,
  lastReading: null,
  isLoading: false,
  error: null,
};

export const DISCONNECTED_STATE: DeviceState = {
  status: 'disconnected',
  deviceId: null,
  lastReading: null,
  isLoading: false,
  error: null,
};

// Fetch the latest reading for a device
export async function fetchLatestReading(deviceId: string): Promise<SensorReading | null> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .select('*')
    .eq('device_id', deviceId)
    .eq('is_simulated', false)
    .order('timestamp', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) return null;
  return data as SensorReading | null;
}

// Fetch the latest real AquaSense reading linked to a specific Water Passport
export async function fetchLatestReadingForPassport(passportId: string): Promise<SensorReading | null> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .select('*')
    .eq('passport_id', passportId)
    .eq('is_simulated', false)
    .order('timestamp', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) return null;
  return data as SensorReading | null;
}

// Fetch reading history for a specific Water Passport (real readings only)
export async function fetchReadingHistoryForPassport(passportId: string, limit = 20): Promise<SensorReading[]> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .select('*')
    .eq('passport_id', passportId)
    .eq('is_simulated', false)
    .order('timestamp', { ascending: false })
    .limit(limit);

  if (error) return [];
  return (data || []) as SensorReading[];
}

// Fetch reading history for a device
export async function fetchReadingHistory(deviceId: string, limit = 20): Promise<SensorReading[]> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .select('*')
    .eq('device_id', deviceId)
    .eq('is_simulated', false)
    .order('timestamp', { ascending: false })
    .limit(limit);

  if (error) return [];
  return (data || []) as SensorReading[];
}

// Save a real reading from the device (future ESP32 API will use this path)
export async function saveSensorReading(
  reading: Omit<SensorReading, 'id' | 'created_at'>
): Promise<SensorReading | null> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .insert(reading)
    .select('*')
    .single();

  if (error) return null;
  return data as SensorReading;
}

// Check if any real (non-simulated) AquaSense reading exists for a passport
export async function hasRealReadingsForPassport(passportId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('sensor_readings')
    .select('*', { count: 'exact', head: true })
    .eq('passport_id', passportId)
    .eq('is_simulated', false)
    .eq('source', 'aquasense-esp32');

  if (error) return false;
  return (count || 0) > 0;
}

// Save a simulated reading (clearly flagged as simulated)
export async function saveSimulatedReading(
  reading: Omit<SensorReading, 'id' | 'created_at' | 'is_simulated'> & { is_simulated?: boolean }
): Promise<SensorReading | null> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .insert({ ...reading, is_simulated: true })
    .select('*')
    .single();

  if (error) return null;
  return data as SensorReading;
}

// Check if any real (non-simulated) reading exists for a device
export async function hasRealReadings(deviceId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('sensor_readings')
    .select('*', { count: 'exact', head: true })
    .eq('device_id', deviceId)
    .eq('is_simulated', false);

  if (error) return false;
  return (count || 0) > 0;
}

export const DEVICE_STATUS_LABELS: Record<DeviceStatus, string> = {
  connected: 'Connected',
  disconnected: 'Not Connected',
  error: 'Connection Error',
  future: 'Future Hardware',
};

export const DEVICE_STATUS_COLORS: Record<DeviceStatus, string> = {
  connected: '#2E9D8C',
  disconnected: '#94A3B8',
  error: '#E8734B',
  future: '#F2B84B',
};
