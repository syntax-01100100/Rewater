import type { WaterSample } from '@/lib/supabase';

const STORAGE_KEY = 'rewater_local_samples';

export function loadLocalSamples(): WaterSample[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as WaterSample[];
  } catch {
    return [];
  }
}

export function saveLocalSample(sample: WaterSample): void {
  try {
    const existing = loadLocalSamples();
    localStorage.setItem(STORAGE_KEY, JSON.stringify([sample, ...existing]));
  } catch {
    // localStorage may be unavailable
  }
}

export function clearLocalSamples(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

let localIdCounter = 0;

export function generateLocalId(): string {
  localIdCounter += 1;
  return `local-${Date.now()}-${localIdCounter}`;
}
