import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface WaterSource {
  id: string;
  name: string;
  type: string;
  latitude: number;
  longitude: number;
  quality: string | null;
  ph: number | null;
  turbidity: number | null;
  tds: number | null;
  temperature: number | null;
  status: string;
  description: string | null;
  is_hidden_water: boolean;
  recovery_potential: string | null;
  created_at: string;
}

export interface WaterSample {
  id: string;
  source_name: string;
  source_type: string;
  ph: number | null;
  temperature: number | null;
  turbidity: number | null;
  tds: number | null;
  ec: number | null;
  nitrate: number | null;
  nitrite: number | null;
  hardness: number | null;
  chlorine: number | null;
  notes: string | null;
  ai_interpretation: Record<string, unknown> | null;
  status: string;
  card_type: string | null;
  image_url: string | null;
  cam_colour: string | null;
  cam_cloudiness: string | null;
  cam_visible_particles: boolean | null;
  cam_sediment: boolean | null;
  cam_foam: boolean | null;
  cam_oil_appearance: boolean | null;
  cam_surface_appearance: string | null;
  cam_confidence: string | null;
  intended_use: string | null;
  before_sample_id: string | null;
  created_at: string;
}

export interface WaterBrand {
  id: string;
  name: string;
  brand: string;
  source: string | null;
  ph: number | null;
  calcium: number | null;
  magnesium: number | null;
  sodium: number | null;
  potassium: number | null;
  bicarbonate: number | null;
  sulfate: number | null;
  chloride: number | null;
  nitrate: number | null;
  tds: number | null;
  fluorine: number | null;
  country: string | null;
  description: string | null;
  created_at: string;
}

export interface Alert {
  id: string;
  sample_id: string | null;
  type: string;
  parameter: string;
  message: string;
  severity: string;
  acknowledged: boolean;
  created_at: string;
}

export interface Scenario {
  id: string;
  name: string;
  type: string;
  water_demand: number;
  rainfall: number;
  catchment_area: number;
  ac_condensate: number;
  wastewater: number;
  greywater: number;
  renewable_energy: number;
  recovered_water: number;
  freshwater_avoided: number;
  circularity_score: number;
  sdg_contribution: Record<string, number> | null;
  notes: string | null;
  created_at: string;
}

export interface ImpactRecord {
  id: string;
  water_recovered: number;
  freshwater_avoided: number;
  resources_recovered: number;
  samples_monitored: number;
  contamination_trends: number;
  by_products_identified: number;
  brine_recovery: number;
  ac_condensate_recovered: number;
  rainwater_captured: number;
  energy_used: number;
  sdg: Record<string, number> | null;
  notes: string | null;
  created_at: string;
}

export interface TreatmentRecord {
  id: string;
  sample_id: string | null;
  pathway: string;
  before_ph: number | null;
  after_ph: number | null;
  before_turbidity: number | null;
  after_turbidity: number | null;
  before_tds: number | null;
  after_tds: number | null;
  water_recovered: number | null;
  by_products: string | null;
  energy_required: number | null;
  status: string;
  notes: string | null;
  created_at: string;
}

export interface SensorReading {
  id: string;
  device_id: string;
  sample_id: string | null;
  passport_id: string | null;
  timestamp: string;
  ph: number | null;
  tds: number | null;
  ec: number | null;
  turbidity: number | null;
  temperature: number | null;
  source: string | null;
  status: string;
  calibration_info: Record<string, unknown> | null;
  is_simulated: boolean;
  created_at: string;
}

export interface HydroStation {
  id: string;
  user_id: string;
  station_id: string;
  name: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  water_status: string;
  safe_water_supply: string;
  supported_initiative: string;
  sponsor_company: string;
  credit_balance: number;
  total_litres_dispensed: number;
  total_worker_visits: number;
  program_hydration_rate: number;
  dispense_cost_250ml: number;
  dispense_cost_500ml: number;
  dispense_cost_750ml: number;
  dispense_cost_1l: number;
  minimum_balance: number;
  created_at: string;
}

export interface HydroStationVisit {
  id: string;
  station_id: string;
  user_id: string;
  worker_token: string;
  litres_dispensed: number;
  visit_date: string;
  created_at: string;
}

export interface WaterCreditTransaction {
  id: string;
  user_id: string;
  transaction_type: 'earned' | 'donated' | 'used' | 'assigned';
  amount: number;
  balance_after: number;
  station_id: string | null;
  station_name: string | null;
  passport_id: string | null;
  sponsor: string | null;
  initiative: string | null;
  description: string;
  created_at: string;
  treatment_partner: string | null;
  verification_partner: string | null;
  net_benefit_aed: number | null;
  company_share_pct: number;
  hydrostation_fund_pct: number;
  rewater_share_pct: number;
  credits_remaining: number | null;
  purpose: string | null;
}

export interface HydroStationDispensing {
  id: string;
  user_id: string;
  station_id: string;
  station_name: string;
  amount_ml: number;
  credits_used: number;
  sponsor: string;
  initiative: string;
  worker_token: string | null;
  treatment_partner: string | null;
  verification_partner: string | null;
  dispensed_at: string;
  created_at: string;
}

export interface WaterPassportRecord {
  id: string;
  user_id: string;
  passport_id: string;
  source: string;
  source_type: string;
  collection_date: string;
  quantity: number | null;
  unit: string;
  intended_use: string;
  status: 'completed' | 'ongoing' | 'awaiting_retest' | 'treatment_required';
  current_stage: string;
  measurements: Record<string, unknown>[];
  profile: Record<string, unknown> | null;
  events: Record<string, unknown>[];
  recovery_history: string[];
  reuse_history: string[];
  treatment_history: string[];
  is_demo: boolean;
  created_at: string;
  last_updated: string;
  input_water_litres: number | null;
  recovered_water_litres: number | null;
  treatment_loss_litres: number | null;
  recovery_rate: number | null;
  treatment_partner: string | null;
  verification_partner: string | null;
  net_benefit_aed: number | null;
  company_share_aed: number | null;
  hydrostation_fund_aed: number | null;
  rewater_share_aed: number | null;
  credits_generated: number | null;
  credit_eligible_litres: number | null;
}

export interface BusinessSubscription {
  id: string;
  user_id: string;
  plan: 'free' | 'essential' | 'professional' | 'enterprise';
  status: 'active' | 'expired' | 'cancelled';
  features: string[];
  started_at: string;
  expires_at: string | null;
  trial_ends_at: string | null;
  cancelled_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ReWaterRevenue {
  id: string;
  user_id: string;
  source: 'service_fee' | 'subscription' | 'transaction_fee';
  amount_aed: number;
  description: string;
  passport_id: string | null;
  created_at: string;
}
