import { useState, useEffect, Component, type ReactNode } from 'react';
import { Navigation, type PageId } from '@/components/Navigation';
import { HomePage } from '@/pages/HomePage';
import { CheckPage } from '@/pages/CheckPage';
import { MapPage } from '@/pages/MapPage';
import { WaterJourneyPage } from '@/pages/WaterJourneyPage';
import { ImpactPage } from '@/pages/ImpactPage';
import { FutureLabPage } from '@/pages/FutureLabPage';
import { AquaSensePage } from '@/pages/AquaSensePage';
import { BrandsPage } from '@/pages/BrandsPage';
import { AuthPage } from '@/pages/AuthPage';
import { TutorialPage } from '@/pages/TutorialPage';
import { WaterPassportPage } from '@/pages/WaterPassportPage';
import { AccountPage } from '@/pages/AccountPage';
import { BusinessProfilePage } from '@/pages/BusinessProfilePage';
import { WaterCreditsPage } from '@/pages/WaterCreditsPage';
import { HydroStationsPage } from '@/pages/HydroStationsPage';
import { AuthProvider, useAuth } from '@/lib/auth';
import { WaterPassportProvider } from '@/lib/waterPassport';
import { AuthGuardProvider, useAuthGuard } from '@/lib/authGuard';
import { AuthGuardModal } from '@/components/AuthGuardModal';
import { useDemoSeeder } from '@/lib/demoSeeder';
import SmoothScroll from '@/components/ui/smooth-scroll';

class PageErrorBoundary extends Component<
  { children: ReactNode; page: PageId },
  { hasError: boolean }
> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidUpdate(prevProps: { page: PageId }) {
    if (prevProps.page !== this.props.page) {
      this.setState({ hasError: false });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="max-w-lg mx-auto px-4 py-20 text-center">
          <div className="card p-8">
            <h2 className="font-display font-bold text-xl text-ocean-600 mb-2">Something went wrong</h2>
            <p className="text-sm text-slatey/60 mb-6">This section could not be loaded. Please try again.</p>
            <button onClick={() => this.setState({ hasError: false })} className="btn-primary">
              Try again
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function AppContent() {
  const { user, loading } = useAuth();
  const { authedCallback, dismiss, showGuard, requestedMode } = useAuthGuard();
  const [page, setPage] = useState<PageId>('home');
  const [showTutorial, setShowTutorial] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  useDemoSeeder();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [page]);

  // When the auth guard is dismissed because the user chose to sign in / sign up,
  // open the auth page in the requested mode. We detect this by watching for
  // showGuard becoming false while there's still a pending callback.
  const [wasGuardOpen, setWasGuardOpen] = useState(false);

  useEffect(() => {
    if (showGuard) {
      setWasGuardOpen(true);
    } else if (wasGuardOpen && authedCallback) {
      // Guard was just closed — open auth page
      setShowAuth(true);
      setAuthMode(requestedMode);
      setWasGuardOpen(false);
    }
  }, [showGuard, wasGuardOpen, authedCallback, requestedMode]);

  const handleAuthSuccess = () => {
    setShowAuth(false);
    if (authedCallback) {
      authedCallback();
      dismiss();
    }
  };

  const handleShowAuth = (mode?: 'signin' | 'signup') => {
    setAuthMode(mode ?? 'signin');
    setShowAuth(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-mist">
        <div className="text-slatey/40">Loading...</div>
      </div>
    );
  }

  if (showAuth) {
    return (
      <AuthPage
        initialMode={authMode}
        onSuccess={handleAuthSuccess}
        onHome={() => { setShowAuth(false); setPage('home'); }}
      />
    );
  }

  if (showTutorial) {
    return (
      <div className="min-h-screen bg-mist">
        <TutorialPage
          onNavigate={(p) => {
            setShowTutorial(false);
            setPage(p as PageId);
          }}
          onClose={() => setShowTutorial(false)}
        />
      </div>
    );
  }

  return (
    <SmoothScroll>
      <div className="min-h-screen bg-mist">
        <Navigation
          current={page}
          onNavigate={setPage}
          onShowAuth={handleShowAuth}
          onShowTutorial={() => setShowTutorial(true)}
          isLoggedIn={!!user}
        />
        <main className="animate-fade-in">
          <PageErrorBoundary page={page}>
            {page === 'home' && <HomePage onNavigate={setPage} onShowAuth={handleShowAuth} />}
            {page === 'check' && <CheckPage onNavigate={setPage} />}
            {page === 'passport' && <WaterPassportPage onNavigate={setPage} />}
            {page === 'map' && <MapPage />}
            {page === 'circular' && <WaterJourneyPage onNavigate={setPage} />}
            {page === 'impact' && <ImpactPage onNavigate={(p) => setPage(p as PageId)} />}
            {page === 'water-credits' && <WaterCreditsPage onNavigate={setPage} />}
            {page === 'hydro-stations' && <HydroStationsPage onNavigate={setPage} />}
            {page === 'future' && <FutureLabPage onNavigate={setPage} />}
            {page === 'aquasense' && <AquaSensePage onNavigate={setPage} />}
            {page === 'brands' && <BrandsPage />}
            {page === 'account' && <AccountPage onNavigate={setPage} />}
            {page === 'business' && <BusinessProfilePage onNavigate={setPage} />}
          </PageErrorBoundary>
        </main>

        <footer className="bg-ocean-900 text-white/60 py-8 mt-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
            <p className="text-sm">
              ReWater — Water Intelligence for a Circular Future
            </p>
            <p className="text-xs mt-2 text-white/30">
              ReWater gives water a digital identity. AquaSense is future hardware — sensor readings are simulated in the prototype. All recommendations are based on available measurements and clearly label uncertainty.
            </p>
          </div>
        </footer>

        <AuthGuardModal />
      </div>
    </SmoothScroll>
  );
}

function App() {
  return (
    <AuthProvider>
      <WaterPassportProvider>
        <AuthGuardProvider>
          <AppContent />
        </AuthGuardProvider>
      </WaterPassportProvider>
    </AuthProvider>
  );
}

export default App;
