/*
 * AquaSense Firmware for ESP32
 * ReWater — Water Intelligence for a Circular Future
 *
 * Hardware:
 *   - ESP32 DevKit (ESP32-WROOM-32 or compatible)
 *   - Gravity Analog pH Sensor (SEN-0161)    → GPIO 34
 *   - Gravity Analog TDS Sensor (SEN-0244)   → GPIO 35
 *   - Gravity Analog Turbidity Sensor (SEN-0182) → GPIO 32
 *   - DS18B20 Waterproof Temperature Probe   → GPIO 4 (with 4.7kΩ pull-up)
 *   - 0.96" OLED SSD1306 (I2C)               → SDA=21, SCL=22
 *
 * Libraries (install via Arduino Library Manager):
 *   - Adafruit SSD1306
 *   - Adafruit GFX Library
 *   - OneWire
 *   - DallasTemperature
 *
 * Usage:
 *   1. Update WIFI_SSID, WIFI_PASSWORD, SUPABASE_URL, SUPABASE_ANON_KEY below
 *   2. Set DEVICE_ID and PASSPORT_ID (copy passport ID from the website)
 *   3. Flash to ESP32
 *   4. Open Serial Monitor at 115200 baud for calibration commands
 *
 * Serial commands:
 *   cal:ph:7.0    — calibrate pH to 7.0 (probe in pH 7.0 buffer)
 *   cal:ph:4.0    — calibrate pH to 4.0 (probe in pH 4.0 buffer)
 *   cal:tds:70    — calibrate TDS to 70 ppm (probe in 70 ppm standard)
 *   info          — print current calibration and device info
 *   test          — send a single test reading to Supabase
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <time.h>

// ─── CONFIGURATION — UPDATE THESE ────────────────────────────────
#define WIFI_SSID         "your-wifi-name"
#define WIFI_PASSWORD     "your-wifi-password"

#define SUPABASE_URL      "https://lkkziixgzkufwzdcjyjl.supabase.co"
#define SUPABASE_ANON_KEY "YOUR_ANON_KEY_HERE"

#define DEVICE_ID         "AQUASENSE-01"
#define PASSPORT_ID       "RW-WP-2026-00001"

#define READING_INTERVAL_MS  30000   // 30 seconds between readings
// ─────────────────────────────────────────────────────────────────

// Pin definitions
#define PH_PIN          34
#define TDS_PIN         35
#define TURB_PIN        32
#define TEMP_PIN         4

// OLED
#define OLED_WIDTH      128
#define OLED_HEIGHT      64
#define OLED_ADDR       0x3C
Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);

// DS18B20 temperature
OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);

// Calibration values (adjust via serial commands)
float phOffset = 0.0;
float phSlope = 3.5;       // typical: ~3.5 pH per volt change at 25°C
float tdsOffset = 0.0;
float tdsCalFactor = 1.0;

// Timing
unsigned long lastReading = 0;

// ─── SETUP ───────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== AquaSense Booting ===");

  // Initialize OLED
  Wire.begin(21, 22);
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("OLED not found — continuing without display");
  } else {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("AquaSense Booting...");
    display.display();
  }

  // Initialize temperature sensor
  tempSensor.begin();
  tempSensor.setWaitForConversion(false);

  // Configure analog pins (ESP32 ADC 12-bit, 0-4095, 0-3.3V)
  analogReadResolution(12);

  // Enable NTP for accurate timestamps
  configTime(0, 0, "pool.ntp.org");
  Serial.println("NTP time sync requested");

  // Connect to Wi-Fi
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Connecting WiFi...");
  display.display();

  int wifiDots = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    wifiDots++;
    if (wifiDots > 60) {
      Serial.println("\nWiFi connection failed — will retry");
      display.clearDisplay();
      display.setCursor(0, 0);
      display.println("WiFi FAILED");
      display.println("Will retry...");
      display.display();
      delay(3000);
      WiFi.reconnect();
      wifiDots = 0;
    }
  }

  Serial.println();
  Serial.print("WiFi connected! IP: ");
  Serial.println(WiFi.localIP());

  // Look up passport mapping from edge function
  String lookedUpPassport = fetchPassportMapping();
  if (lookedUpPassport.length() > 0) {
    Serial.print("Device registered to passport: ");
    Serial.println(lookedUpPassport);
  } else {
    Serial.println("Using hardcoded PASSPORT_ID (device not yet registered via edge function)");
    lookedUpPassport = String(PASSPORT_ID);
  }

  displayStartupScreen(lookedUpPassport);
}

// ─── MAIN LOOP ───────────────────────────────────────────────────
void loop() {
  // Check for serial commands
  handleSerial();

  // Take readings on interval
  if (millis() - lastReading >= READING_INTERVAL_MS || lastReading == 0) {
    lastReading = millis();

    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("WiFi disconnected — attempting reconnect");
      WiFi.reconnect();
      delay(2000);
      return;
    }

    takeAndSendReading();
  }
}

// ─── SENSOR READING ──────────────────────────────────────────────
struct SensorData {
  float ph;
  float tds;
  float ec;
  float turbidity;
  float temperature;
};

SensorData readSensors() {
  SensorData data;

  // Temperature (DS18B20)
  tempSensor.requestTemperatures();
  delay(750); // wait for conversion
  data.temperature = tempSensor.getTempCByIndex(0);
  if (data.temperature == DEVICE_DISCONNECTED_C) {
    data.temperature = -127.0;
  }

  // pH (analog)
  int phRaw = analogRead(PH_PIN);
  float phVoltage = phRaw * 3.3 / 4095.0;
  // Standard pH formula: pH = 7 - (voltage - neutralVoltage) * slope
  // neutralVoltage is ~1.75V for pH 7 at 25°C with Gravity sensor
  float neutralVoltage = 1.75;
  float tempComp = data.temperature > -100 ? data.temperature : 25.0;
  data.ph = 7.0 - (phVoltage - neutralVoltage) * phSlope + phOffset;
  // Temperature compensation for pH
  data.ph = data.ph - (tempComp - 25.0) * 0.003;

  // TDS (analog)
  int tdsRaw = analogRead(TDS_PIN);
  float tdsVoltage = tdsRaw * 3.3 / 4095.0;
  // Gravity TDS formula: TDS = voltage * compensationFactor * calibrationFactor
  // compensationFactor adjusts for temperature (1.0 at 25°C)
  float compFactor = 1.0 + 0.02 * (tempComp - 25.0);
  data.tds = (tdsVoltage * 1000.0 / 2.0) * compFactor * tdsCalFactor + tdsOffset;
  if (data.tds < 0) data.tds = 0;

  // EC = TDS * 2 (approximate, since TDS = EC * 0.5 typically)
  data.ec = data.tds * 2.0;

  // Turbidity (analog)
  int turbRaw = analogRead(TURB_PIN);
  float turbVoltage = turbRaw * 3.3 / 4095.0;
  // Gravity turbidity: voltage decreases as turbidity increases
  // NTU = -1120.4 * voltage^2 + 5742.3 * voltage - 4352.9 (approximate)
  data.turbidity = -1120.4 * sq(turbVoltage) + 5742.3 * turbVoltage - 4352.9;
  if (data.turbidity < 0) data.turbidity = 0;
  if (data.turbidity > 3000) data.turbidity = 3000;

  return data;
}

// ─── SEND READING TO SUPABASE ────────────────────────────────────
void takeAndSendReading() {
  SensorData data = readSensors();

  Serial.println("\n--- Sensor Reading ---");
  Serial.print("pH:         "); Serial.println(data.ph, 2);
  Serial.print("TDS:        "); Serial.print(data.tds, 1); Serial.println(" ppm");
  Serial.print("EC:         "); Serial.print(data.ec, 1); Serial.println(" uS/cm");
  Serial.print("Turbidity:  "); Serial.print(data.turbidity, 1); Serial.println(" NTU");
  Serial.print("Temp:       "); Serial.print(data.temperature, 1); Serial.println(" C");

  // Update OLED
  updateDisplay(data);

  // Build JSON payload
  StaticJsonDocument<512> doc;
  doc["device_id"] = DEVICE_ID;
  doc["passport_id"] = PASSPORT_ID;
  doc["ph"] = round2(data.ph);
  doc["tds"] = round2(data.tds);
  doc["ec"] = round2(data.ec);
  doc["turbidity"] = round2(data.turbidity);
  doc["temperature"] = round2(data.temperature);
  doc["source"] = "aquasense-esp32";
  doc["status"] = "connected";
  doc["is_simulated"] = false;

  // Add timestamp in ISO format (only if NTP synced)
  char timeStr[25];
  getISOTime(timeStr);
  if (strlen(timeStr) > 0) {
    doc["timestamp"] = timeStr;
  }

  // Add calibration info
  JsonObject calInfo = doc.createNestedObject("calibration_info");
  calInfo["ph_offset"] = round4(phOffset);
  calInfo["ph_slope"] = round4(phSlope);
  calInfo["tds_offset"] = round4(tdsOffset);
  calInfo["tds_factor"] = round4(tdsCalFactor);
  calInfo["calibrated_at"] = strlen(timeStr) > 0 ? timeStr : "";

  String jsonPayload;
  serializeJson(doc, jsonPayload);

  // Send to Supabase
  String url = String(SUPABASE_URL) + "/rest/v1/sensor_readings";

  HTTPClient http;
  http.begin(url);
  http.addHeader("apikey", SUPABASE_ANON_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_ANON_KEY);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Prefer", "return=minimal");

  int httpCode = http.POST(jsonPayload);

  if (httpCode > 0) {
    if (httpCode == 201 || httpCode == 200) {
      Serial.println("Reading sent to Supabase successfully!");
    } else {
      Serial.print("Supabase returned HTTP ");
      Serial.println(httpCode);
      String response = http.getString();
      Serial.print("Response: ");
      Serial.println(response);
    }
  } else {
    Serial.print("HTTP request failed: ");
    Serial.println(http.errorToString(httpCode));
  }

  http.end();
}

// ─── FETCH PASSPORT MAPPING FROM EDGE FUNCTION ───────────────────
String fetchPassportMapping() {
  String url = String(SUPABASE_URL) + "/functions/v1/aquasense-register?device_id=" + DEVICE_ID;

  HTTPClient http;
  http.begin(url);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_ANON_KEY);

  int httpCode = http.GET();

  String passportId = "";

  if (httpCode > 0) {
    String response = http.getString();
    Serial.print("Edge function response: ");
    Serial.println(response);

    StaticJsonDocument<256> doc;
    DeserializationError error = deserializeJson(doc, response);

    if (!error) {
      const char* pid = doc["passport_id"];
      if (pid && strlen(pid) > 0) {
        passportId = String(pid);
      }
    }
  } else {
    Serial.print("Edge function request failed: ");
    Serial.println(http.errorToString(httpCode));
  }

  http.end();
  return passportId;
}

// ─── OLED DISPLAY ────────────────────────────────────────────────
void displayStartupScreen(String passport) {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(1);
  display.println("AquaSense Ready");
  display.println();
  display.print("Device: ");
  display.println(DEVICE_ID);
  display.print("Passport:");
  display.setCursor(0, 32);
  display.println(passport);
  display.setCursor(0, 48);
  display.println("Reading in 30s...");
  display.display();
}

void updateDisplay(SensorData data) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(0, 0);
  display.println("AquaSense LIVE");

  display.setCursor(0, 12);
  display.print("pH:   ");
  display.println(data.ph, 2);

  display.setCursor(0, 24);
  display.print("TDS:  ");
  display.print(data.tds, 0);
  display.println(" ppm");

  display.setCursor(0, 36);
  display.print("NTU:  ");
  display.println(data.turbidity, 1);

  display.setCursor(0, 48);
  display.print("Temp: ");
  display.print(data.temperature, 1);
  display.print(" C");

  display.display();
}

// ─── SERIAL COMMANDS ─────────────────────────────────────────────
void handleSerial() {
  if (!Serial.available()) return;

  String input = Serial.readStringUntil('\n');
  input.trim();

  if (input.startsWith("cal:ph:")) {
    float val = input.substring(7).toFloat();
    // Read current voltage and adjust offset so reading equals val
    int raw = analogRead(PH_PIN);
    float voltage = raw * 3.3 / 4095.0;
    float neutralVoltage = 1.75;
    float calculated = 7.0 - (voltage - neutralVoltage) * phSlope;
    phOffset = val - calculated;
    Serial.print("pH calibrated to ");
    Serial.print(val, 2);
    Serial.print(" (offset = ");
    Serial.print(phOffset, 4);
    Serial.println(")");
  }
  else if (input.startsWith("cal:tds:")) {
    float val = input.substring(8).toFloat();
    // Read current voltage and adjust factor so reading equals val
    int raw = analogRead(TDS_PIN);
    float voltage = raw * 3.3 / 4095.0;
    float compFactor = 1.0 + 0.02 * (25.0 - 25.0); // assume 25°C during calibration
    float currentTds = (voltage * 1000.0 / 2.0) * compFactor * tdsCalFactor + tdsOffset;
    if (currentTds > 0) {
      tdsCalFactor = (val - tdsOffset) / (currentTds - tdsOffset) * tdsCalFactor;
    }
    Serial.print("TDS calibrated to ");
    Serial.print(val, 1);
    Serial.print(" ppm (factor = ");
    Serial.print(tdsCalFactor, 4);
    Serial.println(")");
  }
  else if (input == "info") {
    Serial.println("\n=== AquaSense Device Info ===");
    Serial.print("Device ID:    "); Serial.println(DEVICE_ID);
    Serial.print("Passport ID:  "); Serial.println(PASSPORT_ID);
    Serial.print("Supabase URL: "); Serial.println(SUPABASE_URL);
    Serial.print("WiFi Status:  ");
    Serial.println(WiFi.status() == WL_CONNECTED ? "Connected" : "Disconnected");
    if (WiFi.status() == WL_CONNECTED) {
      Serial.print("IP Address:   "); Serial.println(WiFi.localIP());
    }
    Serial.print("pH offset:    "); Serial.println(phOffset, 4);
    Serial.print("pH slope:     "); Serial.println(phSlope, 4);
    Serial.print("TDS offset:   "); Serial.println(tdsOffset, 4);
    Serial.print("TDS factor:   "); Serial.println(tdsCalFactor, 4);
    Serial.print("Reading interval: "); Serial.print(READING_INTERVAL_MS / 1000); Serial.println("s");
    Serial.println("==============================\n");
  }
  else if (input == "test") {
    Serial.println("Sending test reading...");
    takeAndSendReading();
  }
  else if (input.length() > 0) {
    Serial.println("Unknown command. Available:");
    Serial.println("  cal:ph:7.0   — calibrate pH to 7.0");
    Serial.println("  cal:ph:4.0   — calibrate pH to 4.0");
    Serial.println("  cal:tds:70   — calibrate TDS to 70 ppm");
    Serial.println("  info         — print device info");
    Serial.println("  test         — send a test reading");
  }
}

// ─── HELPERS ─────────────────────────────────────────────────────
float round2(float val) {
  return round(val * 100.0) / 100.0;
}

float round4(float val) {
  return round(val * 10000.0) / 10000.0;
}

void getISOTime(char* buffer) {
  time_t now = time(nullptr);
  if (now < 100000) {
    // NTP not yet synced — send empty string, Supabase defaults to now()
    buffer[0] = '\0';
    return;
  }
  struct tm* t = gmtime(&now);
  // Format: 2026-10-04T12:00:00Z
  strftime(buffer, 25, "%Y-%m-%dT%H:%M:%SZ", t);
}
